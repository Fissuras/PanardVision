/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
// Panard Scape : Terragen's raw intel 16 bit files loader
//
// Before using this library consult the LICENSE file

#include <math.h>
#include "terraw16.h"

IMPLEMENT_POMIZED(psLoadTerrainRaw16Intel,TERRAIN_LOADERS_DOMAIN);

psLoadTerrainInterface::psTerrainData *psLoadTerrainRaw16Intel::Load(istream &in)
{
	psTerrainData *p;
	UPVD16 *tmp;
	
	unsigned h=GetStreamLength(in)/2;

	_Side=sqrt(h);

	p=new psTerrainData[_Side*_Side];
	tmp=new UPVD16[_Side*_Side];
	in.read((char*)tmp,_Side*_Side*2);

	for(unsigned i=0;i<_Side*_Side;i++)
	{
		p[i].y=tmp[i];
	}

	delete tmp;
	return p;
}

unsigned psLoadTerrainRaw16Intel::GetSideSize()
{
	return _Side;
}

const char *psLoadTerrainRaw16Intel::GetExtension(unsigned i)
{
	switch(i)
	{
	case 0: return "r16";
	case 1: return "b16";
	case 2: return "Terragen Binary Export 16 Bit Intel";
	}
	return NULL;
}

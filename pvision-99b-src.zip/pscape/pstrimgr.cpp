/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include "pstrimgr.h"

#define SETUP_CHILDREN_INDEX(index,a,b)		\
	unsigned a,b; \
	if(index<((1<<_NbrLevels))) \
	{		\
		a=index*2+1; \
		b=a+1; \
} \
	else \
{ \
		a=((1<<_NbrLevels))+(index-((1<<_NbrLevels)))*2+1; \
		b=a+1; \
	}


map<unsigned,psLandscapePart::psTriVert *> psTriTableMgr::_Tables;

psTriTableMgr::~psTriTableMgr()
{
   	std::map<unsigned,psLandscapePart::psTriVert*>::iterator	p1,p2;		
	p1=_Tables.begin();
	p2=_Tables.end();
	
	while(p1!=p2)
	{
		delete[] (*p1).second;
		p1++;
	}
}

void psTriTableMgr::SplitTriIndices(psLandscapePart::psTriVert *_TriTable,unsigned index,unsigned _NbrLevels,unsigned n)
{
	// Stops if last level
	if(n==1) return;
	
	SETUP_CHILDREN_INDEX(index,lci,rci);

	_TriTable[lci].v0=(_TriTable[index].v2+_TriTable[index].v1)/2;
	_TriTable[lci].v1=_TriTable[index].v2;
	_TriTable[lci].v2=_TriTable[index].v0;

	_TriTable[rci].v0=(_TriTable[index].v2+_TriTable[index].v1)/2;
	_TriTable[rci].v1=_TriTable[index].v0;
	_TriTable[rci].v2=_TriTable[index].v1;

	SplitTriIndices(_TriTable,lci,_NbrLevels,n-1);
	SplitTriIndices(_TriTable,rci,_NbrLevels,n-1);
}


psLandscapePart::psTriVert *psTriTableMgr::GetTriTable(unsigned size)
{
    psLandscapePart::psTriVert* _TriTable;
	unsigned _NbrLevels;

	_NbrLevels=(unsigned)(1+(2*log(size-1)/log(2.0)));
	
	// recherche si deja cr��e
   	std::map<unsigned,psLandscapePart::psTriVert*>::iterator	p1,p2;		
	p1=_Tables.find(size);
	p2=_Tables.end();
	
    if(p1!=p2)
    {
        return (*p1).second;
    }

    // No create it
	_TriTable=new psLandscapePart::psTriVert[(1<<_NbrLevels)*2];
	_TriTable[0].v0=0;
	_TriTable[0].v1=size-1;
	_TriTable[0].v2=size*size-size;

	_TriTable[(1<<_NbrLevels)].v0=size*size-1;
	_TriTable[(1<<_NbrLevels)].v1=size*size-size;
	_TriTable[(1<<_NbrLevels)].v2=size-1;

	SplitTriIndices(_TriTable,0,_NbrLevels,_NbrLevels);
	SplitTriIndices(_TriTable,(1<<_NbrLevels),_NbrLevels,_NbrLevels);

	_Tables.insert(std::map<unsigned,psLandscapePart::psTriVert*>::value_type(size,_TriTable));
	
	return _TriTable;
}


static psTriTableMgr StaticInstance;


psTriTableMgr* psGetTriTableMgr()
{
	return &StaticInstance;
}

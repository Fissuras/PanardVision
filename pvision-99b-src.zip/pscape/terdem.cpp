/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "terdem.h"

IMPLEMENT_POMIZED(psLoadTerrainDEM,TERRAIN_LOADERS_DOMAIN);

int psLoadTerrainDEM::nextint(istream &is) 
{
  char ch;
  int i;
  char in[64];

  // xxx while(isspace(in.get(ch)));
  is.eatwhite();
  //i=0;
  // xxx in[0] = ch;
  is.getline(in, 64, ' ');
  /*in>>in[0];
  while(!isspace(ch = fgetcb(fptr))) { i++; in[i] = ch; }
  in[i+1] = '\0';*/
  return(atoi(in));
} 


double psLoadTerrainDEM::nextfloat(istream &is) 
{
  char ch;
  int i;
  char in[64];

  is.eatwhite();
  //while(isspace(ch = fgetcb(fptr))) { }
  //i=0;
  is.getline(in, 64, ' ');
  //in[0] = ch;
  //while(!isspace(ch = fgetcb(fptr))) { 
    /*i++; 
    if(ch == 'D') { ch = 'E'; }
    in[i] = ch; 
  }*/

  i=0;
  while(1)
  {
	  if(in[i]='D') 
	  {
		  in[i]='E';
		  break;
	  }
	  i++;
  }

  //in[i+1] = '\0';
  return atof(in);
}


psLoadTerrainInterface::psTerrainData *psLoadTerrainDEM::Load(istream &in)
{
	psTerrainData *p;
	unsigned d;
	
	in.seekg(144,ios::cur); // skip name

	// Skip some records
	for(unsigned i=0; i < 19+3; i++) nextint(in);
	for(i=0; i < 8+2; i++) nextfloat(in);
	for(i=0; i < 3; i++) nextint(in);

	_Side=nextint(in);

	nextint(in);nextint(in);

	//if(_Side!=nextint(in)) return NULL;

	p=new psTerrainData[_Side*_Side];			// XXX gestion m�moire

	for(unsigned j=0;j<_Side;j++)
	{
		nextint(in);nextint(in);nextint(in);
		nextint(in);nextint(in);nextint(in);

		for(unsigned i=0;i<_Side;i++)
		{
			d=nextint(in);
			p[j*_Side+i].y=d;
		}
		p[j*(_Side+1)+_Side+1-1]=p[j*(_Side+1)+_Side+1-2];
	}
	memcpy(&p[(_Side)*(_Side+1)],&p[(_Side-1)*(_Side+1)],sizeof(psTerrainData)*(_Side+1));

	_Side++;


/*	p=new psTerrainData[257*257];			// XXX gestion m�moire

*/
	return p;
}

unsigned psLoadTerrainDEM::GetSideSize()
{
	return _Side;
}

const char *psLoadTerrainDEM::GetExtension(unsigned i)
{
	switch(i)
	{
	case 0: return "dem";
	case 1: return "USGS DEM";
	}
	return NULL;
}

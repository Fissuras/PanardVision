/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include <fstream.h>
#include "landpart.h"
#include "pstrimgr.h"
#include "vector3.h"

#include <algorithm>
#include <functional>
#include <stack>
using std::sort;
using std::stack;

#ifdef __UNIX__
#define stricmp strcasecmp
#endif

// Decroissant
#define PRI_SPLIT_FORGET	0
#define PRI_SPLIT_MIN		1

// Croissant
#define PRI_MERGE_FORGET	0xFFFFFFFF
#define PRI_MERGE_MAX		0xFFFFFFFE
#define PRI_MERGE_MIN		0x0

// Sorting overloading
bool psLandscapePart::psMergeRecord::operator<(const psMergeRecord& y) const
{ 
    return prio < y.prio;
}

bool psLandscapePart::psSplitRecord::operator<(const psSplitRecord& y) const
{ 
    return prio > y.prio;
}

//////////////////////////////////////////////////////////////////////////////

#define EMPTY 0xFFFFFFFF

#define TRI_IN			0x1
#define TRI_DONTKNOW	0x2
#define TRI_LEAF		0x4
#define TRI_QUEUE2		0x8

#define TRI_CULLMASK	(TRI_IN|TRI_DONTKNOW)

#define SETUP_CHILDREN_INDEX(index,a,b)		\
	unsigned a,b; \
	if(index<((1<<_NbrLevels)-_CompactOffset)) \
	{		\
		a=index*2+1; \
		b=a+1; \
} \
	else \
{ \
		a=((1<<_NbrLevels)-_CompactOffset)+(index-((1<<_NbrLevels)-_CompactOffset))*2+1; \
		b=a+1; \
	}

#define FATHER(index)		(index<((1<<_NbrLevels)-_CompactOffset)?((index-1)>>1):((index-1-((1<<_NbrLevels)-_CompactOffset))>>1)+((1<<_NbrLevels)-_CompactOffset))

#define IS_LEAF(index) (((index>=((1<<(_NbrLevels-1))-1))&&(index<((1<<_NbrLevels)-1)))|| \
					   ((index+_CompactOffset>=(1<<_NbrLevels)+((1<<(_NbrLevels-1))-1))&&(index+_CompactOffset<(1<<_NbrLevels)+((1<<_NbrLevels)-1))))

IMPLEMENT_POMIZED(psLandscapePart,"/domains/PanardScape/");

unsigned psLandscapePart::GetLevel(unsigned index)
{
	unsigned l=0;

	if(index<((1<<_NbrLevels)-_CompactOffset))
	{
		while(index!=0)
		{			
			l++;
			index--;
			index>>=1;
		}
	}
	else
	{
		index=index+_CompactOffset-((1<<_NbrLevels));
		while(index!=0)
		{
			l++;
			index--;
			index>>=1;
		}
	}
	return l;
}

void psLandscapePart::Merge(psMergeIterator p1)
{	
	psMergeDiamond d;

	_TriCount-=2;
	
	d=(*p1).d;

	// merge
	_BinTri[d.d1].BottomNeighbor=d.d2;
	_BinTri[d.d2].BottomNeighbor=d.d1;

	SETUP_CHILDREN_INDEX(d.d1,lci,rci);
	SETUP_CHILDREN_INDEX(d.d2,lci2,rci2);

/*if(!((_BinTri[lci].Flags&TRI_LEAF)&&(_BinTri[lci2].Flags&TRI_LEAF)&&(_BinTri[rci].Flags&TRI_LEAF)&&(_BinTri[rci2].Flags&TRI_LEAF)))
	cout<<"ouie ouie ouie"<<endl; */

	_BinTri[d.d1].LeftNeighbor=_BinTri[lci].BottomNeighbor;
	_BinTri[d.d1].RightNeighbor=_BinTri[rci].BottomNeighbor;

	if(_BinTri[lci].BottomNeighbor!=EMPTY)
	{
		if(_BinTri[_BinTri[lci].BottomNeighbor].LeftNeighbor==lci)
			_BinTri[_BinTri[lci].BottomNeighbor].LeftNeighbor=d.d1;
		else
			if(_BinTri[_BinTri[lci].BottomNeighbor].RightNeighbor==lci)
				_BinTri[_BinTri[lci].BottomNeighbor].RightNeighbor=d.d1;
			else
				_BinTri[_BinTri[lci].BottomNeighbor].BottomNeighbor=d.d1;
	}

	if(_BinTri[rci].BottomNeighbor!=EMPTY)
	{
		if(_BinTri[_BinTri[rci].BottomNeighbor].LeftNeighbor==rci)
			_BinTri[_BinTri[rci].BottomNeighbor].LeftNeighbor=d.d1;
		else
			if(_BinTri[_BinTri[rci].BottomNeighbor].RightNeighbor==rci)
				_BinTri[_BinTri[rci].BottomNeighbor].RightNeighbor=d.d1;
			else
				_BinTri[_BinTri[rci].BottomNeighbor].BottomNeighbor=d.d1;
	}

	_BinTri[d.d2].LeftNeighbor=_BinTri[lci2].BottomNeighbor;
	_BinTri[d.d2].RightNeighbor=_BinTri[rci2].BottomNeighbor;

	if(_BinTri[lci2].BottomNeighbor!=EMPTY)
	{			
		if(_BinTri[_BinTri[lci2].BottomNeighbor].LeftNeighbor==lci2)
			_BinTri[_BinTri[lci2].BottomNeighbor].LeftNeighbor=d.d2;
		else
			if(_BinTri[_BinTri[lci2].BottomNeighbor].RightNeighbor==lci2)
				_BinTri[_BinTri[lci2].BottomNeighbor].RightNeighbor=d.d2;
			else
				_BinTri[_BinTri[lci2].BottomNeighbor].BottomNeighbor=d.d2;
	}
	
	if(_BinTri[rci2].BottomNeighbor!=EMPTY)
	{			
		if(_BinTri[_BinTri[rci2].BottomNeighbor].LeftNeighbor==rci2)
			_BinTri[_BinTri[rci2].BottomNeighbor].LeftNeighbor=d.d2;
		else
			if(_BinTri[_BinTri[rci2].BottomNeighbor].RightNeighbor==rci2)
				_BinTri[_BinTri[rci2].BottomNeighbor].RightNeighbor=d.d2;
			else
				_BinTri[_BinTri[rci2].BottomNeighbor].BottomNeighbor=d.d2;
	}

	_BinTri[d.d1].Flags|=TRI_LEAF;
	_BinTri[d.d2].Flags|=TRI_LEAF;

	_BinTri[lci].Flags=0;
	_BinTri[rci].Flags=0;
	_BinTri[lci2].Flags=0;
	_BinTri[rci2].Flags=0;

	// add merge parents to split list
	_SplitQueue.push_back(psSplitRecord(PRI_SPLIT_MIN,d.d1));
	_SplitQueue.push_back(psSplitRecord(PRI_SPLIT_MIN,d.d2));

	// remove from merge queue
	(*p1).prio=PRI_MERGE_FORGET;

	// Add all newly mergeable diamonds to Qm 
	for(unsigned i=0;i<2;i++)
	{		
		unsigned k;

		if(i==0) k=d.d1; else k=d.d2;

		unsigned brother=(k&1)?k+1:k-1;
		unsigned father=FATHER(k);
		unsigned next=_BinTri[k].LeftNeighbor!=brother?_BinTri[k].LeftNeighbor:_BinTri[k].RightNeighbor;

		if(next==EMPTY) continue;

		if(GetLevel(k)!=GetLevel(next)) continue;
		
		unsigned fatherb=FATHER(next);

		SETUP_CHILDREN_INDEX(father,lci,rci);
		SETUP_CHILDREN_INDEX(fatherb,lci2,rci2);

		if((_BinTri[lci].Flags&TRI_LEAF)&&(_BinTri[lci2].Flags&TRI_LEAF)&&(_BinTri[rci].Flags&TRI_LEAF)&&(_BinTri[rci2].Flags&TRI_LEAF))
		{
			psMergeRecord d;

			d.prio=PRI_MERGE_MAX;
			d.d.d1=father;
			d.d.d2=fatherb;

			_MergeQueue.push_back(d);
		}
	}
}

void psLandscapePart::Split(unsigned index)
{
	psBinTriNode *tri=&_BinTri[index];
	psMergeDiamond d;
	
	SETUP_CHILDREN_INDEX(index,lci,rci);

	if(tri->BottomNeighbor!=EMPTY)
	{
		if(_BinTri[tri->BottomNeighbor].BottomNeighbor!=index)
		{
			Split(tri->BottomNeighbor);
		}
	
		d.d1=0;
		if(_BinTri[tri->BottomNeighbor].BottomNeighbor==index)
		{			
			d.d1=index;
			d.d2=tri->BottomNeighbor;
		}
	
		SETUP_CHILDREN_INDEX(tri->BottomNeighbor,nlci,nrci);
		Split2(index);
		Split2(tri->BottomNeighbor);
		_BinTri[lci].RightNeighbor=nrci;
		_BinTri[rci].LeftNeighbor=nlci;
		_BinTri[nlci].RightNeighbor=rci;
		_BinTri[nrci].LeftNeighbor=lci;
	}
	else
	{
		Split2(index);
		_BinTri[lci].RightNeighbor=EMPTY;
		_BinTri[rci].LeftNeighbor=EMPTY;

		d.d1=0;
		if(_BinTri[tri->BottomNeighbor].BottomNeighbor==index)
		{			
			d.d1=index;
			d.d2=tri->BottomNeighbor;
		}
	}

	if(d.d1!=0) 
	{
		psMergeRecord D;
		D.d=d;
		D.prio=PRI_MERGE_MAX;
		_MergeQueue.push_back(D);
	}
}

void psLandscapePart::Split2(unsigned index)
{
	psBinTriNode *tri;
	psBinTriNode *lc;
	psBinTriNode *rc;

	SETUP_CHILDREN_INDEX(index,lci,rci);

	// Update split queue, only when it's not final level
	if(!IS_LEAF(rci))
	{
		_TempoSplitList.insert(_TempoSplitList.begin(),lci);
		_TempoSplitList.insert(_TempoSplitList.begin(),rci);
	}
	
	tri=&_BinTri[index];
	lc=&_BinTri[lci];
	rc=&_BinTri[rci];

	// Propagation des flag de clips
	_TriCount+=1;
	lc->Flags=tri->Flags;
	rc->Flags=tri->Flags;
	tri->Flags&=~TRI_LEAF;
	lc->TexNbr=tri->TexNbr;
	rc->TexNbr=tri->TexNbr;

	lc->LeftNeighbor=rci;
	rc->RightNeighbor=lci;
	
	lc->BottomNeighbor=tri->LeftNeighbor;
	if(tri->LeftNeighbor!=EMPTY)
	{
		if(_BinTri[tri->LeftNeighbor].BottomNeighbor==index)
		{
			_BinTri[tri->LeftNeighbor].BottomNeighbor=lci;
		}
		else
		{
			if(_BinTri[tri->LeftNeighbor].LeftNeighbor==index)
			{
				_BinTri[tri->LeftNeighbor].LeftNeighbor=lci;
			}
			else
			{
				_BinTri[tri->LeftNeighbor].RightNeighbor=lci;
			}
		}
	}

	rc->BottomNeighbor=tri->RightNeighbor;
	if(tri->RightNeighbor!=EMPTY)
	{
		if(_BinTri[tri->RightNeighbor].BottomNeighbor==index)
		{
			_BinTri[tri->RightNeighbor].BottomNeighbor=rci;
		}
		else
		{
			if(_BinTri[tri->RightNeighbor].RightNeighbor==index)
			{
				_BinTri[tri->RightNeighbor].RightNeighbor=rci;
			}
			else
			{
				_BinTri[tri->RightNeighbor].LeftNeighbor=rci;
			}
		}
	}

	// Mise a jour des queues cardinales
	if(index==0)
	{
		_NSEW[PS_NORTH].push_back(0);
		_NSEW[PS_WEST].push_back(0);
		rc->Flags|=TRI_QUEUE2;
		return;
	}
	else
	if(index==(1<<_NbrLevels))
	{
		_NSEW[PS_SOUTH].push_back((1<<_NbrLevels));
		_NSEW[PS_EAST].push_back((1<<_NbrLevels));
		rc->Flags|=TRI_QUEUE2;
		return;
	}
	else
	{
		lc->Flags|=tri->Flags&TRI_QUEUE2;
		rc->Flags|=tri->Flags&TRI_QUEUE2;
	}

	if((tri->BottomNeighbor!=EMPTY)&&(tri->RightNeighbor!=EMPTY)&&(tri->LeftNeighbor!=EMPTY)) return;

	if(index<(1<<_NbrLevels))
	{
		// Nord/Ouest
		if(tri->Flags&TRI_QUEUE2)
		{
			// Nord
			if(_Links[PS_NORTH]==NULL) return;
		}
		else
		{
			// Ouest
			if(_Links[PS_WEST]==NULL) return;
		}
	}
	else
	{
		// Sud/Est
		if(tri->Flags&TRI_QUEUE2)
		{
			// Sud
			if(_Links[PS_SOUTH]==NULL) return;
		}
		else
		{
			// Est
			if(_Links[PS_EAST]==NULL) return;
		}
	}


	// Backtrace
	stack<unsigned> bt;

	unsigned cind=index;

	if(!(cind<(1<<_NbrLevels))) cind-=(1<<_NbrLevels);

	while(cind>2)
	{
		if(cind&1)
		{
			bt.push(2);
		}
		else
		{
			bt.push(1);
			cind--;
		}
		cind/=2;
	}

	// Forwardtrace
	if(index<(1<<_NbrLevels))
	{
		// Nord/Ouest
		if(tri->Flags&TRI_QUEUE2)
		{
			// Nord
			unsigned ind=2;

			while(!bt.empty())
			{
				ind*=2;
				ind+=bt.top();
				bt.pop();
			}

			_NSEW[PS_NORTH].push_back(ind+(1<<_NbrLevels));
		}
		else
		{
			// Ouest
			unsigned ind=1;

			while(!bt.empty())
			{
				ind*=2;
				ind+=bt.top();
				bt.pop();
			}

			_NSEW[PS_WEST].push_back(ind+(1<<_NbrLevels));
		}
	}
	else
	{
		// Sud/Est
		if(tri->Flags&TRI_QUEUE2)
		{
			// Sud
			unsigned ind=2;

			while(!bt.empty())
			{
				ind*=2;
				ind+=bt.top();
				bt.pop();
			}

			_NSEW[PS_SOUTH].push_back(ind);
		}
		else
		{
			// Est
			unsigned ind=1;

			while(!bt.empty())
			{
				ind*=2;
				ind+=bt.top();
				bt.pop();
			}

			_NSEW[PS_EAST].push_back(ind);
		}
	}
}

void psLandscapePart::InitTextures()
{
	_NbrTextureLevel=0;
	delete[] _Textures;
	_Textures=NULL;
	_Enforced=false;
}

void psLandscapePart::SetTextureSubdivisionLevel(unsigned level)
{
	if(level!=_NbrTextureLevel)
	
	delete[] _Textures;
	_Textures=NULL;
	
	_NbrTextureLevel=level;

	_Textures=new psTextureBlockInfo[(1<<_NbrTextureLevel)*(1<<_NbrTextureLevel)];

	_Enforced=false;
}

void psLandscapePart::SetTexture(unsigned x,unsigned y,unsigned repeatx,unsigned repeaty,PVMaterial *m)
{
	if(x>=(1<<_NbrTextureLevel)) return;
	if(y>=(1<<_NbrTextureLevel)) return;

	_Textures[y*(1<<_NbrTextureLevel)+x].Mat=m;
	_Textures[y*(1<<_NbrTextureLevel)+x].RepeatX=repeatx;
	_Textures[y*(1<<_NbrTextureLevel)+x].RepeatY=repeaty; 
}

psLandscapePart::psLandscapePart()
{
	_ScaleX=_ScaleZ=100000;
	_ScaleY=10;
	_Terrain=NULL;
	_Side=0;
	_BinTri=NULL;
	_TriTable=NULL;
	_NbrLevels=0;
	_Wedgies=NULL;
	_Thresold=100;
	_DistThresold=1000;
	_CompactOffset=0;
	_TriCount=0;
	_Textures=NULL;
	InitTextures();
	_MinHeight=_MaxHeight=0;
	_State=NOT_READY;
	_MaxTriCount=500;
	_TriNormals=NULL;
	_VertNormals=NULL;
	_Flags=0;

	_TempoSplitList.reserve(500);

	for(unsigned i=0;i<4;i++) _Links[i]=NULL;
}

int psLandscapePart::Load()
{
	return 0;
}

void psLandscapePart::Unload()
{
	Init(true);
}

psLandscapePart::~psLandscapePart()
{
	Init();
}

void psLandscapePart::Init(bool keepinfos)
{
	delete[] _Terrain;
	delete[] _BinTri;
	delete[] _Wedgies;
	delete[] _TriNormals;
	delete[] _VertNormals;

	_Terrain=NULL;	
	_BinTri=NULL;
	_TriTable=NULL;
	_NbrLevels=0;
	_Wedgies=NULL;
	_TriNormals=NULL;
	_VertNormals=NULL;
	_SplitQueue.clear();
	_MergeQueue.clear();	
	_CompactOffset=0;
	_TriCount=0;
	InitTextures();
	
	if(!keepinfos)
	{
		_MaxTriCount=500;
		_Thresold=100;
		_DistThresold=1000;
		_MinHeight=_MaxHeight=0;
		_Side=0;
		_Flags=0;

		for(unsigned i=0;i<4;i++) _Links[i]=NULL;
	}
}

void psLandscapePart::InitBinTri()
{
	if((_CompactOffset)||(_BinTri==NULL))
	{
		delete _BinTri;
		_BinTri=new psBinTriNode[(1<<_NbrLevels)*2];
		_CompactOffset=0;
	}

	if(_Wedgies==NULL)
	{
		// Wedgies
		CalcWedgies();
	}

	_TriCount=2;
	
	// Setup first diamond
	_BinTri[0].LeftNeighbor=EMPTY;
	_BinTri[0].RightNeighbor=EMPTY;
	_BinTri[0].BottomNeighbor=(1<<_NbrLevels);
	_BinTri[0].Flags=TRI_LEAF|TRI_IN;
	_BinTri[0].TexNbr=0;

	_BinTri[(1<<_NbrLevels)].LeftNeighbor=EMPTY;
	_BinTri[(1<<_NbrLevels)].RightNeighbor=EMPTY;
	_BinTri[(1<<_NbrLevels)].BottomNeighbor=0;
	_BinTri[(1<<_NbrLevels)].Flags=TRI_LEAF|TRI_IN;
	_BinTri[(1<<_NbrLevels)].TexNbr=0;

	// Init Split queue
	_SplitQueue.clear();
	_SplitQueue.push_back(psSplitRecord(_Wedgies[0].w,0));
	_SplitQueue.push_back(psSplitRecord(_Wedgies[(1<<_NbrLevels)].w,(1<<_NbrLevels)));

	_MergeQueue.clear();

	for(unsigned i=0;i<4;i++) _NSEW[i].clear();	

	_Enforced=false;
}

void psLandscapePart::CalcNormals()
{
	unsigned short *index;
	unsigned i;

	if(_TriNormals==NULL) _TriNormals=new pvVector3D[(1<<_NbrLevels)*2];
	if(_VertNormals==NULL) _VertNormals=new pvVector3D[_Side*_Side];
	
	index=new unsigned short[_Side*_Side];
	memset(index,0,sizeof(unsigned short)*(_Side*_Side));

	for(i=0;i<_Side*_Side;i++) _VertNormals[i].Zero();

	// Face normals
	for(i=0;i<(1<<_NbrLevels)-1;i++)
	{
		pvVector3D a,b,c,d;

		a.FromArray(&_Terrain[_TriTable[i].v0].x);
		b.FromArray(&_Terrain[_TriTable[i].v1].x);
		c.FromArray(&_Terrain[_TriTable[i].v2].x);
		d=a;

		a-=b;
		d-=c;

		_TriNormals[i]=a^d;
		_TriNormals[i].Normalize();
		_VertNormals[_TriTable[i].v0]+=_TriNormals[i];
		_VertNormals[_TriTable[i].v1]+=_TriNormals[i];
		_VertNormals[_TriTable[i].v2]+=_TriNormals[i];
		index[_TriTable[i].v0]++;
		index[_TriTable[i].v1]++;
		index[_TriTable[i].v2]++;
	}

	for(i=(1<<_NbrLevels);i<2*(1<<_NbrLevels)-1;i++)
	{
		pvVector3D a,b,c,d;

		a.FromArray(&_Terrain[_TriTable[i].v0].x);
		b.FromArray(&_Terrain[_TriTable[i].v1].x);
		c.FromArray(&_Terrain[_TriTable[i].v2].x);
		d=a;

		a-=b;
		d-=c;

		_TriNormals[i]=a^d;
		_TriNormals[i].Normalize();
		_VertNormals[_TriTable[i].v0]+=_TriNormals[i];
		_VertNormals[_TriTable[i].v1]+=_TriNormals[i];
		_VertNormals[_TriTable[i].v2]+=_TriNormals[i];
		index[_TriTable[i].v0]++;
		index[_TriTable[i].v1]++;
		index[_TriTable[i].v2]++;
	}

	// VertexNormals
	for(i=0;i<_Side*_Side;i++) _VertNormals[i]/=index[i];

	delete[] index;
}

void psLandscapePart::ProcessTerrain()
{
	unsigned i,j;

	if(_Terrain==NULL) return;

	_NbrLevels=(unsigned)(1+(2*log(_Side-1)/log(2.0)));

	_MinHeight=_MaxHeight=_Terrain[0].y*_ScaleY;
	for(i=0;i<_Side;i++)
	{
		for(j=0;j<_Side;j++)
		{
			_Terrain[i*_Side+j].x=(float)j*_ScaleX;
			_Terrain[i*_Side+j].y*=_ScaleY;
			_Terrain[i*_Side+j].z=(float)i*_ScaleZ;

			if(_Terrain[i*_Side+j].y>_MaxHeight) _MaxHeight=_Terrain[i*_Side+j].y;
			if(_Terrain[i*_Side+j].y<_MinHeight) _MinHeight=_Terrain[i*_Side+j].y;
		}
	}	
	
	// Setup triangles vertices tables
	psTriTableMgr *trimgr=psGetTriTableMgr();

	_TriTable=trimgr->GetTriTable(_Side);

	// BinTri setup
	InitBinTri();

	if(_Flags&PSF_CALCNORMALS) CalcNormals();
}

void psLandscapePart::CalcWedgies(unsigned level)
{
	float zt,part;
	unsigned i;

	for(i=(1<<(level-1))-1;i<(1<<level)-1;i++)
	{
		zt=fabs(_Terrain[_TriTable[i].v1].y+_Terrain[_TriTable[i].v2].y);
		zt/=2;		
		if(level<_NbrLevels)
		{
			SETUP_CHILDREN_INDEX(i,lci,rci);

			part=fabs(_Terrain[(_TriTable[i].v1+_TriTable[i].v2)/2].y-zt);
			_Wedgies[i].w=max(_Wedgies[lci].w,_Wedgies[rci].w)+part;
		}
		else
		{
			_Wedgies[i].w=zt;
		}
	}

	for(i=(1<<_NbrLevels)+(1<<(level-1))-1;i<(1<<_NbrLevels)+(1<<level)-1;i++)
	{
		zt=fabs(_Terrain[_TriTable[i].v1].y+_Terrain[_TriTable[i].v2].y);
		zt/=2;		
		if(level<_NbrLevels)
		{
			SETUP_CHILDREN_INDEX(i,lci,rci);

			part=fabs(_Terrain[(_TriTable[i].v1+_TriTable[i].v2)/2].y-zt);
			_Wedgies[i].w=max(_Wedgies[lci].w,_Wedgies[rci].w)+part;
		}
		else
		{
			_Wedgies[i].w=zt;
		}
	}
}

void psLandscapePart::CalcWedgies()
{
	if(_Wedgies==NULL) _Wedgies=new psWedgie[(1<<_NbrLevels)*2];

	for(int i=_NbrLevels;i>0;i--)
	{
		CalcWedgies(i);
	}
}

void psLandscapePart::EnforceMinimumSplitLevel()
{
	unsigned nbrsplit=2*_NbrTextureLevel,i;

	if(_Enforced) return;
	if(_CompactOffset) return;
	if(_BinTri==NULL) return;
	if(_TriTable==NULL) return;
	if(_Textures==NULL) return;

	_Enforced=true;

	unsigned spx=_Side>>_NbrTextureLevel;

	for(i=0;i<_Side*_Side;i++)
	{	
		// Selection de la texture
		unsigned x,y;
		
		y=i/_Side;
		x=i-y*_Side;
		_Terrain[i].u=(float)x/(float)spx;
		_Terrain[i].v=(float)y/(float)spx;		

		while(_Terrain[i].u>1.0) _Terrain[i].u-=1.0;
		while(_Terrain[i].v>1.0) _Terrain[i].v-=1.0;

		unsigned xm=(x)/(spx);
		unsigned ym=(y)/(spx);

		_Terrain[i].u*=_Textures[ym*(1<<_NbrTextureLevel)+xm].RepeatX;
		_Terrain[i].v*=_Textures[ym*(1<<_NbrTextureLevel)+xm].RepeatY;
	}

	if(nbrsplit==0) return;	

	for(i=0;i<(1<<(nbrsplit-1))+1;i++)
	{
		if(_BinTri[i].Flags&TRI_LEAF) 
		{
			Split(i);
		}
			SETUP_CHILDREN_INDEX(i,lci,rci);
						
			unsigned v0=_TriTable[lci].v0;
			unsigned v1=_TriTable[lci].v1;
			unsigned v2=_TriTable[lci].v2;

			unsigned y0=v0/_Side;
			unsigned x0=v0-y0*_Side;

			unsigned y1=v1/_Side;
			unsigned x1=v1-y1*_Side;

			unsigned y2=v2/_Side;
			unsigned x2=v2-y2*_Side;
		
			unsigned y;
			unsigned x;

			y=min(y0,y1);
			y=min(y,y2);

			x=min(x0,x1);
			x=min(x,x2);

			unsigned spx=_Side>>_NbrTextureLevel;
			unsigned xm=(x)/(spx);
			unsigned ym=(y)/(spx);

			_BinTri[lci].TexNbr=ym*(1<<_NbrTextureLevel)+xm;

			v0=_TriTable[rci].v0;
			v1=_TriTable[rci].v1;
			v2=_TriTable[rci].v2;

			y0=v0/_Side;
			x0=v0-y0*_Side;

			y1=v1/_Side;
			x1=v1-y1*_Side;

			y2=v2/_Side;
			x2=v2-y2*_Side;
	
			y=min(y0,y1);
			y=min(y,y2);

			x=min(x0,x1);
			x=min(x,x2);

			spx=_Side>>_NbrTextureLevel;
			xm=(x)/(spx);
			ym=(y)/(spx);

			_BinTri[rci].TexNbr=ym*(1<<_NbrTextureLevel)+xm;		
	}
	for(i=(1<<_NbrLevels)+0;i<(1<<_NbrLevels)+(1<<(nbrsplit-1))+1;i++)
	{
		if(_BinTri[i].Flags&TRI_LEAF) 
		{
			Split(i);
		}
			SETUP_CHILDREN_INDEX(i,lci,rci);
						
			unsigned v0=_TriTable[lci].v0;
			unsigned v1=_TriTable[lci].v1;
			unsigned v2=_TriTable[lci].v2;

			unsigned y0=v0/_Side;
			unsigned x0=v0-y0*_Side;

			unsigned y1=v1/_Side;
			unsigned x1=v1-y1*_Side;

			unsigned y2=v2/_Side;
			unsigned x2=v2-y2*_Side;
		
			unsigned y;
			unsigned x;

			y=min(y0,y1);
			y=min(y,y2);

			x=min(x0,x1);
			x=min(x,x2);

			unsigned spx=_Side>>_NbrTextureLevel;
			unsigned xm=(x)/(spx);
			unsigned ym=(y)/(spx);

			_BinTri[lci].TexNbr=ym*(1<<_NbrTextureLevel)+xm;

			v0=_TriTable[rci].v0;
			v1=_TriTable[rci].v1;
			v2=_TriTable[rci].v2;

			y0=v0/_Side;
			x0=v0-y0*_Side;

			y1=v1/_Side;
			x1=v1-y1*_Side;

			y2=v2/_Side;
			x2=v2-y2*_Side;
	
			y=min(y0,y1);
			y=min(y,y2);

			x=min(x0,x1);
			x=min(x,x2);

			spx=_Side>>_NbrTextureLevel;
			xm=(x)/(spx);
			ym=(y)/(spx);

			_BinTri[rci].TexNbr=ym*(1<<_NbrTextureLevel)+xm;		
	}

	_MergeQueue.clear();
	CleanSplitQueue();
}

float psLandscapePart::CalcPriority(unsigned v)
{
	PVCam *c=pvGetCamera();
	float d,dist;

	if(c!=NULL)
	{
		pvVector3D v1,v2a,v2b,v2c,v11,v111;
		unsigned hyp=(_TriTable[v].v2+_TriTable[v].v1)/2;

		v1.FromArray(&c->pos.xf);
		v2a.FromArray(&_Terrain[hyp].x);		
		v2a+=*_Vis;
		v1-=v2a;


		dist=v1.GetNorm();
	}
	else d=1;

	d=_Wedgies[v].w*_DistThresold/dist;

	return d;
}

void psLandscapePart::UpdateQueues()
{
	psSplitIterator p1,p2;
	psMergeIterator s1,s2;
	unsigned v;	

	p1=_SplitQueue.begin();
	p2=_SplitQueue.end();
	while(p1!=p2)
	{
		// Supprime de la split list les tris non visibles
		v=(*p1).index;
		if((*p1).prio!=PRI_SPLIT_FORGET)
		{
			if(_BinTri[v].Flags&TRI_CULLMASK)
			{
				float prio=CalcPriority(v);
				(*p1).prio=prio;			
			}
			else
			{
				(*p1).prio=PRI_SPLIT_MIN;
			}
		}

		p1++;
	}
	
	s1=_MergeQueue.begin();
	s2=_MergeQueue.end();
	while(s1!=s2)
	{
		if((*s1).prio!=PRI_MERGE_FORGET)
		{
			psMergeDiamond d=(*s1).d;
			bool novis=((_BinTri[d.d1].Flags&TRI_CULLMASK)==0)&&((_BinTri[d.d2].Flags&TRI_CULLMASK)==0);

			if(novis)
			{
				(*s1).prio=PRI_MERGE_MIN;
			}
			else 
			{
				(*s1).prio=max(CalcPriority(d.d1),CalcPriority(d.d2));
			}
		}
		s1++;
	}
}

void psLandscapePart::CleanSplitQueue()
{
	// Clean Split list
	psSplitIterator p1,p2;

	p1=_SplitQueue.begin();
	p2=_SplitQueue.end();
	while(p1!=p2)
	{
		if((_BinTri[(*p1).index].Flags&TRI_LEAF)==0)
		{
			(*p1).prio=PRI_SPLIT_FORGET;		
		}
		p1++;
	}

	std::vector<unsigned>::iterator	l1,l2;		
	l1=_TempoSplitList.begin();
	l2=_TempoSplitList.end();
	while(l1!=l2)
	{		
		_SplitQueue.push_back(psSplitRecord(PRI_SPLIT_MIN,(*l1)));
		l1++;
	}	
	_TempoSplitList.clear();
}

void psLandscapePart::CleanMergeQueue()
{
	psMergeIterator s1,s2;
	s1=_MergeQueue.begin();
	s2=_MergeQueue.end();
	while(s1!=s2)
	{
		psMergeDiamond d;

		d=(*s1).d;

		// Check if merge still valid
		SETUP_CHILDREN_INDEX(d.d1,lci,rci);
		SETUP_CHILDREN_INDEX(d.d2,lci2,rci2);
		if(((_BinTri[lci].Flags&TRI_LEAF)==0) ||((_BinTri[lci2].Flags&TRI_LEAF)==0)||((_BinTri[rci].Flags&TRI_LEAF)==0)||((_BinTri[rci2].Flags&TRI_LEAF)==0))
		{
			(*s1).prio=PRI_MERGE_FORGET;		
		}
		s1++;
	}
}

void psLandscapePart::Update(pvVector3D *org)
{
	psSplitIterator p1,p2;
	psMergeIterator s1,s2;	
	unsigned MinTriCount=(unsigned)(_MaxTriCount*0.9);

	if(_CompactOffset) return;
	if(_State!=READY) return;

	if(org!=NULL) _Vis=org;
	
	UpdateFrustumFlags();
	UpdateQueues();

	// Clean lists
	sort(_SplitQueue.begin(),_SplitQueue.end());
	p1=_SplitQueue.begin();
	p2=_SplitQueue.end();
	while(p1!=p2)
	{
		p2--;
		if((*p2).prio!=PRI_SPLIT_FORGET)
		{
			p2++;
			_SplitQueue.erase(p2,_SplitQueue.end());
			break;
		}
	}

	// Now proceed with merge
	sort(_MergeQueue.begin(),_MergeQueue.end());
	s1=_MergeQueue.begin();
	s2=_MergeQueue.end();		
	while(s1!=s2)
	{
		s2--;
		if((*s2).prio!=PRI_MERGE_FORGET)
		{
			s2++;
			_MergeQueue.erase(s2,_MergeQueue.end());
			break;
		}
	}

	// Lets split visible tris that require it
	p1=_SplitQueue.begin();
	p2=_SplitQueue.end();		
	while((p1!=p2)&&(_TriCount<MinTriCount))
	{
		if ((*p1).prio<=PRI_SPLIT_MIN) break;		

		if ((*p1).prio>_Thresold)
		{
			if(_BinTri[(*p1).index].Flags&TRI_LEAF) Split((*p1).index);  // Test vraiment nescessaire 
		}
		else break;
		p1++;
	}
	CleanMergeQueue();

	// Now proceed with merge	
	unsigned s=0,e=0;
	e=_MergeQueue.size();
	while(s!=e)
	{	
		if(_MergeQueue[s].prio<_Thresold)
		{
			Merge(&_MergeQueue[s]);
		}
		else break;
		
		s++;
	}

	// Now keep in synch with other patches
	static unsigned convert[4]={3,2,1,0};
	for(unsigned i=0;i<4;i++)
	{
		if(_Links[i]!=NULL)
		{
			psLandscapePart *target=_Links[i];

			// North, compare queue mine queue 0 to target's queue 3
			psNSEWIterator ts,te;			

			ts=target->_NSEW[convert[i]].begin();
			te=target->_NSEW[convert[i]].end();
			
			for(psNSEWIterator f=ts;f!=te;f++)
			{
				unsigned b=*f;

				if(_BinTri[b].Flags&TRI_LEAF)
				{		
						Split(b);
				}
			}
		}
	}
	CleanSplitQueue();
}

void __fastcall psLandscapePart::UpdateFrustumFlags(unsigned index,unsigned flags)
{
	if((_BinTri[index].Flags&TRI_CULLMASK)==flags) return;

	SETUP_CHILDREN_INDEX(index,lci,rci);
	
	_BinTri[index].Flags&=~TRI_CULLMASK;
	_BinTri[index].Flags|=flags;
	
	if((!IS_LEAF(index))&&(!(_BinTri[index].Flags&TRI_LEAF)))
	{
		UpdateFrustumFlags(lci,flags);
		UpdateFrustumFlags(rci,flags);
	}
}

void psLandscapePart::UpdateFrustumFlags(unsigned index)
{
	unsigned f1,f2,f3,f4,f5,f6,or,and;
	psLoadTerrainInterface::psTerrainData *p0,*p1,*p2;
	PVPoint p;
	float w;

	if(!(index<((1<<_NbrLevels)-_CompactOffset)))
	{
		index+=_CompactOffset;
	}

	p0=&_Terrain[_TriTable[index].v0];
	p1=&_Terrain[_TriTable[index].v1];
	p2=&_Terrain[_TriTable[index].v2];
	w=_Wedgies[index].w;

	p.xf=p0->x;
	p.yf=p0->y-w;
	p.zf=p0->z;
	f1=PV_GetFrustumFlags(&p);

	p.xf=p1->x;
	p.yf=p1->y-w;
	p.zf=p1->z;
	f2=PV_GetFrustumFlags(&p);

	p.xf=p2->x;
	p.yf=p2->y-w;
	p.zf=p2->z;
	f3=PV_GetFrustumFlags(&p);

	p.xf=p0->x;
	p.yf=p0->y+w;
	p.zf=p0->z;
	f4=PV_GetFrustumFlags(&p);

	p.xf=p1->x;
	p.yf=p1->y+w;
	p.zf=p1->z;
	f5=PV_GetFrustumFlags(&p);

	p.xf=p2->x;
	p.yf=p2->y+w;
	p.zf=p2->z;
	f6=PV_GetFrustumFlags(&p);

	if(!(index<((1<<_NbrLevels)-_CompactOffset)))
	{
		index-=_CompactOffset;
	}

	and=f1&f2&f3&f4&f5&f6;
	if(and)
	{
		// Totalement dehors
		if(!((_BinTri[index].Flags&TRI_CULLMASK)==0))
		{
			UpdateFrustumFlags(index,0);
		}
		return;
	}
	
	or=f1|f2|f3|f4|f5|f6;
	if(!or)
	{
		// totalement dedans
		if(!(_BinTri[index].Flags&TRI_IN))
		{
			// Pas comme avant, on rcurse
			UpdateFrustumFlags(index,TRI_IN);
		}
		return;
	}

	SETUP_CHILDREN_INDEX(index,lci,rci);

	_BinTri[index].Flags&=~TRI_CULLMASK;
	_BinTri[index].Flags|=TRI_DONTKNOW;

	if((!IS_LEAF(index))&&(!(_BinTri[index].Flags&TRI_LEAF)))	
	{
		UpdateFrustumFlags(lci);
		UpdateFrustumFlags(rci);
	}
}

void psLandscapePart::UpdateFrustumFlags()
{
	// hack hack hack 
	// Use PV for frustum classification	
	pvBegin(PV_TRIANGLES,(unsigned char*)-1);
	pvVertex(0,0,0);
	pvVertex(0,0,0);
	pvVertex(0,0,0);
	pvEnd();

	UpdateFrustumFlags(0);		
	UpdateFrustumFlags((1<<_NbrLevels)-_CompactOffset);
}

void psLandscapePart::Compact()
{
	unsigned max1,max2,size;
	psBinTriNode *t;

	if(_CompactOffset) return;

	InitBinTri();
	Update();
	
	GetTriCount();
	max1=_MaxIndex1;
	max2=_MaxIndex2;

	size=max1+max2-(1<<_NbrLevels)+2;

	t=new psBinTriNode[size];

	_CompactOffset=(1<<_NbrLevels)-max1-1;

	memcpy(t,_BinTri,sizeof(psBinTriNode)*(max1+1));
	memcpy(&t[max1+1],&_BinTri[(1<<_NbrLevels)],sizeof(psBinTriNode)*(max2-(1<<_NbrLevels)+1));

	for(unsigned i=0;i<size;i++) 
	{
		if(t[i].BottomNeighbor!=EMPTY) 
			if(t[i].BottomNeighbor>=(1<<_NbrLevels)) 
				t[i].BottomNeighbor-=_CompactOffset;
		if(t[i].LeftNeighbor!=EMPTY) 
			if(t[i].LeftNeighbor>=(1<<_NbrLevels)) 
				t[i].LeftNeighbor-=_CompactOffset;
		if(t[i].RightNeighbor!=EMPTY) 
			if(t[i].RightNeighbor>=(1<<_NbrLevels)) 
				t[i].RightNeighbor-=_CompactOffset;
	}

	delete[] _BinTri;
	_BinTri=t;
}

void psLandscapePart::CompactHardCore()
{
	Compact();
	if(_Wedgies)
	{
		delete[] _Wedgies;
		_Wedgies=NULL;
		_SplitQueue.clear();
	}
}

void psLandscapePart::CountTris(unsigned index,unsigned &r,unsigned &max)
{
	SETUP_CHILDREN_INDEX(index,lci,rci);

	if(_BinTri[index].Flags&TRI_LEAF)
	{
		if(index>max) max=index;
			
		r++;
		return;
	}

	CountTris(lci,r,max);
	CountTris(rci,r,max);
}

float psLandscapePart::GetHeight(float x,float z)
{
	if(_State!=READY) return 0;
	
	x/=_ScaleX;
	z/=_ScaleZ;

	if(x>=_Side) return 0;
	if(z>=_Side) return 0;

	unsigned ux,uz,ux1,uz1;
	float by,fx,fz;

	ux=(unsigned)x;
	uz=(unsigned)z;
	ux1=(unsigned)x+1;
	uz1=(unsigned)z+1;

	
	float y11=_Terrain[uz*_Side+ux].y;
	float y12=_Terrain[uz*_Side+ux1].y;
	float y21=_Terrain[uz1*_Side+ux].y;
	float y22=_Terrain[uz1*_Side+ux1].y;

	fx=x-ux;
	fz=z-uz;
	
	by=(1.0-fx)*(1.0-fz)*y11;
	by+=fx*(1.0-fz)*y22;
	by+=fz*(1.0-fx)*y21;
	by+=fx*fz*y12;
	
	return by;
}

unsigned psLandscapePart::LoadFromStream(istream &in,const char *type)
{
	pomNameServer *ns;
	pomClassInfo ci;
	
	pomGetNameServer(&ns);

	if(_State==READY) Init();
	
	// Loop terrain loader domain for registered classes
	unsigned ret=POMERR_COOL;
	for(unsigned i=0;ret==POMERR_COOL;i++)
	{
		ret=ns->IterateClassesDirectory(i,ci);
		if(ret==POMERR_COOL)
		{
			if(strcmp(ci.DomainName,TERRAIN_LOADERS_DOMAIN)==0)
			{
				// Loop registered extension for this loader
				psLoadTerrainInterface *loader=(psLoadTerrainInterface *)pomCreateObjectFromClass(ci.ClassName);

				if(loader!=NULL)
				{
					const char *ext;
					unsigned k=0;
					
					while((ext=loader->GetExtension(k))!=NULL)
					{						
						if(stricmp(ext,type)==0)
						{
							_Terrain=loader->Load(in);
							if(_Terrain!=NULL)
							{
								_Side=loader->GetSideSize();									
								if(_Side==0)
								{
									delete loader;
									return 1;
								}

								ProcessTerrain();
								delete loader;	
								return 0;
							}															
						}
						k++;
					}
				}
				delete loader;
			}
		}
	}
	
	return 1;								
}

unsigned psLandscapePart::LoadFromFile(const char *name)
{
	char *t;

	if(name==NULL) return 0;

	t=strrchr(name,'.');
	if(t==NULL) return 0;
	t++;
	if(*t=='\0') return 0;

	pomNameServer *ns;
	pomClassInfo ci;
	
	pomGetNameServer(&ns);

	if(_State==READY) Init();
	
	// Loop terrain loader domain for registered classes
	unsigned ret=POMERR_COOL;
	for(unsigned i=0;ret==POMERR_COOL;i++)
	{
		ret=ns->IterateClassesDirectory(i,ci);
		if(ret==POMERR_COOL)
		{
			if(strcmp(ci.DomainName,TERRAIN_LOADERS_DOMAIN)==0)
			{
				// Loop registered extension for this loader
				psLoadTerrainInterface *loader=(psLoadTerrainInterface *)pomCreateObjectFromClass(ci.ClassName);

				if(loader!=NULL)
				{
					const char *ext;
					unsigned k=0;
					
					while((ext=loader->GetExtension(k))!=NULL)
					{						
						if(stricmp(ext,t)==0)
						{
							// openfile
							ifstream ifs(name,ios::in|ios::binary|ios::nocreate);

							if(ifs.is_open())
							{								
								_Terrain=loader->Load(ifs);
								if(_Terrain!=NULL)
								{
									_Side=loader->GetSideSize();
									if(_Side==0)
									{
										delete loader;
										return 1;
									}
									ProcessTerrain();
									delete loader;	
									return 0;
								}								
							}
						}
						k++;
					}
				}
				delete loader;
			}
		}
	}
	
	return 1;								
}

unsigned psLandscapePart::WriteSubBlock(ostream &out,unsigned startx,unsigned sizex,unsigned starty,unsigned sizey)
{
	UPVD16 d;

	for(unsigned i=starty;i<starty+sizey;i++)
	{
		for(unsigned j=startx;j<startx+sizex;j++)
		{
			d=(unsigned short)(_Terrain[i*_Side+j].y/_ScaleY);			
			out.write((char*)&d,2);
		}
	}
	return 0;
}

void psLandscapePart::UpdateHeight(unsigned x,unsigned y,float h)
{
	_Terrain[y*_Side+x].y=h;
}

void psLandscapePart::UpdateHeight(float x,float z,float h)
{
	x/=_ScaleX;
	z/=_ScaleZ;

	if(x>=_Side) return;
	if(z>=_Side) return;

	unsigned ux=(unsigned)x;
	unsigned uz=(unsigned)z;

	_Terrain[uz*_Side+ux].y=h;
}

//////////////////////////////////////////////////////////////////////////////

IMPLEMENT_POMIZED(psLandscapePartPV,"/domains/PanardScape/");

void __fastcall psLandscapePartPV::RenderRecursive(unsigned index,unsigned level)
{
	static unsigned spx;
	
	if(level==2*_NbrTextureLevel)
	{
		if(!(index<((1<<_NbrLevels)-_CompactOffset)))
		{
			pvSetMaterial(_Textures[_BinTri[index-_CompactOffset].TexNbr].Mat);
		}
		else
		{
			pvSetMaterial(_Textures[_BinTri[index].TexNbr].Mat);
		}		
	}

	if((_BinTri[index].Flags&TRI_CULLMASK)==0) return;
	if(_BinTri[index].Flags&TRI_LEAF)
	{
		
		if(!(index<((1<<_NbrLevels)-_CompactOffset)))
			index+=_CompactOffset;

		if(_BinTri[index].Flags&TRI_IN) pvSetWrapFlag(POLYGON_NOCLIP);
		pvVertexIndexedf(_TriTable[index].v2);
		pvVertexIndexedf(_TriTable[index].v1);
		pvVertexIndexedf(_TriTable[index].v0);
		_LastNbrOutputedTris++;
	}
	else
	{
		SETUP_CHILDREN_INDEX(index,lci,rci);
		RenderRecursive(lci,level+1);
		RenderRecursive(rci,level+1);
	}
}

void psLandscapePartPV::SetupRender()
{
	pvEnableIndex(PPI_MAPCOORD);
	pvSetVertexIndex(&_Terrain[0].x,sizeof(psLoadTerrainInterface::psTerrainData));
	pvSetMapIndex(&_Terrain[0].u,sizeof(psLoadTerrainInterface::psTerrainData));
}

void psLandscapePartPV::Render()
{	
	if(_State!=READY) return;

	EnforceMinimumSplitLevel();

	SetupRender();

	_LastNbrOutputedTris=0;
	pvBegin(PV_TRIANGLES,(unsigned char*)-1);
	RenderRecursive(0,0);
	RenderRecursive((1<<_NbrLevels)-_CompactOffset,0);
	pvEnd();
}

psLandscapePartPV::psLandscapePartPV()
{
	_DummyMat=PV_CreateMaterial("$$DUMMY PVLANDSCAPE MAT",FLAT,TEXTURE_NONE,0);
	pvSetMaterial(_DummyMat);
}

psLandscapePartPV::~psLandscapePartPV()
{
	PV_KillMaterial(_DummyMat);
}




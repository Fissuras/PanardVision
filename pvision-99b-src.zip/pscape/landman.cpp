/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "landman.h"
#include "pvsys.h"

IMPLEMENT_POMIZED(psLandscapePartManager,"/domains/PanardScape/");

int psLandscapePartManager::AddPart(psLandscapePart *p)
{
	pslpmPartInfos *inf=new pslpmPartInfos;

	if(inf==NULL) return -1;

	inf->Part=p;
	inf->Pos.Set(0,0,0);

	p->SetThresold(_Thresold);
	_Parts.push_back(*inf);

	delete inf;

	return _Parts.size();
}

void psLandscapePartManager::SetPartPos(int handle,pvVector3D &p)
{
	if(handle==-1) return;
	if(handle==0) return;

	_Parts[handle-1].Pos=p;
}

psLandscapePart *psLandscapePartManager::GetPart(int handle)
{
	if(handle==-1) return NULL;
	if(handle==0) return NULL;
	
	return _Parts[handle-1].Part;
}

bool psLandscapePartManager::IsCloseToFrustum(int handle)
{
	// Calcul de la bbox
	pvVector3D min,max;
	unsigned side;
	float sx,sy,sz;
	PVCam *cam;

	handle--;

	side=_Parts[handle].Part->GetSide();
	sx=_Parts[handle].Part->GetScaleX();
	sy=_Parts[handle].Part->GetScaleY();
	sz=_Parts[handle].Part->GetScaleZ();

	min.Set(0,_Parts[handle].Part->GetMinHeight(),0);
	max.Set((side-1)*sx,_Parts[handle].Part->GetMaxHeight(),(side-1)*sz);

	// Test de la BBox avec le frustum
	PVPoint p;
	unsigned andc=0xFFFFFFFF;

	p.xf=min.x;
	p.yf=min.y;
	p.zf=min.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	p.xf=max.x;
	p.yf=min.y;
	p.zf=min.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	p.xf=max.x;
	p.yf=min.y;
	p.zf=max.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	p.xf=min.x;
	p.yf=min.y;
	p.zf=max.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	p.xf=min.x;
	p.yf=max.y;
	p.zf=min.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	p.xf=max.x;
	p.yf=max.y;
	p.zf=min.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	p.xf=max.x;
	p.yf=max.y;
	p.zf=max.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	p.xf=min.x;
	p.yf=max.y;
	p.zf=max.z;
	andc&=PV_GetFrustumFlags(&p);
	if(!andc) return true;

	min+=_Parts[handle].Pos;
	max+=_Parts[handle].Pos;

	// Caclul distance camera
	pvVector3D c,d;
	cam=pvGetCamera();

	c.FromArray(&cam->pos.xf);
	d.FromArray(&cam->pos.xf);
	c-=min;
	d-=max;
	if(c.GetNorm()<_LoadingRadius) return true;
	if(d.GetNorm()<_LoadingRadius) return true;

	return false;
}

void psLandscapePartManager::Render(unsigned char *target)
{	
	for(unsigned i=0;i<_Parts.size();i++)
	{
		PVPoint p;

		p.xf=_Parts[i].Pos.x;
		p.yf=_Parts[i].Pos.y;
		p.zf=_Parts[i].Pos.z;
		pvSetModelPos(p);

		// hack hack hack 
		// Use PV for frustum classification	
		pvBegin(PV_TRIANGLES,target);
		pvVertex(0,0,0);
		pvVertex(0,0,0);
		pvVertex(0,0,0);
		pvEnd();

		if(!IsCloseToFrustum(i+1)) 
		{
			if(_Parts[i].Part->IsReady())  // Unload when it's fully loaded
			{
				_Parts[i].Part->SetState(psLandscapePart::TRANSIENT_UNLOADING);
				pvSystem::StartThread(_Parts[i].Part);
			}
			continue;
		}

		if(_Parts[i].Part->GetState()==psLandscapePart::NOT_READY) // Not loaded, need load
		{
			_Parts[i].Part->SetState(psLandscapePart::TRANSIENT_LOADING);
			pvSystem::StartThread(_Parts[i].Part);
			continue;
		}
		
		if(_Parts[i].Part->IsReady())
		{
			_Parts[i].Part->Update(&_Parts[i].Pos);
			_Parts[i].Part->Render();
		}
	}
}

void psLandscapePartManager::UpdateHeight(float x,float z,float h)
{
	for(unsigned i=0;i<_Parts.size();i++) 
	{
		if((x>=_Parts[i].Pos.x)&&(x<_Parts[i].Pos.x+(_Parts[i].Part->GetSide()-1)*_Parts[i].Part->GetScaleX()))
		{
			if((z>=_Parts[i].Pos.z)&&(z<_Parts[i].Pos.z+(_Parts[i].Part->GetSide()-1)*_Parts[i].Part->GetScaleZ()))
			{
				_Parts[i].Part->UpdateHeight(x-_Parts[i].Pos.x,z-_Parts[i].Pos.z,h);;
			}
		}
	}
}

psLandscapePart *psLandscapePartManager::GetPartAt(float x,float z)
{
	for(unsigned i=0;i<_Parts.size();i++) 
	{
		if((x>=_Parts[i].Pos.x)&&(x<_Parts[i].Pos.x+(_Parts[i].Part->GetSide()-1)*_Parts[i].Part->GetScaleX()))
		{
			if((z>=_Parts[i].Pos.z)&&(z<_Parts[i].Pos.z+(_Parts[i].Part->GetSide()-1)*_Parts[i].Part->GetScaleZ()))
			{
				return _Parts[i].Part;
			}
		}
	}
	return NULL;
}

bool psLandscapePartManager::GetHeight(float x,float z,float &height)
{
	for(unsigned i=0;i<_Parts.size();i++) 
	{
		if((x>=_Parts[i].Pos.x)&&(x<_Parts[i].Pos.x+(_Parts[i].Part->GetSide()-1)*_Parts[i].Part->GetScaleX()))
		{
			if((z>=_Parts[i].Pos.z)&&(z<_Parts[i].Pos.z+(_Parts[i].Part->GetSide()-1)*_Parts[i].Part->GetScaleZ()))
			{
				if(_Parts[i].Part->IsReady())
				{
					height=_Parts[i].Part->GetHeight(x-_Parts[i].Pos.x,z-_Parts[i].Pos.z)+_Parts[i].Pos.y;
					return true;
				}
				else
					return false;
			}
		}
	} 
	
	return false;
}

void psLandscapePartManager::SetThresold(const float t)
{
	if(t<=0) return;
	for(unsigned i=0;i<_Parts.size();i++) _Parts[i].Part->SetThresold(t);
	_Thresold=t;
}

void psLandscapePartManager::SetDistThresold(const float t)
{
	if(t<=0) return;
	for(unsigned i=0;i<_Parts.size();i++) _Parts[i].Part->SetDistThresold(t);
	_DistThresold=t;
}

void psLandscapePartManager::SetMaxTriCount(const unsigned t)
{
	if(t<=0) return;
	for(unsigned i=0;i<_Parts.size();i++) _Parts[i].Part->SetMaxTriCount(t);
	_MaxTriCount=t;
}

unsigned psLandscapePartManager::GetTriCount()
{
	unsigned t=0;
	for(unsigned i=0;i<_Parts.size();i++) t+=_Parts[i].Part->GetTriCount();
	return t;
}

psLandscapePartManager::psLandscapePartManager()
{
	_Thresold=100000;
	_DistThresold=1000;
	_MaxTriCount=500;
	_LoadingRadius=100000;
}

psLandscapePartManager::~psLandscapePartManager()
{
	unsigned i;
	for(i=0;i<_Parts.size();i++) _Parts[i].Part->Unload();
	for(i=0;i<_Parts.size();i++) delete _Parts[i].Part;
}


/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
// Panard Scape : Metacreation's bryce HF files loader
//
// Before using this library consult the LICENSE file

#include "terhf.h"

IMPLEMENT_POMIZED(psLoadTerrainHFBryce,TERRAIN_LOADERS_DOMAIN);

psLoadTerrainInterface::psTerrainData *psLoadTerrainHFBryce::Load(istream &in)
{
	psTerrainData *p;
	UPVD16 *tmp;
	char s[4096];
	unsigned side;

	// Check file
	in.read(s,0x1A);

	if(strcmp(s,"binary_heightfield:shorts")!=0) return NULL;

	in.seekg(0x1e7,ios::cur);
	in.read(s,10);
	
	side=atoi(s);
	side++;
	_Side=side;
	in.seekg(47,ios::cur);

	p=new psTerrainData[side*side];
	tmp=new UPVD16[(_Side-1)*(_Side-1)];
	in.read((char*)tmp,(_Side-1)*(_Side-1)*2);

	for(unsigned j=0;j<_Side-1;j++)
	{
		for(unsigned i=0;i<_Side-1;i++)
		{
			p[j*_Side+i].y=-tmp[j*(_Side-1)+i];
		}
		p[j*_Side+_Side-1]=p[j*_Side+_Side-2];
	}
	memcpy(&p[(_Side-1)*_Side],&p[(_Side-2)*_Side],sizeof(psTerrainData)*_Side);

	delete[] tmp;
	return p;
}

unsigned psLoadTerrainHFBryce::GetSideSize()
{
	return _Side;
}

const char *psLoadTerrainHFBryce::GetExtension(unsigned i)
{
	switch(i)
	{
	case 0: return "hf";
	case 1: return "Bryce Height Field";
	}
	return NULL;
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Generic Directx8 driver for the Panard Vision 3D Engine
// (C) 2000, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//
//---------------------------------------------------------------------------

#ifdef _MSC_VER
#pragma warning(disable:4786)
#endif

#define MAX_DYN_FACES	16384

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ddraw.h>
#include "d3d8fill.h"
#include "pvd3d8.h"

#include <map>
#include <stack>
#include <set>
using std::map;
using std::stack;
using std::set;

/////////////////////////////////////////////////////////////////////////////////

static LPDIRECT3D8				lpD3D		= NULL;
LPDIRECT3DDEVICE8				lpD3DDEV	= NULL;
static LPDIRECT3DSURFACE8		lpDDS		= NULL;
static D3DVIEWPORT8 viewport;
static D3DCAPS8 HalCaps;
static D3DPRESENT_PARAMETERS d3dpp; 

static LPD3DXMESH DynVB;

static PVFLAGS PVM;
static bool FogTable,FogEnabled;
static PVMaterial *lastm=NULL;
static unsigned OverrideCull;
static D3DZBUFFERTYPE zbuftype;
static unsigned StencilSupported;

////////////////////////////////////////////////////////////////////////////////////////////////////

struct MaterialDeterminant
{
	unsigned blended;
	unsigned boxid;
	PVMaterial* matid;
	PVLightMap* lightmapid;
	unsigned wrapflags;
	PVMesh *mesh;
	
	bool operator<(const MaterialDeterminant& y) const;
};

bool MaterialDeterminant::operator<(const MaterialDeterminant& y) const
{
	if(blended==y.blended)
	{
		if(boxid==y.boxid)
		{
			if(matid==y.matid)
			{
				if(wrapflags==y.wrapflags)
				{
					return (lightmapid<y.lightmapid);
				}
				else
					return(wrapflags<y.wrapflags);
			}
			else
				return (matid<y.matid);
		}
		else
			return (boxid<y.boxid);
	}
	else
		return (blended<y.blended);
}

static stack<MaterialDeterminant> BlendedParts;

///////////////////////////////////////////////////////////////////////////////////////////

struct PVFaceInfosBundle
{	
	unsigned boxid;	  // Id of Box
	std::set<MaterialDeterminant> dets;
};

#define MESH_CTRL_MAPPING			1
#define MESH_CTRL_VERTEX_PER_FACE	2
#define MESH_CTRL_LIGHTMAP			4

struct PVMeshCtrl
{	
	LPD3DXMESH DMeshNoOpt;
	LPD3DXMESH DMeshOpt;
	DWORD *MAdj;

	std::map<unsigned,PVFaceInfosBundle> Boxes;
	std::map<unsigned,unsigned> reverseindex; // Face to Box, FaceNumber/BoxPointer
	std::map<MaterialDeterminant,unsigned> DetToHandle;

	unsigned HandleCount;
	unsigned Flags;

	PVMeshCtrl() {DMeshNoOpt=DMeshOpt=NULL;Flags=0;HandleCount=1;MAdj=NULL;};
};

struct PVLMCtrl
{
	LPDIRECT3DTEXTURE8 tex[MAX_LIGHTMAPS];
};

struct PVSurfCtrl
{
	LPDIRECT3DTEXTURE8 d3dtex[2];
	DWORD D3DState;
	PVFLAGS PVM;

	PVSurfCtrl() {d3dtex[0]=d3dtex[1]=NULL;D3DState=0;PVM=0;}
};

typedef	std::map<unsigned,PVFaceInfosBundle>::iterator BoxIter;
typedef std::map<unsigned,unsigned>::iterator RIIter;
typedef std::set<MaterialDeterminant>::iterator DetIter;
typedef	std::map<MaterialDeterminant,unsigned>::iterator DTHIter;

PVRGBF *AmbientLight;
float fp,bp,depthval,depthval2;
unsigned MultiTexture;

#define LoadTextureStage(x,m) \
		lpD3DDEV->SetTexture(x,m);

/////////////////////////////////////////////////////////////////////////////////

static void __cdecl DebugString(char *fmt, ...)
{
    char ach[128];
    va_list va;
	FILE *f;

	if(getenv("PVD3D8")!=NULL)
	{
		if(strcmp(getenv("PVD3D8"),"QUIET")==0)
		{
			return;
		}
	}

    va_start( va, fmt );
    wvsprintf( ach, fmt, va );
    va_end( va );
	
	f=fopen("pvd3d8.log","a+");
	fprintf(stderr,"%s",ach);
	fprintf(f,"%s",ach);
	OutputDebugString(ach);
	fclose(f);
}

static int PVAPI D3DDetect(void)
{	
    lpD3D=Direct3DCreate8(D3D_SDK_VERSION);
	if(lpD3D==NULL) return 0;
        
    // Get the current desktop display mode
    /*D3DDISPLAYMODE d3ddm;
    if( FAILED( lpD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) )
	{		
		lpD3D->Release();
		lpD3D=NULL;
        return 0;
	}

    // Set up the structure used to create the D3DDevice. Most parameters are
    // zeroed out. We set Windowed to TRUE, since we want to do D3D in a
    // window, and then set the SwapEffect to "discard", which is the most
    // efficient method of presenting the back buffer to the display.  And 
    // we request a back buffer format that matches the current desktop display 
    // format.
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = d3ddm.Format;
xxx
    // Create the Direct3D device. Here we are using the default adapter (most
    // systems only have one, unless they have multiple graphics hardware cards
    // installed) and requesting the HAL (which is saying we want the hardware
    // device rather than a software one). Software vertex processing is 
    // specified since we know it will work on all cards. On cards that support 
    // hardware vertex processing, though, we would see a big performance gain 
    // by specifying hardware vertex processing.
    if( FAILED( lpD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, GetActiveWindow(),
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &lpD3DDEV) ) )
    {
		lpD3D->Release();
		lpD3D=NULL;
		return 0;
    }
*/
//	lpD3DDEV->Release();
	lpD3D->Release();
//	lpD3DDEV=NULL;
	lpD3D=NULL;
	return 1;
}

BOOL IsDepthFormatExisting( D3DFORMAT DepthFormat, D3DFORMAT AdapterFormat, D3DFORMAT RenderTarget ) 
{
    HRESULT hr = lpD3D->CheckDeviceFormat( D3DADAPTER_DEFAULT,
                                          D3DDEVTYPE_HAL,
                                          AdapterFormat,
                                          D3DUSAGE_DEPTHSTENCIL,
                                          D3DRTYPE_SURFACE,
                                          DepthFormat);
    HRESULT hr2 = lpD3D->CheckDepthStencilMatch( D3DADAPTER_DEFAULT,
                                          D3DDEVTYPE_HAL,
                                          AdapterFormat,
										  RenderTarget,
										  DepthFormat);

    return (SUCCEEDED(hr)&&SUCCEEDED(hr2));
}

extern PVHardwareCaps D3DCaps,D3DCapsOrg;
static void PVAPI D3DHint(char *hint,UPVD32 val);
static int PVAPI D3DInitSupport(long win)
{
	D3DDISPLAYMODE d3ddm;

   	DebugString("Panard Vision Dx8 Driver : Starting (%s)\n",PVDriver.Desc);
	
	lpD3D = Direct3DCreate8(D3D_SDK_VERSION);
	if(lpD3D==NULL) return NO_ACCELSUPPORT;

	memcpy(&D3DCaps,&D3DCapsOrg,sizeof(D3DCaps));

	// Try an init
	ZeroMemory(&d3dpp, sizeof(d3dpp));
	if(getenv("PVLOCKBB")!=NULL)
		if(strcmp(getenv("PVLOCKBB"),"TRUE")==0)	
			d3dpp.Flags=D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;
	d3dpp.Windowed   = TRUE;
	d3dpp.hDeviceWindow=(HWND)win;
	if(!IsWindow((HWND)win)) 
	{
		d3dpp.hDeviceWindow=(HWND)GetActiveWindow();

		// The entry parameters is a ddraw object
		LPDIRECTDRAW7 lpDD=(LPDIRECTDRAW7)win;
		RECT r;
		
		lpD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm);		
		GetWindowRect(d3dpp.hDeviceWindow,&r);

		if((d3ddm.Width==(r.right-r.left))&&(d3ddm.Height==(r.bottom-r.top)))
		{
			// Assume fullscreen
			DebugString("INFO: Full screen assumed.\n");			
			d3dpp.Windowed   = FALSE;						

			lpDD->SetCooperativeLevel(d3dpp.hDeviceWindow,DDSCL_NORMAL);
		}
	}       
    	
	d3dpp.BackBufferCount = 1;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.MultiSampleType=D3DMULTISAMPLE_NONE;

	if(d3dpp.Windowed)
	{	
		lpD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm);
		d3dpp.BackBufferWidth  = 0;
		d3dpp.BackBufferHeight = 0;
		d3dpp.BackBufferFormat = d3ddm.Format;
	}
	else
	{
		d3dpp.BackBufferWidth  = d3ddm.Width;
		d3dpp.BackBufferHeight = d3ddm.Height;
		d3dpp.BackBufferFormat = d3ddm.Format;
	}
	
	d3dpp.EnableAutoDepthStencil = TRUE;
	unsigned tabst[]={D3DFMT_D32,D3DFMT_D15S1,D3DFMT_D24S8,D3DFMT_D16,D3DFMT_D24X8,D3DFMT_D24X4S4,D3DFMT_D16_LOCKABLE,0};
	for(unsigned i=0;tabst[i]!=0;i++)
	{
		if(IsDepthFormatExisting((D3DFORMAT)tabst[i],d3dpp.BackBufferFormat,d3dpp.BackBufferFormat))
		{
			d3dpp.AutoDepthStencilFormat = (D3DFORMAT)tabst[i];
			break;
		}
	}

	switch(d3dpp.AutoDepthStencilFormat)
	{
	case D3DFMT_D32:
	case D3DFMT_D16:
	case D3DFMT_D15S1:
	case D3DFMT_D24X8:
	case D3DFMT_D16_LOCKABLE:
	case 0:
		StencilSupported=0;break;
	
	case D3DFMT_D24S8:StencilSupported=8;break;
	case D3DFMT_D24X4S4:StencilSupported=4;break;
	default:
		DebugString("ERROR: Unknown stencil format (this maybe because you don't have any DX8 compliant hardware)\n");		
		StencilSupported=0;
	}

    lpD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3dpp.hDeviceWindow,
                         D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                         &d3dpp, &lpD3DDEV );

	if(lpD3DDEV==NULL) return NO_ACCELSUPPORT;


	// Infos
	D3DDEVICE_CREATION_PARAMETERS d3dcp;
	D3DADAPTER_IDENTIFIER8 d3did;
	
	lpD3DDEV->GetCreationParameters(&d3dcp);
	lpD3D->GetAdapterIdentifier(d3dcp.AdapterOrdinal,D3DENUM_NO_WHQL_LEVEL,&d3did);
	DebugString("INFO: Driver = %s (%s)\n",d3did.Driver,d3did.Description);
	DebugString("INFO: Version = %d.%d.%d.%d\n",HIWORD(d3did.DriverVersion.HighPart),LOWORD(d3did.DriverVersion.HighPart),
												HIWORD(d3did.DriverVersion.LowPart),LOWORD(d3did.DriverVersion.LowPart));
	DebugString("INFO: IDs = %x,%x,%x,%x\n",d3did.VendorId,d3did.DeviceId,d3did.SubSysId,d3did.Revision);

	lpD3DDEV->GetBackBuffer(0,D3DBACKBUFFER_TYPE_MONO, &lpDDS);

	// Viewport set
	D3DSURFACE_DESC d3dsd;
	lpDDS->GetDesc(&d3dsd);

	viewport.X=0;
	viewport.Y=0;
	viewport.Height=d3dsd.Height;
	viewport.Width=d3dsd.Width;
	viewport.MinZ=0.0f;
	viewport.MaxZ=1.0f;

	lpD3DDEV->SetViewport(&viewport);

	lpD3DDEV->GetDeviceCaps(&HalCaps);

	// PV Setup
	PV_SetPipelineControl(PV_GetPipelineControl()|PVP_HARDWARETL|PVP_NO_TRIANGULATE);

	// D3D Setup
	lpD3DDEV->SetRenderState(D3DRS_DITHERENABLE,TRUE);
	lpD3DDEV->SetRenderState(D3DRS_SPECULARENABLE,FALSE);
	lpD3DDEV->SetRenderState(D3DRS_ZENABLE,FALSE);
	lpD3DDEV->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);    
		
	lpD3DDEV->SetRenderState(D3DRS_CLIPPING,TRUE);

	lpD3DDEV->SetRenderState(D3DRS_COLORVERTEX,FALSE);
	lpD3DDEV->SetRenderState(D3DRS_AMBIENT, 0);

	lpD3DDEV->SetRenderState(D3DRS_NORMALIZENORMALS,FALSE);
	
	lpD3DDEV->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );    
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
	

	lpD3DDEV->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 1 );
    lpD3DDEV->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    lpD3DDEV->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT ); 

	lpD3DDEV->SetTextureStageState( 1,D3DTSS_ADDRESSU,D3DTADDRESS_CLAMP);
	lpD3DDEV->SetTextureStageState( 1,D3DTSS_ADDRESSV,D3DTADDRESS_CLAMP);

	lpD3DDEV->SetTextureStageState( 1, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
	lpD3DDEV->SetTextureStageState( 1, D3DTSS_MIPFILTER, D3DTEXF_POINT);
    lpD3DDEV->SetTextureStageState( 1, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );

	lpD3DDEV->SetRenderState(D3DRS_WRAP1,0);

	// Fog Testing
	D3DHint("PV_FOG_TABLE",0);
	D3DHint("PV_FOG_RANGE",0);

	// W-Buffer
	D3DHint("PV_WBUFFER",0);

	if(HalCaps.DevCaps&D3DDEVCAPS_HWRASTERIZATION)
	{
		DebugString("INFO: Using hardware rasterization\n");
	}
	else
	{
		DebugString("WARNING : Running with Direct3D sofware emulation !!!\n");
		DebugString("          The modes/options you selected are not supported by hardware\n");		
	}

	if(HalCaps.DevCaps&D3DDEVCAPS_PUREDEVICE)
	{
		DebugString("INFO: Device is pure\n");
	}

	if(HalCaps.MaxSimultaneousTextures>1) 
	{
		MultiTexture=HalCaps.MaxSimultaneousTextures; 
		DebugString("INFO: Multitexture enabled (%u)\n",HalCaps.MaxSimultaneousTextures);
	}
	else 
	{
		MultiTexture=0;
		DebugString("INFO: Multitexture not supported, some features are disabled\n");
	}

	if(HalCaps.DevCaps&D3DDEVCAPS_HWTRANSFORMANDLIGHT) 
	{
		DebugString("INFO: Device supports Hardware T&L\n");
		D3DCaps.GeneralCaps|=PHG_HARDWARETL;
	}
	else
		DebugString("INFO: Device does NOT supports Hardware T&L\n");

	DebugString("INFO: Number of lights supported: %u\n",HalCaps.MaxActiveLights); 
	DebugString("INFO: Number of user clip planes supported: %u\n",HalCaps.MaxUserClipPlanes);
	DebugString("INFO: Number of stencil bits: %u\n",StencilSupported);

	// Init for 2D drawing
	lpD3DDEV->SetVertexShader(D3DFVF_CUSTOMVERTEX);

	// Dynamic VB
	unsigned dwFVF=/*D3DFVF_DIFFUSE|*/D3DFVF_NORMAL|D3DFVF_XYZ|D3DFVF_TEX1; // xxx comment faire pour le select de composantes ??
	D3DXCreateMeshFVF(MAX_DYN_FACES,MAX_DYN_FACES*3,D3DXMESH_DYNAMIC,dwFVF,lpD3DDEV,&DynVB); // xxx gerer le lost	

	// Driver Caps
	if(StencilSupported) 
	{
		D3DCaps.GeneralCaps|=PHG_STENCILBUFFER;
		D3DCaps.BitsPerStencil=StencilSupported;
	}
	D3DCaps.NbrSurf=2;
	D3DCaps.GeneralCaps|=PHG_ZBUFFER;
	D3DCaps.FrameCaps|=PHF_DEPTHBUFFER;

	if(HalCaps.TextureFilterCaps&D3DPTFILTERCAPS_MAGFLINEAR) D3DCaps.TextureCaps|=PHT_BILINEAR;
	if(HalCaps.TextureFilterCaps&D3DPTFILTERCAPS_MIPFPOINT) D3DCaps.TextureCaps|=PHT_MIPMAP;
	if(HalCaps.TextureFilterCaps&D3DPTFILTERCAPS_MIPFLINEAR ) D3DCaps.TextureCaps|=PHT_TRILINEAR;
	
	if(HalCaps.SrcBlendCaps!=0) D3DCaps.BlendCaps|=PHB_SRCRGBBLEND;
	if(HalCaps.DestBlendCaps!=0) D3DCaps.BlendCaps|=PHB_DSTRGBBLEND;

	return COOL;
}

static void PVAPI D3DEndSupport(void)
{
	DebugString("Panard Vision DX Driver : Ending\n");
	
	if(DynVB) DynVB->Release();
	
	if(lpD3DDEV)
		for(unsigned i=0;i<8;i++) lpD3DDEV->SetTexture(i,NULL);

	if(lpDDS) lpDDS->Release();
	if(lpD3DDEV) lpD3DDEV->Release();
	if(lpD3D) lpD3D->Release();
	lpDDS=NULL;
	lpD3DDEV=NULL;
	lpD3D=NULL;
}

static int PVAPI D3DSetViewPort(unsigned int cmx,unsigned int cMx,unsigned int cmy,unsigned int cMy)
{	
	D3DSURFACE_DESC d3dsd;
	
	lpDDS->GetDesc(&d3dsd);

	viewport.X=cmx;
	viewport.Y=cmy;
	viewport.Width=min(1+cMx-cmx,d3dsd.Width);
	viewport.Height=min(1+cMy-cmy,d3dsd.Height);
	lpD3DDEV->SetViewport(&viewport);

	return COOL;
}

static int PVAPI D3DLoadTexture(PVMaterial *m)
{
	LPDIRECT3DTEXTURE8 lpt;
	LPDIRECT3DSURFACE8 lps;
	
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return COOL;
		
	unsigned width,height,mip;
	D3DFORMAT format;

	width=m->Tex[0].Width;
	height=m->Tex[0].Height;
	mip=(m->NbrMipMaps==0?1:m->NbrMipMaps);
	if(m->Type&PROCEDURAL) mip=1;	

	if(m->TextureFlags&TEXTURE_RGBA)
	{
		format=D3DFMT_DXT4;
		if(m->Hint.Quality&PHQ_HIGH) format=D3DFMT_A8R8G8B8;
		if(m->Hint.Quality&PHQ_LOW) format=D3DFMT_DXT2;				

		if(m->Type&PROCEDURAL) format=D3DFMT_A8R8G8B8;
	}
	else
	{
		format=D3DFMT_DXT1;
		if(m->Hint.Quality&PHQ_HIGH) format=D3DFMT_R8G8B8;

		if(m->Type&PROCEDURAL) format=D3DFMT_R8G8B8;
	}	
	
	D3DXCheckTextureRequirements(lpD3DDEV,&width,&height,&mip,0,&format,D3DPOOL_MANAGED);
	D3DXCreateTexture(lpD3DDEV,width,height,mip,0,format,D3DPOOL_MANAGED,&lpt);
	
	lpt->GetSurfaceLevel(0,&lps);
	
	RECT srcr;
	srcr.top=0;
	srcr.left=0;
	srcr.right=m->Tex[0].Width;
	srcr.bottom=m->Tex[0].Height;
		
	if(m->TextureFlags&TEXTURE_RGBA)
	{
		// xxx faire le swap de composantes

		D3DXLoadSurfaceFromMemory(lps,NULL,NULL,m->Tex[0].Texture,D3DFMT_A8R8G8B8,m->Tex[0].Width*4,NULL,&srcr,D3DX_FILTER_BOX,0);
	}
	else
	{
		for(unsigned i=0;i<m->Tex[0].Width*m->Tex[0].Height;i++)
		{
			UPVD8 t;

			t=m->Tex[0].Texture[i*3];
			m->Tex[0].Texture[i*3]=m->Tex[0].Texture[i*3+2];
			m->Tex[0].Texture[i*3+2]=t;
		}
		D3DXLoadSurfaceFromMemory(lps,NULL,NULL,m->Tex[0].Texture,D3DFMT_R8G8B8,m->Tex[0].Width*3,NULL,&srcr,D3DX_FILTER_BOX,0);
	}

	lps->Release();

	D3DXFilterTexture(lpt,NULL,0,D3DX_FILTER_BOX);
	lpt->SetPriority(width*height);

	// Saves texture infos
	PVSurfCtrl *sc;
	sc=new PVSurfCtrl;
	if(sc==NULL) return NO_MEMORY;

	sc->d3dtex[0]=lpt;
	m->HardwarePrivate=sc;		

	// Process auxiliary texture
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{			
		// Preprocess lightmap to be darker
		for(unsigned i=0;i<m->AuxiliaryTexture.Width;i++)
			for(unsigned j=0;j<m->AuxiliaryTexture.Height;j++)
			{
				m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]=max(0,m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]-1.3*(255-m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]));
			}

		width=m->AuxiliaryTexture.Width;
		height=m->AuxiliaryTexture.Height;
		format=D3DFMT_L8;
		mip=1;

		D3DXCheckTextureRequirements(lpD3DDEV,&width,&height,&mip,0,&format,D3DPOOL_MANAGED);
		D3DXCreateTexture(lpD3DDEV,width,height,mip,0,format,D3DPOOL_MANAGED,&lpt);		
		lpt->GetSurfaceLevel(0,&lps);
		
		RECT srcr;
		srcr.top=0;
		srcr.left=0;
		srcr.right=m->AuxiliaryTexture.Width;
		srcr.bottom=m->AuxiliaryTexture.Height;
			
		D3DXLoadSurfaceFromMemory(lps,NULL,NULL,m->AuxiliaryTexture.Texture,D3DFMT_L8,m->AuxiliaryTexture.Width,NULL,&srcr,D3DX_FILTER_BOX,0);
		lps->Release();	

		sc->d3dtex[1]=lpt;
	}
			
	return COOL;
}

static void PVAPI D3DDeleteTexture(PVMaterial *m)
{
	PVSurfCtrl *sc;
			
	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL) return;

	if(sc->d3dtex[0]!=NULL) sc->d3dtex[0]->Release();
	if(sc->d3dtex[1]!=NULL) sc->d3dtex[1]->Release();
	if((lpD3DDEV!=NULL)&&(sc->D3DState!=0)) lpD3DDEV->DeleteStateBlock(sc->D3DState);

	delete sc;
	m->HardwarePrivate=NULL;
}

//////////////////////////////////////////////////////////////////////////// LIGHTMAPS

#define MAXLIGHTMAPS	100000
#define LMAPW			128
#define LMAPH			128

static PVLightMap **LMaps=NULL; // xxx
static unsigned nbrlmaps=0,LMapComputed=0;

static int PVAPI D3DLoadLightMap(PVLightMap *m)
{	
	if(LMapComputed) return COOL;
	if(m->Flags&LIGHTMAP_PROCESSED) return COOL;
	
	// On alloue le tablo pseudo statique
	if(LMaps==NULL)
	{
		LMaps=new PVLightMap*[MAXLIGHTMAPS];
		if(LMaps==NULL) return NO_MEMORY;
		nbrlmaps=0;
	}
	
	LMaps[nbrlmaps++]=m;
	m->Flags|=LIGHTMAP_PROCESSED;
	
    return COOL;
}

static int __cdecl LMCompare( const void *arg1, const void *arg2 )
{
	PVLightMap *m1,*m2;
	
	m1=*(PVLightMap**)arg1;
	m2=*(PVLightMap**)arg2;
	
	if(m1->Height==m2->Height)
	{
		if(m1->Width>m2->Width) return -1;
		else return 1;
	}

	if(m1->Height<m2->Height) return 1;
	else return -1;
}

static int DownloadLightMaps(void)
{
	LPDIRECT3DSURFACE8 surf=NULL;    
	unsigned CurrentW=0,CurrentH=0,MaxH=0;

	unsigned width=LMAPW,height=LMAPH,mip=1;
	D3DFORMAT format=D3DFMT_R5G6B5;
	LPDIRECT3DTEXTURE8 lpt;
	RECT srcr,dstr;
	
	PVLightMap *m;
	PVLMCtrl *sc;
	unsigned k;
	
	if(nbrlmaps==0) return COOL;
	
	DebugString("Processing %u lightmaps ...\n",nbrlmaps);
	
	// Sort lightmaps
	qsort( (void*)LMaps, nbrlmaps, sizeof( PVLightMap * ), LMCompare );	

	// Get surface
	D3DXCheckTextureRequirements(lpD3DDEV,&width,&height,&mip,0,&format,D3DPOOL_MANAGED);
	
	CurrentW=CurrentH=MaxH=0;
	LMapComputed=1;
	
	for(k=0;k<nbrlmaps;k++)
	{
		m=LMaps[k];
		sc=new PVLMCtrl;
		if(sc==NULL) return NO_MEMORY;
		m->HardwarePrivate=sc;
		
		for(int z=0;z<m->NbrLightMaps;z++)
		{
			if((CurrentW==0)&&(CurrentH==0))
			{
				// Try to create a a surface in system memory	
				if(surf) surf->Release();
				D3DXCreateTexture(lpD3DDEV,width,height,mip,0,format,D3DPOOL_MANAGED,&lpt);
				lpt->GetSurfaceLevel(0,&surf);
			}
			
			// Now fills the surface with the texture						
			// Decal
			if((CurrentW+m->Width<width)&&(CurrentH+m->Height<height))
			{
				CurrentW+=m->Width;
				if(m->Height+CurrentH>MaxH) MaxH=m->Height+CurrentH;
			}
			else
			{
				// not enough room, try a lower band
				if(MaxH+m->Height<height)
				{
					CurrentH=MaxH;
					CurrentW=0;
					z--;
					continue;
				}
				else
				{					
					// New surface
					CurrentW=CurrentH=MaxH=0;
					z--;
					continue;
				}
			}					

			UPVD8 *rov=&m->Maps[z][0];

			srcr.top=0;
			srcr.left=0;
			srcr.right=m->Width;
			srcr.bottom=m->Height;

			dstr.top=CurrentH;
			dstr.left=CurrentW-m->Width;
			dstr.right=width;
			dstr.bottom=height;

			if(m->Flags&LIGHTMAP_RGB)
				D3DXLoadSurfaceFromMemory(surf,NULL,&dstr,rov,D3DFMT_R8G8B8,m->Width*3,NULL,&srcr,D3DX_FILTER_NONE,0);
			else
				D3DXLoadSurfaceFromMemory(surf,NULL,&dstr,rov,D3DFMT_L8,m->Width,NULL,&srcr,D3DX_FILTER_NONE,0);
						
			// Saves texture interface to destroy them or reload them									
			sc->tex[z]=lpt;
			lpt->AddRef();
			
			// Fixup ccord		
			m->su[z]*=(float)m->Width/(float)width;
			m->sv[z]*=(float)m->Height/(float)height;
			
			m->su[z]+=(float)(CurrentW-m->Width)/(float)width;
			m->sv[z]+=(float)(CurrentH)/(float)height;
		}
		// Setup lightmaps scaling
		m->ScaleU*=(float)m->Width/(float)width;
		m->ScaleV*=(float)m->Height/(float)height;
		m->ScaleU*=(1.0/(float)(m->MaxU-m->MinU));
		m->ScaleV*=(1.0/(float)(m->MaxV-m->MinV));
	}
	if(surf) surf->Release();
	DebugString("Lightmap done\n");
						
	return COOL;
}

static void PVAPI D3DDeleteLightMap(PVLightMap *m)
{
	PVLMCtrl *sc;
	
	if(!(m->Flags&LIGHTMAP_PROCESSED)) return;
	if(m==NULL) return;

	sc=(PVLMCtrl*)m->HardwarePrivate;
	if(sc)
	{
		for(unsigned z=0;z<m->NbrLightMaps;z++) if(sc->tex[z]) sc->tex[z]->Release();
		delete sc;
	}
	
	nbrlmaps--;
	if(nbrlmaps==0) LMapComputed=0;
	
	m->HardwarePrivate=NULL;
	REMOVEFLAG(m->Flags,LIGHTMAP_PROCESSED);
}

////////////////////////////////////////////////////////////////////////////////////////////

static void *PVAPI D3DGetFiller(PVFLAGS flags)
{
	return TriD3D2D;
}

static void PVAPI D3DBeginFrame(PVFLAGS PVMode,PVFLAGS PVPipe)
{	
	// Clear ZBuffer+Stencil
	DWORD flags=0;
	
	if((!(PVPipe&PVP_NO_ZBUFFERCLEAR))&&(PVMode&PVM_ZBUFFER)) flags|=D3DCLEAR_ZBUFFER;	
	if(StencilSupported)
		if((!(PVPipe&PVP_NO_STENCILCLEAR))&&(PVMode&PVM_STENCILBUFFER)) flags|=D3DCLEAR_STENCIL;

	if(flags!=0)
	{
		D3DRECT rect;

		rect.x1=viewport.X;
		rect.y1=viewport.Y;
		rect.x2=viewport.X+viewport.Width;
		rect.y2=viewport.Y+viewport.Height;

		lpD3DDEV->Clear(1, &rect,flags,0,1.0,(1<<(StencilSupported-1))|(1<<(StencilSupported-2)));
	}

	// Generates lightmaps
	if(LMapComputed==0)
	{		
		int hr=DownloadLightMaps();
		if(hr!=COOL) return;
	}

	lpD3DDEV->BeginScene();

	lastm=NULL;
	OverrideCull=0xFFFFFFFF;
}

static int PVAPI D3DPreRender(PVWorld *w,unsigned surfacenum,PVFLAGS PVMode,PVFLAGS PVPipe)
{			
	AmbientLight=&w->AmbientLight;	
	PVM=PVMode;
	fp=w->Camera->FrontDist;
	bp=w->Camera->BackDist;	
	depthval=(bp/(bp-fp));
	depthval2=(bp*fp)/(bp-fp);

    // Set the transform matrices
	D3DXMATRIX matView1,matView,matProj,matScale;
	D3DXVECTOR3 from;
	D3DXVECTOR4 r;
	
	D3DXMatrixIdentity(&matView1);
	D3DXMatrixScaling(&matScale,1,-1,-1);
	for(unsigned i=0;i<3;i++)
		for(unsigned j=0;j<3;j++) matView1.m[i][j]=w->Camera->Matrix[j][i];
	D3DXMatrixMultiply(&matView,&matView1,&matScale);;	
	from.x=w->Camera->pos.xf;
	from.y=w->Camera->pos.yf;
	from.z=w->Camera->pos.zf;
	D3DXVec3Transform(&r,&from,&matView);
	matView.m[3][0]=-r.x;
	matView.m[3][1]=-r.y;
	matView.m[3][2]=-r.z;

	lpD3DDEV->SetTransform(D3DTS_VIEW,&matView);

	D3DMATRIX mp;
	float W,H,Q;
	ZeroMemory(&mp,sizeof(mp));

	Q=depthval;
	W=1.0/tan((atan(2.0/(w->Camera->fieldofview*w->Camera->fscale/w->Camera->xscreenscale)))/2.0);
	H=1.0/tan((atan(2.0/(w->Camera->fieldofview*w->Camera->fscale/w->Camera->yscreenscale)))/2.0);

	mp._11=W;
	mp._22=H;
	mp._33=Q;
	mp._43=-Q*fp;
	mp._34=1;
	
	lpD3DDEV->SetTransform(D3DTS_PROJECTION, &mp ); 

	// Setup clip planes
	float d[4];
	DWORD clipf=0;
	unsigned nclip=0;

	for(i=0;(i<MAX_USER_CLIPPLANES)&&(nclip<HalCaps.MaxUserClipPlanes);i++)
	{
		if(w->Camera->UserPlanesEnabled[i])
		{
			d[0]=-w->Camera->UserPlanes[i].Plane.Normal.xf;
			d[1]=-w->Camera->UserPlanes[i].Plane.Normal.yf;
			d[2]=-w->Camera->UserPlanes[i].Plane.Normal.zf;
			d[3]=w->Camera->UserPlanes[i].Plane.d;
			lpD3DDEV->SetClipPlane(i,d);
			clipf|=(1<<i);
			nclip++;
		}
	}
	lpD3DDEV->SetRenderState( D3DRS_CLIPPLANEENABLE,clipf);

	// Set up lights
	unsigned nlight=0,totlight;
	static unsigned lastnl=0;
	PVLight *l;
	D3DLIGHT8 li;

	totlight=HalCaps.MaxActiveLights;
	l=w->Lights;
	while(l!=NULL)
	{
		if(nlight==totlight) break;

		if(!(l->Flags&LIGHT_FORGET))
		{
			li.Diffuse.r=l->Color.r;
			li.Diffuse.g=l->Color.g;
			li.Diffuse.b=l->Color.b;
			li.Diffuse.a=l->Color.a;

			li.Specular.r=1.0;
			li.Specular.g=1.0;
			li.Specular.b=1.0;
			li.Specular.a=1.0;

			li.Ambient.r=w->AmbientLight.r;
			li.Ambient.g=w->AmbientLight.g;
			li.Ambient.b=w->AmbientLight.b;
			li.Ambient.a=w->AmbientLight.a;

			li.Type=(D3DLIGHTTYPE)0xffffffff;
			li.Range=0;

			switch(l->Type)
			{
			case PVL_PARALLEL:
			case PVL_DIRECTIONAL:
				if(HalCaps.VertexProcessingCaps&D3DVTXPCAPS_DIRECTIONALLIGHTS )
				{
					li.Type=D3DLIGHT_DIRECTIONAL;
					li.Direction=D3DXVECTOR3(l->Direction.xf,l->Direction.yf,l->Direction.zf);
				}
				break;
			case PVL_INFINITEPOINT:
				if(HalCaps.VertexProcessingCaps&D3DVTXPCAPS_POSITIONALLIGHTS )
				{
					li.Type=D3DLIGHT_POINT;
					li.Position.x=l->Position.xf;
					li.Position.y=l->Position.yf;
					li.Position.z=l->Position.zf;
					li.Attenuation0=1;
					li.Attenuation1=0;
					li.Attenuation2=0;
					li.Range=sqrtf(FLT_MAX);
				}
				break;
			case PVL_POINT:
				if(HalCaps.VertexProcessingCaps&D3DVTXPCAPS_POSITIONALLIGHTS )
				{
					li.Type=D3DLIGHT_POINT;
					li.Position.x=l->Position.xf;
					li.Position.y=l->Position.yf;
					li.Position.z=l->Position.zf;
					li.Attenuation0=l->Attenuation0;
					li.Attenuation1=l->Attenuation1;
					li.Attenuation2=l->Attenuation2;
					li.Range=l->Range;
				}
				break;
			case PVL_SPOT:
				if(HalCaps.VertexProcessingCaps&D3DVTXPCAPS_POSITIONALLIGHTS )
				{
					li.Type=D3DLIGHT_SPOT;
					li.Position.x=l->Position.xf;
					li.Position.y=l->Position.yf;
					li.Position.z=l->Position.zf;
					li.Attenuation0=l->Attenuation0;
					li.Attenuation1=l->Attenuation1;
					li.Attenuation2=l->Attenuation2;
					li.Range=l->Range;
					li.Theta=l->Theta;
					li.Phi=l->Phi;
					li.Falloff=l->FallOff;
					li.Direction=D3DXVECTOR3(l->Direction.xf,l->Direction.yf,l->Direction.zf);
				}
				break;
			case PVL_USER_LIGHT:
			case PVL_POINT_FOG:
				break;

			}
			if(li.Type!=0xffffffff)
			{
				lpD3DDEV->SetLight(nlight,&li);
				lpD3DDEV->LightEnable(nlight,TRUE);
				nlight++;
			}
		}
		l=l->Next;
	}
	for(i=nlight;i<lastnl;i++) lpD3DDEV->LightEnable(i,FALSE);
	lastnl=nlight;
	
	// Fog support
	if(w->Fog.Type!=PVF_NONE)		
	{			
		float s,e;

        lpD3DDEV->SetRenderState(D3DRS_FOGCOLOR,D3DXCOLOR(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b,0));

		FogEnabled=true;

		s=w->Fog.Start;
		e=w->Fog.End;		

		lpD3DDEV->SetRenderState(D3DRS_FOGSTART,*( LONG* ) &s);
		lpD3DDEV->SetRenderState(D3DRS_FOGEND,*( LONG* ) &e);
		lpD3DDEV->SetRenderState(D3DRS_FOGDENSITY,*( LONG* ) &w->Fog.Density);				

		if(FogTable)
		{
			lpD3DDEV->SetRenderState(D3DRS_FOGVERTEXMODE,D3DFOG_NONE);

			switch(w->Fog.Type)
			{
			case PVF_LINEAR:lpD3DDEV->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_LINEAR);break;
			case PVF_EXP:lpD3DDEV->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_EXP);break;
			case PVF_EXP2:lpD3DDEV->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_EXP2);break;
			default:
				PV_Fatal("DX Driver: Unknown fog mode !",w->Fog.Type);
			}
		}
		else
		{			
			lpD3DDEV->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_NONE);

			switch(w->Fog.Type)
			{
			case PVF_LINEAR:lpD3DDEV->SetRenderState(D3DRS_FOGVERTEXMODE,D3DFOG_LINEAR);break;
			case PVF_EXP:lpD3DDEV->SetRenderState(D3DRS_FOGVERTEXMODE,D3DFOG_EXP);break;
			case PVF_EXP2:lpD3DDEV->SetRenderState(D3DRS_FOGVERTEXMODE,D3DFOG_EXP2);break;
			default:
				PV_Fatal("DX Driver: Unknown fog mode !",w->Fog.Type);
			}
		}
	}
	else 
	{		
        if(PVMode&PVM_VERTEXFOGGING)
        {
            lpD3DDEV->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_NONE);		
			lpD3DDEV->SetRenderState(D3DRS_FOGVERTEXMODE,D3DFOG_NONE);		
		    lpD3DDEV->SetRenderState(D3DRS_FOGCOLOR,D3DXCOLOR(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b,0));
			FogEnabled=true;
        }
        else
		{
			FogEnabled=false;
		}
	}
		
	return COOL;
}

static void FinalizeFace(PVMaterial *m)
{
	// PP Force Cull
	if(OverrideCull!=0xFFFFFFFF)
	{
		switch(OverrideCull)
		{
		case PV_CULL_NONE:lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);break;
		case PV_CULL_CW:  lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_CW);break;
		case PV_CULL_CCW: lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);break;
		}
	}

	// Fog Powah!
	if((!(m->Type&FOGABLE))||(!FogEnabled))
	{
		lpD3DDEV->SetRenderState(D3DRS_FOGENABLE,FALSE);				
	}
	else
	{
		lpD3DDEV->SetRenderState(D3DRS_FOGENABLE,TRUE);
	} 

	lastm=m;
}

void PVAPI D3DPrepareFace(PVMaterial *m)
{	
	PVSurfCtrl *sc;

	static int Alphaf[]={D3DBLEND_ZERO,D3DBLEND_ONE,D3DBLEND_DESTCOLOR,D3DBLEND_INVDESTCOLOR,D3DBLEND_SRCALPHA,D3DBLEND_INVSRCALPHA,D3DBLEND_DESTALPHA,D3DBLEND_INVDESTALPHA,D3DBLEND_SRCALPHASAT,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR};

    sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL)
	{
		sc=new PVSurfCtrl;
		if(sc==NULL) return;
		m->HardwarePrivate=sc;
		sc->D3DState=0;
	}

	if(sc->PVM==PVM)
	{
        if(lastm==m) 
		{
			// Material Not Changed
			FinalizeFace(m);
			return;
		}
	}
	else
	{
		// PV_Mode changed, reload state
		if(sc->D3DState)
		{
			lpD3DDEV->DeleteStateBlock(sc->D3DState);
			sc->D3DState=0;
		}
		sc->PVM=PVM;
	}
		
	if(sc->D3DState==0)
	{
		// Record New State block
		lpD3DDEV->BeginStateBlock();
	}
	else
	{
		// Can reuse state
		// Use State Block
		lpD3DDEV->ApplyStateBlock(sc->D3DState);

		FinalizeFace(m);
		return;
	}

	// Setup Cull
	if(OverrideCull!=0xFFFFFFFF)
	{
		switch(OverrideCull)
		{
		case PV_CULL_NONE:lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);break;
		case PV_CULL_CW:  lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_CW);break;
		case PV_CULL_CCW: lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);break;
		}
	}
	else
	{
		if(m->Type&DOUBLE_SIDED)
			lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
		else
			lpD3DDEV->SetRenderState(D3DRS_CULLMODE,D3DCULL_CW);
	}

	// Setup Material
	if(m->Type&(FLAT|GOURAUD))
	{
		D3DMATERIAL8 mat; 
		mat.Diffuse.r = m->Diffuse.r;
		mat.Diffuse.g = m->Diffuse.g;
		mat.Diffuse.b = m->Diffuse.b;
		mat.Diffuse.a = m->Diffuse.a;
		mat.Ambient.r = m->Diffuse.r;
		mat.Ambient.g = m->Diffuse.g;
		mat.Ambient.b = m->Diffuse.b;
		mat.Ambient.a = m->Diffuse.a;
		mat.Specular.r = m->Specular.r;
		mat.Specular.g = m->Specular.g;
		mat.Specular.b = m->Specular.b;
		mat.Specular.a = m->Specular.a;
		mat.Power = m->SpecularPower;
		mat.Emissive.r=m->Emissive.r;
		mat.Emissive.g=m->Emissive.g;
		mat.Emissive.b=m->Emissive.b;
		mat.Emissive.a=m->Emissive.a;
		lpD3DDEV->SetMaterial(&mat);

		lpD3DDEV->SetRenderState(D3DRS_LIGHTING,TRUE);
		lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	}
	else
	{
		lpD3DDEV->SetRenderState(D3DRS_LIGHTING,FALSE);
		lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
	}

	// Shading mode
	if(m->Type&GOURAUD)
	{
		lpD3DDEV->SetRenderState(D3DRS_SHADEMODE,D3DSHADE_GOURAUD);
	}
	else
	{
		lpD3DDEV->SetRenderState(D3DRS_SHADEMODE,D3DSHADE_FLAT);		
	}

	// Sets for wireframe
	if(m->Type&WIREFRAME)
		lpD3DDEV->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
	else
		lpD3DDEV->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);

	// Sets for zbuffer
	if((PVM&PVM_ZBUFFER)&&(m->Type&ZBUFFER))
	{
		lpD3DDEV->SetRenderState(D3DRS_ZENABLE,zbuftype);
		if(m->ZWrite) 
			lpD3DDEV->SetRenderState(D3DRS_ZWRITEENABLE,TRUE);
		else
			lpD3DDEV->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);

		switch(m->DepthTest)
		{
		case CMP_LESS:lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:
			lpD3DDEV->SetRenderState(D3DRS_ZFUNC,D3DCMP_ALWAYS);break;
		}
	}
	else  
	{
		lpD3DDEV->SetRenderState(D3DRS_ZENABLE,FALSE);
		lpD3DDEV->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);
	}

	// Stencil Buffer
	if((PVM&PVM_STENCILBUFFER)&&(m->Type&STENCILBUFFER))
	{
		static D3DSTENCILOP sop[]={D3DSTENCILOP_KEEP,D3DSTENCILOP_ZERO,D3DSTENCILOP_REPLACE, D3DSTENCILOP_INCRSAT,
								   D3DSTENCILOP_DECRSAT, D3DSTENCILOP_INVERT,D3DSTENCILOP_INCR, D3DSTENCILOP_DECR};				

		lpD3DDEV->SetRenderState(D3DRS_STENCILENABLE,TRUE);
		lpD3DDEV->SetRenderState(D3DRS_STENCILREF,m->StencilRef);
		lpD3DDEV->SetRenderState(D3DRS_STENCILMASK,m->StencilMask);
		lpD3DDEV->SetRenderState(D3DRS_STENCILWRITEMASK,m->StencilWriteMask);
		lpD3DDEV->SetRenderState(D3DRS_STENCILFAIL,sop[m->StencilFail]);
		lpD3DDEV->SetRenderState(D3DRS_STENCILZFAIL,sop[m->StencilZFail]);
		lpD3DDEV->SetRenderState(D3DRS_STENCILPASS,sop[m->StencilPass]);
		
		switch(m->StencilFunc)
		{
		case CMP_LESS:lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:
			lpD3DDEV->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_ALWAYS);break;
		}
	}
	else 
	{
		lpD3DDEV->SetRenderState(D3DRS_STENCILENABLE,FALSE);
	}
	
	// Sets for AlphaBlending
	if(PVM&PVM_ALPHABLENDING)
	{
		lpD3DDEV->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		lpD3DDEV->SetRenderState(D3DRS_SRCBLEND,Alphaf[m->BlendRgbSrcFactor]);
		lpD3DDEV->SetRenderState(D3DRS_DESTBLEND,Alphaf[m->BlendRgbDstFactor]);
		
		if(m->AlphaConstant!=1.0)
		{
			lpD3DDEV->SetRenderState(D3DRS_TEXTUREFACTOR,D3DXCOLOR(0,0,0,m->AlphaConstant));
			lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_TFACTOR); 
		}
		else
			lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );		
	}
	else lpD3DDEV->SetRenderState(D3DRS_ALPHABLENDENABLE,FALSE);
	
	// Sets for Alpha testing
	if(PVM&PVM_ALPHATESTING)
	{
		switch(m->AlphaTest)
		{
		case CMP_LESS:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_ALWAYS);break;
		}
		
		lpD3DDEV->SetRenderState(D3DRS_ALPHAREF,(unsigned)((float)m->AlphaReference*255.0)); //16.16 fixed, bah non en fait avec dx7
		lpD3DDEV->SetRenderState(D3DRS_ALPHATESTENABLE,TRUE);
	}
	else 
	{
		lpD3DDEV->SetRenderState(D3DRS_ALPHATESTENABLE,FALSE);
		lpD3DDEV->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_ALWAYS); // Voodoo 1 Hack
	}
	
	// The following is for textured faces only	
	if(m->Type&(MAPPED_MATERIAL))
	{
		// Sets wrapping modes
		switch(m->RepeatU)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);break;
		}
		
		switch(m->RepeatV)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);break;
		}
		
		// Sets up mag filtering
		if((m->TextureFlags&TEXTURE_BILINEAR)||(m->TextureFlags&TEXTURE_TRILINEAR))
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
		else
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTEXF_POINT);
		
		// Sets for min filtering
		if((m->TextureFlags&TEXTURE_BILINEAR)||(m->TextureFlags&TEXTURE_TRILINEAR))
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
		else 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTEXF_POINT);

		if(m->TextureFlags&TEXTURE_TRILINEAR) 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
		else
		{
			if(m->TextureFlags&TEXTURE_MIPMAP) 
				lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTEXF_POINT);
			else
				lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTEXF_NONE);
		}

		// Loads texture
		if(m->HardwarePrivate!=NULL)
		{
			LoadTextureStage(0,((PVSurfCtrl*)m->HardwarePrivate)->d3dtex[0]);			
			LoadTextureStage(1,((PVSurfCtrl*)m->HardwarePrivate)->d3dtex[1]);
		}

		// Ambienbt mapping
		if(m->Type&AMBIENT_MAPPING)
		{
			lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXCOORDINDEX,D3DTSS_TCI_CAMERASPACENORMAL|0);
			lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);

			D3DXMATRIX matTrans;
			D3DXMatrixIdentity(&matTrans);
			matTrans.m[0][0]=0.5;
			matTrans.m[1][1]=0.5;
			matTrans.m[3][0]=0.5;
			matTrans.m[3][1]=0.5;
			lpD3DDEV->SetTransform(D3DTS_TEXTURE0, &matTrans);
		}
		else
		{
			lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXCOORDINDEX,0);
			lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
		}

		if(m->Type&(PHONG|U_PHONG|BUMP|U_BUMP))
		{
			lpD3DDEV->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_MODULATE);
			lpD3DDEV->SetTextureStageState(1,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);
			lpD3DDEV->SetTextureStageState(1,D3DTSS_TEXCOORDINDEX,D3DTSS_TCI_CAMERASPACENORMAL|1);

			D3DXMATRIX matTrans;
			D3DXMatrixIdentity(&matTrans);
			matTrans.m[0][0]=0.5;
			matTrans.m[1][1]=0.5;
			matTrans.m[3][0]=0.5;
			matTrans.m[3][1]=0.5;
			lpD3DDEV->SetTransform(D3DTS_TEXTURE1, &matTrans);
		}
		else
		{
			lpD3DDEV->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_DISABLE);
			lpD3DDEV->SetTextureStageState(1,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
			lpD3DDEV->SetTextureStageState(1,D3DTSS_TEXCOORDINDEX,0);
		}
	}
	else 
	{
		LoadTextureStage(0,NULL);			
		LoadTextureStage(1,NULL);

		lpD3DDEV->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_DISABLE);
	}

	// Multitexturing
	unsigned decal;
	if(m->Type&LIGHTMAP) decal=1; else decal=0;
	for(unsigned s=1;s<MAX_TEXTURE_STAGE;s++)
	{
		switch(m->TexStage[s-1].ColorOp)
		{
		case PVTSO_DISABLE:
			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_COLOROP,D3DTOP_DISABLE);
			s=MAX_TEXTURE_STAGE;
			continue;
			break;
		case PVTSO_DETAILTEXTURE:			
			D3DCOLOR fact=D3DCOLOR_RGBA(255,255,255,(int)(255.0*0.3));
			LoadTextureStage(s+decal,((PVSurfCtrl*)m->TexStage[s-1].Mat->HardwarePrivate)->d3dtex[0]);
			lpD3DDEV->SetRenderState(D3DRS_TEXTUREFACTOR,*( LONG* )(&fact));			
			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_COLOROP,D3DTOP_BLENDFACTORALPHA);
			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_COLORARG2,D3DTA_CURRENT);
			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_COLORARG1,D3DTA_TEXTURE);

			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);
			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_TEXCOORDINDEX,0);

			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
			lpD3DDEV->SetTextureStageState(s+decal,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);


			D3DXMATRIX matTrans;
			D3DXMatrixIdentity(&matTrans);
			matTrans.m[0][0]=m->TexStage[s-1].Data1;
			matTrans.m[1][1]=m->TexStage[s-1].Data2;
			
			D3DTRANSFORMSTATETYPE stage[]={D3DTS_TEXTURE0,D3DTS_TEXTURE1,D3DTS_TEXTURE2,D3DTS_TEXTURE3,D3DTS_TEXTURE4,D3DTS_TEXTURE5,D3DTS_TEXTURE6,D3DTS_TEXTURE7};
			lpD3DDEV->SetTransform(stage[s+decal], &matTrans);
			break;
		}
	}

	lpD3DDEV->EndStateBlock(&sc->D3DState);	
	lpD3DDEV->ApplyStateBlock(sc->D3DState);

	FinalizeFace(m);
}

static void PVAPI D3DPrepareFace(PVFace *f)
{	
	D3DPrepareFace(f->MaterialInfo);
}

static void D3DDrawMeshPart(MaterialDeterminant *det);
static void SetupTransforms(PVMesh *m);
static void PVAPI D3DPostRender(void)
{
	lpD3DDEV->SetRenderState(D3DRS_CLIPPING,TRUE);
	while(!BlendedParts.empty())
	{
		MaterialDeterminant attrid=BlendedParts.top();

		SetupTransforms(attrid.mesh);		
		D3DDrawMeshPart(&attrid);

		BlendedParts.pop();
	}
	lpD3DDEV->SetRenderState(D3DRS_CLIPPING,FALSE);
}

static void PVAPI D3DEndFrame(void)
{
	if(lpD3DDEV!=NULL)	
		lpD3DDEV->EndScene();
}

static int PVAPI D3DFlipSurface(void)
{
	lpD3DDEV->Present( NULL, NULL, NULL, NULL );
	return COOL;
}

static int PVAPI D3DFillSurface(unsigned surfacenum,float r,float g,float b,float a)
{
	D3DCOLOR c=D3DCOLOR_RGBA((int)r*255,(int)g*255,(int)b*255,(int)a*255);
	lpD3DDEV->Clear(0, NULL,D3DCLEAR_TARGET,c,0.0,0);

	return COOL;
}

static void PVAPI D3DRefreshMaterial(PVMaterial *m)
{
	PVSurfCtrl *sc;
	
	if(m==lastm) lastm=NULL;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc!=NULL)
	{
		lpD3DDEV->DeleteStateBlock(sc->D3DState);
		sc->D3DState=0;
		sc->PVM=0;
	}
}

extern PVHardwareCaps D3DCaps;
static PVHardwareCaps * PVAPI D3DGetInfo(void)
{
	return &D3DCaps;
}

static void * PVAPI D3DLockFB(unsigned surfacenum,PVFLAGS mode)
{
	unsigned flags=0;
	D3DSURFACE_DESC desc;
	
	switch(mode)
	{
	case PFB_READONLY:flags=D3DLOCK_READONLY;break;	
	}

	lpDDS->GetDesc(&desc);
	
	D3DLOCKED_RECT lr;
	RECT r;

	r.top=0;
	r.left=0;
	r.bottom=desc.Height;
	r.right=desc.Width;
	HRESULT hr=lpDDS->LockRect(&lr,NULL,D3DLOCK_NO_DIRTY_UPDATE|D3DLOCK_NOSYSLOCK|flags);
	
	D3DCaps.RowStride=lr.Pitch;
	
	return lr.pBits;
}

static void PVAPI D3DUnLockFB(unsigned surfacenum,PVFLAGS mode)
{
	lpDDS->UnlockRect();
}


static UPVD8* PVAPI D3DLockProcedural(PVMaterial *m,PVRGBFormat *rgb,PVFLAGS access)
{
	PVSurfCtrl *sc;	
	D3DSURFACE_DESC desc;
	HRESULT hr;
	DWORD flags;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL) return NULL;

	sc->d3dtex[0]->GetLevelDesc(0,&desc);

	rgb->RedSize=8;
	rgb->GreenSize=8;
	rgb->BlueSize=8;
	rgb->RedPos=16;
	rgb->GreenPos=8;
	rgb->BluePos=0;

	if(desc.Format==D3DFMT_R8G8B8)
	{
		rgb->AlphaPos=0;
		rgb->NbrBitsPerPixel=24;
		rgb->AlphaSize=0;
	}
	else
	{
		rgb->AlphaPos=24;
		rgb->NbrBitsPerPixel=32;
		rgb->AlphaSize=8;
	}
	
	flags=0;
	if(access==PV_READ_ONLY) flags|=D3DLOCK_READONLY;
	else
	if(access==PV_WRITE_ONLY) flags|=D3DLOCK_DISCARD;
			
	
	D3DLOCKED_RECT lr;
	RECT r;

	r.top=0;
	r.left=0;
	r.bottom=desc.Height;
	r.right=desc.Width;

	hr=sc->d3dtex[0]->LockRect(0,&lr,&r,flags);
	if(hr!=D3D_OK) return NULL;

	rgb->Pitch=lr.Pitch;
		
	return (UPVD8 *)lr.pBits;

	return NULL;
}

static void PVAPI D3DUnLockProcedural(PVMaterial *m)
{
	PVSurfCtrl *sc;

	if(m==NULL) return;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL) return;

	sc->d3dtex[0]->UnlockRect(0);
}

static void PVAPI D3DHint(char *hint,UPVD32 val)
{
	if(strcmp(hint,"PV_FOG_RANGE")==0)	
	{
		if(val)
			DebugString("INFO: Using Fog-Range\n");
		else
			DebugString("INFO: Using Fog-plane\n");
		lpD3DDEV->SetRenderState(D3DRS_RANGEFOGENABLE ,val==1?TRUE:FALSE);
	}	

	if(strcmp(hint,"PV_FOG_TABLE")==0)	
	{
		if(HalCaps.RasterCaps&D3DPRASTERCAPS_FOGTABLE)		
			FogTable=(val?TRUE:FALSE);
		else
			FogTable=FALSE;

		if(FogTable)
			DebugString("INFO: Using Fog Table functions\n");
		else
			DebugString("INFO: Using Vertex Fog functions\n");		
	}

	if(strcmp(hint,"PV_WBUFFER")==0)
	{
		if((val)&&(HalCaps.RasterCaps&D3DPRASTERCAPS_WBUFFER))
		{
			DebugString("INFO: Using W-Buffer\n");
			zbuftype=D3DZB_USEW;		
		}
		else
		{
			DebugString("INFO: Using Z-Buffer\n");
			zbuftype=D3DZB_TRUE;
		}
	}

	if(strcmp(hint,"PV_MIPMAPLODBIAS")==0)
	{
		if(val!=NULL)
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPMAPLODBIAS, *((LPDWORD) (val)));
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////
static void PVAPI D3DModifyMesh(PVMesh *m)
{
	PVMeshCtrl *mc;
	LPD3DXMESH im;
	BYTE *vb;
	DWORD *ab;
	unsigned size;
	float luv[2];

	map<unsigned,unsigned> attroldnew;
	map<MaterialDeterminant,MaterialDeterminant> matdetoldnew;
	DTHIter its,ite;
	std::map<MaterialDeterminant,unsigned> newdets;


	if(!(m->Dirty.Flags)) return;
	
	mc=(PVMeshCtrl*)m->HardwarePrivate;

	im=mc->DMeshNoOpt;
	size=D3DXGetFVFVertexSize(im->GetFVF());

	//////////////////////////////////////////////////////////////////////////////////////////////////////

	if(m->Dirty.Flags&MESH_DIRTY_LIGHTMAP_BIND)
	if(mc->Flags&MESH_CTRL_LIGHTMAP)
	{
		its=mc->DetToHandle.begin();
		ite=mc->DetToHandle.end();
		while(its!=ite)
		{
			MaterialDeterminant matdet;
			
			matdet=(*its).first;
			if((matdet.lightmapid)&&(matdet.lightmapid->HardwarePrivate!=NULL))
			{
				// Create new from old
				matdet.lightmapid=(PVLightMap*)(((PVLMCtrl*)matdet.lightmapid->HardwarePrivate)->tex[0]);

				// Add new 
				std::pair<DTHIter, bool> re;
				
				re=newdets.insert(std::make_pair(matdet,mc->HandleCount));
				
				if(re.second)
				{
					// it's a new one
					// Register attrid old/new, pour reconstruire l'attribute buffer
					attroldnew.insert(std::make_pair((*its).second,mc->HandleCount));

					mc->HandleCount++;
				}
				else
				{
					unsigned nattr=(*newdets.find(matdet)).second;

					// Register attrid old/new, pour reconstruire l'attribute buffer
					attroldnew.insert(std::make_pair((*its).second,nattr));
				}

				// Register old matdet to delete it in box indexes
				matdetoldnew.insert(std::make_pair((*its).first,matdet));
			}
			its++;
		}

		// Clean master list
		std::map<MaterialDeterminant,MaterialDeterminant>::iterator mms,mme;				
		mms=matdetoldnew.begin();
		mme=matdetoldnew.end();
		while(mms!=mme)
		{
			mc->DetToHandle.erase((*mms).first);

			mms++;
		}

		// Add new handles to master list
		its=newdets.begin();
		ite=newdets.end();
		while(its!=ite)
		{
			mc->DetToHandle.insert(*its);

			its++;
		}

		// Clean Box Index
		BoxIter bbs,bbe;

		bbs=mc->Boxes.begin();
		bbe=mc->Boxes.end();

		while(bbs!=bbe)
		{
			PVFaceInfosBundle *bu;
			DetIter dts,dte;

			bu=&(*bbs).second;

			dts=bu->dets.begin();
			dte=bu->dets.end();
			while(dts!=dte)
			{
				std::map<MaterialDeterminant,MaterialDeterminant>::iterator mmf;
				
				mmf=matdetoldnew.find((*dts));

				if(mmf!=matdetoldnew.end())
				{
					dts=bu->dets.erase(dts);
					bu->dets.insert((*mmf).second);
				}
				else
					dts++;
			}

			bbs++;
		}
		
		// Updates AB
		im->LockAttributeBuffer(0,&ab);
		for(unsigned h=0;h<im->GetNumFaces();h++,ab++)
		{			
			std::map<unsigned,unsigned>::iterator aai;
			
			aai=attroldnew.find(*ab);
			if(aai!=attroldnew.end())
			{
				*ab=(*aai).second;
			}

		}
		im->UnlockAttributeBuffer();
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////

	if(m->Dirty.Flags&MESH_DIRTY_LIGHTMAP)
	if(mc->Flags&MESH_CTRL_LIGHTMAP)
	{
		// Compute lightmap coords in VBs
		im->LockVertexBuffer(0,&vb);
		for(unsigned h=0;h<m->NbrFaces;h++)
		{
			PVFace *f=&m->Face[h];
			PV_PrepareFace(f);
			for(unsigned j=0;j<f->NbrVertices;j++,vb+=size)
			{
				unsigned ind=f->V[j];

				luv[0]=f->LightMap->su[f->LightMap->CurrentLightMap]+(m->Mapping[ind].u-f->LightMap->MinU)*f->LightMap->ScaleU;
				luv[1]=f->LightMap->sv[f->LightMap->CurrentLightMap]+(m->Mapping[ind].v-f->LightMap->MinV)*f->LightMap->ScaleV;				
				
				memcpy(&vb[8*sizeof(float)],&luv[0],sizeof(float)*2);
			}
			PV_PrepareFace(f);
		}			
		im->UnlockVertexBuffer();
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////
	m->Dirty.Flags=0;
	im->Optimize(D3DXMESHOPT_ATTRSORT|D3DXMESHOPT_VERTEXCACHE,mc->MAdj,NULL,NULL,NULL,&mc->DMeshOpt);
}

static void CreateIndexForMesh(PVMesh *m,PVBox *b,unsigned *boxnbr,unsigned *nbrtris,unsigned *nbrvtxpoly)
{
	if(b->Flags)
	{
		PVFaceInfosBundle bu;		
		PVMeshCtrl *mc;

		mc=(PVMeshCtrl*)m->HardwarePrivate;
		
		bu.boxid=*boxnbr;
		(*boxnbr)++;
		
		for(unsigned f=0;f<b->NbrFaces;f++)
		{
			unsigned i;
			i=b->FaceIndex[f];

			*nbrtris+=m->Face[i].NbrVertices-2;
			*nbrvtxpoly+=m->Face[i].NbrVertices;

			if(m->Face[i].MaterialInfo!=NULL)
			{				
				MaterialDeterminant matdet;
				
				// Register matdet in box
				matdet.mesh=m;
				matdet.boxid=bu.boxid;
				matdet.matid=m->Face[i].MaterialInfo;
								
				if(m->Face[i].MaterialInfo->Type&LIGHTMAP)
					matdet.lightmapid=m->Face[i].LightMap;
				else
					matdet.lightmapid=0;
				
				if((m->Face[i].MaterialInfo->AlphaConstant!=1.0)||
				   (m->Face[i].MaterialInfo->BlendRgbSrcFactor!=BLEND_ONE)||
				   (m->Face[i].MaterialInfo->BlendRgbDstFactor!=BLEND_ZERO))
				   	matdet.blended=1;
				else
					matdet.blended=0;

				matdet.wrapflags=0;
				if(m->Face[i].Flags&U_WRAP) matdet.wrapflags|=D3DWRAPCOORD_0;
				if(m->Face[i].Flags&V_WRAP) matdet.wrapflags|=D3DWRAPCOORD_1;
					
				bu.dets.insert(bu.dets.begin(),matdet);
							
				/// Register Face to box mapping
				mc->reverseindex.insert(std::make_pair(i,(unsigned)b));

				// Setup mesh flags
				if(m->Face[i].MaterialInfo->Type&(MAPPED_MATERIAL))
					mc->Flags|=MESH_CTRL_MAPPING;

				if(m->Face[i].MaterialInfo->Type&(LIGHTMAP))
					mc->Flags|=MESH_CTRL_LIGHTMAP;
			}
		}

		////// Generate attrid
		DetIter msi,mse;
		
		msi=bu.dets.begin();
		mse=bu.dets.end();
		while(msi!=mse)
		{
			mc->DetToHandle.insert(std::make_pair((*msi),mc->HandleCount));
			mc->HandleCount++;

			msi++;
		}

		mc->Boxes.insert(std::make_pair((unsigned)b,bu));		
	}
	else
		for(unsigned i=0;i<8;i++) if (b->Child[i]!=NULL) CreateIndexForMesh(m,b->Child[i],boxnbr,nbrtris,nbrvtxpoly);
}

static unsigned PVAPI D3DUpdateMesh(PVMesh *m)
{
	PVMeshCtrl *mc;
	LPD3DXMESH im;
	BYTE *vb;
	WORD *ib;
	DWORD *ab;
	unsigned size;

	if(m->Flags&MESH_SWITCHNODE) return COOL;
	if((m->NbrFaces==0)||(m->NbrVertices==0)) return COOL;
	
	mc=(PVMeshCtrl*)m->HardwarePrivate;
	if(mc==NULL)
	{
		mc=new PVMeshCtrl;
		m->HardwarePrivate=mc;
		if(mc==NULL) return BIZAR_ERROR;
	}

	// Dynamic Mesh (fromm PP3D ? xxx creer un flag interne c encore mieux, paske y'a conflit d'interet la)
	if(m->Name)
	if(m->Flags&MESH_DYNAMIC)
		DebugString("Rendring %s using Dynamic VB\n",m->Name);
	else
		DebugString("Compiling %s\n",m->Name);

	// Disable user pipes
	m->UserPipeline=NULL;

	// Assure les boxes
	if(m->Box==NULL)
	{
		PVFLAGS oldf=m->Flags;
		m->Flags|=MESH_DYNAMIC;
		PV_MeshBuildBoxes(m,1000);
		m->Flags=oldf;
	}

	// Comptage du nombre de triangles du mesh
	unsigned nbrtri=0,nbrbox=0,nbrvtxpoly=0;
	CreateIndexForMesh(m,m->Box,&nbrbox,&nbrtri,&nbrvtxpoly);

	if(m->NbrMapIndex>m->NbrVertices) mc->Flags|=MESH_CTRL_VERTEX_PER_FACE;

	// Default Index Buffer will have 3 indexes per face
	DWORD dwFVF=D3DFVF_NORMAL|D3DFVF_XYZ;
	unsigned dwLockFlags;
	unsigned numvtx;
	numvtx=m->NbrVertices;

	if((!(m->Flags&MESH_DYNAMIC))||(nbrtri>MAX_DYN_FACES))
	{
	
		if(mc->Flags&MESH_CTRL_MAPPING) 
			dwFVF|=D3DFVF_TEX1;

		if(mc->Flags&MESH_CTRL_LIGHTMAP) 
		{
			dwFVF&=~D3DFVF_TEX1;
			dwFVF|=D3DFVF_TEX2;

			numvtx=nbrvtxpoly;
			m->Dirty.Flags|=MESH_DIRTY_LIGHTMAP|MESH_DIRTY_LIGHTMAP_BIND;
		}
			
		if(mc->Flags&MESH_CTRL_VERTEX_PER_FACE)
			numvtx=max(m->LastMapIndex,m->NbrIndex);

		D3DXCreateMeshFVF(nbrtri,numvtx,D3DXMESH_MANAGED,dwFVF,lpD3DDEV,&im);
		dwLockFlags=0;
	}
	else
	{
		im=DynVB;
		im->AddRef();
		dwLockFlags=D3DLOCK_NOOVERWRITE|D3DLOCK_DISCARD;
	}
	size=D3DXGetFVFVertexSize(im->GetFVF());

	// Print infos
	if(!(m->Flags&MESH_DYNAMIC))
		DebugString("   VB approximated size (%u vtx/%u tris/%u Kb, %u mats)\n",numvtx,nbrtri,numvtx*size/1024,mc->HandleCount-1);

	// Charge le VB
	im->LockVertexBuffer(dwLockFlags|D3DLOCK_DISCARD,&vb);
	if(mc->Flags&(MESH_CTRL_VERTEX_PER_FACE|MESH_CTRL_LIGHTMAP))
	{
		// Gestion des mesh avec mappings additionels (par face) ou base	
		for(unsigned i=0;i<m->NbrFaces;i++)
		{
			PVFace *f=&m->Face[i];
			PV_PrepareFace(f);
			for(unsigned j=0;j<f->NbrVertices;j++,vb+=size)
			{
				unsigned ind=f->V[j];										
				
				memcpy(&vb[0],&m->Vertex[ind].xf,sizeof(float)*3);
				memcpy(&vb[3*sizeof(float)],&m->Vertex[ind].Normal.xf,sizeof(float)*3);
								
				if(mc->Flags&MESH_CTRL_MAPPING) 
					memcpy(&vb[6*sizeof(float)],&m->Mapping[ind].u,sizeof(float)*2);
			}
			PV_PrepareFace(f);
		}
	}
	else
	{
		// Standard Mesh
		for(unsigned i=0;i<min(im->GetNumVertices(),m->NbrVertices);i++,vb+=size)
		{
			memcpy(&vb[0],&m->Vertex[i].xf,sizeof(float)*3);		
			memcpy(&vb[3*sizeof(float)],&m->Vertex[i].Normal.xf,sizeof(float)*3);								

			if(mc->Flags&MESH_CTRL_MAPPING)
				memcpy(&vb[6*sizeof(float)],&m->Mapping[i].u,sizeof(float)*2);
		}		
	}
	im->UnlockVertexBuffer();

	// Charge le IB & AB
	RIIter fsi;
	BoxIter bsi;
	DTHIter it;	
	MaterialDeterminant matdet;
	unsigned attrid;

	im->LockIndexBuffer(dwLockFlags|D3DLOCK_DISCARD,(BYTE**)&ib);
	im->LockAttributeBuffer(dwLockFlags|D3DLOCK_DISCARD,&ab);
	unsigned curtri=0,decalindex=0;
	for(unsigned i=0;i<m->NbrFaces;i++)
	{		
		// Get MaterialInfo/BoxInfo
		attrid=0;
		fsi=mc->reverseindex.find(i);
		if(fsi!=mc->reverseindex.end())
		{
			bsi=mc->Boxes.find((*fsi).second);
			if(bsi!=mc->Boxes.end())
			{
				PVFaceInfosBundle *bi;

				bi=&(*bsi).second;
				
				matdet.boxid=bi->boxid;
				matdet.matid=m->Face[i].MaterialInfo;

				if((m->Face[i].MaterialInfo->AlphaConstant!=1.0)||
				   (m->Face[i].MaterialInfo->BlendRgbSrcFactor!=BLEND_ONE)||
				   (m->Face[i].MaterialInfo->BlendRgbDstFactor!=BLEND_ZERO))
					matdet.blended=1;
				else
					matdet.blended=0;
				
				if(m->Face[i].MaterialInfo->Type&LIGHTMAP)
					matdet.lightmapid=m->Face[i].LightMap;
				else
					matdet.lightmapid=0;

				matdet.wrapflags=0;
				if(m->Face[i].Flags&U_WRAP) matdet.wrapflags|=D3DWRAPCOORD_0;
				if(m->Face[i].Flags&V_WRAP) matdet.wrapflags|=D3DWRAPCOORD_1;

				it=mc->DetToHandle.find(matdet);
				attrid=(*it).second;
			}
		}

		if((mc->Flags&MESH_CTRL_LIGHTMAP)||((mc->Flags&MESH_CTRL_VERTEX_PER_FACE)))
		{
			for(unsigned j=1;j<m->Face[i].NbrVertices-1;j++)
			{
 				ib[curtri*3]=decalindex+0;
				ib[curtri*3+1]=decalindex+j;
				ib[curtri*3+2]=decalindex+j+1;
				ab[curtri]=attrid;
				curtri++;
			}
			decalindex+=m->Face[i].NbrVertices;
		}
		else
		{	
			for(unsigned j=1;j<m->Face[i].NbrVertices-1;j++)
			{
 				ib[curtri*3]=m->Face[i].V[0];
				ib[curtri*3+1]=m->Face[i].V[j];
				ib[curtri*3+2]=m->Face[i].V[j+1];
				ab[curtri]=attrid;
				curtri++;
			}
		}
	}
	im->UnlockAttributeBuffer();
	im->UnlockIndexBuffer();
	
	// Generate adjacency
	if(!(m->Flags&MESH_DYNAMIC))
	{
		mc->MAdj=new DWORD[nbrtri*3];	
		im->GenerateAdjacency(0.1,mc->MAdj);	
		im->Optimize(D3DXMESHOPT_ATTRSORT|D3DXMESHOPT_VERTEXCACHE,mc->MAdj,NULL,NULL,NULL,&mc->DMeshOpt);
	}
	else
	{
		mc->DMeshOpt=im;
		im->AddRef();
	}

	// Free
	mc->reverseindex.clear();

	// Save
	mc->DMeshNoOpt=im;
	
	return COOL;
}

static void PVAPI D3DFinalizeMesh(PVMesh *m)
{
	PVMeshCtrl *mc;

	mc=(PVMeshCtrl*)m->HardwarePrivate;
	if(mc==NULL) return;

	if(mc->DMeshNoOpt!=NULL) 
	{
		if(mc->DMeshOpt) mc->DMeshOpt->Release();
		if(mc->DMeshNoOpt) mc->DMeshNoOpt->Release();
		delete[] mc->MAdj;
	}

	delete mc;
	m->HardwarePrivate=NULL;
}

static void SetupTransforms(PVMesh *m)
{
	// setup transforms
	D3DXMATRIX matWorld,matScale,matWorld1;
	D3DXVECTOR4 piv;
	
	D3DXMatrixIdentity(&matWorld1);
	D3DXMatrixScaling(&matScale,m->ScaleX,m->ScaleY,m->ScaleZ);
			
	for(unsigned i=0;i<3;i++)
		for(unsigned j=0;j<3;j++) matWorld1.m[i][j]=m->WorldMatrix[j][i];
	
	D3DXVec3Transform(&piv,&D3DXVECTOR3(-m->Pivot.xf,-m->Pivot.yf,-m->Pivot.zf),&matWorld1);

	D3DXMatrixMultiply(&matWorld,&matWorld1,&matScale);
	matWorld.m[3][0]=m->WorldPos.xf+piv.x+m->Pivot.xf;
	matWorld.m[3][1]=m->WorldPos.yf+piv.y+m->Pivot.yf;
	matWorld.m[3][2]=m->WorldPos.zf+piv.z+m->Pivot.zf;
	lpD3DDEV->SetTransform(D3DTS_WORLDMATRIX(0),&matWorld);
}

static void D3DDrawMeshPart(MaterialDeterminant *det)
{
	PVMeshCtrl *mc;		
	PVMesh *m=det->mesh;
	unsigned attrid;
	DTHIter it;	

	if(m->Flags&MESH_INSTANCE)	
		mc=(PVMeshCtrl*)m->Face[0].Father->HardwarePrivate;
	else
		mc=(PVMeshCtrl*)m->HardwarePrivate;
				
	D3DPrepareFace(det->matid);
	lpD3DDEV->SetRenderState(D3DRS_WRAP0,det->wrapflags);

	// Lightmaps
	if(det->lightmapid)
	{
		lpD3DDEV->SetTexture(1,(LPDIRECT3DTEXTURE8)det->lightmapid);		
		lpD3DDEV->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_MODULATE);
		lpD3DDEV->SetTextureStageState(1,D3DTSS_TEXCOORDINDEX,1);
	}
	
	it=mc->DetToHandle.find(*det);
	attrid=(*it).second;
		
	if(mc->DMeshOpt) mc->DMeshOpt->DrawSubset(attrid); else mc->DMeshNoOpt->DrawSubset(attrid);
	lpD3DDEV->SetVertexShader(D3DFVF_CUSTOMVERTEX); // Reset for 2d
}

static void PVAPI D3DRenderMesh(PVMesh *m,PVBox *b,PVFLAGS clipflags,unsigned Scr)
{
	if(m==NULL) return;

	PVMeshCtrl *mc;		

	if(m->Flags&MESH_INSTANCE)	
		mc=(PVMeshCtrl*)m->Face[0].Father->HardwarePrivate;
	else
		mc=(PVMeshCtrl*)m->HardwarePrivate;

	if(!clipflags)
		lpD3DDEV->SetRenderState(D3DRS_CLIPPING,FALSE);
	else
		lpD3DDEV->SetRenderState(D3DRS_CLIPPING,TRUE);	

	SetupTransforms(m);

	D3DModifyMesh(m);

	if(b!=NULL)
	{
		// Boite + VB
		// PP3D Display List
		unsigned bi=(unsigned)b;
		BoxIter bo=mc->Boxes.find((unsigned)bi);
		PVFaceInfosBundle bu=(*bo).second;

		DetIter msi,mse;

		mse=bu.dets.end();
		msi=bu.dets.begin();

		while(msi!=mse)
		{
			MaterialDeterminant det;
			
			det=(*msi);				

			if(det.blended)
			{
				BlendedParts.push(det);					
			}
			else
			{
				D3DDrawMeshPart(&det);
			}
			
			msi++;
		}		
	}
}

static void PVAPI D3DOverrideCullMode(pvCULL mode)
{
	OverrideCull=mode;
}

///////////////////////////////////////////////////////////////////////////////
static PVHardwareCaps D3DCapsOrg={ 
	0,
		PHF_FRAMEBUFFER,
		0,
		0,
		PHD_DEPTHPROP,	
		0,0,0,0,
		0,0,0,0,
		0,
		-1,-1,
		0,
		16,
		0,
		0
};

static PVHardwareCaps D3DCaps;

PVEXPORT PVHardwareDriver PVDriver={
	1,
		PV_MN2,
		sizeof(PVHardwareCaps),
		"Panard Vision DirectX8 Generic Driver V1.02",
		D3DDetect,
		D3DInitSupport,
		D3DEndSupport,
		D3DSetViewPort,
		D3DLoadTexture,
		D3DDeleteTexture,
		D3DGetFiller,
		D3DPreRender,
		D3DPrepareFace,
		D3DPostRender,
		D3DBeginFrame,
		D3DEndFrame,
		D3DFlipSurface,
		D3DFillSurface,
		D3DRefreshMaterial,
		D3DGetInfo,
		D3DLockFB,
		D3DUnLockFB,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		D3DLoadLightMap,
		D3DDeleteLightMap,
		D3DLockProcedural,
		D3DUnLockProcedural,
		D3DHint,
		D3DUpdateMesh,
		D3DFinalizeMesh,
		D3DRenderMesh,
		D3DOverrideCullMode,
		D3DModifyMesh,
		NULL,
};



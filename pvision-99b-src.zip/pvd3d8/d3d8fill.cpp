/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Direct3D v8 Driver for the Panard Vision 3D Engine
// (C) 2000, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//

#include "d3d8fill.h"

VTX BufVtx[MAX_VERTICES_PER_POLY*2];

#define Color(p) \
	D3DXCOLOR( \
	min(1,(o->Shading[p].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r), \
	min(1,(o->Shading[p].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g), \
	min(1,(o->Shading[p].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b), \
	o->Shading[p].Color.a*f->MaterialInfo->AlphaConstant)

#define LoadZ(a) \
	(depthval+o->Projected[a].InvertZ*depthval2)


////////////////////////////////////////////////////////////// 2D Drawing Routines

void PVAPI TriD3D2D(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i,nbrv,*vtn;	
	D3DCOLOR col;
	
	if(f->MaterialInfo->Type&FLAT)
		col=Color(f->V[0]);

	if(f->Poly!=NULL)
	{
		nbrv=f->Poly->NbrVertices;
		vtn=f->Poly->Vertices;
	}
	else
	{
		nbrv=f->NbrVertices;
		vtn=f->V;
	}

	for(i=0;i<nbrv;i++)
	{
		a=vtn[i];
		
		BufVtx[i].x=o->Projected[a].xf;
		BufVtx[i].y=o->Projected[a].yf;
		BufVtx[i].z=LoadZ(a);
		BufVtx[i].rhw=-o->Projected[a].InvertZ;

		if(f->MaterialInfo->Type&(FLAT))
		{
			BufVtx[i].color=col;
		}
		else
		if(f->MaterialInfo->Type&(GOURAUD))
		{
			BufVtx[i].color=Color(a);
		}

		if(f->MaterialInfo->Type&(MAPPED_MATERIAL))
		{
			BufVtx[i].u=o->Mapping[a].u;
			BufVtx[i].v=o->Mapping[a].v;
		}
	}

	lpD3DDEV->DrawPrimitiveUP(D3DPT_TRIANGLEFAN,nbrv-2,BufVtx,sizeof(VTX));	
}

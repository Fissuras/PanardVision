// This code directly taken from the DX5 SDK

#include <dinput.h>
#include "DirectInputEasy.h"

static LPDIRECTINPUT        g_lpDI; 
static LPDIRECTINPUTDEVICE  g_lpDIDevice; 

void WINAPI DI_Term() 
{ 
    if (g_lpDI) 
    { 
        if (g_lpDIDevice) 
        { 
            /* 
             *  Always unacquire the device before calling Release(). 
             */ 
             g_lpDIDevice->Unacquire(); 
             g_lpDIDevice->Release();
             g_lpDIDevice = NULL; 
        } 
        g_lpDI->Release();
        g_lpDI = NULL; 
    } 
} 
 
BOOL WINAPI DI_Init(HWND Wnd) 
{ 
    HRESULT hr; 
 
    // Create the DirectInput object. 
    hr = DirectInputCreate(GetModuleHandle(NULL), DIRECTINPUT_VERSION,&g_lpDI, NULL); 
    if FAILED(hr) return FALSE; 
 
    // Retrieve a pointer to an IDirectInputDevice interface 

    hr = g_lpDI->CreateDevice(GUID_SysKeyboard, &g_lpDIDevice, NULL); 
    if FAILED(hr) 
    {
        DI_Term(); 
        return FALSE; 
    } 
 
// Now that you have an IDirectInputDevice interface, get 
// it ready to use. 
 
    // Set the data format using the predefined keyboard data 
    // format provided by the DirectInput object for keyboards. 
    hr = g_lpDIDevice->SetDataFormat(&c_dfDIKeyboard); 
    if FAILED(hr) 
    { 
        DI_Term(); 

        return FALSE; 
    } 
 
    // Set the cooperative level 
    hr = g_lpDIDevice->SetCooperativeLevel(Wnd,DISCL_FOREGROUND | DISCL_NONEXCLUSIVE); 
    if FAILED(hr) 
    { 
        DI_Term(); 
        return FALSE; 
    } 
 
    // Get access to the input device. 
    hr = g_lpDIDevice->Acquire(); 
    if FAILED(hr) 
    { 
    //    DI_Term(); 
        //return FALSE; 
    } 
 
    return TRUE; 
} 

char     DIE_KBState[256]; 

void WINAPI ProcessKBInput() 
{ 
    HRESULT  hr; 
	char zob[255];
 
	again:;
    hr = g_lpDIDevice->GetDeviceState(sizeof(DIE_KBState),(LPVOID)&DIE_KBState); 

    if FAILED(hr)
    { 
		if (hr == DIERR_INPUTLOST) {
                hr = g_lpDIDevice->Acquire();
                if (SUCCEEDED(hr)) {
                    goto again;
                }
            }
         return; 
    }  
} 

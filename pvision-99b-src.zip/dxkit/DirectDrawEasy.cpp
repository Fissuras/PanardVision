// DirectDrawEasy

// Very simple (but useful) Wrapper for DirectDraw3 Interfaces
// Method's names pretty self explanatory

//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.

// This version requires DX3 to run, DX7 to compile 
// and benefits from multimonitoring support with DX6

//
// (C) 1997-2000, Olivier Brunet
//

// SMKaribou/GMF

#define INITGUID
#define DIRECTDRAW_VERSION		0x0700
#include "DirectDrawEasy.h"
#include <stdio.h>
#include <math.h>

DDrawEasy::DDrawEasy()
{
	lpDD=NULL;
	lpDD4=NULL;
	lpDDSPrimary=lpDDSBack=NULL;
	lpDDPalette=NULL;
	lpDDClipper=NULL;
	Pitch=0;
	RedMask=GreenMask=BlueMask=AlphaMask=0;
	Fullscreen=FALSE;
	win=0;
	OwnWindow=FALSE;
	Running=0;
}

DDrawEasy::~DDrawEasy()
{
	UnInit();
}

int DDrawEasy::GetMaskSize(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
	}

	while(x&1)
	{
		x>>=1;
		i++;
	}
	return i;
}

int DDrawEasy::GetMaskPos(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
		i++;
	}

	return i;
}

unsigned DDrawEasy::MakeRGBAColor(unsigned char r,unsigned char g,unsigned char b,unsigned char a)
{
	unsigned rs,gs,bs,rp,gp,bp,as,ap,rf,gf,bf,af;

	// Looking for the correct color mask					
	rs=GetMaskSize(RedMask);
	gs=GetMaskSize(GreenMask);
	bs=GetMaskSize(BlueMask);
	as=GetMaskSize(AlphaMask);
	rp=GetMaskPos(RedMask);
	gp=GetMaskPos(GreenMask);
	bp=GetMaskPos(BlueMask);
	ap=GetMaskSize(AlphaMask);

    // Compute colors
    rf=r*((1<<rs)-1)/255;
    rf<<=rp;
    bf=b*((1<<bs)-1)/255;
    bf<<=bp;
    gf=g*((1<<gs)-1)/255;
    gf<<=gp;
    af=a*((1<<as)-1)/255;
    af<<=ap;		
	
	return (rf|gf|bf|af);
}

#define BLACK   PALETTERGB(0,0,0)
#define WHITE   PALETTERGB(255,255,255)
#define NUM_STATIC_COLORS   (COLOR_BTNHIGHLIGHT - COLOR_SCROLLBAR + 1)

static COLORREF gacrSave[NUM_STATIC_COLORS];

static COLORREF gacrBlackAndWhite[NUM_STATIC_COLORS] = {
    WHITE,  // COLOR_SCROLLBAR
    BLACK,  // COLOR_BACKGROUND
    BLACK,  // COLOR_ACTIVECAPTION
    WHITE,  // COLOR_INACTIVECAPTION
    WHITE,  // COLOR_MENU
    WHITE,  // COLOR_WINDOW
    BLACK,  // COLOR_WINDOWFRAME
    BLACK,  // COLOR_MENUTEXT
    BLACK,  // COLOR_WINDOWTEXT
    WHITE,  // COLOR_CAPTIONTEXT
    WHITE,  // COLOR_ACTIVEBORDER
    WHITE,  // COLOR_INACTIVEBORDER
    WHITE,  // COLOR_APPWORKSPACE
    BLACK,  // COLOR_HIGHLIGHT
    WHITE,  // COLOR_HIGHLIGHTTEXT
    WHITE,  // COLOR_BTNFACE
    BLACK,  // COLOR_BTNSHADOW
    BLACK,  // COLOR_GRAYTEXT
    BLACK,  // COLOR_BTNTEXT
    BLACK,  // COLOR_INACTIVECAPTIONTEXT
    BLACK   // COLOR_BTNHIGHLIGHT
    };
static INT gaiStaticIndex[NUM_STATIC_COLORS] = {
    COLOR_SCROLLBAR          ,
    COLOR_BACKGROUND         ,
    COLOR_ACTIVECAPTION      ,
    COLOR_INACTIVECAPTION    ,
    COLOR_MENU               ,
    COLOR_WINDOW             ,
    COLOR_WINDOWFRAME        ,
    COLOR_MENUTEXT           ,
    COLOR_WINDOWTEXT         ,
    COLOR_CAPTIONTEXT        ,
    COLOR_ACTIVEBORDER       ,
    COLOR_INACTIVEBORDER     ,
    COLOR_APPWORKSPACE       ,
    COLOR_HIGHLIGHT          ,
    COLOR_HIGHLIGHTTEXT      ,
    COLOR_BTNFACE            ,
    COLOR_BTNSHADOW          ,
    COLOR_GRAYTEXT           ,
    COLOR_BTNTEXT            ,
    COLOR_INACTIVECAPTIONTEXT,
    COLOR_BTNHIGHLIGHT
    };

static BOOL        bSystemColorsInUse = FALSE;
static BOOL        bStaticSaved = FALSE;

static void SaveStaticEntries(HDC hdc)
{
    int i;

    if ( !bSystemColorsInUse )
    {
        for (i = COLOR_SCROLLBAR; i <= COLOR_BTNHIGHLIGHT; i++)
            gacrSave[i - COLOR_SCROLLBAR] = GetSysColor(i);

        bStaticSaved = TRUE;
    }
}

static void UseStaticEntries(HDC hdc)
{
    SetSysColors(NUM_STATIC_COLORS, gaiStaticIndex, gacrBlackAndWhite);
    bSystemColorsInUse = TRUE;

    PostMessage(HWND_BROADCAST, WM_SYSCOLORCHANGE, 0, 0);
}

static void RestoreStaticEntries(HDC hdc)
{
    if ( bStaticSaved )
    {
        SetSysColors(NUM_STATIC_COLORS, gaiStaticIndex, gacrSave);
        bSystemColorsInUse = FALSE;

        PostMessage(HWND_BROADCAST, WM_SYSCOLORCHANGE, 0, 0);
    }
}

void DDrawEasy::SetPal(char pal[256*3])
{		
	unsigned i;
	PALETTEENTRY Pal[256];
	
	if(lpDD==NULL) return;	

	if(lpDDPalette!=NULL) 
	{
		lpDDPalette->Release();
		lpDDPalette=NULL;
	}

	//
    // build a 332 palette as the default.
    //
    for (i=0; i<256; i++)
    {
		Pal[i].peRed   = (BYTE)(((i >> 5) & 0x07) * 255 / 7);
		Pal[i].peGreen = (BYTE)(((i >> 2) & 0x07) * 255 / 7);
		Pal[i].peBlue  = (BYTE)(((i >> 0) & 0x03) * 255 / 3);
		Pal[i].peFlags = PC_NOCOLLAPSE;;
    }
	
	if(pal!=NULL)
	{
		if(Fullscreen)
		{
			for(i=0;i<256;i++)
			{
				Pal[i].peRed=pal[i*3];
				Pal[i].peGreen=pal[i*3+1];
				Pal[i].peBlue=pal[i*3+2];
				Pal[i].peFlags=PC_NOCOLLAPSE;
			}
		}
		else
		{
			for(i=0;i<1;i++)
			{
				Pal[i].peFlags=Pal[i+255].peFlags=PC_EXPLICIT;
				Pal[i].peRed=i;
				Pal[i+255].peRed=i+255;			
			}

			for(i=0;i<256;i++) 
			{
				Pal[i].peFlags=PC_NOCOLLAPSE;
				Pal[i].peRed=pal[i*3];
				Pal[i].peGreen=pal[i*3+1];
				Pal[i].peBlue=pal[i*3+2];
			}
		}
	}

    if(!Fullscreen)
    {
        HPALETTE ghPalette;
        LOGPALETTE  pPal;
        HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);      
        
        pPal.palVersion = 0x300;
        pPal.palNumEntries = 256;
        memcpy(pPal.palPalEntry,Pal,sizeof(Pal));
        
        ghPalette=CreatePalette(&pPal);

        SelectPalette(dc, ghPalette, FALSE);
        RealizePalette(dc);
        DeleteDC(dc);
        DeleteObject(ghPalette);
    }

    if(CurrentVersion==DDE_DX6)
	{
		if(lpDD!=NULL)
			lpDD->CreatePalette(DDPCAPS_8BIT|DDPCAPS_ALLOW256,Pal,&lpDDPalette,NULL); 
		if(lpDDSPrimary!=NULL)
			lpDDSPrimary->SetPalette(lpDDPalette);
		if(lpDDSBack!=NULL)
			lpDDSBack->SetPalette(lpDDPalette);	
	}
	else
	{
		if(lpDD7!=NULL)
			lpDD7->CreatePalette(DDPCAPS_8BIT|DDPCAPS_ALLOW256,Pal,&lpDDPalette,NULL); 
		if(lpDDSPrimary7!=NULL)
			lpDDSPrimary7->SetPalette(lpDDPalette);
		if(lpDDSBack7!=NULL)
			lpDDSBack7->SetPalette(lpDDPalette);	
	}
}

void DDrawEasy::SetDirectPal(IDirectDrawPalette *pal)
{
	if(lpDDPalette!=NULL) 
	{
		lpDDPalette->Release();
		lpDDPalette=NULL;
	}
	lpDDPalette=pal;

    if(CurrentVersion==DDE_DX6)
	{
		if(lpDDSPrimary!=NULL)
			lpDDSPrimary->SetPalette(lpDDPalette);
		if(lpDDSBack!=NULL)
			lpDDSBack->SetPalette(lpDDPalette);
	}
	else
	{
		if(lpDDSPrimary7!=NULL)
			lpDDSPrimary7->SetPalette(lpDDPalette);
		if(lpDDSBack7!=NULL)
			lpDDSBack7->SetPalette(lpDDPalette);
	}
}

void DDrawEasy::Flip(void)
{	
	if(lpDDSPrimary==NULL) return;

	if(CurrentVersion==DDE_DX6)
	{
		if(Fullscreen)
		{
			while( 1 )
				{
					HRESULT ddrval;
					ddrval = lpDDSPrimary->Flip( NULL, 0 );				
					if( ddrval == DD_OK ) break;
					if( ddrval == DDERR_SURFACELOST )
					{
						ddrval = lpDDSPrimary->Restore();
						if( ddrval != DD_OK ) break;					
						ddrval = lpDDSBack->Restore();
						if( ddrval != DD_OK ) break;					
					}
				}
		}
		else
		{
			RECT srcr,dstr;
			POINT pt;

			GetClientRect(win,&srcr);
			pt.x=pt.y=0;
			ClientToScreen(win,&pt);
			dstr=srcr;
			dstr.left+=pt.x;
			dstr.right+=pt.x;
			dstr.top+=pt.y;
			dstr.bottom+=pt.y;
			lpDDSPrimary->Blt(&dstr,lpDDSBack,&srcr,DDBLT_ASYNC,0);
		}
	}
	else
	{
		if(Fullscreen)
		{
			while( 1 )
				{
					HRESULT ddrval;
					ddrval = lpDDSPrimary7->Flip( NULL, 0 );				
					if( ddrval == DD_OK ) break;
					if( ddrval == DDERR_SURFACELOST )
					{
						ddrval = lpDDSPrimary7->Restore();
						if( ddrval != DD_OK ) break;					
						ddrval = lpDDSBack7->Restore();
						if( ddrval != DD_OK ) break;					
					}
				}
		}
		else
		{
			RECT srcr,dstr;
			POINT pt;

			GetClientRect(win,&srcr);
			pt.x=pt.y=0;
			ClientToScreen(win,&pt);
			dstr=srcr;
			dstr.left+=pt.x;
			dstr.right+=pt.x;
			dstr.top+=pt.y;
			dstr.bottom+=pt.y;
			lpDDSPrimary7->Blt(&dstr,lpDDSBack7,&srcr,DDBLT_ASYNC,0);
		}
	}
}

BYTE *DDrawEasy::Lock(void)
{
	
	HRESULT hr;

	if(lpDDSBack==NULL) return NULL;
	
	if(CurrentVersion==DDE_DX6)
	{
		DDSURFACEDESC ddsd;
		ddsd.dwSize=sizeof(ddsd);

		hr=lpDDSBack->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR/*|DDLOCK_WRITEONLY|DDLOCK_NOSYSLOCK*/,NULL);
		if(hr!=DD_OK) ddsd.lpSurface=NULL;
		return (BYTE *)ddsd.lpSurface;
	}
	else
	{
		DDSURFACEDESC2 ddsd;

		ddsd.dwSize=sizeof(ddsd);

		hr=lpDDSBack7->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR/*|DDLOCK_WRITEONLY|DDLOCK_NOSYSLOCK*/,NULL);
		if(hr!=DD_OK) ddsd.lpSurface=NULL;
		return (BYTE *)ddsd.lpSurface;
	}
}

void DDrawEasy::Unlock(void)
{
	if(lpDDSBack==NULL) return;
	
	if(CurrentVersion==DDE_DX6)
		lpDDSBack->Unlock(NULL);
	else
		lpDDSBack7->Unlock(NULL);
}

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    DDrawEasy *dd;
	HRESULT hr;

	dd=(DDrawEasy*)GetWindowLong(hwnd,0);

	switch (msg)
    {        
	case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
	     return FALSE;
		 break;
	case WM_KEYDOWN:
		// The esc key will quit the application as well
		if((int)wParam==VK_ESCAPE) 
		{
			PostQuitMessage(0);
			return 0L;
		}
		break;
	case WM_QUERYNEWPALETTE:
        //
        //  we are getting the palette focus, select our palette
        //
		if(dd!=NULL)
		{
			if((!dd->Fullscreen)&&(dd->Depth==8))
			{
				if(dd->CurrentVersion==DDE_DX6)
				{
					hr=dd->lpDDSPrimary->SetPalette(dd->lpDDPalette);
					if(hr==DDERR_SURFACELOST)
					{
						dd->lpDDSPrimary->Restore();
						dd->lpDDSPrimary->SetPalette(dd->lpDDPalette);
					}
				}
				else
				{
					hr=dd->lpDDSPrimary7->SetPalette(dd->lpDDPalette);
					if(hr==DDERR_SURFACELOST)
					{
						dd->lpDDSPrimary7->Restore();
						dd->lpDDSPrimary7->SetPalette(dd->lpDDPalette);
					}
				}
			}
			return 0;
		}
		break;
		
    case WM_MOVE:if((dd!=NULL)&&(dd->IsRunning())) dd->OnIdle();break;
	case WM_CLOSE:
    case WM_DESTROY:
            PostQuitMessage(0);
            return 0L;
    }
	
	if(dd!=NULL)
	{
		if(dd->UserWindowProc(hwnd,msg,wParam,lParam)!=0) return 1;
	}

    return DefWindowProc(hwnd, msg, wParam, lParam);
}

LRESULT DDrawEasy::UserWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

int DDrawEasy::OnIdle(void)
{
	return TRUE;
}

void DDrawEasy::Run(void)
{
	MSG      msg;
	unsigned t=0,p;

	Running=1;
    while (TRUE)
    {
        if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            /*
             * Message pending. If its QUIT then exit the message
             * loop. Otherwise, process the message.
             */
            if (WM_QUIT == msg.message)
            {
                break;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }

		// No more than 70Hz refresh
		p=timeGetTime();
		if(p-t>1000/70)
		{
			if(OnIdle()==FALSE) break;
			t=p;
		}
	}
}

void DDrawEasy::Error(char *str)
{
	if(lpDD!=NULL)
	{
		if(CurrentVersion==DDE_DX6) 
			lpDD->SetCooperativeLevel(win, DDSCL_NORMAL);
		else
			lpDD7->SetCooperativeLevel(win, DDSCL_NORMAL);
	}
	MessageBox(win,str,"Direct Draw Error",MB_ICONERROR|MB_OK|MB_TASKMODAL);
	UnInit();			
}

int DDrawEasy::SetMode(LPGUID lpguid,HWND _win,unsigned xres,unsigned yres,unsigned depth,BOOL fullscreen)
{	
	GUID NullGUID={0,0,0,0,0,0,0,0,0,0,0};
	HRESULT hr;
	
	// Object already initialized
	if (lpDD!=NULL) return DDE_ALREADYINITIALIZED;

	// If handle is null, create a new window
	if(_win==NULL)
	{
		WNDCLASS    wc;	
		// Register Main Window Class
		wc.style            = CS_DBLCLKS; 
		wc.lpfnWndProc      = (WNDPROC)WindowProc; 
		wc.cbClsExtra       = 0; 
		wc.cbWndExtra       = sizeof(DDrawEasy*);
		wc.hInstance        = GetModuleHandle(NULL); 
		wc.hIcon            = NULL;
		wc.hCursor          = NULL;
		wc.hbrBackground    = (HBRUSH)GetStockObject (NULL_BRUSH);
		wc.lpszMenuName     = NULL; 
		wc.lpszClassName    = "DDEASY"; 

		if (! RegisterClass (&wc)) 
		{
			Error("Cannot register window class");
			return DDE_REGISTERFAILED;
		}
    
		//
		// Create Main Window
		//
		RECT r;
		DWORD style=WS_OVERLAPPED | WS_SYSMENU |WS_VISIBLE| WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;

		r.left=0;
		r.top=0;
		r.bottom=yres;
		r.right=xres;

		AdjustWindowRect(&r,style,FALSE);

		_win = CreateWindow (	   "DDEASY",
								   "Panard Vision Test",
								   style,
								   r.left,r.top,r.right,r.bottom,
								   NULL,
								   NULL,
								   GetModuleHandle(NULL),
								   NULL
								   );
		if (_win==NULL) 
		{
			Error("Cannot create window");
			return DDE_CREATEWINDOWFAILED;
		}
		
		SetWindowLong(_win,0,(long)this);
		
		UpdateWindow(_win);
		SetFocus(_win);

		OwnWindow=TRUE;
	}
	
	this->win=_win;
	Width=xres;
	Height=yres;
	Depth=depth;

	// Wonderful DirectDraw world 	
	if(lpguid!=NULL)
		if(memcmp(lpguid,&NullGUID,sizeof(GUID))==0) 
		{
			lpguid=NULL;
		}
	if(!fullscreen) 
	{
		lpguid=NULL;
		HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);
		Depth=GetDeviceCaps(dc,BITSPIXEL);
		DeleteDC(dc);
	}

	// Try to init DX7
	HINSTANCE h = LoadLibrary("ddraw.dll");         
	typedef HRESULT (WINAPI* ddex)(GUID FAR *,LPVOID *,REFIID,IUnknown FAR *);
	ddex DDF;

    DDF = (ddex) GetProcAddress(h,"DirectDrawCreateEx");	
    // DDF=NULL;

	FreeLibrary(h);
	
	if(DDF!=NULL)
	{
		// Starting with DX7
		if(FAILED(DDF( lpguid,(LPVOID*) &lpDD7, IID_IDirectDraw7, NULL )))
		{
			Error("Unable to create DirectDraw Object");
			return DDE_DDCREATEFAILED;
		}
		lpDD=(IDirectDraw*)lpDD7;
		CurrentVersion=DDE_DX7;
		
		// lpDD7 is a valid DirectDraw object
		if(fullscreen)
		{
			lpDD7->SetCooperativeLevel( win, DDSCL_SETFOCUSWINDOW);

			hr=lpDD7->SetCooperativeLevel(win, DDSCL_SETDEVICEWINDOW |DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT  );
			if(FAILED(hr))
			{
				// not successful
				// however, the application can still run				
				lpDD7->SetCooperativeLevel(win, DDSCL_NORMAL);
			}
		}
		else hr=lpDD7->SetCooperativeLevel(win, DDSCL_NORMAL);

		if(fullscreen)
			if( lpDD7->SetDisplayMode( Width, Height, Depth,0 ,0) != DD_OK )
			{
				UnInit();		
				Error("Unable to switch to requested video mode");
				return DDE_NOVIDEOMODE;
			}
	}
	else
	{
		// Upto Dx6
		if(FAILED(DirectDrawCreate( lpguid, &lpDD, NULL )))
		{
				Error("Unable to create DirectDraw Object");
				return DDE_DDCREATEFAILED;
		}
		
		// try to get an idd4 interface		
		lpDD->QueryInterface(IID_IDirectDraw4,(LPVOID*)&lpDD4);
		CurrentVersion=DDE_DX6;

		// lpDD is a valid DirectDraw object
		if(fullscreen)
		{
			if(lpDD4!=NULL) lpDD4->SetCooperativeLevel( win, DDSCL_SETFOCUSWINDOW);

			if(lpDD4!=NULL)
				hr=lpDD4->SetCooperativeLevel(win, DDSCL_SETDEVICEWINDOW |DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT  );
			else
				hr=lpDD->SetCooperativeLevel(win, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT  );
			if(FAILED(hr))
			{
				// not successful
				// however, the application can still run				
				lpDD->SetCooperativeLevel(win, DDSCL_NORMAL);
			}
		}
		else lpDD->SetCooperativeLevel(win, DDSCL_NORMAL);

		if(fullscreen)
			if( lpDD->SetDisplayMode( Width, Height, Depth ) != DD_OK )
			{
				UnInit();		
				Error("Unable to switch to requested video mode");
				return DDE_NOVIDEOMODE;
			}
	}

	// DX7 Path
	if(CurrentVersion==DDE_DX7)
	{
		DDSURFACEDESC2 ddsd2;
		DDSCAPS2 ddscaps2;

		ZeroMemory(&ddsd2, sizeof(ddsd2));
		ddsd2.dwSize = sizeof( ddsd2 );
		
		if(fullscreen)
		{
			// Primary & back buffer
			ddsd2.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
			ddsd2.dwBackBufferCount = 1;
			ddsd2.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
								  DDSCAPS_FLIP |
								  DDSCAPS_COMPLEX |
								  DDSCAPS_VIDEOMEMORY|DDSCAPS_3DDEVICE;
			if( lpDD7->CreateSurface( &ddsd2, &lpDDSPrimary7, NULL ) != DD_OK )
			{
				ddsd2.ddsCaps.dwCaps &= ~DDSCAPS_VIDEOMEMORY;
				if( lpDD7->CreateSurface( &ddsd2, &lpDDSPrimary7, NULL ) != DD_OK )
				{
					UnInit();
					Error("Unable to create primary surface");
					return DDE_PRIMARYFAILED;		
				}
			}

			// Gets BackBuffer for fullscreen
			ZeroMemory(&ddscaps2, sizeof(ddscaps2));
			ddscaps2.dwCaps = DDSCAPS_BACKBUFFER;
			if( lpDDSPrimary7->GetAttachedSurface( &ddscaps2, &lpDDSBack7 ) != DD_OK )
			{
				UnInit();
				Error("Unable to get the back buffer");
				return DDE_GETBACKFAILED;
			}
		}
		else
		{
			// Primary
			ddsd2.dwFlags = DDSD_CAPS;
			ddsd2.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE|DDSCAPS_3DDEVICE;

			if( lpDD7->CreateSurface( &ddsd2, &lpDDSPrimary7, NULL ) != DD_OK )
			{
				// surface was not created
				UnInit();
				Error("Unable to create primary surface");
				return DDE_PRIMARYFAILED;
			}

			// Backbuffer
			ddsd2.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;
			ddsd2.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN|DDSCAPS_3DDEVICE;
			ddsd2.dwWidth=xres;
			ddsd2.dwHeight=yres;

			if( lpDD7->CreateSurface( &ddsd2, &lpDDSBack7, NULL ) != DD_OK )
			{
				// surface was not created
				UnInit();
				Error("Unable to create back buffer");		
				return DDE_BACKFAILED;
			}

			lpDD7->CreateClipper(0,&lpDDClipper,NULL);
			lpDDClipper->SetHWnd(0, win);			
			lpDDSPrimary7->SetClipper(lpDDClipper);
			lpDDClipper->Release();
		}
	
		// Gets pixel format for RGB modes
		DDPIXELFORMAT       ddpf;
		ZeroMemory(&ddpf, sizeof(ddpf));
		ddpf.dwSize = sizeof(ddpf);
		lpDDSPrimary7->GetPixelFormat(&ddpf);

		if (ddpf.dwRGBBitCount != 8) {
			
			RedMask= ddpf.dwRBitMask;
			GreenMask = ddpf.dwGBitMask;
			BlueMask = ddpf.dwBBitMask;

			// ATTENTION: Here we do not return the Alpha Mask
			// From DDRAW, since what is interesting is the place left in the pixel
			// and ddraw don't return this as the alpha channel since it's not really usable 
			// as alpha values for him
			// Gets the number of alpha bits
			double tmp=pow(2,ddpf.dwRGBBitCount)-1;		// some trouble with integer arithmetic so use heavy tools
			AlphaMask = ~(RedMask|GreenMask|BlueMask);
			AlphaMask &=(unsigned)tmp;
		}	

		// Gets pitch
		ZeroMemory(&ddsd2, sizeof(ddsd2));
		ddsd2.dwSize=sizeof(ddsd2);
		lpDDSBack7->Lock(NULL,&ddsd2,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR/*DDLOCK_NOSYSLOCK*/,NULL);
		lpDDSBack7->Unlock(NULL);
		Pitch=ddsd2.lPitch;
	}
	else
	{
		DDSURFACEDESC ddsd;	
		DDSCAPS ddscaps;

		// lpDD is a valid DirectDraw object
		ddsd.dwSize = sizeof( ddsd );		
		if(fullscreen)
		{
			// Primary & back buffer
			ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
			ddsd.dwBackBufferCount = 1;
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
								  DDSCAPS_FLIP |
								  DDSCAPS_COMPLEX |
								  DDSCAPS_VIDEOMEMORY|DDSCAPS_3DDEVICE;
			if( lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL ) != DD_OK )
			{
				ddsd.ddsCaps.dwCaps &= ~DDSCAPS_VIDEOMEMORY;
				if( lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL ) != DD_OK )
				{
					UnInit();
					Error("Unable to create primary surface");
					return DDE_PRIMARYFAILED;		
				}
			}

			// Gets BackBuffer for fullscreen
			ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
			if( lpDDSPrimary->GetAttachedSurface( &ddscaps, &lpDDSBack ) != DD_OK )
			{
				UnInit();
				Error("Unable to get the back buffer");
				return DDE_GETBACKFAILED;
			}
		}
		else
		{
			// Primary
			ddsd.dwFlags = DDSD_CAPS;
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE|DDSCAPS_3DDEVICE;

			if( lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL ) != DD_OK )
			{
				// surface was not created
				UnInit();
				Error("Unable to create primary surface");
				return DDE_PRIMARYFAILED;
			}

			// Backbuffer
			ddsd.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;
			ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN|DDSCAPS_3DDEVICE;
			ddsd.dwWidth=xres;
			ddsd.dwHeight=yres;

			if( lpDD->CreateSurface( &ddsd, &lpDDSBack, NULL ) != DD_OK )
			{
				// surface was not created
				UnInit();
				Error("Unable to create back buffer");		
				return DDE_BACKFAILED;
			}

			lpDD->CreateClipper(0,&lpDDClipper,NULL);
			lpDDClipper->SetHWnd(0, win);			
			lpDDSPrimary->SetClipper(lpDDClipper);
			lpDDClipper->Release();
		}

		// Gets pixel format for RGB modes
		DDPIXELFORMAT       ddpf;
		ddpf.dwSize = sizeof(ddpf);
		lpDDSPrimary->GetPixelFormat(&ddpf);

		if (ddpf.dwRGBBitCount != 8) {
			
			RedMask= ddpf.dwRBitMask;
			GreenMask = ddpf.dwGBitMask;
			BlueMask = ddpf.dwBBitMask;

			// ATTENTION: Here we do not return the Alpha Mask
			// From DDRAW, since what is interesting is the place left in the pixel
			// and ddraw don't return this as the alpha channel since it's not really usable 
			// as alpha values for him
			// Gets the number of alpha bits
			double tmp=pow(2,ddpf.dwRGBBitCount)-1;		// some trouble with integer arithmetic so use heavy tools
			AlphaMask = ~(RedMask|GreenMask|BlueMask);
			AlphaMask &=(unsigned)tmp;
		}	

		// Gets pitch
		ddsd.dwSize=sizeof(ddsd);		
		lpDDSBack->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR/*DDLOCK_NOSYSLOCK*/,NULL);
		lpDDSBack->Unlock(NULL);
		Pitch=ddsd.lPitch;
	}
	
	
	Fullscreen=fullscreen;
	
	// Shut up stupid mouse
	if(fullscreen) while(ShowCursor(FALSE) >= 0);	

	// Finally sets up a font
	Font = CreateFont(Width < 640 ? 24/2 : 48/3,
    0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
    ANSI_CHARSET,
    OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    NONANTIALIASED_QUALITY,
    VARIABLE_PITCH,
    "Comic Sans MS");

	// Sets a default Palette
	if((Depth==8)&&(!fullscreen))
    {        
        HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);

        SaveStaticEntries( dc );
        SetSystemPaletteUse( dc, SYSPAL_NOSTATIC );

        SetPal(NULL);

        UseStaticEntries( dc );
        DeleteDC(dc);
    }

	return 0;
}

void DDrawEasy::Fill(unsigned bufnum,unsigned top,unsigned left,unsigned bottom,unsigned right,unsigned color)
{
	RECT RSource;
	DDBLTFX ddbltfx;         	
	HRESULT hr;

	RSource.left = left;
    RSource.top = top;
    RSource.right = right;
    RSource.bottom = bottom;

    ddbltfx.dwSize = sizeof(ddbltfx);
    ddbltfx.dwFillColor = color;

	if(CurrentVersion==DDE_DX6)	
	{
		switch(bufnum)
		{
		case 0:if(lpDDSBack!=NULL)
			   {
				   while(lpDDSBack->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
				   hr=lpDDSBack->Blt(&RSource,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx);
			   }
			break;
		case 1:if(lpDDSPrimary!=NULL)
			   {
				   while(lpDDSPrimary->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
				   hr=lpDDSPrimary->Blt(&RSource,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx);
			   }
			break;
		}
	}
	else
	{
		switch(bufnum)
		{
		case 0:if(lpDDSBack7!=NULL)
			   {
				   while(lpDDSBack7->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
				   hr=lpDDSBack7->Blt(&RSource,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx);
			   }
			break;
		case 1:if(lpDDSPrimary7!=NULL)
			   {
				   while(lpDDSPrimary7->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
				   hr=lpDDSPrimary7->Blt(&RSource,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx);
			   }
			break;
		}    
	}
}

void DDrawEasy::UnInit(void)
{
	HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);
    
    SetSystemPaletteUse( dc, SYSPAL_STATIC );
    RestoreStaticEntries(dc);
    
    DeleteDC(dc);

    // Kills DDraw objects
	if(CurrentVersion==DDE_DX6)			
	{
		if( lpDD != NULL )
		{
			if(Fullscreen) lpDD->RestoreDisplayMode();
			if(lpDDSPrimary != NULL )
			{
				lpDDSPrimary->Release();
				lpDDSPrimary = NULL;			
			}

			if(!Fullscreen) 
				if(lpDDSBack!=NULL) lpDDSBack->Release();		
			lpDDSBack=NULL;
			
			if(lpDDPalette!=NULL)
			{
				lpDDPalette->Release();
				lpDDPalette=NULL;
			}
			
			lpDD->Release();
			lpDD = NULL;
			if(lpDD4!=NULL)
			{
				lpDD4->Release();
				lpDD4=NULL;
			}
		}
	}
	else
	{
		if( lpDD7 != NULL )
		{
			lpDD7->SetCooperativeLevel(win,DDSCL_NORMAL);

			if(lpDDSPrimary7 != NULL )
			{
				lpDDSPrimary7->Release();
				lpDDSPrimary7 = NULL;			
			}

			if(!Fullscreen) 
				if(lpDDSBack7!=NULL) lpDDSBack7->Release();		
			lpDDSBack7=NULL;
			
			if(lpDDPalette!=NULL)
			{
				lpDDPalette->Release();
				lpDDPalette=NULL;
			}

			lpDD7->Release();
			lpDD7 = NULL;
		}
	}

	if ((OwnWindow)&&(win!=0)) 
	{	DestroyWindow(win); win=0;}
	ShowCursor(TRUE);
	DeleteObject(Font);

	Running=0;
}

void DDrawEasy::Print(unsigned x,unsigned y,char *str,unsigned r,unsigned g,unsigned b)
{
	HDC hdc;

	if(CurrentVersion==DDE_DX6)
	{
		if(lpDDSBack->GetDC(&hdc)==DD_OK)
		{
			SelectObject(hdc,Font);
			SetTextColor(hdc, RGB(r,g,b));
			SetBkMode(hdc, TRANSPARENT);
			TextOut(hdc, x, y, str, strlen(str));
			lpDDSBack->ReleaseDC(hdc);
		}
	}
	else
	{
		if(lpDDSBack7->GetDC(&hdc)==DD_OK)
		{
			SelectObject(hdc,Font);
			SetTextColor(hdc, RGB(r,g,b));
			SetBkMode(hdc, TRANSPARENT);
			TextOut(hdc, x, y, str, strlen(str));
			lpDDSBack7->ReleaseDC(hdc);
		}
	}
}

void DDrawEasy::RestorePalette(void)
{
	if(lpDDPalette!=NULL) lpDDPalette->AddRef();
	SetDirectPal(lpDDPalette);
}
#ifndef __DIRECTINPUTEASY_H__
#define __DIRECTINPUTEASY_H__

#include <dinput.h>

#define KEYDOWN(key) (DIE_KBState[key] & 0x80) 

extern char    DIE_KBState[256]; 

void WINAPI DI_Term();
BOOL WINAPI DI_Init(HWND Wnd);
void WINAPI ProcessKBInput();


#endif
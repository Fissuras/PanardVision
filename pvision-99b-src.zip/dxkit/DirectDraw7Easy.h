// DirectDraw7Easy

// Very simple (but useful) Wrapper for DirectDraw7 Interfaces
// Method's names pretty self explanatory

//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.

// This version requires DX7

//
// (C) 1997-98, Olivier Brunet
//

// Last updated : 06/06/1999

// SMKaribou/GMF

#ifndef __DD7EASY_H__
#define __DD7EASY_H__

#define DIRECTDRAW_VERSION		0x0700
#include <ddraw.h>

#ifdef _MSC_VER
#pragma comment(lib,"ddraw.lib")
#pragma comment(lib,"winmm.lib")
#endif

class DDraw7Easy {

public:      // Yeah it's dirty, but It's called DirectDrawEasy, so it should be easy !
	IDirectDraw7 *lpDD;
	HWND win;						// Window to which is attachd the DDraw oject
	IDirectDrawSurface7 *lpDDSPrimary,*lpDDSBack;
	IDirectDrawClipper *lpDDClipper;
	IDirectDrawPalette *lpDDPalette;
	unsigned RedMask,GreenMask,BlueMask,AlphaMask;	
	unsigned Pitch;
	BOOL Fullscreen,OwnWindow;	
	unsigned Width,Height,Depth;
	
private:
	char Running;
	HFONT Font;

	// Methods
public:
	DDraw7Easy();
	~DDraw7Easy();
	int GetMaskSize(unsigned x);
	int GetMaskPos(unsigned x);
	void SetPal(char pal[256*3]);
	void SetDirectPal(IDirectDrawPalette *pal);
	
	// forge a 32bit color value suitable for the fill routine
	unsigned MakeRGBAColor(unsigned char r,unsigned char g,unsigned char b,unsigned char a=255);	
	void Flip(void);
	BYTE *Lock(void);							// Get a pointer on the back buffer
	void Unlock(void);							// Release lock on the back buffer

    // Fill buffers: 0 for backbuffer, 1 for frontbuffer
    void Fill(unsigned bufnum,unsigned top,unsigned left,unsigned bottom,unsigned right,unsigned color);

    // if win is NULL creates a window, if not convert the incoming window to a ddraw window
    // if lpguid is NULL is the default device adaptater, ie the one the desktop is displaying on
    virtual int SetMode(LPGUID lpguid,HWND win,unsigned xres,unsigned yres,unsigned depth,BOOL fullscreen);	
    
	virtual void UnInit(void);

    // Called when the application do nothing put your code here
    virtual int OnIdle(void);
	virtual void Run(void);
	virtual LRESULT UserWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	virtual void Error(char *str);
	void Print(unsigned x,unsigned y,char *str,unsigned r=255,unsigned g=255,unsigned b=255);
	void RestorePalette(void);

	char inline IsRunning(void) {return Running;}
};

// Error codes returned by SetMode
#define DDE_ALREADYINITIALIZED                  1
#define DDE_DDCREATEFAILED						2
#define DDE_REGISTERFAILED						3
#define DDE_CREATEWINDOWFAILED                  4
#define DDE_NOVIDEOMODE							5
#define DDE_PRIMARYFAILED						6
#define DDE_BACKFAILED							7
#define DDE_GETBACKFAILED						8

#endif


// DirectDraw7Easy

// Very simple (but useful) Wrapper for DirectDraw7 Interfaces
// Method's names pretty self explanatory

//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.

// This version requires DX7

//
// (C) 1997-99, Olivier Brunet
//

// SMKaribou/GMF

#define INITGUID
#include "DirectDraw7Easy.h"
#include <stdio.h>
#include <math.h>

DDraw7Easy::DDraw7Easy()
{
	lpDD=NULL;
	lpDDSPrimary=lpDDSBack=NULL;
	lpDDPalette=NULL;
	lpDDClipper=NULL;
	Pitch=0;
	RedMask=GreenMask=BlueMask=AlphaMask=0;
	Fullscreen=FALSE;
	win=0;
	OwnWindow=FALSE;
	Running=0;
}

DDraw7Easy::~DDraw7Easy()
{
	UnInit();
}

int DDraw7Easy::GetMaskSize(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
	}

	while(x&1)
	{
		x>>=1;
		i++;
	}
	return i;
}

int DDraw7Easy::GetMaskPos(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
		i++;
	}

	return i;
}

unsigned DDraw7Easy::MakeRGBAColor(unsigned char r,unsigned char g,unsigned char b,unsigned char a)
{
	unsigned rs,gs,bs,rp,gp,bp,as,ap,rf,gf,bf,af;

	// Looking for the correct color mask					
	rs=GetMaskSize(RedMask);
	gs=GetMaskSize(GreenMask);
	bs=GetMaskSize(BlueMask);
	as=GetMaskSize(AlphaMask);
	rp=GetMaskPos(RedMask);
	gp=GetMaskPos(GreenMask);
	bp=GetMaskPos(BlueMask);
	ap=GetMaskSize(AlphaMask);

    // Compute colors
    rf=r*((1<<rs)-1)/255;
    rf<<=rp;
    bf=b*((1<<bs)-1)/255;
    bf<<=bp;
    gf=g*((1<<gs)-1)/255;
    gf<<=gp;
    af=a*((1<<as)-1)/255;
    af<<=ap;		
	
	return (rf|gf|bf|af);
}

#define BLACK   PALETTERGB(0,0,0)
#define WHITE   PALETTERGB(255,255,255)
#define NUM_STATIC_COLORS   (COLOR_BTNHIGHLIGHT - COLOR_SCROLLBAR + 1)

static COLORREF gacrSave[NUM_STATIC_COLORS];

static COLORREF gacrBlackAndWhite[NUM_STATIC_COLORS] = {
    WHITE,  // COLOR_SCROLLBAR
    BLACK,  // COLOR_BACKGROUND
    BLACK,  // COLOR_ACTIVECAPTION
    WHITE,  // COLOR_INACTIVECAPTION
    WHITE,  // COLOR_MENU
    WHITE,  // COLOR_WINDOW
    BLACK,  // COLOR_WINDOWFRAME
    BLACK,  // COLOR_MENUTEXT
    BLACK,  // COLOR_WINDOWTEXT
    WHITE,  // COLOR_CAPTIONTEXT
    WHITE,  // COLOR_ACTIVEBORDER
    WHITE,  // COLOR_INACTIVEBORDER
    WHITE,  // COLOR_APPWORKSPACE
    BLACK,  // COLOR_HIGHLIGHT
    WHITE,  // COLOR_HIGHLIGHTTEXT
    WHITE,  // COLOR_BTNFACE
    BLACK,  // COLOR_BTNSHADOW
    BLACK,  // COLOR_GRAYTEXT
    BLACK,  // COLOR_BTNTEXT
    BLACK,  // COLOR_INACTIVECAPTIONTEXT
    BLACK   // COLOR_BTNHIGHLIGHT
    };
static INT gaiStaticIndex[NUM_STATIC_COLORS] = {
    COLOR_SCROLLBAR          ,
    COLOR_BACKGROUND         ,
    COLOR_ACTIVECAPTION      ,
    COLOR_INACTIVECAPTION    ,
    COLOR_MENU               ,
    COLOR_WINDOW             ,
    COLOR_WINDOWFRAME        ,
    COLOR_MENUTEXT           ,
    COLOR_WINDOWTEXT         ,
    COLOR_CAPTIONTEXT        ,
    COLOR_ACTIVEBORDER       ,
    COLOR_INACTIVEBORDER     ,
    COLOR_APPWORKSPACE       ,
    COLOR_HIGHLIGHT          ,
    COLOR_HIGHLIGHTTEXT      ,
    COLOR_BTNFACE            ,
    COLOR_BTNSHADOW          ,
    COLOR_GRAYTEXT           ,
    COLOR_BTNTEXT            ,
    COLOR_INACTIVECAPTIONTEXT,
    COLOR_BTNHIGHLIGHT
    };

static BOOL        bSystemColorsInUse = FALSE;
static BOOL        bStaticSaved = FALSE;

static void SaveStaticEntries(HDC hdc)
{
    int i;

    if ( !bSystemColorsInUse )
    {
        for (i = COLOR_SCROLLBAR; i <= COLOR_BTNHIGHLIGHT; i++)
            gacrSave[i - COLOR_SCROLLBAR] = GetSysColor(i);

        bStaticSaved = TRUE;
    }
}

static void UseStaticEntries(HDC hdc)
{
    SetSysColors(NUM_STATIC_COLORS, gaiStaticIndex, gacrBlackAndWhite);
    bSystemColorsInUse = TRUE;

    PostMessage(HWND_BROADCAST, WM_SYSCOLORCHANGE, 0, 0);
}

static void RestoreStaticEntries(HDC hdc)
{
    if ( bStaticSaved )
    {
        SetSysColors(NUM_STATIC_COLORS, gaiStaticIndex, gacrSave);
        bSystemColorsInUse = FALSE;

        PostMessage(HWND_BROADCAST, WM_SYSCOLORCHANGE, 0, 0);
    }
}

void DDraw7Easy::SetPal(char pal[256*3])
{		
	unsigned i;
	PALETTEENTRY Pal[256];
	
	if(lpDD==NULL) return;	

	if(lpDDPalette!=NULL) 
	{
		lpDDPalette->Release();
		lpDDPalette=NULL;
	}

	//
    // build a 332 palette as the default.
    //
    for (i=0; i<256; i++)
    {
		Pal[i].peRed   = (BYTE)(((i >> 5) & 0x07) * 255 / 7);
		Pal[i].peGreen = (BYTE)(((i >> 2) & 0x07) * 255 / 7);
		Pal[i].peBlue  = (BYTE)(((i >> 0) & 0x03) * 255 / 3);
		Pal[i].peFlags = PC_NOCOLLAPSE;;
    }
	
	if(pal!=NULL)
	{
		if(Fullscreen)
		{
			for(i=0;i<256;i++)
			{
				Pal[i].peRed=pal[i*3];
				Pal[i].peGreen=pal[i*3+1];
				Pal[i].peBlue=pal[i*3+2];
				Pal[i].peFlags=PC_NOCOLLAPSE;
			}
		}
		else
		{
			for(i=0;i<1;i++)
			{
				Pal[i].peFlags=Pal[i+255].peFlags=PC_EXPLICIT;
				Pal[i].peRed=i;
				Pal[i+255].peRed=i+255;			
			}

			for(i=0;i<256;i++) 
			{
				Pal[i].peFlags=PC_NOCOLLAPSE;
				Pal[i].peRed=pal[i*3];
				Pal[i].peGreen=pal[i*3+1];
				Pal[i].peBlue=pal[i*3+2];
			}
		}
	}

    if(!Fullscreen)
    {
        HPALETTE ghPalette;
        LOGPALETTE  pPal;
        HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);      
        
        pPal.palVersion = 0x300;
        pPal.palNumEntries = 256;
        memcpy(pPal.palPalEntry,Pal,sizeof(Pal));
        
        ghPalette=CreatePalette(&pPal);

        SelectPalette(dc, ghPalette, FALSE);
        RealizePalette(dc);
        DeleteDC(dc);
        DeleteObject(ghPalette);
    }

    if(lpDD!=NULL)
		lpDD->CreatePalette(DDPCAPS_8BIT|DDPCAPS_ALLOW256,Pal,&lpDDPalette,NULL); 
	if(lpDDSPrimary!=NULL)
		lpDDSPrimary->SetPalette(lpDDPalette);
	if(lpDDSBack!=NULL)
		lpDDSBack->SetPalette(lpDDPalette);	
}

void DDraw7Easy::SetDirectPal(IDirectDrawPalette *pal)
{
	if(lpDDPalette!=NULL) 
	{
		lpDDPalette->Release();
		lpDDPalette=NULL;
	}
	lpDDPalette=pal;

	if(lpDDSPrimary!=NULL)
		lpDDSPrimary->SetPalette(lpDDPalette);
	if(lpDDSBack!=NULL)
		lpDDSBack->SetPalette(lpDDPalette);		
}

void DDraw7Easy::Flip(void)
{	
	if(lpDDSPrimary==NULL) return;

	if(Fullscreen)
	{
		while( 1 )
			{
				HRESULT ddrval;
				ddrval = lpDDSPrimary->Flip( NULL, 0 );				
				if( ddrval == DD_OK ) break;
				if( ddrval == DDERR_SURFACELOST )
				{
					ddrval = lpDDSPrimary->Restore();
					if( ddrval != DD_OK ) break;					
					ddrval = lpDDSBack->Restore();
					if( ddrval != DD_OK ) break;					
				}
			}
	}
	else
	{
		RECT srcr,dstr;
		POINT pt;

		GetClientRect(win,&srcr);
		pt.x=pt.y=0;
		ClientToScreen(win,&pt);
		dstr=srcr;
		dstr.left+=pt.x;
		dstr.right+=pt.x;
		dstr.top+=pt.y;
		dstr.bottom+=pt.y;
		lpDDSPrimary->Blt(&dstr,lpDDSBack,&srcr,DDBLT_ASYNC,0);
	}
}

BYTE *DDraw7Easy::Lock(void)
{
	DDSURFACEDESC2 ddsd;
	HRESULT hr;

	if(lpDDSBack==NULL) return NULL;
	
	ddsd.dwSize=sizeof(ddsd);

	hr=lpDDSBack->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR/*|DDLOCK_WRITEONLY|DDLOCK_NOSYSLOCK*/,NULL);
	if(hr!=DD_OK) ddsd.lpSurface=NULL;
	return (BYTE *)ddsd.lpSurface;
}

void DDraw7Easy::Unlock(void)
{
	if(lpDDSBack==NULL) return;
	lpDDSBack->Unlock(NULL);
}

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    DDraw7Easy *dd;
	HRESULT hr;

	dd=(DDraw7Easy*)GetWindowLong(hwnd,0);

	switch (msg)
    {        
	case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
	     return FALSE;
		 break;
	case WM_KEYDOWN:
		// The esc key will quit the application as well
		if((int)wParam==VK_ESCAPE) 
		{
			PostQuitMessage(0);
			return 0L;
		}
		break;
	case WM_QUERYNEWPALETTE:
        //
        //  we are getting the palette focus, select our palette
        //
		if(dd!=NULL)
		{
			if((!dd->Fullscreen)&&(dd->Depth==8))
			{
				hr=dd->lpDDSPrimary->SetPalette(dd->lpDDPalette);
				if(hr==DDERR_SURFACELOST)
				{
					dd->lpDDSPrimary->Restore();
					dd->lpDDSPrimary->SetPalette(dd->lpDDPalette);
				}
			}
			return 0;
		}
		break;
		
    case WM_MOVE:if((dd!=NULL)&&(dd->IsRunning())) dd->OnIdle();break;
	case WM_CLOSE:
    case WM_DESTROY:
            PostQuitMessage(0);
            return 0L;
    }
	
	if(dd!=NULL)
	{
		if(dd->UserWindowProc(hwnd,msg,wParam,lParam)!=0) return 1;
	}

    return DefWindowProc(hwnd, msg, wParam, lParam);
}

LRESULT DDraw7Easy::UserWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

int DDraw7Easy::OnIdle(void)
{
	return TRUE;
}

void DDraw7Easy::Run(void)
{
	MSG      msg;
	unsigned t=0,p;

	Running=1;
    while (TRUE)
    {
        if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            /*
             * Message pending. If its QUIT then exit the message
             * loop. Otherwise, process the message.
             */
            if (WM_QUIT == msg.message)
            {
                break;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }

		// No more than 70Hz refresh
		p=timeGetTime();
		if(p-t>1000/70)
		{
			if(OnIdle()==FALSE) break;
			t=p;
		}
	}
}

void DDraw7Easy::Error(char *str)
{
	if(lpDD!=NULL) lpDD->SetCooperativeLevel(win, DDSCL_NORMAL);
	MessageBox(win,str,"Direct Draw Error",MB_ICONERROR|MB_OK|MB_TASKMODAL);
	UnInit();			
}

int DDraw7Easy::SetMode(LPGUID lpguid,HWND _win,unsigned xres,unsigned yres,unsigned depth,BOOL fullscreen)
{
	DDSURFACEDESC2 ddsd;
	DDSCAPS2 ddscaps;
	GUID NullGUID={0,0,0,0,0,0,0,0,0,0,0};
	HRESULT hr;
	
	// Object already initialized
	if (lpDD!=NULL) return DDE_ALREADYINITIALIZED;

	// If handle is null, create a new window
	if(_win==NULL)
	{
		WNDCLASS    wc;	
		// Register Main Window Class
		wc.style            = CS_DBLCLKS; 
		wc.lpfnWndProc      = (WNDPROC)WindowProc; 
		wc.cbClsExtra       = 0; 
		wc.cbWndExtra       = sizeof(DDraw7Easy*);
		wc.hInstance        = GetModuleHandle(NULL); 
		wc.hIcon            = NULL;
		wc.hCursor          = NULL;
		wc.hbrBackground    = (HBRUSH)GetStockObject (WHITE_BRUSH);
		wc.lpszMenuName     = NULL; 
		wc.lpszClassName    = "DDEASY"; 

		if (! RegisterClass (&wc)) 
		{
			Error("Cannot register window class");
			return DDE_REGISTERFAILED;
		}
    
		//
		// Create Main Window
		//
		RECT r;
		DWORD style=WS_OVERLAPPED | WS_SYSMENU |WS_VISIBLE| WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;

		r.left=0;
		r.top=0;
		r.bottom=yres;
		r.right=xres;

		AdjustWindowRect(&r,style,FALSE);

		_win = CreateWindow (	   "DDEASY",
								   "Panard Vision Test",
								   style,
								   r.left,r.top,r.right,r.bottom,
								   NULL,
								   NULL,
								   GetModuleHandle(NULL),
								   NULL
								   );
		if (_win==NULL) 
		{
			Error("Cannot create window");
			return DDE_CREATEWINDOWFAILED;
		}
		
		SetWindowLong(_win,0,(long)this);
		
		UpdateWindow(_win);
		SetFocus(_win);

		OwnWindow=TRUE;
	}
	
	this->win=_win;
	Width=xres;
	Height=yres;
	Depth=depth;

	// Wonderful DirectDraw world 	
	if(lpguid!=NULL)
		if(memcmp(lpguid,&NullGUID,sizeof(GUID))==0) 
		{
			lpguid=NULL;
		}
	if(!fullscreen) 
	{
		lpguid=NULL;
		HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);
		Depth=GetDeviceCaps(dc,BITSPIXEL);
		DeleteDC(dc);
	}

	if(!FAILED(DirectDrawCreateEx( lpguid,(LPVOID*) &lpDD, IID_IDirectDraw7, NULL )))
	{		
		// lpDD is a valid DirectDraw object
		if(fullscreen)
		{
			lpDD->SetCooperativeLevel( win, DDSCL_SETFOCUSWINDOW);

			hr=lpDD->SetCooperativeLevel(win, DDSCL_SETDEVICEWINDOW |DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT  );
			if(FAILED(hr))
			{
				// not successful
				// however, the application can still run				
				lpDD->SetCooperativeLevel(win, DDSCL_NORMAL);
			}
		}
		else hr=lpDD->SetCooperativeLevel(win, DDSCL_NORMAL);
	}
	else 
	{
		Error("Unable to create DirectDraw Object");
		return DDE_DDCREATEFAILED;
	}	
		
	if(fullscreen)
		if( lpDD->SetDisplayMode( Width, Height, Depth,0 ,0) != DD_OK )
		{
			UnInit();		
			Error("Unable to switch to requested video mode");
			return DDE_NOVIDEOMODE;
		}
	
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof( ddsd );
	
	if(fullscreen)
	{
		// Primary & back buffer
		ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
		ddsd.dwBackBufferCount = 1;
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
							  DDSCAPS_FLIP |
							  DDSCAPS_COMPLEX |
							  DDSCAPS_VIDEOMEMORY|DDSCAPS_3DDEVICE;
		if( lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL ) != DD_OK )
		{
			ddsd.ddsCaps.dwCaps &= ~DDSCAPS_VIDEOMEMORY;
			if( lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL ) != DD_OK )
			{
				UnInit();
				Error("Unable to create primary surface");
				return DDE_PRIMARYFAILED;		
			}
		}

		// Gets BackBuffer for fullscreen
		ZeroMemory(&ddscaps, sizeof(ddscaps));
		ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
		if( lpDDSPrimary->GetAttachedSurface( &ddscaps, &lpDDSBack ) != DD_OK )
		{
			UnInit();
			Error("Unable to get the back buffer");
			return DDE_GETBACKFAILED;
		}
	}
	else
	{
		// Primary
		ddsd.dwFlags = DDSD_CAPS;
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE|DDSCAPS_3DDEVICE;

		if( lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL ) != DD_OK )
		{
			// surface was not created
			UnInit();
			Error("Unable to create primary surface");
			return DDE_PRIMARYFAILED;
		}

		// Backbuffer
		ddsd.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN|DDSCAPS_3DDEVICE;
		ddsd.dwWidth=xres;
		ddsd.dwHeight=yres;

		if( lpDD->CreateSurface( &ddsd, &lpDDSBack, NULL ) != DD_OK )
		{
			// surface was not created
			UnInit();
			Error("Unable to create back buffer");		
			return DDE_BACKFAILED;
		}

		lpDD->CreateClipper(0,&lpDDClipper,NULL);
		lpDDClipper->SetHWnd(0, win);			
		lpDDSPrimary->SetClipper(lpDDClipper);
		lpDDClipper->Release();
	}

	// Gets pixel format for RGB modes
	DDPIXELFORMAT       ddpf;
	ZeroMemory(&ddpf, sizeof(ddpf));
    ddpf.dwSize = sizeof(ddpf);
    lpDDSPrimary->GetPixelFormat(&ddpf);

	if (ddpf.dwRGBBitCount != 8) {
		
        RedMask= ddpf.dwRBitMask;
		GreenMask = ddpf.dwGBitMask;
		BlueMask = ddpf.dwBBitMask;

		// ATTENTION: Here we do not return the Alpha Mask
		// From DDRAW, since what is interesting is the place left in the pixel
		// and ddraw don't return this as the alpha channel since it's not really usable 
		// as alpha values for him
		// Gets the number of alpha bits
		double tmp=pow(2,ddpf.dwRGBBitCount)-1;		// some trouble with integer arithmetic so use heavy tools
		AlphaMask = ~(RedMask|GreenMask|BlueMask);
		AlphaMask &=(unsigned)tmp;
	}	

	// Gets pitch
	ddsd.dwSize=sizeof(ddsd);		
	lpDDSBack->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR/*DDLOCK_NOSYSLOCK*/,NULL);
	lpDDSBack->Unlock(NULL);
	Pitch=ddsd.lPitch;
	
	Fullscreen=fullscreen;
	
	// Shut up stupid mouse
	if(fullscreen) while(ShowCursor(FALSE) >= 0);	

	// Finally sets up a font
	Font = CreateFont(Width < 640 ? 24/2 : 48/3,
    0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
    ANSI_CHARSET,
    OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    NONANTIALIASED_QUALITY,
    VARIABLE_PITCH,
    "Comic Sans MS");

	// Sets a default Palette
	if((Depth==8)&&(!fullscreen))
    {        
        HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);

        SaveStaticEntries( dc );
        SetSystemPaletteUse( dc, SYSPAL_NOSTATIC );

        SetPal(NULL);

        UseStaticEntries( dc );
        DeleteDC(dc);
    }

	return 0;
}

void DDraw7Easy::Fill(unsigned bufnum,unsigned top,unsigned left,unsigned bottom,unsigned right,unsigned color)
{
	RECT RSource;
	DDBLTFX ddbltfx;         	
	HRESULT hr;

	RSource.left = left;
    RSource.top = top;
    RSource.right = right;
    RSource.bottom = bottom;

    ddbltfx.dwSize = sizeof(ddbltfx);
    ddbltfx.dwFillColor = color;

	switch(bufnum)
	{
	case 0:if(lpDDSBack!=NULL)
		   {
			   while(lpDDSBack->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
			   hr=lpDDSBack->Blt(&RSource,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx);
		   }
		break;
	case 1:if(lpDDSPrimary!=NULL)
		   {
			   while(lpDDSPrimary->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
			   hr=lpDDSPrimary->Blt(&RSource,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx);
		   }
		break;
	}    
}

void DDraw7Easy::UnInit(void)
{
	HDC dc=CreateDC("DISPLAY",NULL,NULL,NULL);
    
    SetSystemPaletteUse( dc, SYSPAL_STATIC );
    RestoreStaticEntries(dc);
    
    DeleteDC(dc);

    // Kills DDraw objects
	if( lpDD != NULL )
    {
        lpDD->SetCooperativeLevel(win,DDSCL_NORMAL);

		if(lpDDSPrimary != NULL )
        {
            lpDDSPrimary->Release();
            lpDDSPrimary = NULL;			
        }

		if(!Fullscreen) 
			if(lpDDSBack!=NULL) lpDDSBack->Release();		
		lpDDSBack=NULL;
		
		if(lpDDPalette!=NULL)
		{
			lpDDPalette->Release();
			lpDDPalette=NULL;
		}

		lpDD->Release();
        lpDD = NULL;
	}

	if ((OwnWindow)&&(win!=0)) 
	{	DestroyWindow(win); win=0;}
	ShowCursor(TRUE);
	DeleteObject(Font);

	Running=0;
}

void DDraw7Easy::Print(unsigned x,unsigned y,char *str,unsigned r,unsigned g,unsigned b)
{
	HDC hdc;

	if(lpDDSBack->GetDC(&hdc)==DD_OK)
	{
		SelectObject(hdc,Font);
		SetTextColor(hdc, RGB(r,g,b));
		SetBkMode(hdc, TRANSPARENT);
		TextOut(hdc, x, y, str, strlen(str));
		lpDDSBack->ReleaseDC(hdc);
	}
}

void DDraw7Easy::RestorePalette(void)
{
	if(lpDDPalette!=NULL) lpDDPalette->AddRef();
	SetDirectPal(lpDDPalette);
}
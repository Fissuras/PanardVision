//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dxmenu.rc
//
#define IDD_DXMENU                      129
#define IDC_DDDEVICE                    1000
#define IDC_WINDOWED                    1001
#define IDC_DDMODE                      1002
#define IDC_WIDTH                       1003
#define IDC_HEIGHT                      1004
#define IDC_BUTTON1                     1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

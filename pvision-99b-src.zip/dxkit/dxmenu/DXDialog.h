#if !defined(AFX_DXDIALOG_H__B1C269C1_638A_11D1_B003_444553540000__INCLUDED_)
#define AFX_DXDIALOG_H__B1C269C1_638A_11D1_B003_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DXDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDXDialog dialog

#include "dxmen.h"

class CDXDialog : public CDialog
{
// Construction
public:
	DDInfo DDI;
	CDXDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDXDialog)
	enum { IDD = IDD_DXMENU };
	CEdit	m_Width;
	CEdit	m_Height;
	CButton	m_Windowed;
	CComboBox	m_DDModes;
	CComboBox	m_DDDevices;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDXDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDXDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeDddevice();
	afx_msg void OnWindowed();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DXDIALOG_H__B1C269C1_638A_11D1_B003_444553540000__INCLUDED_)

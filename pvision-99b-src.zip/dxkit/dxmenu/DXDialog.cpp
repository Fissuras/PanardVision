// DirectX Setup Dialog Box
// (C) 1997, Olivier Brunet
// SMKaribou/GMF


// DXDialog.cpp : implementation file
//

#include "stdafx.h"
#include "dxmenu.h"
#include "DXDialog.h"
#include "ddriver.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDXDialog dialog


CDXDialog::CDXDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CDXDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDXDialog)
	//}}AFX_DATA_INIT
}


void CDXDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDXDialog)
	DDX_Control(pDX, IDC_WIDTH, m_Width);
	DDX_Control(pDX, IDC_HEIGHT, m_Height);
	DDX_Control(pDX, IDC_WINDOWED, m_Windowed);
	DDX_Control(pDX, IDC_DDMODE, m_DDModes);
	DDX_Control(pDX, IDC_DDDEVICE, m_DDDevices);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDXDialog, CDialog)
	//{{AFX_MSG_MAP(CDXDialog)
	ON_CBN_SELCHANGE(IDC_DDDEVICE, OnSelchangeDddevice)
	ON_BN_CLICKED(IDC_WINDOWED, OnWindowed)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDXDialog message handlers

BOOL CDXDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	// Enumerates DDraw devices
	EnumerateDDDevices();
	POSITION pos = DDDevices.GetHeadPosition();
	while( pos != NULL )
	{
		DDDriverInfo* mi = (DDDriverInfo*)DDDevices.GetNext( pos );
		m_DDDevices.AddString(mi->lpDesc);
	}

	m_DDDevices.SetCurSel(0);
	OnSelchangeDddevice();

	m_Width.SetWindowText("320");
	m_Height.SetWindowText("200");

	// Read Data from registry
	HKEY key;

	if(RegOpenKeyEx(HKEY_CURRENT_USER,"Software\\Panard Soft\\DXMenu",0,KEY_READ,&key)==ERROR_SUCCESS)
	{
		DDInfo DDI;
		unsigned long s;
		unsigned b;
		char tmp[255];

		s=sizeof(DDI.Width);
		RegQueryValueEx(key,"Width",0,NULL,(unsigned char*)&DDI.Width,&s);
		s=sizeof(DDI.Height);
		RegQueryValueEx(key,"Height",0,NULL,(unsigned char*)&DDI.Height,&s);		
		s=sizeof(b);
		RegQueryValueEx(key,"Windowed",0,NULL,(unsigned char*)&b,&s);
		DDI.Windowed=(bool)b;
		
		sprintf(tmp,"%u",DDI.Width);
		m_Width.SetWindowText(tmp);
		sprintf(tmp,"%u",DDI.Height);
		m_Height.SetWindowText(tmp);
		m_Windowed.SetCheck(DDI.Windowed);
		OnWindowed();

		s=sizeof(b);
		RegQueryValueEx(key,"GUID",0,NULL,(unsigned char*)&b,&s);
		m_DDDevices.SetCurSel(b);
		OnSelchangeDddevice();

		s=sizeof(b);
		RegQueryValueEx(key,"Mode",0,NULL,(unsigned char*)&b,&s);
		m_DDModes.SetCurSel(b);
		
		RegCloseKey(key);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDXDialog::OnSelchangeDddevice() 
{
	// TODO: Add your control notification handler code here	
	char zob[255];

	m_DDModes.ResetContent();

	if(m_DDDevices.GetCurSel()!=CB_ERR)
	{
		LPGUID lpGuid=&((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(m_DDDevices.GetCurSel())))->GUID;

		if(!(((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(m_DDDevices.GetCurSel())))->CanRenderWindowed))
		{
			m_Windowed.EnableWindow(FALSE);
			m_Windowed.SetCheck(FALSE);
		}
		else
			m_Windowed.EnableWindow(TRUE);

		// modes list
		EnumerateDDModes(lpGuid,m_hWnd);
		POSITION pos = DDModeList.GetHeadPosition();
		while( pos != NULL )
		{
			DDModeInfo* mi = (DDModeInfo*)DDModeList.GetNext( pos );
			wsprintf(zob,"%ux%u %u bits",mi->Width,mi->Height,mi->RGBBitCount);

			m_DDModes.AddString(zob);
		}
	}
	m_DDModes.SetCurSel(0);	
}

void CDXDialog::OnWindowed() 
{
	// TODO: Add your control notification handler code here
	if(m_Windowed.GetCheck()==1)
	{
		// Checked
		m_Width.EnableWindow(TRUE);
		m_Height.EnableWindow(TRUE);		
		m_DDModes.EnableWindow(FALSE);
		m_DDDevices.EnableWindow(FALSE);
	}
	else
	{
		m_Width.EnableWindow(FALSE);
		m_Height.EnableWindow(FALSE);
		m_DDModes.EnableWindow(TRUE);
		m_DDDevices.EnableWindow(TRUE);
	}

}

void CDXDialog::OnOK() 
{
	// TODO: Add extra validation here
	if(m_DDDevices.GetCurSel()==CB_ERR) 
	{
		DDI.Depth=0;
		return;
	}

	DDI.GUID=((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(m_DDDevices.GetCurSel())))->GUID;
	LPGUID lpGuid=&((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(m_DDDevices.GetCurSel())))->GUID;

	if(DDI.Windowed=m_Windowed.GetCheck())
	{
		CString str;

		m_Width.GetWindowText(str);
		DDI.Width=atoi(LPCSTR(str));
		m_Height.GetWindowText(str);
		DDI.Height=atoi(LPCSTR(str));

		DDI.Depth=0;
		
		// Retrieve depth of primary surface
		DDSURFACEDESC ddsd;		
		IDirectDraw *lpDD;
		IDirectDrawSurface *lpDDSPrimary;
		GUID NullGUID={0,0,0,0,0,0,0,0,0,0,0};

		LPGUID lpGuid=&((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(m_DDDevices.GetCurSel())))->GUID;
		
		HRESULT hr;
		
		if(memcmp(&DDI.GUID,&NullGUID,sizeof(GUID))==0)
			hr=DirectDrawCreate(NULL, &lpDD, NULL );
		else
			hr=DirectDrawCreate(lpGuid, &lpDD, NULL );
		if(hr== DD_OK)
		{
			lpDD->SetCooperativeLevel(0, DDSCL_NORMAL);
			
			ddsd.dwSize = sizeof( ddsd );
			ddsd.dwFlags = DDSD_CAPS;
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE|DDSCAPS_3DDEVICE;

			if( (lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL )) != DD_OK )
			{
				lpDD->Release();
			}
			else
			{
				// Gets pixel format for RGB modes
				DDPIXELFORMAT       ddpf;
				ddpf.dwSize = sizeof(ddpf);
				lpDDSPrimary->GetPixelFormat(&ddpf);

				DDI.Depth=ddpf.dwRGBBitCount;

				lpDDSPrimary->Release();
				lpDD->Release();
			}
		}		
	}
	else
	{
		DDI.Width=((DDModeInfo*)DDModeList.GetAt(DDModeList.FindIndex(m_DDModes.GetCurSel())))->Width;
		DDI.Height=((DDModeInfo*)DDModeList.GetAt(DDModeList.FindIndex(m_DDModes.GetCurSel())))->Height;
		DDI.Depth=((DDModeInfo*)DDModeList.GetAt(DDModeList.FindIndex(m_DDModes.GetCurSel())))->RGBBitCount;
	}

	// Save values into registry
	HKEY key;
	unsigned m;
	RegCreateKeyEx(HKEY_CURRENT_USER,"Software\\Panard Soft\\DXMenu",0,"",REG_OPTION_NON_VOLATILE,KEY_WRITE,NULL,&key,NULL);
	RegSetValueEx(key,"Width",0,REG_DWORD,(unsigned char*)&DDI.Width,sizeof(DDI.Width));
	RegSetValueEx(key,"Height",0,REG_DWORD,(unsigned char*)&DDI.Height,sizeof(DDI.Height));
	m=DDI.Windowed;
	RegSetValueEx(key,"Windowed",0,REG_DWORD,(unsigned char*)&m,sizeof(m));
	m=m_DDModes.GetCurSel();
	RegSetValueEx(key,"Mode",0,REG_DWORD,(unsigned char*)&m,sizeof(m));
	m=m_DDDevices.GetCurSel();
	RegSetValueEx(key,"GUID",0,REG_DWORD,(unsigned char*)&m,sizeof(m));	
	RegCloseKey(key);
	
	CDialog::OnOK();
}

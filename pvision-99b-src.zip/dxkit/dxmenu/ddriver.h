#ifndef __DDRIVER_H__
#define __DDRIVER_H__

#include <afxcoll.h>
#define DIRECTDRAW_VERSION		0x300
#include <ddraw.h>
#include <d3d.h>

struct DDDriverInfo {
	GUID	GUID;
	LPSTR	lpDesc;
	LPSTR	lpName;
	bool	CanRenderWindowed;
};

struct DDModeInfo
{
	unsigned RGBBitCount;
	unsigned Width,Height;
};

extern CPtrList DDDevices;
extern CPtrList DDModeList;
extern CPtrList D3DDevices;

void EnumerateDDDevices();
void EnumerateDDModes(LPGUID lpGUID,HWND wnd);
void EnumerateD3DDevices(LPGUID lpGUID);

#endif
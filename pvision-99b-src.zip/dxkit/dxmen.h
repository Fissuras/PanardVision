// DirectX Setup Dialog Box
// (C) 1997-99, Olivier Brunet
// SMKaribou/GMF

#ifndef __DXMEN_H__
#define __DXMEN_H__

#include <objbase.h>

struct DDInfo {
	GUID	GUID;
	bool	Windowed;
	unsigned Width;
	unsigned Height;
	unsigned Depth;
};

extern "C" {
__declspec(dllimport) DDInfo *__stdcall DoDXMenu(void);
}

#ifdef _MSC_VER
#pragma comment(lib,"dxmenu.lib")
#endif

#endif

// DirectDrawEasy

// Very simple (but useful) Wrapper for DirectDraw3 Interfaces
// Method's names pretty self explanatory

//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.

// This version requires DX3 to run, DX7 to compile 
// and benefits from multimonitoring support with DX6

//
// (C) 1997-2000, Olivier Brunet
//

// Last updated : 29/11/1999

// SMKaribou/GMF

#ifndef __DDEASY_H__
#define __DDEASY_H__

#define DIRECTDRAW_VERSION		0x0700
#include <ddraw.h>

#ifdef _MSC_VER
#pragma comment(lib,"ddraw.lib")
#pragma comment(lib,"winmm.lib")
#endif

#define DDE_DX7	1
#define DDE_DX6	2

class DDrawEasy {

public:      // Yeah it's dirty, but It's called DirectDrawEasy, so it should be easy !
	IDirectDraw *lpDD;
	union {
		IDirectDraw4 *lpDD4;
		IDirectDraw7 *lpDD7;
	};
	HWND win;						// Window to which is attachd the DDraw oject
	union {
		IDirectDrawSurface *lpDDSPrimary;
		IDirectDrawSurface7 *lpDDSPrimary7;
	};
	union {
		IDirectDrawSurface *lpDDSBack;
		IDirectDrawSurface7 *lpDDSBack7;
	};

	IDirectDrawClipper *lpDDClipper;
	IDirectDrawPalette *lpDDPalette;
	unsigned RedMask,GreenMask,BlueMask,AlphaMask;	
	unsigned Pitch;
	BOOL Fullscreen,OwnWindow;	
	unsigned Width,Height,Depth;
	unsigned CurrentVersion;
	
private:
	char Running;
	HFONT Font;

	// Methods
public:
	DDrawEasy();
	~DDrawEasy();
	int GetMaskSize(unsigned x);
	int GetMaskPos(unsigned x);
	void SetPal(char pal[256*3]);
	void SetDirectPal(IDirectDrawPalette *pal);
	
	// forge a 32bit color value suitable for the fill routine
	unsigned MakeRGBAColor(unsigned char r,unsigned char g,unsigned char b,unsigned char a=255);	
	void Flip(void);
	BYTE *Lock(void);							// Get a pointer on the back buffer
	void Unlock(void);							// Release lock on the back buffer

    // Fill buffers: 0 for backbuffer, 1 for frontbuffer
    void Fill(unsigned bufnum,unsigned top,unsigned left,unsigned bottom,unsigned right,unsigned color);

    // if win is NULL creates a window, if not convert the incoming window to a ddraw window
    // if lpguid is NULL is the default device adaptater, ie the one the desktop is displaying on
    virtual int SetMode(LPGUID lpguid,HWND win,unsigned xres,unsigned yres,unsigned depth,BOOL fullscreen);	
    
	virtual void UnInit(void);

    // Called when the application do nothing put your code here
    virtual int OnIdle(void);
	virtual void Run(void);
	virtual LRESULT UserWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	virtual void Error(char *str);
	void Print(unsigned x,unsigned y,char *str,unsigned r=255,unsigned g=255,unsigned b=255);
	void RestorePalette(void);

	char inline IsRunning(void) {return Running;}
};

// Error codes returned by SetMode
#define DDE_ALREADYINITIALIZED                  1
#define DDE_DDCREATEFAILED						2
#define DDE_REGISTERFAILED						3
#define DDE_CREATEWINDOWFAILED                  4
#define DDE_NOVIDEOMODE							5
#define DDE_PRIMARYFAILED						6
#define DDE_BACKFAILED							7
#define DDE_GETBACKFAILED						8

#endif


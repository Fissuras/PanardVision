                        Simple DirectDraw Wrapper
                       (C) 1998-99, Olivier Brunet

I/ What is it ?
---------------
   This is a C++ class to encapsulate DirectDraw objects. It permits very
simple screen management (Full screen or windowed, RGB or paletized)
abstracting you from the DirectDraw world.
   This class requires DX3 to run and DX7 to compile, it also benefits from
multimonitor support when running with DX6.

II/ How to use it ?
-------------------
   See minimal.cpp and DirectDrawEasy.h.

   If you use the DoDXMenu() call, you must have the dxmenu.dll file in
the application directory.

   For more examples, see the Panard Vision 3D Engine SDK.

   All the stuffs have been created/tested/compiled with Visual C 6 and
the DX7 SDK. But it may work with orther compilers too.

IV/ Contact
------------
If you find bugs, make improvements, have comments or whatever you may
think about regarding this package contact me at:
		pvision@panardvision.com                

Don't forget to visit the Panard Vision Home Page for updates:
        http://www.panardvision.com/

And the GMF Homepage:
	http://gmf.planet-d.net/

                                                SMKaribou/GMF                                                                        

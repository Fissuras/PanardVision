// DirectDrawEasy Sample
// (C) 1998, Olivier Brunet

// SMKaribou/GMF

#include <stdio.h>
#include "..\DirectDrawEasy.h"
#include "..\DXMen.h"

class DDEasy:public DDrawEasy
{
public:
	int OnIdle(void);
};

///////////////////////////////////////////////////////////////////////////////

int DDEasy::OnIdle(void)
{		
	unsigned char *ScrBuf;
	static char val=0x10;
	
	val^=0x70;
	
	Fill(0,0,0,Height,Width,0);			// Fill backbuffer to black

	// The Lock primitives gives access to the DirectDraw surface
	// The surface should be unlocked ASAP!
	ScrBuf=Lock();
	
	memset(ScrBuf,val,Pitch*Height);	// The pitch is the size in Bytes of a scanline in video memory
										// It's not the size of the visible portion of a scanline										
	Unlock();

	Print(0,0,"ALT+F4 to quit",255,0,0);
		
	Flip();								// Flips the two pages, make the back buffer visible

	return TRUE;
}

//////////////////////////////////////////////////////////////

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	DDEasy pve;
	DDInfo *ddi;

	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Some nice things
	pve.Run();

	return 0;
}

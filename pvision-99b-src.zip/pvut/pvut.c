/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
// Utilities Library
//
// Before using this library consult the LICENSE file

#define PVMEM_OVERLOAD
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "pvut.h"

static PVWorld *Wor;

//********************************************************************************************
//************************************** JPEG Loading
//********************************************************************************************

// JPEG
#ifdef __cplusplus
extern "C" {
#endif
#include "jpeglib.h"
#ifdef __cplusplus
}
#endif
#include <setjmp.h>

struct my_error_mgr {
  struct jpeg_error_mgr pub;	/* "public" fields */

  jmp_buf setjmp_buffer;	/* for return to caller */
};

typedef struct my_error_mgr * my_error_ptr;

static void my_error_exit (j_common_ptr cinfo)
{
  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  (*cinfo->err->output_message) (cinfo);

  longjmp(myerr->setjmp_buffer, 1);
}

int PVAPI pvuLoadJpeg(char * filename,PVMaterial *m)
{
  struct jpeg_decompress_struct cinfo;
  struct my_error_mgr jerr;
  FILE * infile;		/* source file */
  char **buffer;
  char *buffer2;
  int row_stride;		/* physical row width in output buffer */
  unsigned i;

#ifdef __PVUT_VERBOSE__
  printf("Loading %s for %s...\n", filename, m->Name);
#endif

  if ((infile = fopen(filename, "rb")) == NULL)
	{
#ifdef __PVUT_VERBOSE__
		printf("Error opening %s, aborting.\n",filename);
#endif
		return FILE_IOERROR;
	}

  cinfo.err = jpeg_std_error(&jerr.pub);
  jerr.pub.error_exit = my_error_exit;
  if (setjmp(jerr.setjmp_buffer)) {
    jpeg_destroy_decompress(&cinfo);
    fclose(infile);
    return BIZAR_ERROR;
  }
  jpeg_create_decompress(&cinfo);

  jpeg_stdio_src(&cinfo, infile);

  (void) jpeg_read_header(&cinfo, 1);

  cinfo.out_color_space=JCS_RGB;

  (void) jpeg_start_decompress(&cinfo);

  row_stride = cinfo.output_width * cinfo.output_components;

  buffer=(char**)malloc(cinfo.output_height*sizeof(void*));
  if(buffer==NULL) return NO_MEMORY;

  buffer2=(char*)malloc(row_stride*cinfo.output_height);
  if(buffer2==NULL) return NO_MEMORY;

  for(i=0;i<cinfo.output_height;i++) buffer[i]=&buffer2[i*row_stride];

#ifdef __PVUT_VERBOSE__
  printf("\t %dx%d %d channels image.\n",cinfo.output_width,cinfo.output_height,cinfo.output_components);
#endif
  if(cinfo.output_components!=3) return BAD_FILE_FORMAT;

  while (cinfo.output_scanline < cinfo.output_height) {
    jpeg_read_scanlines(&cinfo, (unsigned char**)&buffer[cinfo.output_scanline],1);
  }

  (void) jpeg_finish_decompress(&cinfo);
  jpeg_destroy_decompress(&cinfo);

  fclose(infile);

  free(buffer);
  if(PV_SetMaterialTexture(m,cinfo.output_width,cinfo.output_height,(unsigned char *)buffer2,0)!=COOL) return BAD_FILE_FORMAT;
  REMOVEFLAG(m->TextureFlags,TEXTURE_PALETIZED8);
  ADDFLAG(m->TextureFlags,TEXTURE_RGB);

  return COOL;
}

//********************************************************************************************
//************************************** RAW Loading
//********************************************************************************************

static int filesize(FILE *fp)
{
    int sp,sf;

    sp=ftell(fp);
    fseek(fp,0L,SEEK_END);
    sf=ftell(fp);
    fseek(fp,sp,SEEK_SET);
    return sf;
}

int PVAPI pvuLoadRaw(char *na,PVMaterial *mat)
{
    FILE *f;
    unsigned long n;
    UPVD8 *t=NULL;
    PVRGB *pal=NULL;

    if ((f=fopen(na,"rb"))==NULL)
	{
#ifdef __PVUT_VERBOSE__
		printf("Error opening %s, aborting.\n",na);
#endif
		return FILE_IOERROR;
	}

    n=filesize(f);
#ifdef __PVUT_VERBOSE__
	printf("Loading %s(%d) for %s...\n",na,n,mat->Name);
#endif
    if ((t=(UPVD8*)malloc(n))==NULL)
    {
       fclose(f);
	   return NO_MEMORY;
    }
    fread(t,1,n,f);
    fclose(f);

    pal=(PVRGB*)malloc(sizeof(PVRGB)*256);
    memcpy(pal,&t[256*256],256*sizeof(PVRGB));
	if(PV_SetMaterialTexture(mat,256,256,t,pal)!=COOL) return BAD_FILE_FORMAT;

	ADDFLAG(mat->TextureFlags,TEXTURE_PALETIZED8);
    REMOVEFLAG(mat->TextureFlags,TEXTURE_RGB);
	return COOL;
}

int PVAPI pvuLoadBump(char *na,PVMaterial *mat)
{
    UPVD8 *t;
    FILE *f;
    unsigned n;

    if ((f=fopen(na,"rb"))==NULL)
	{
#ifdef __PVUT_VERBOSE__
		printf("Error opening %s, aborting.\n",na);
#endif
		return FILE_IOERROR;
	}
#ifdef __PVUT_VERBOSE__
	printf("Loading %s for %s's bump map...\n",na,mat->Name);
#endif
    n=filesize(f);
    if ((t=(UPVD8*)malloc(n))==NULL) return NO_MEMORY;
    fread(t,n,1,f);
    fclose(f);
    if(PV_BuildBumpMap(mat,t,256,256,1)!=COOL) return NO_MEMORY;
    free(t);
	return COOL;
}

//********************************************************************************************
//************************************** Material File
//********************************************************************************************

static char *ReadLine(FILE *f)
{
    static char b[2048];
    unsigned i=0;

    do
    {
        fscanf(f,"%s",b);
    }
    while(b[0]=='#');

    while(b[i]!=0) {if(b[i]=='$') b[i]=' ';i++;}
#ifdef __UNIX__
    i=0;
    while(b[i]!=0) {if(b[i]=='\\') b[i]='/';i++;}
#endif

    return b;
}

static int DecodeFlags(char *a2)
{
    int flags=0,i;
    
    if(a2!=NULL)
            {
                // convert to upper case
                i=0;
                while(a2[i]!=0) {if((a2[i]>=97)&&(a2[i]<=122)) a2[i]-=32;i++;}
                        
                if(strcmp("NOTHING",a2)==0) flags|=NOTHING;
				if(strcmp("FLAT",a2)==0) flags|=FLAT;
                if(strcmp("GOURAUD",a2)==0) flags|=GOURAUD;
                if(strcmp("PHONG",a2)==0) flags|=PHONG;
                if(strcmp("BUMP",a2)==0) flags|=BUMP;
                if(strcmp("MAPPING",a2)==0) flags|=MAPPING;
                if(strcmp("AMBIENT_MAPPING",a2)==0) flags|=AMBIENT_MAPPING;
                if(strcmp("AUTOMATIC_PERSPECTIVE",a2)==0) flags|=AUTOMATIC_PERSPECTIVE;
                if(strcmp("AUTOMATIC_BILINEAR",a2)==0) flags|=AUTOMATIC_BILINEAR;
                if(strcmp("PERSPECTIVE",a2)==0) flags|=PERSPECTIVE;
                if(strcmp("ZBUFFER",a2)==0) flags|=ZBUFFER;
                if(strcmp("TEXTURE_NONE",a2)==0) flags|=TEXTURE_NONE;
                if(strcmp("TEXTURE_PALETIZED8",a2)==0) flags|=TEXTURE_PALETIZED8;
                if(strcmp("TEXTURE_RGB",a2)==0) flags|=TEXTURE_RGB;
                if(strcmp("TEXTURE_MIPMAP",a2)==0) flags|=TEXTURE_MIPMAP;
                if(strcmp("TEXTURE_BILINEAR",a2)==0) flags|=TEXTURE_BILINEAR;
				if(strcmp("TEXTURE_TRILINEAR",a2)==0) flags|=TEXTURE_TRILINEAR;
				if(strcmp("DOUBLE_SIDED",a2)==0) flags|=DOUBLE_SIDED;
				if(strcmp("WIREFRAME",a2)==0) flags|=WIREFRAME;
            }

    return flags;
}

int PVAPI pvuLoadMaterialsDefinitions(PVWorld *zeworld,char *s,pvuMatInfo *matinfo)
{
    FILE *f;
    char *l,*a1,*a2;
    PVRGBF col,col2,col3;
    unsigned i,flags1,flags2;
    PVMaterial *mat;
	int h;

	if(zeworld==NULL) return ARG_INVALID;
	if((s==NULL)||(strcmp(s,"")==0)) return COOL;

	Wor=zeworld;

	if ((f=fopen(s,"rt"))==NULL) return FILE_IOERROR;
#ifdef __PVUT_VERBOSE__
	printf("Reading %s\n",s);
#endif
    while(!feof(f))
    {
        l=ReadLine(f);

        if(strcmp(l,"END")==0) break;

		if(strcmp(l,"SPEED")==0)
		{
			l=ReadLine(f);
			if(matinfo!=NULL) sscanf(l,"%f",&matinfo->SPEED);
		}

		if(strcmp(l,"CACHESIZE")==0)
		{
			l=ReadLine(f);
			if(matinfo!=NULL) sscanf(l,"%f",&matinfo->CACHESIZE);
		}

		if(strcmp(l,"STEP")==0)
		{
			l=ReadLine(f);
			if(matinfo!=NULL) sscanf(l,"%f",&matinfo->STEP);
		}

        if(strcmp(l,"AMBIENT")==0)
        {
            l=ReadLine(f);
            sscanf(l,"%f",&col.r);
            l=ReadLine(f);
            sscanf(l,"%f",&col.g);
            l=ReadLine(f);
            sscanf(l,"%f",&col.b);
#ifdef __PVUT_VERBOSE__
            printf("Setting ambiant light to (%f,%f,%f)\n",col.r,col.g,col.b);
#endif
            PV_WorldSetAmbientLight(Wor,col);
        }

        if(strcmp(l,"MATERIAL")==0)
        {
            l=ReadLine(f);
            a1=strdup(l);

            l=ReadLine(f);
            a2=strtok(l,"|");
            flags1=DecodeFlags(a2);
            while((a2=strtok(NULL,"|"))!=NULL)
            {
                flags1|=DecodeFlags(a2);
            }

            l=ReadLine(f);
            sscanf(l,"%f",&col.r);
            l=ReadLine(f);
            sscanf(l,"%f",&col.g);
            l=ReadLine(f);
            sscanf(l,"%f",&col.b);

            l=ReadLine(f);
            sscanf(l,"%f",&col2.r);
            l=ReadLine(f);
            sscanf(l,"%f",&col2.g);
            l=ReadLine(f);
            sscanf(l,"%f",&col2.b);

            l=ReadLine(f);
            sscanf(l,"%f",&col3.r);
            l=ReadLine(f);
            sscanf(l,"%f",&col3.g);
            l=ReadLine(f);
            sscanf(l,"%f",&col3.b);

            l=ReadLine(f);
            sscanf(l,"%u",&i);

            l=ReadLine(f);
            a2=strtok(l,"|");
            flags2=DecodeFlags(a2);
            while((a2=strtok(NULL,"|"))!=NULL)
            {
                flags2|=DecodeFlags(a2);
            }
            l=ReadLine(f);

            mat=PV_CreateMaterial(a1,flags1,flags2,0);
            if(mat==NULL) return NO_MEMORY;
            PV_SetMaterialLightInfo(mat,col,col2,col3,i);

			if(flags2&(TEXTURE_RGB|TEXTURE_RGBA|TEXTURE_PALETIZED8))
			{
				// convert to lower case
				i=0;
				while(l[i]!=0) {if((l[i]>=(97-32))&&(l[i]<=(122-32))) l[i]+=32;i++;}
				
				if(strstr(l,".jpg")!=NULL)
				{
					h=pvuLoadJpeg(l,mat);
					if(h==COOL) PV_AddMaterial(Wor,mat);
					else return h;
				}
				else
				{
					h=pvuLoadRaw(l,mat);
					if(h==COOL) PV_AddMaterial(Wor,mat);
					else return h;
				}
			}
			else PV_AddMaterial(Wor,mat);

            l=ReadLine(f);
            if(flags1&(BUMP|U_BUMP))
			{
				h=pvuLoadBump(l,mat);
				if(h!=COOL) return h;
			}
            free(a1);
        }
    }
    fclose(f);

	return COOL;
}

////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// MATERIALS & Meshes

// WARNING: this routine saves a compiled material to reload it later and gain the compile time.
//			the load and save routines are highly correlated, no version checking is done.
//			Hence a material saved by version X of PV may not be readable by a version Y !
//			Error checking is very simple.
int PVAPI pvuSaveCompiledMaterial(PVWorld *Wor,char *matname,char *filename)
{
    FILE *fp;
    int i;
    PVMaterial *mat1;
    char tmp[255];
	unsigned ps;

	if(Wor==NULL) return ARG_INVALID;
	if(matname==NULL) return ARG_INVALID;
	
	mat1=PV_GetMaterialPtrByName(matname,Wor);
	if(mat1==NULL) return ARG_INVALID;

	if(!(mat1->TextureFlags&TEXTURE_PROCESSED)) return ARG_INVALID;

    if(filename==NULL)
	{
		strcpy(tmp,matname);
		strcat(tmp,".mat");
	}
	else
	{
		strcpy(tmp,filename);
	}
    fp=fopen(tmp, "wb");
	if(fp==NULL) return FILE_IOERROR;

	// save the whole material structure including some unuseful infos and
	// bad pointers, but it's just one line of c :)
    fwrite(mat1,sizeof(PVMaterial),1,fp);

    if(mat1->Pal!=NULL) fwrite(mat1->Pal,768,1,fp);   // palette

    // Here is things :)
    // save number of textures in this material
	ps=0;
	if(mat1->TextureFlags&TEXTURE_RGBDIRECT) ps=PixelSize;
	if(mat1->TextureFlags&TEXTURE_RGB) ps=3;
	if(mat1->TextureFlags&TEXTURE_RGBA) ps=4;
	if(mat1->TextureFlags&TEXTURE_PALETIZED8) ps=1;
	if(mat1->TextureFlags&TEXTURE_RGB_A) ps=4;

    for(i=0;i<mat1->NbrMipMaps;i++)
    {
        fwrite(&mat1->Tex[i],sizeof(PVTexture),1,fp);
        fwrite(mat1->Tex[i].Texture,ps*mat1->Tex[i].Width*mat1->Tex[i].Height,1,fp);
    }

	// Then Save the color maps
	if(mat1->PaletteTranscodeTable!=NULL)
		fwrite(mat1->PaletteTranscodeTable,256*256,1,fp); // this one is ALWAYS
                                                          //256*256, and is used only in paletized mode (PVM_PALETIZED8)
	if(mat1->RGB16TranscodeTable!=NULL)
		fwrite(mat1->RGB16TranscodeTable,256*256*2,1,fp); // this one is ALWAYS
                                                          //256*256, but 16 bit and is only used in fake 16 bit modes (PVM_RGB16)
	fclose(fp);
	
	return COOL;
}

int PVAPI pvuLoadCompiledMaterial(PVWorld *w,char *matname,char *filename)
{
    FILE *fp;
    int i;
    PVMaterial *mat1;
    char tmp[255];
	unsigned ps;

	if(w==NULL) return ARG_INVALID;
	if(matname==NULL) return ARG_INVALID;	

    mat1=PV_CreateMaterial("",0,0,0);
    if(mat1==NULL) return NO_MEMORY;

	free(mat1->Name);
	free(mat1->Tex);

    if(filename==NULL)
	{
		strcpy(tmp,matname);
		strcat(tmp,".mat");
	}
	else
	{
		strcpy(tmp,filename);
	}
    fp=fopen(tmp, "rb");


    fread(mat1,sizeof(PVMaterial),1,fp);

    if(mat1->Pal!=NULL)
    {
        mat1->Pal=(PVRGB*)malloc(256*sizeof(PVRGB));
        fread(mat1->Pal,768,1,fp);   // palette
    }

	ps=0;
	if(mat1->TextureFlags&TEXTURE_RGBDIRECT) ps=PixelSize;
	if(mat1->TextureFlags&TEXTURE_RGB) ps=3;
	if(mat1->TextureFlags&TEXTURE_RGBA) ps=4;
	if(mat1->TextureFlags&TEXTURE_PALETIZED8) ps=1;
	if(mat1->TextureFlags&TEXTURE_RGB_A) ps=4;

    if(mat1->NbrMipMaps==0)
        mat1->Tex=(PVTexture*)calloc(1,sizeof(PVTexture));
    else
        mat1->Tex=(PVTexture*)malloc(mat1->NbrMipMaps*sizeof(PVTexture));
    
	for(i=0;i<mat1->NbrMipMaps;i++)
	{
		fread(&mat1->Tex[i],sizeof(PVTexture),1,fp);
		mat1->Tex[i].Texture=(UPVD8*)malloc(ps*mat1->Tex[i].Width*mat1->Tex[i].Height);
		fread(mat1->Tex[i].Texture,ps*mat1->Tex[i].Width*mat1->Tex[i].Height,1,fp);
	}

	// Then Save the color maps
	if(mat1->PaletteTranscodeTable!=NULL)
    {
        mat1->PaletteTranscodeTable=(UPVD8*)malloc(256*256);
        fread(mat1->PaletteTranscodeTable,256*256,1,fp); // this one is ALWAYS
    }
                                                          //256*256, and is used only in paletized mode (PVM_PALETIZED8)
	if(mat1->RGB16TranscodeTable!=NULL)
    {
        mat1->RGB16TranscodeTable=(UPVD16*)malloc(256*256*2);
        fread(mat1->RGB16TranscodeTable,256*256*2,1,fp); // this one is ALWAYS
                                                          //256*256, but 16 bit and is only used in fake 16 bit modes (PVM_RGB16)
    }
	fclose(fp);

    mat1->RefCnt=0;
    mat1->Next=NULL;
	PV_SetMaterialName(mat1,matname);
	mat1->HardwarePrivate=NULL;
	mat1->Filler=NULL;

	PV_FinalizeMaterial(mat1);

    PV_AddMaterial(w,mat1);
	return COOL;
}

static void RecurseSaveBoxes(FILE *fp,PVBox *b)
{
	unsigned i;

	fwrite(b,sizeof(PVBox),1,fp);
	
	if(b->Flags)	
		fwrite(b->FaceIndex,sizeof(unsigned),b->NbrFaces,fp);

	if(!b->Flags)
		for(i=0;i<8;i++)
			if(b->Child[i]!=NULL) RecurseSaveBoxes(fp,b->Child[i]);
}

int PVAPI pvuSaveMeshBBoxes(PVWorld *Wor,char *meshname,char *filename)
{
    FILE *fp;
    PVMesh *me1;
    char tmp[255];	

	if(Wor==NULL) return ARG_INVALID;
	if(meshname==NULL) return ARG_INVALID;
	
	me1=PV_GetMeshPtr(Wor,meshname);
	if(me1==NULL) return ARG_INVALID;

	if(me1->Box==NULL) return ARG_INVALID;

    if(filename==NULL)
	{
		strcpy(tmp,meshname);
		strcat(tmp,".mbb");
	}
	else
	{
		strcpy(tmp,filename);
	}
    
	fp=fopen(tmp, "wb");
	if(fp==NULL) return FILE_IOERROR;

	fwrite(&me1->NodeInfos.NbrBoxes,sizeof(unsigned),1,fp);

	RecurseSaveBoxes(fp,me1->Box);

	fclose(fp);
	
	return COOL;
}

static void RecurseReadBoxes(FILE *fp,PVBox **box)
{
	unsigned i;

	*box=(PVBox*)malloc(sizeof(PVBox));
	
	fread(*box,sizeof(PVBox),1,fp);
	
	if((*box)->Flags)	
	{
		(*box)->FaceIndex=(unsigned*)malloc((*box)->NbrFaces*sizeof(unsigned));
		fread((*box)->FaceIndex,sizeof(unsigned),(*box)->NbrFaces,fp);
	}

	if(!(*box)->Flags)
		for(i=0;i<8;i++)
			if((*box)->Child[i]!=NULL) RecurseReadBoxes(fp,&((*box)->Child[i]));
}

int PVAPI pvuLoadMeshBBoxes(PVWorld *Wor,char *meshname,char *filename)
{
    FILE *fp;
    PVMesh *me1;
    char tmp[255];	

	if(Wor==NULL) return ARG_INVALID;
	if(meshname==NULL) return ARG_INVALID;
	
	me1=PV_GetMeshPtr(Wor,meshname);
	if(me1==NULL) return ARG_INVALID;

	if(me1->Box!=NULL) PV_KillBoxes(me1->Box);
	me1->Box=NULL;

    if(filename==NULL)
	{
		strcpy(tmp,meshname);
		strcat(tmp,".mbb");
	}
	else
	{
		strcpy(tmp,filename);
	}
    
	fp=fopen(tmp, "rb");
	if(fp==NULL) return FILE_IOERROR;

	fread(&me1->NodeInfos.NbrBoxes,sizeof(unsigned),1,fp);

	RecurseReadBoxes(fp,&me1->Box);

	fclose(fp);
	
	return COOL;
}

////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// Teapot (taken and adapted from Mesa), it's slow but it's for testing

static long patchdata[][16] = {
    {102,103,104,105,4,5,6,7,8,9,10,11,12,13,14,15},		   /* rim */
    {12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27},		   /* body */
    {24,25,26,27,29,30,31,32,33,34,35,36,37,38,39,40},		   /* body */
    {96,96,96,96,97,98,99,100,101,101,101,101,0,1,2,3,},	   /* lid */
    {0,1,2,3,106,107,108,109,110,111,112,113,114,115,116,117},	   /* lid */
    {118,118,118,118,124,122,119,121,123,126,125,120,40,39,38,37}, /* bottom */
    {41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56},		   /* handle */
    {53,54,55,56,57,58,59,60,61,62,63,64,28,65,66,67},		   /* handle */
    {68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83},		   /* spout */
    {80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95}		   /* spout */
};

static float cpdatao[][3] = {
{0.2,0,2.7},{0.2,-0.112,2.7},{0.112,-0.2,2.7},{0,-0.2,2.7},{1.3375,0,2.53125},
{1.3375,-0.749,2.53125},{0.749,-1.3375,2.53125},{0,-1.3375,2.53125},
{1.4375,0,2.53125},{1.4375,-0.805,2.53125},{0.805,-1.4375,2.53125},
{0,-1.4375,2.53125},{1.5,0,2.4},{1.5,-0.84,2.4},{0.84,-1.5,2.4},{0,-1.5,2.4},
{1.75,0,1.875},{1.75,-0.98,1.875},{0.98,-1.75,1.875},{0,-1.75,1.875},{2,0,1.35},
{2,-1.12,1.35},{1.12,-2,1.35},{0,-2,1.35},{2,0,0.9},{2,-1.12,0.9},{1.12,-2,0.9},
{0,-2,0.9},{-2,0,0.9},{2,0,0.45},{2,-1.12,0.45},{1.12,-2,0.45},{0,-2,0.45},
{1.5,0,0.225},{1.5,-0.84,0.225},{0.84,-1.5,0.225},{0,-1.5,0.225},{1.5,0,0.15},
{1.5,-0.84,0.15},{0.84,-1.5,0.15},{0,-1.5,0.15},{-1.6,0,2.025},{-1.6,-0.3,2.025},
{-1.5,-0.3,2.25},{-1.5,0,2.25},{-2.3,0,2.025},{-2.3,-0.3,2.025},{-2.5,-0.3,2.25},
{-2.5,0,2.25},{-2.7,0,2.025},{-2.7,-0.3,2.025},{-3,-0.3,2.25},{-3,0,2.25},
{-2.7,0,1.8},{-2.7,-0.3,1.8},{-3,-0.3,1.8},{-3,0,1.8},{-2.7,0,1.575},
{-2.7,-0.3,1.575},{-3,-0.3,1.35},{-3,0,1.35},{-2.5,0,1.125},{-2.5,-0.3,1.125},
{-2.65,-0.3,0.9375},{-2.65,0,0.9375},{-2,-0.3,0.9},{-1.9,-0.3,0.6},{-1.9,0,0.6},
{1.7,0,1.425},{1.7,-0.66,1.425},{1.7,-0.66,0.6},{1.7,0,0.6},{2.6,0,1.425},
{2.6,-0.66,1.425},{3.1,-0.66,0.825},{3.1,0,0.825},{2.3,0,2.1},{2.3,-0.25,2.1},
{2.4,-0.25,2.025},{2.4,0,2.025},{2.7,0,2.4},{2.7,-0.25,2.4},{3.3,-0.25,2.4},
{3.3,0,2.4},{2.8,0,2.475},{2.8,-0.25,2.475},{3.525,-0.25,2.49375},
{3.525,0,2.49375},{2.9,0,2.475},{2.9,-0.15,2.475},{3.45,-0.15,2.5125},
{3.45,0,2.5125},{2.8,0,2.4},{2.8,-0.15,2.4},{3.2,-0.15,2.4},{3.2,0,2.4},
{0,0,3.15},{0.8,0,3.15},{0.8,-0.45,3.15},{0.45,-0.8,3.15},{0,-0.8,3.15},
{0,0,2.85},{1.4,0,2.4},{1.4,-0.784,2.4},{0.784,-1.4,2.4},{0,-1.4,2.4},
{0.4,0,2.55},{0.4,-0.224,2.55},{0.224,-0.4,2.55},{0,-0.4,2.55},{1.3,0,2.55},
{1.3,-0.728,2.55},{0.728,-1.3,2.55},{0,-1.3,2.55},{1.3,0,2.4},{1.3,-0.728,2.4},
{0.728,-1.3,2.4},{0,-1.3,2.4},{0,0,0},{1.425,-0.798,0},{1.5,0,0.075},{1.425,0,0},
{0.798,-1.425,0},{0,-1.5,0.075},{0,-1.425,0},{1.5,-0.84,0.075},{0.84,-1.5,0.075}
};

static float cpdata[][3] = {
{0.2,0,2.7},{0.2,-0.112,2.7},{0.112,-0.2,2.7},{0,-0.2,2.7},{1.3375,0,2.53125},
{1.3375,-0.749,2.53125},{0.749,-1.3375,2.53125},{0,-1.3375,2.53125},
{1.4375,0,2.53125},{1.4375,-0.805,2.53125},{0.805,-1.4375,2.53125},
{0,-1.4375,2.53125},{1.5,0,2.4},{1.5,-0.84,2.4},{0.84,-1.5,2.4},{0,-1.5,2.4},
{1.75,0,1.875},{1.75,-0.98,1.875},{0.98,-1.75,1.875},{0,-1.75,1.875},{2,0,1.35},
{2,-1.12,1.35},{1.12,-2,1.35},{0,-2,1.35},{2,0,0.9},{2,-1.12,0.9},{1.12,-2,0.9},
{0,-2,0.9},{-2,0,0.9},{2,0,0.45},{2,-1.12,0.45},{1.12,-2,0.45},{0,-2,0.45},
{1.5,0,0.225},{1.5,-0.84,0.225},{0.84,-1.5,0.225},{0,-1.5,0.225},{1.5,0,0.15},
{1.5,-0.84,0.15},{0.84,-1.5,0.15},{0,-1.5,0.15},{-1.6,0,2.025},{-1.6,-0.3,2.025},
{-1.5,-0.3,2.25},{-1.5,0,2.25},{-2.3,0,2.025},{-2.3,-0.3,2.025},{-2.5,-0.3,2.25},
{-2.5,0,2.25},{-2.7,0,2.025},{-2.7,-0.3,2.025},{-3,-0.3,2.25},{-3,0,2.25},
{-2.7,0,1.8},{-2.7,-0.3,1.8},{-3,-0.3,1.8},{-3,0,1.8},{-2.7,0,1.575},
{-2.7,-0.3,1.575},{-3,-0.3,1.35},{-3,0,1.35},{-2.5,0,1.125},{-2.5,-0.3,1.125},
{-2.65,-0.3,0.9375},{-2.65,0,0.9375},{-2,-0.3,0.9},{-1.9,-0.3,0.6},{-1.9,0,0.6},
{1.7,0,1.425},{1.7,-0.66,1.425},{1.7,-0.66,0.6},{1.7,0,0.6},{2.6,0,1.425},
{2.6,-0.66,1.425},{3.1,-0.66,0.825},{3.1,0,0.825},{2.3,0,2.1},{2.3,-0.25,2.1},
{2.4,-0.25,2.025},{2.4,0,2.025},{2.7,0,2.4},{2.7,-0.25,2.4},{3.3,-0.25,2.4},
{3.3,0,2.4},{2.8,0,2.475},{2.8,-0.25,2.475},{3.525,-0.25,2.49375},
{3.525,0,2.49375},{2.9,0,2.475},{2.9,-0.15,2.475},{3.45,-0.15,2.5125},
{3.45,0,2.5125},{2.8,0,2.4},{2.8,-0.15,2.4},{3.2,-0.15,2.4},{3.2,0,2.4},
{0,0,3.15},{0.8,0,3.15},{0.8,-0.45,3.15},{0.45,-0.8,3.15},{0,-0.8,3.15},
{0,0,2.85},{1.4,0,2.4},{1.4,-0.784,2.4},{0.784,-1.4,2.4},{0,-1.4,2.4},
{0.4,0,2.55},{0.4,-0.224,2.55},{0.224,-0.4,2.55},{0,-0.4,2.55},{1.3,0,2.55},
{1.3,-0.728,2.55},{0.728,-1.3,2.55},{0,-1.3,2.55},{1.3,0,2.4},{1.3,-0.728,2.4},
{0.728,-1.3,2.4},{0,-1.3,2.4},{0,0,0},{1.425,-0.798,0},{1.5,0,0.075},{1.425,0,0},
{0.798,-1.425,0},{0,-1.5,0.075},{0,-1.425,0},{1.5,-0.84,0.075},{0.84,-1.5,0.075}
};


static float tex[2][2][2] = {{{0, 0},{1, 0}},{{0, 1},{1, 1}}};

void PVAPI pvuTeapot(double scale,unsigned grid,UPVD8 *buf)
{
    float p[4][4][3], q[4][4][3], r[4][4][3], s[4][4][3];
    long i, j, k, l,I;
	PVSpline2 *spltex,*splvtx;
	float du,dv,du2,dv2,v11,v21,v1,v2,u,u2;
	unsigned GRD;
	float r1[2*2],r3[3*2],r4[3*2],t;
	static int swapped=0;

	scale*=0.5;
	
	if (grid < 2) grid = 7;
    GRD = grid;
	
	memcpy(cpdata,cpdatao,sizeof(cpdata));

	for(i=0;i<sizeof(cpdata)/(sizeof(float)*3);i++)
	{		
		cpdata[i][1]*=scale;
		cpdata[i][2]*=scale;
		cpdata[i][0]*=scale;
	}
	
	for (I = 0; I < 10; I++) {
	for (j = 0; j < 4; j++)
	    for (k = 0; k < 4; k++) 
		for (l = 0; l < 3; l++) {
		    p[j][k][l] = cpdata[patchdata[I][j*4+k]][l];
		    q[j][k][l] = cpdata[patchdata[I][j*4+(3-k)]][l];
		    if (l == 1) q[j][k][l] *= -1.0;
		    if (I < 6) {
			r[j][k][l] = cpdata[patchdata[I][j*4+(3-k)]][l];
			if (l == 0) r[j][k][l] *= -1.0;
			s[j][k][l] = cpdata[patchdata[I][j*4+k]][l];
			if (l == 0) s[j][k][l] *= -1.0;
			if (l == 1) s[j][k][l] *= -1.0;
		    }
		}
	
	
	// Indexed primitive setup
	pvEnableIndex(PPI_NORMAL|PPI_MAPCOORD);									
	pvSetVertexIndex(r3,sizeof(float)*3);
	pvSetNormalIndex(r4,sizeof(float)*3);
	pvSetMapIndex(r1,sizeof(float)*2);
	
	// Create splines
	// For mapping
	spltex=PV_CreateSpline2(2,2,2);
	spltex->u1=spltex->v1=0;
	spltex->u2=spltex->v2=1;
	memcpy(spltex->Points,tex,sizeof(float)*spltex->VOrder*spltex->UOrder*spltex->NbrComponent);
	spltex->CalcNormal=spltex->AutoNormalize=0;
	
	// For mesh
	splvtx=PV_CreateSpline2(4,4,3);
	splvtx->u1=splvtx->v1=0;
	splvtx->u2=splvtx->v2=1;
	memcpy(splvtx->Points,p,sizeof(float)*splvtx->VOrder*splvtx->UOrder*splvtx->NbrComponent);
	splvtx->CalcNormal=splvtx->AutoNormalize=1;
	
	du = (spltex->u2-spltex->u1)/(float) GRD;
	dv = (spltex->v2-spltex->v1)/(float) GRD;
	du2 = (splvtx->u2-splvtx->u1)/(float) GRD;
	dv2 = (splvtx->v2-splvtx->v1)/(float) GRD;
	v1=spltex->v1;	
	v2=v1+dv;	
	v11=splvtx->v1;
	v21=v11+dv;

	for (j=0;j<GRD;j++,v1+=dv,v2+=dv,v11+=dv2,v21+=dv2) 
	{
		pvBegin(PV_TRIANGLES_STRIP,buf);		
		u=spltex->u1;
		u2=splvtx->u1;
		
		for (i=0;i<=GRD;i++,u+=du,u2+=du2) 
		{												
			PV_EvalSpline2(spltex,u,v1,r1,NULL);
			PV_EvalSpline2(spltex,u,v2,&r1[2],NULL);
			PV_EvalSpline2(splvtx,u2,v11,r3,(PVPoint*)r4);
			PV_EvalSpline2(splvtx,u2,v21,&r3[3],(PVPoint*)&r4[3]);

			t=r4[1];
			r4[1]=-r4[2];
			r4[2]=-t;
			t=r4[4];
			r4[4]=-r4[5];
			r4[5]=-t;
			for(l=0;l<6;l++) r4[l]*=-1;

			t=r3[1];
			r3[1]=-r3[2];
			r3[2]=-t;
			t=r3[4];
			r3[4]=-r3[5];
			r3[5]=-t;
	
			pvVertexIndexedf(0);
			pvVertexIndexedf(1);
		}
		pvEnd();
	}

	memcpy(splvtx->Points,q,sizeof(float)*splvtx->VOrder*splvtx->UOrder*splvtx->NbrComponent);

	du = (spltex->u2-spltex->u1)/(float) GRD;
	dv = (spltex->v2-spltex->v1)/(float) GRD;
	du2 = (splvtx->u2-splvtx->u1)/(float) GRD;
	dv2 = (splvtx->v2-splvtx->v1)/(float) GRD;
	v1=spltex->v1;	
	v2=v1+dv;	
	v11=splvtx->v1;
	v21=v11+dv;

	for (j=0;j<GRD;j++,v1+=dv,v2+=dv,v11+=dv2,v21+=dv2) 
	{
		pvBegin(PV_TRIANGLES_STRIP,buf);		
		u=spltex->u1;
		u2=splvtx->u1;
		
		for (i=0;i<=GRD;i++,u+=du,u2+=du2) 
		{									
			PV_EvalSpline2(spltex,u,v1,r1,NULL);
			PV_EvalSpline2(spltex,u,v2,&r1[2],NULL);
			PV_EvalSpline2(splvtx,u2,v11,r3,(PVPoint*)r4);
			PV_EvalSpline2(splvtx,u2,v21,&r3[3],(PVPoint*)&r4[3]);

			t=r4[1];
			r4[1]=-r4[2];
			r4[2]=-t;
			t=r4[4];
			r4[4]=-r4[5];
			r4[5]=-t;
			for(l=0;l<6;l++) r4[l]*=-1;

			t=r3[1];
			r3[1]=-r3[2];
			r3[2]=-t;
			t=r3[4];
			r3[4]=-r3[5];
			r3[5]=-t;
			
			pvVertexIndexedf(0);
			pvVertexIndexedf(1);
		}
		pvEnd();
	}

	if(I<6)
	{
		memcpy(splvtx->Points,r,sizeof(float)*splvtx->VOrder*splvtx->UOrder*splvtx->NbrComponent);

		du = (spltex->u2-spltex->u1)/(float) GRD;
		dv = (spltex->v2-spltex->v1)/(float) GRD;
		du2 = (splvtx->u2-splvtx->u1)/(float) GRD;
		dv2 = (splvtx->v2-splvtx->v1)/(float) GRD;
		v1=spltex->v1;	
		v2=v1+dv;	
		v11=splvtx->v1;
		v21=v11+dv;

		for (j=0;j<GRD;j++,v1+=dv,v2+=dv,v11+=dv2,v21+=dv2) 
		{
			pvBegin(PV_TRIANGLES_STRIP,buf);		
			u=spltex->u1;
			u2=splvtx->u1;
			
			for (i=0;i<=GRD;i++,u+=du,u2+=du2) 
			{									
				PV_EvalSpline2(spltex,u,v1,r1,NULL);
				PV_EvalSpline2(spltex,u,v2,&r1[2],NULL);
				PV_EvalSpline2(splvtx,u2,v11,r3,(PVPoint*)r4);
				PV_EvalSpline2(splvtx,u2,v21,&r3[3],(PVPoint*)&r4[3]);

				t=r4[1];
				r4[1]=-r4[2];
				r4[2]=-t;
				t=r4[4];
				r4[4]=-r4[5];
				r4[5]=-t;
				for(l=0;l<6;l++) r4[l]*=-1;

				t=r3[1];
				r3[1]=-r3[2];
				r3[2]=-t;
				t=r3[4];
				r3[4]=-r3[5];
				r3[5]=-t;

				pvVertexIndexedf(0);
				pvVertexIndexedf(1);
			}
			pvEnd();
		}

		memcpy(splvtx->Points,s,sizeof(float)*splvtx->VOrder*splvtx->UOrder*splvtx->NbrComponent);

		du = (spltex->u2-spltex->u1)/(float) GRD;
		dv = (spltex->v2-spltex->v1)/(float) GRD;		
		du2 = (splvtx->u2-splvtx->u1)/(float) GRD;
		dv2 = (splvtx->v2-splvtx->v1)/(float) GRD;
		v1=spltex->v1;	
		v2=v1+dv;	
		v11=splvtx->v1;
		v21=v11+dv;

		for (j=0;j<GRD;j++,v1+=dv,v2+=dv,v11+=dv2,v21+=dv2) 
		{
			pvBegin(PV_TRIANGLES_STRIP,buf);		
			u=spltex->u1;
			u2=splvtx->u1;
			
			for (i=0;i<=GRD;i++,u+=du,u2+=du2) 
			{									
				PV_EvalSpline2(spltex,u,v1,r1,NULL);
				PV_EvalSpline2(spltex,u,v2,&r1[2],NULL);
				PV_EvalSpline2(splvtx,u2,v11,r3,(PVPoint*)r4);
				PV_EvalSpline2(splvtx,u2,v21,&r3[3],(PVPoint*)&r4[3]);

				t=r4[1];
				r4[1]=-r4[2];
				r4[2]=-t;
				t=r4[4];
				r4[4]=-r4[5];
				r4[5]=-t;
				for(l=0;l<6;l++) r4[l]*=-1;

				t=r3[1];
				r3[1]=-r3[2];
				r3[2]=-t;
				t=r3[4];
				r3[4]=-r3[5];
				r3[5]=-t;

				pvVertexIndexedf(0);
				pvVertexIndexedf(1);
			}
			pvEnd();
		}
	}
	}
	pvEnableIndex(0);									
}

////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// MISC

void PVAPI pvuInverseWinding(PVFace *f)
{
	unsigned i,v[MAX_VERTICES_PER_POLY];

	memcpy(v,f->V,sizeof(unsigned)*f->NbrVertices);
	for(i=0;i<f->NbrVertices;i++)
	{
		f->V[i]=v[f->NbrVertices-1-i];
	}
}

void PVAPI pvuRemapMaterials(PVMesh *m,char *old,char *newm)
{
    unsigned i;
    
    if(m==NULL) return;

    for(i=0;i<m->NbrFaces;i++)
    {
        if(m->Face[i].Material!=NULL)
        {
            if(strcmp(m->Face[i].Material,old)==0)
            {
                free(m->Face[i].Material);
				PV_SetMaterialNameToFace(&m->Face[i],newm);
            }             
        }
    }
}

static PVMesh * PVAPI AutoDistanceCallBack(PVMesh *o)
{
	PVPoint p;
	PVMesh *m;
	double d;

	m=PV_GetSwitchItem(o,0);

	p.xf=o->Owner->Camera->pos.xf-m->Position.xf;
	p.yf=o->Owner->Camera->pos.yf-m->Position.yf;
	p.zf=o->Owner->Camera->pos.zf-m->Position.zf;

	d=sqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);

	if(d>*(float*)(&o->UserData))
	{
		m->Flags|=MESH_FORGET_ALL;
	}
	else
	{
		m->Flags&=~MESH_FORGET_ALL;
	}
	return m;
}

int PVAPI pvuAddAutoDistanceOffMesh(PVMesh *father,float dist,PVMesh *mesh)
{
	PVMesh *s;
	int hr;

	s=PV_CreateSwitchNode(AutoDistanceCallBack);
	if(s==NULL) return NO_MEMORY;

	*(float*)(&s->UserData)=dist;

	hr=PV_AddChildMesh(father,s);
	if(hr!=COOL) return hr;

	hr=PV_AddSwitch(s,mesh);
	if(hr!=COOL) return hr;

	return hr;
}

char *PVAPI pvuTranslateError(int e)
{
	switch(e)
	{
	case COOL:return "No error (Yes !)";
	case FILE_IOERROR:return "IO error during a file access";
	case ALREADY_ASSIGNED:return "Texture has already been set";
	case NO_MEMORY: return "Not enough memory to carry operation";
	case BIZAR_ERROR:return "Undetermined error (but there is one)";
	case ARG_INVALID:return "Invalid arguments used";
	case ITEM_NOT_FOUND:return "item not found";
	case MATERIAL_NOT_REGISTERED:return "Material not registered";
	case INVALID_CAM:return "Invalid camera";
	case INVALID_TEXTURE:return "Invalid texture";
	case NO_MATERIALS:return "No materials";
	case ALREADY_IN_HIERARCHY:return "This mesh has already been added in a hierarchy";
	case MESH_HAS_CHILD:return "This mesh cannot be added because he has child";
	case NO_ACCELSUPPORT: return "No hardware support";
	case ACCEL_NO_MEMORY: return "No more memory on hardware";
	case ACCEL_FUNCTION_UNSUPPORTED: return "Acceleration function unsupported by hardware";
	case NO_HARDWARE_SET: return "No hardware driver set by PV_SetHardwareDriver()";
	case INVALID_DRIVER: return "Wrong version of driver";
	case NO_COLLISIONINFO: return "No collision info";
	case BAD_FILE_FORMAT: return "Bad file format";
	case NOT_AVAILABLE:return "Data not available";
	default:return "Unknown error code";
	}
}

////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// PICKING
// These functions should be called just after a rendering to be accurate
// They use info generated by PV_RenderWorld()

// pvuPickFaceFromMesh() and pvuPickFaceFromWorld() return an array of PVPickedFace
// which is termined by a NULL pointer in the Face member. See routines for details.

// This buffer is static and must not be freed by caller, and thus is valid only until another 
// call to one of the two routine is made.

// ex of usage:
//    PVPickedFace *f=pvuPickFaceFromWorld(Wor,10,10);
//
//    if(f[0].Face!=NULL)
//    {
//        printf("%s\n",f[0].Face->MaterialInfo->Name);
//    }


#define MAX_PICKED_FACES	4096

/*

// The following functions only works if PV handles transformations
// They will not work with newer hardware driver
// For these case use the more generic functions below using RayIntersection

static int pnpoly(int npol, float *xp, float *yp, float x, float y)
{
  int i, j, c = 0;
  for (i = 0, j = npol-1; i < npol; j = i++) {
	if ((((yp[i]<=y) && (y<yp[j])) ||
		 ((yp[j]<=y) && (y<yp[i]))) &&
		(x < (xp[j] - xp[i]) * (y - yp[i]) / (yp[j] - yp[i]) + xp[i]))

	  c = !c;
  }
  return c;
}

static void FilterPickedFace(PVPickedFace found[],unsigned nbrfound)
{
	// Keep only one face according to Z, not ZBuffer accurate
	for(;;)	
	{
		if(found[0].Face==NULL) return;
		if(found[1].Face==NULL) return;

		if(found[0].ooz<found[1].ooz)
		{
			memcpy(&found[1],&found[2],sizeof(PVPickedFace)*(nbrfound-1));
			nbrfound--;
		}
		else
		{
			memcpy(&found[0],&found[1],sizeof(PVPickedFace)*(nbrfound));
			nbrfound--;
		}
	}
}

PVPickedFace *PVAPI pvuPickFaceFromWorld(PVWorld *w,unsigned xs,unsigned ys)
{
	unsigned i,j;
	int r;
	float x[2*MAX_VERTICES_PER_POLY];
	float y[2*MAX_VERTICES_PER_POLY];
	static PVPickedFace found[MAX_PICKED_FACES];
	static float ooz;
	unsigned nbrfound;

	nbrfound=0;
	memset(found,0,sizeof(found));
	ooz=0;
	
	// Extract infos
	for(i=0;i<w->NbrVisibles;i++)
	{
		PVMesh *m;

        m=(PVMesh*)w->Visible[i*2+1];

        if(w->Visible[i*2]->Poly!=NULL)
		{
			for(j=0;j<w->Visible[i*2]->Poly->NbrVertices;j++)
			{
				x[j]=m->Projected[w->Visible[i*2]->Poly->Vertices[j]].xf;
				y[j]=m->Projected[w->Visible[i*2]->Poly->Vertices[j]].yf;
				ooz+=m->Projected[w->Visible[i*2]->Poly->Vertices[j]].InvertZ;				
			}
		}
		else
		{
			for(j=0;j<w->Visible[i*2]->NbrVertices;j++)
			{
				x[j]=m->Projected[w->Visible[i*2]->V[j]].xf;
				y[j]=m->Projected[w->Visible[i*2]->V[j]].yf;
				ooz+=m->Projected[w->Visible[i*2]->V[j]].InvertZ;
			}
		}
		ooz/=j;

		// Test this face
		r=pnpoly(j,x,y,xs,ys);
		if(r)
		{
			// point is inside, store face
			found[nbrfound].Face=w->Visible[i*2];
			found[nbrfound].Owner=(PVMesh*)w->Visible[i*2+1];
			found[nbrfound].ooz=ooz;
			nbrfound++;
			if(nbrfound==(MAX_PICKED_FACES-1)) break;
		}
	}

	FilterPickedFace(found,nbrfound);

	return found;
}

PVPickedFace *PVAPI pvuPickFaceFromMesh(PVMesh* m,unsigned xs,unsigned ys)
{
	unsigned i,j;
	int r;
	float x[2*MAX_VERTICES_PER_POLY];
	float y[2*MAX_VERTICES_PER_POLY];
	static PVPickedFace found[MAX_PICKED_FACES];
	static float ooz;
	unsigned nbrfound;

	nbrfound=0;
	memset(found,0,sizeof(found));
	ooz=0;
	
	// Extract infos
	for(i=0;i<m->NbrVisibles;i++)
	{
		if(m->Visible[i]->Poly!=NULL)
		{
			for(j=0;j<m->Visible[i]->Poly->NbrVertices;j++)
			{
				x[j]=m->Projected[m->Visible[i]->Poly->Vertices[j]].xf;
				y[j]=m->Projected[m->Visible[i]->Poly->Vertices[j]].yf;
				ooz+=m->Projected[m->Visible[i]->Poly->Vertices[j]].InvertZ;				
			}
		}
		else
		{
			for(j=0;j<m->Visible[i]->NbrVertices;j++)
			{
				x[j]=m->Projected[m->Visible[i]->V[j]].xf;
				y[j]=m->Projected[m->Visible[i]->V[j]].yf;
				ooz+=m->Projected[m->Visible[i]->V[j]].InvertZ;
			}
		}
		ooz/=j;

		// Test this face
		r=pnpoly(j,x,y,xs,ys);
		if(r)
		{
			// point is inside, store face
			found[nbrfound].Face=m->Visible[i];
			found[nbrfound].Owner=m;
			found[nbrfound].ooz=ooz;
			nbrfound++;
			if(nbrfound==(MAX_PICKED_FACES-1)) break;
		}
	}

	FilterPickedFace(found,nbrfound);

	return found;
}*/

// These set of functions allows for picking without 2d infos
// There are much slower than 2d version, but should work with every hardware
// Optimization to be done, test ray against mesh's bounding box before trying all faces :)

static int __cdecl FilterPicked(const void *elem1, const void *elem2 ) 
{
	PVPickedFace *e1=(PVPickedFace*)elem1,*e2=(PVPickedFace*)elem2;

	if(e1->ooz<e2->ooz) return -1;
	if(e1->ooz==e2->ooz) return 0;
	return 1;
}

PVPickedFace *PVAPI pvuPickFaceFromMesh(PVMesh *Mesh,PVCam *Camera,unsigned x,unsigned y,PVPickedFace *found,unsigned maxpicked,unsigned *nbrfound)
{
    PVPoint PickRayDir,PickRayOrig,v;
    unsigned i,j;
    float W,H,m[3][3];
	PVFace *f;

	// Compute the vector of the pick ray in screen space
	W=1.0/tan((atan(2.0/(Camera->fieldofview*Camera->fscale/Camera->xscreenscale)))/2.0);
	H=1.0/tan((atan(2.0/(Camera->fieldofview*Camera->fscale/Camera->yscreenscale)))/2.0);
	
	v.xf =  (((2.0f * x ) / Camera->Width) - 1 ) / W;
	v.yf =  (((2.0f * y ) / Camera->Height ) - 1 ) / H;
	v.zf = -1.0;

	for(i=0;i<3;i++)
		for(j=0;j<3;j++) m[i][j]=Mesh->OldMatrix[i][j];
	
	// Transform the screen space pick ray into 3D space
	PickRayDir.xf  = v.xf*m[0][0] + v.yf*m[1][0] + v.zf*m[2][0];
	PickRayDir.yf  = v.xf*m[0][1] + v.yf*m[1][1] + v.zf*m[2][1];
	PickRayDir.zf  = v.xf*m[0][2] + v.yf*m[1][2] + v.zf*m[2][2];
	PickRayOrig.xf = Mesh->InvertCamPos.xf;
	PickRayOrig.yf = Mesh->InvertCamPos.yf;
	PickRayOrig.zf = Mesh->InvertCamPos.zf;

	NormalizePoint(&PickRayDir);

    for(i=0,f=Mesh->Face; i<Mesh->NbrFaces; i++ ,f++)
    {
        float dist,P[3];

        if(PV_RayFaceIntersection(f,&PickRayOrig,&PickRayDir,-1,&dist,P))
        {
            found[*nbrfound].Face=f;
			found[*nbrfound].Owner=Mesh;
			found[*nbrfound].ooz=dist;
			(*nbrfound)++;
			
			if((*nbrfound)==(maxpicked-1)) break;            	
        }
    }    
	
	qsort(found,*nbrfound,sizeof(PVPickedFace),FilterPicked);
	
    return found;
}

typedef struct __PickInfos
{
	PVCam *camera;
	PVPickedFace *found;
	unsigned *nbrfound,max,x,y;
} PickInfos;

static int PVAPI PickMesh(PVMesh *o,int userarg)
{
	PickInfos *pi=(PickInfos*)userarg;

	if(o->NbrFaces)
		pvuPickFaceFromMesh(o,pi->camera,pi->x,pi->y,pi->found,pi->max,pi->nbrfound);

	return COOL;
}

PVPickedFace *PVAPI pvuPickFaceFromWorld(PVWorld *w,unsigned xs,unsigned ys)
{
	static PVPickedFace found[MAX_PICKED_FACES];
	unsigned nbrfound=0;
	PickInfos pi;

	pi.camera=w->Camera;
	pi.found=found;
	pi.nbrfound=&nbrfound;
	pi.max=MAX_PICKED_FACES;
	pi.x=xs;
	pi.y=ys;

	memset(found,0,sizeof(found));

	PV_IterateMeshList(Wor->Objs,PickMesh,(int)&pi);
			
	qsort(found,nbrfound,sizeof(PVPickedFace),FilterPicked);

	return found;	
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Vision++ : Image loading interface
//
// Before using this library consult the LICENSE file

#ifndef __IMGLOAD_H__
#define __IMGLOAD_H__

#include <iostream.h>
#include "pvcconf.h"
#include "pomcore.h"

#define IMAGE_LOADERS_DOMAIN "/domains/PanardVision/ImageLoaders"

////////////////////////////////////////////////////////////////////////////////////////////////////////////

class PVDLL pvImageLoader : public pomCoreObject
{
    DECLARE_POMIZED(pvImageLoader);

public:
	enum pvIDFlags {pvidRGB,pvidRGBA};
    struct pvImageData   // This describes RGB or RGBA images, no palettes
    {
        unsigned Width,Height;
        UPVD8 *Pixels;
		pvIDFlags Flags;
		
		pvImageData::pvImageData(){Width=Height=0;Pixels=NULL;Flags=pvidRGB;};
		pvImageData::~pvImageData(){delete[] Pixels;};
    };

    pvImageData *LoadFromFile(const char *name);
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////

class PVDLL psLoadImageInterface : public pomCoreObject
{
public:
	virtual pvImageLoader::pvImageData *Load(istream &in)=0;
	virtual const char *GetExtension(unsigned i) {return NULL;};
	virtual const char *GetName() {return "(no-name)";};
};


#endif
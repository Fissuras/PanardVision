/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// OpenGL generic Driver
//
// Before using this library consult the LICENSE file

#ifndef __PVGL_H__
#define __PVGL_H__

//--------------------------------------------- Compile time defines

// define this to compile for X
//#define GLX

// Defines the following to let Panard Vision do the light calculations
// This permits full support of User defined lights but does not
// provides support for specular
#define PVLIGHT

//--------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

PVEXPORT PVHardwareDriver PVDriver;

#ifdef __cplusplus
}
#endif

#endif

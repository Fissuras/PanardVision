/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard-Vision
// 3D real time engine
// (C) 1997-98, Olivier Brunet
//
// Before using this library consult the LICENSE file

// This header will map old type names used up to 
// PV 0.98a to new types name used since 0.98b

#ifndef __COMPAT_H__
#define __COMPAT_H__

#include "pvision.h"

typedef PVQuat Quat;
typedef PVPoint Point;
typedef PVRGB RGB;
typedef PVRGBF RGBF;
typedef PVMat3x3 Mat3x3;

#endif
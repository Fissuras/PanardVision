/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Confettis : Ponctual particle emitter
//
// Before using this library consult the LICENSE file

#ifndef __PC_POINT_EMITER_H__
#define __PC_POINT_EMITER_H__

#include "peint.h"

class PVDLL pcPointEmitter : public pcParticleEmitterInterface
{
	DECLARE_POMIZED(pcPointEmitter);

    private:        
        unsigned _StdOff;
        unsigned _NewOff;
        
		float _LastEmittedTime;

	public:        
		pvVector3D _Position,_Direction;
        float _Angle;
        float _Freq;
        float _Radius,_PercentRadiusRand;
        float _Weigth,_PercentWeigthRand;
        float _Speed,_PercentSpeedRand;
		pvVector3D _Acc;
    
    public:
        pcPointEmitter();
        pcPointEmitter(pvVector3D pos);
        
        int GetNewParticles(float time, pctParticleTable &table, pctParticleTable &tabledead);
        void SetFlagInfo(pctParticleFlags f,unsigned offset);
        pctParticleFlags GetUsedFlags() const;

        void DefaultVal();

		void WriteParams(ostream &o);
		void ReadParams(istream &i);
};

#endif

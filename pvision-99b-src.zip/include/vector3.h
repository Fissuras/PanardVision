/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Vision++ : Vector classes
//
// Before using this library consult the LICENSE file

#ifndef __PV_VECTOR3D__
#define __PV_VECTOR3D__
#include <math.h>
#include "pvcconf.h"

#ifdef _MSC_VER
#pragma warning(disable:4244)
#pragma warning(disable:4305)
#endif

struct PVDLL pvVector3D
{
        float x,y,z;

        ////////////////////////// Operations
        inline pvVector3D() {};
        inline pvVector3D(float Px,float Py,float Pz) {x=Px;y=Py;z=Pz;};
		inline pvVector3D(float array[3]) {FromArray(array);}

		inline void FromArray(float array[3]) {x=array[0]; y=array[1]; z=array[2];};
        
        inline pvVector3D operator+(const pvVector3D &b) const
        {
            pvVector3D ret;

            ret.x=x+b.x;
            ret.y=y+b.y;
            ret.z=z+b.z;

            return ret;
        };
        inline pvVector3D operator-(const pvVector3D &b) const
        {
            pvVector3D ret;

            ret.x=x-b.x;
            ret.y=y-b.y;
            ret.z=z-b.z;

            return ret;
        };
        inline pvVector3D operator*(float factor) const
        {
            pvVector3D ret;

            ret.x=x*factor;
            ret.y=y*factor;
            ret.z=z*factor;

            return ret;
        }
        inline float operator*(const pvVector3D &V) const         // dot product
        {
            return x*V.x+y*V.y+z*V.z;
        }
        
        inline pvVector3D operator^(const pvVector3D &V) const    // cross product
        {
            pvVector3D Ret;

            Ret.x=y*V.z-V.y*z;
            Ret.y=z*V.x-V.z*x;
            Ret.z=x*V.y-V.x*y;

            return Ret;
        }
        inline void Set(float Px,float Py,float Pz)
        {
            x=Px;
            y=Py;
            z=Pz;
        }
        inline void Normalize()
        {
            double l;
            
            l=sqrt(x*x+y*y+z*z);
            if(l!=0)
            {
                    l=1/l;
                    x*=l;  
                    y*=l;
                    z*=l;
            }   
        }

		inline void Mul(pvVector3D &p)
		{
			x*=p.x;
			y*=p.y;
			z*=p.z;
		}
                
		void VectorToAngles(float &theta,float &phi) const;
        void AnglesToVector(float theta,float phi,float rho);
        
        inline void Zero() {x=y=z=0;};
        
        inline char IsNull() const
        {
            return ((x==0)&&(y==0)&&(z==0));
        }
        		
        inline float GetNorm(void) const {return (float)sqrt(x*x+y*y+z*z);} 
        inline pvVector3D operator /(float f) const {return *this*(1.0/f);}
        inline void operator +=(const pvVector3D &v) {x+=v.x;y+=v.y;z+=v.z;}
        inline void operator -=(const pvVector3D &v) {x-=v.x;y-=v.y;z-=v.z;}
        inline void operator *=(float f) {x*=f;y*=f;z*=f;}
        inline void operator /=(float f) {*this*=1.0/f;}
};

#endif
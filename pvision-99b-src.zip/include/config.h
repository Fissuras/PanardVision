/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Compile time config file
//
// Before using this library consult the LICENSE file

// API calling convention
#define PVAPI __stdcall

// Define if compiling for win95/NT
#ifndef WIN32
#define WIN32
#endif

// Define if compiling for a Unix-like os
#undef __UNIX__

// Define to use x86 assembly code (define one of the two above if needed)
#define __386__

// Win32 DLL stuffs (VC)
#ifdef WIN32
	#ifdef _PVDLL_
	#define PVEXPORT extern 
	#else
	#define PVEXPORT extern __declspec(dllimport)
	#endif
#else
	#define PVEXPORT extern
#endif

// Visual C stuffs
#ifdef _MSC_VER
#pragma warning( disable : 4244 )
#pragma warning( disable : 4018 )
#pragma warning( disable : 4146 )
#pragma warning( disable : 4305 )
#endif

// Define if you have a Big Indian CPU (not Intel)
//#define __INDIAN_SWAP__

// Number of user definables clipping planes
#define MAX_USER_CLIPPLANES     8

// Max vertices per polys
#define MAX_VERTICES_PER_POLY   16

// Max number of lightmaps per face
#define MAX_LIGHTMAPS   16

// Max number of mipmaps per texture
#define MAX_MIPMAP_NUM   12

// Structure alignement
#define PACK_STRUCTURE 8

// Max Shadow volumes per mesh
#define MAX_SHADOW_VOLUMES	8

// Max Texture pipe
#define MAX_TEXTURE_STAGE	8

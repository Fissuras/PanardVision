/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Confettis : Base particle system class
//
// Before using this library consult the LICENSE file

#ifndef __PC_PCSYS__
#define __PC_PCSYS__

#include "peint.h"
#include "point.h"
#include <vector>
#include <map>
#include <iostream.h>
using std::vector;
using std::map;

class PVDLL pcParticlesSystem : public pomCoreObject
{
	DECLARE_POMIZED(pcParticlesSystem);

    private:
        typedef map<unsigned,pcParticleOperatorInterface*> pctOperatorTable;
        typedef vector<pcParticleEmitterInterface*> pctEmitterTable;
        
        float _Time;
        unsigned _Lock;
        pctEmitterTable _Emitters; 
        pctOperatorTable _POperators;
        pctParticleTable _Particles;
        pctParticleTable _ParticlesDead;
        class pcParticleAttributeManager *_AttManager;

        unsigned _LastPartSize;
        
    public:
        pcParticlesSystem();
        ~pcParticlesSystem();
        int ComputeSystem();

        int Lock();
        int UnLock();
        unsigned AddEmitter(pcParticleEmitterInterface *e);
        unsigned AddOperator(unsigned priority,pcParticleOperatorInterface *o);

        int RegisterPFlag(pctParticleFlags flag,string name,unsigned size);
		int UnRegisterPFlag(pctParticleFlags flag);

        void Flush();
        
        inline void SetTime(float t) {_Time=t;};
        inline float GetTime() const {return _Time;};

        static pcParticle *StdGetPart(pctParticleTable &table,pctParticleTable &tabledead,unsigned partsize);

		// Scripting
		void WriteDefs(ostream &o);
		void ReadDefs(istream &i);

};

#endif
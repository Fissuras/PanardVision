/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Utilities library
//
// Before using this library consult the LICENSE file

#ifndef __PVUT_H__
#define __PVUT_H__


#ifdef _PVDLL_
#undef _PVDLL_
#include "config.h"
#include "pvision.h"
#define _PVDLL_
#undef PVEXPORT
#include "config.h"
#else
#include "pvision.h"
#endif

#ifdef _MSC_VER
#ifndef _PVDLL_
#pragma comment(lib,"pvut.lib")
#endif
#endif

// This will turn verbose mode on (console apps only)
#define __PVUT_VERBOSE__

// Additional infos read by LoadMaterialsDefinitions()
typedef struct _pvuMatInfo
{
	float SPEED;
	float STEP;
	unsigned CACHESIZE;
} pvuMatInfo;

typedef struct _PVPickedFace
{
	PVFace *Face;
	PVMesh *Owner;
	float ooz;
} PVPickedFace;

#ifdef __cplusplus
extern "C" {
#endif

PVEXPORT int PVAPI pvuLoadJpeg(char * filename,PVMaterial *m);
PVEXPORT int PVAPI pvuLoadRaw(char *na,PVMaterial *mat);
PVEXPORT int PVAPI pvuLoadBump(char *na,PVMaterial *mat);
PVEXPORT int PVAPI pvuLoadMaterialsDefinitions(PVWorld *zeworld,char *s,pvuMatInfo *matinfo);

PVEXPORT int PVAPI pvuSaveCompiledMaterial(PVWorld *Wor,char *matname,char *filename);
PVEXPORT int PVAPI pvuLoadCompiledMaterial(PVWorld *w,char *matname,char *filename);
PVEXPORT int PVAPI pvuSaveMeshBBoxes(PVWorld *Wor,char *meshname,char *filename);
PVEXPORT int PVAPI pvuLoadMeshBBoxes(PVWorld *Wor,char *meshname,char *filename);

PVEXPORT PVPickedFace *PVAPI pvuPickFaceFromWorld(PVWorld* w,unsigned xs,unsigned ys);
PVEXPORT PVPickedFace *PVAPI pvuPickFaceFromMesh(PVMesh *Mesh,PVCam *Camera,unsigned x,unsigned y,PVPickedFace *found,unsigned maxpicked,unsigned *nbrfound);

PVEXPORT void PVAPI pvuTeapot(double scale,unsigned grid,UPVD8 *buf);

PVEXPORT int PVAPI pvuAddAutoDistanceOffMesh(PVMesh *father,float dist,PVMesh *mesh);

PVEXPORT void PVAPI pvuInverseWinding(PVFace *f);
PVEXPORT void PVAPI pvuRemapMaterials(PVMesh *m,char *old,char *newm);

PVEXPORT char *PVAPI pvuTranslateError(int e);

#ifdef __cplusplus
}
#endif

// pvut specific error codes
#define BAD_FILE_FORMAT		1000

#endif

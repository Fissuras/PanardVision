/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Confettis : Core types
//
// Before using this library consult the LICENSE file

#ifndef __PV_PCTYPES__
#define __PV_PCTYPES__

#include "pvcconf.h"

#include <list>
using std::list;

#include "vector3.h"

/////////////////////////////////////////////////////////////////////// Error codes
#define PC_ERR_NO_ERROR				0
#define PC_ERR_ATTRIB_NOT_FOUND		1
#define PC_ERR_PS_ALREADY_LOCKED	2
#define PC_ERR_PS_NOT_LOCKED		3
#define PC_ERR_PS_LOCKED			4

///////////////////////////////////////////////////////////////////// A particle

struct pcParticle
{
    enum pcParticleState {STATE_DEAD,STATE_ALIVE};

    float Time,BirthTime;
    pcParticleState State;
};
typedef list<pcParticle*> pctParticleTable;


///////////////////////////////////////////////////////////////////// Particle flags
#define PC_PF_STANDARD      1   //{x,y,z,radius}
struct pcsPartStandard
{    
    pvVector3D p;
    float radius;
};

#define PC_PF_NEWTONSYS     2   //{speed ,acceleration, weight}
struct pcsPartNewton
{
    pvVector3D s,a;             // m.s,m.s
    float w;                    // gram
};

#define PC_PF_ARTISTIC		4	// {color, opacity}
struct pcsPartArtistic
{
	float r,g,b,a;				// 0.0-1.0
	float opacity;				// 0.0-1.0
};

typedef unsigned pctParticleFlags;

///////////////////////////////////////////////////////////////////// Helpers functions

static inline char *PC_GET_PART_FIELD(pcParticle *p,unsigned offset)
{
    char *s=(char*)p;
    s+=offset;
    return s;
}

#endif
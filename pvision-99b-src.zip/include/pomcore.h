/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Object Model Core header file
//
// Before using this library consult the LICENSE file

#ifndef __POM_CORE_H__
#define __POM_CORE_H__

//////////////////////////////////////////////////////////////////////////////////// System dependant setup
#ifdef WIN32
	#ifdef _POMDLL_
	#define POM_DLL	__declspec(dllexport)
	#else
	#define POM_DLL	__declspec(dllimport)
	#endif
	#else
	#define POM_DLL
#endif

#ifdef _MSC_VER
#ifndef _POMDLL_
#pragma comment(lib,"pomcore.lib")
#endif
#endif

#ifdef __UNIX__
#define POMAPI
#else
#define POMAPI	__stdcall
#endif
#define POMERR	unsigned

#ifdef _MSC_VER
#pragma warning(disable:4786)
#endif

//////////////////////////////////////////////////////////////////////////////////// Error Codes

#define POMERR_COOL									0
#define POMERR_NO_SUCH_NAME							1

//////////////////////////////////////////////////////////////////////
  
#include <ostream.h>
#include <map>
#include <string>
using std::map;
using std::multimap;
using std::string;

////////////////////////////////////////////////////////////////////// Core Structs

struct pomClassInfo
{
	char *ClassName;
	char *DomainName;
	unsigned ObjectSize;
	
	class pomCoreObject* (POMAPI* CreateObject)();		// If NULL, abstract class
};


////////////////////////////////////////////////////////////////////////// Helper macros

#define POM_CLASS_INFO(class_name) \
 ((pomClassInfo*)(&class_name::pomclass##class_name))

#define DECLARE_POMIZED(class_name) \
private: \
	pomClassInfo *_CurrentClassInfo; \
public: \
	static class pomCoreObject* POMAPI pomCreateObject(); \
	static const pomClassInfo pomclass##class_name; \
    virtual pomClassInfo* pomGetRuntimeClass() const; 

#define IMPLEMENT_POMIZED(class_name,domain_name) \
	class pomCoreObject* POMAPI class_name::pomCreateObject() { return (class pomCoreObject*)new class_name; } \
	const pomClassInfo class_name::pomclass##class_name = {#class_name,domain_name, sizeof(class class_name), class_name::pomCreateObject}; \
	pomClassInfo* class_name::pomGetRuntimeClass() const { return POM_CLASS_INFO(class_name); }; \
	static const __pomAutoRegister _pom_init_##class_name(POM_CLASS_INFO(class_name));

#define IMPLEMENT_POMIZED_ABSTRACT(class_name) \
	class pomCoreObject* POMAPI class_name::pomCreateObject() { return NULL; } \
	const pomClassInfo class_name::pomclass##class_name = {#class_name,"/abstract/", sizeof(class class_name), NULL}; \
	pomClassInfo* class_name::pomGetRuntimeClass() const { return POM_CLASS_INFO(class_name); }; \
	static const __pomAutoRegister _pom_init_##class_name(POM_CLASS_INFO(class_name));

////////////////////////////////////////////////////////////////////// Core Classes

class POM_DLL pomCoreObject					// Base Class for all pomized class
{
	DECLARE_POMIZED(pomCoreObject)

	private:
		unsigned _RefCnt;
		unsigned _Id;
        static unsigned _CurrentId;
		string _ShortName;

	public:
		pomCoreObject();
		~pomCoreObject();

		inline void AddRef() {_RefCnt++;}
		inline void Release() {_RefCnt--;}
        inline unsigned GetId() const {return _Id;}

		void SetShortName(char *name);
		const char *GetShortName();

//		virtual int Serialize(ostream &s) const;
//		virtual int UnSerialize(istream &s);
};

class POM_DLL pomNameServer
{
	private:	
		multimap<string,pomClassInfo> _NameSpaces;
	public:
		void AddName(const char *name,pomClassInfo &ci);
		
		POMERR GetClassInfoFromName(const char *name,pomClassInfo &ci);
		POMERR GetObjectFromFQN(const char *name,pomCoreObject **c);
		POMERR IterateClassesDirectory(unsigned index,pomClassInfo &ci);
		POMERR IterateObjectsDirectory(unsigned index,const char *directory,pomCoreObject **c);

		void DumpNameSpace(ostream &out);
};

class POM_DLL pomConstrainedNameServer : public pomNameServer
{
	private:	
		string _DomainRoot;

		pomConstrainedNameServer();
	
	public:
		pomConstrainedNameServer(const char *DomainRoot);
		
		POMERR GetClassInfoFromName(const char *name,pomClassInfo &ci);
		POMERR GetObjectFromFQN(const char *name,pomCoreObject **c);
};

/////////////////////////////////////////////////////////////////////////// Core API

POM_DLL POMERR POMAPI pomGetNameServer(pomNameServer **ns);
POM_DLL pomCoreObject *POMAPI pomCreateObjectFromClass(char *name);
POM_DLL pomCoreObject *POMAPI pomGetObjectFromName(char *name);

///////////////////////////////////////////////////////////////////////// BackStage

struct POM_DLL __pomAutoRegister
{
	__pomAutoRegister(pomClassInfo *ci);
};

#endif

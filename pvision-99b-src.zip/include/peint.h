/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Confettis : Particle emitter interface
//
// Before using this library consult the LICENSE file

#ifndef __PC_PEINT__
#define __PC_PEINT__

#include <iostream.h>
#include "pctypes.h"
#include "pomcore.h"

class PVDLL pcParticleEmitterInterface : public pomCoreObject
{   
	public:
		enum pcParticleEmitterState {STATE_ON,STATE_OFF};

    protected:
        unsigned _PartSize;
		pcParticleEmitterState _State;

    public:
		pcParticleEmitterInterface() {_State=STATE_ON;}
        virtual int GetNewParticles(float time, pctParticleTable &table,pctParticleTable &tabledead)=0;
        virtual void SetFlagInfo(pctParticleFlags f,unsigned offset)=0;
        virtual pctParticleFlags GetUsedFlags() const=0;
        inline void SetParticleSize(unsigned size) {_PartSize=size;};
		inline void SetState(pcParticleEmitterState state) {_State=state;};
		inline pcParticleEmitterState GetState() {return _State;};

		virtual void WriteParams(ostream &o);
		virtual void ReadParams(istream &i);
};

#ifdef __UNIX__
#ifndef __STRUPR__
#define __STRUPR__
static void strupr(char *t)
{
       unsigned i=0;
       while(t[i]!=0) {if((t[i]>=97)&&(t[i]<=122)) t[i]-=32;i++;}
}
#endif
#endif

#endif
/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Scape : Landscape block manager
//
// Before using this library consult the LICENSE file

#ifndef __PS_LAND_MANAGER_H__
#define __PS_LAND_MANAGER_H__

#include "pvcconf.h"
#include "pomcore.h"
#include "landpart.h"
#include "vector3.h"
#include <vector>
using std::vector;

class PVDLL psLandscapePartManager : public pomCoreObject
{
	DECLARE_POMIZED(psLandscapePartManager);

protected:
	bool IsCloseToFrustum(int handle);
	float _Thresold,_DistThresold;
	float _LoadingRadius;
	unsigned _MaxTriCount;
	
	struct pslpmPartInfos	
	{
		psLandscapePart *Part;
		pvVector3D Pos;
	};

public:	
	psLandscapePartManager();
	~psLandscapePartManager();
	int AddPart(psLandscapePart *p);
	void SetPartPos(int handle,pvVector3D &p);
	psLandscapePart *GetPart(int handle);

	virtual void Render(unsigned char *target=(unsigned char*)-1);
	void SetThresold(const float t);
	void SetDistThresold(const float t);
	void SetMaxTriCount(const unsigned t);
	psLandscapePart *GetPartAt(float x,float z);
	void UpdateHeight(float x,float z,float h);

	inline float GetThresold() {return _Thresold;};
	inline float GetDistThresold() {return _DistThresold;};
	inline unsigned GetMaxTriCount() {return _MaxTriCount;};
	bool GetHeight(float x,float z,float &height);
	unsigned GetTriCount();
	float GetLoadingRadius() const {return _LoadingRadius;};
	void SetLoadingRadius(float lr) {_LoadingRadius=lr;};

private:
	vector<pslpmPartInfos> _Parts;
};

#endif
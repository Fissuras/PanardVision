/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// Panard Scape : Base landscape block
//
// Before using this library consult the LICENSE file

#ifndef __PS_LAND_PART_H__
#define __PS_LAND_PART_H__

#include "pvcconf.h"
#include "pomcore.h"
#include "vector3.h"
#include "psterload.h"
#include "pvsys.h"
#include "pvision.h"

#ifdef __UNIX__
#define __fastcall
#endif

#include <vector>
using std::vector;

////////////////////////////////////////////////////////////////////////

// Constants to designate neighbors of a patch
#define PS_NORTH	0
#define PS_WEST		1
#define PS_EAST		2
#define PS_SOUTH	3

#define PSF_CALCNORMALS		1  // Compute normals for this landscape part

class PVDLL psLandscapePart : public pomCoreObject, public pvThreadable
{
	DECLARE_POMIZED(psLandscapePart);

public:
	enum PartState {NOT_READY,READY,TRANSIENT_LOADING,TRANSIENT_UNLOADING,TRANSIENT_UPDATING};

	struct psMergeDiamond
	{
		unsigned d1,d2;
	};

	struct psSplitRecord
	{
			float prio;
			unsigned index;

			psSplitRecord(float prio,unsigned index):prio(prio),index(index){};
			psSplitRecord(){};

			bool operator<(const psSplitRecord& y) const;
	};

	struct psMergeRecord
	{
			float prio;
			psMergeDiamond d;

			psMergeRecord(float prio,psMergeDiamond d):prio(prio),d(d){};
			psMergeRecord(){};

			bool operator<(const psMergeRecord& y) const;
	};

protected:	
	volatile PartState _State;
	psLandscapePart *_Links[4];
	unsigned _Flags;

private:
	struct psTextureBlockInfo
	{
		PVMaterial *Mat;
		unsigned RepeatX,RepeatY;
	};
	
	float _ScaleX,_ScaleY,_ScaleZ,_MinHeight,_MaxHeight;
	float _Thresold,_DistThresold;
	pvVector3D *_Vis;
	unsigned _TriCount,_MaxIndex1,_MaxIndex2,_MaxTriCount;

	std::vector<unsigned> _TempoSplitList;	

public:
	struct psTriVert
	{
		unsigned v0,v1,v2;
	};

	psLandscapePart();
	~psLandscapePart();
	void Init(bool keepinfos=false);
	unsigned LoadFromFile(const char *name);
	unsigned LoadFromStream(istream &in,const char *type);
	unsigned WriteSubBlock(ostream &out,unsigned startx,unsigned sizex,unsigned starty,unsigned sizey);
	void Update(pvVector3D *org=NULL);
	void InitBinTri();
	void Compact();
	void CompactHardCore();
	void SetTexture(unsigned x,unsigned y,unsigned repeatx,unsigned repeaty,PVMaterial *m);
	unsigned GetLevel(unsigned index);
	
	virtual void Render() {};
	virtual void Unload();
	virtual int Load();
	int RunThread() {if(_State==psLandscapePart::TRANSIENT_UNLOADING) {Unload(); _State=NOT_READY; return 0;} else {unsigned h=Load(); EnforceMinimumSplitLevel(); _State=READY; return h;}};
	void UpdateHeight(unsigned x,unsigned y,float h);
	void UpdateHeight(float x,float z,float h);
	void CalcWedgies();
	
	inline void SetFlags(unsigned flags) {_Flags=flags;};
	inline unsigned GetFlags() {return _Flags;};

	float GetHeight(float x,float z);
	inline float GetMinHeight() const {return _MinHeight;};	
	inline float GetMaxHeight() const {return _MaxHeight;};	
	inline float GetScaleX() const {return _ScaleX;};
	inline float GetScaleY() const {return _ScaleY;};
	inline float GetScaleZ() const {return _ScaleZ;};
	inline unsigned GetSide() const {return _Side;};
	inline float GetThresold() const {return _Thresold;};
	inline float GetDistThresold() const {return _DistThresold;};
	inline unsigned GetMaxTriCount() const {return _MaxTriCount;};
	inline unsigned GetTriCount() const {return _TriCount;};
	inline void SetScaleX(const float stepx) {_ScaleX=stepx;};
	inline void SetScaleY(const float stepy) {_ScaleY=stepy;};
	inline void SetScaleZ(const float stepz) {_ScaleZ=stepz;};
	inline void SetThresold(const float t) {if((t!=_Thresold)&&(t>0)) {_Thresold=t;}};	
	inline void SetDistThresold(const float t) {if((t!=_DistThresold)&&(t>0)) {_DistThresold=t;}};
	inline void SetMaxTriCount(const unsigned t) {if(t>0) _MaxTriCount=t;}
	inline bool IsCompacted() {return (_CompactOffset==0);};
	inline PartState GetState() {return _State;};
	inline void SetState(PartState state) {_State=state;};
	inline bool IsReady() {return (_State==READY);};
	
	inline unsigned GetTextureSubdivisionLevel() {return _NbrTextureLevel;};
	void SetTextureSubdivisionLevel(unsigned level);	
	inline psLandscapePart *GetNeighbor(unsigned where) {if(where<4) return _Links[where]; else return NULL;};
	inline void SetNeighbor(unsigned where, psLandscapePart *p) {if(where>=4) return; _Links[where]=p;};

protected:
	struct psBinTriNode
	{
		unsigned LeftNeighbor,RightNeighbor,BottomNeighbor;
		char Flags,TexNbr;
	};
	struct psWedgie
	{
		float w;
	};	
	
	psLoadTerrainInterface::psTerrainData *_Terrain;	
	psBinTriNode *_BinTri;
	psTriVert *_TriTable;
	psWedgie *_Wedgies;
	pvVector3D *_TriNormals,*_VertNormals;
	unsigned _NbrLevels;
	vector<psSplitRecord> _SplitQueue;
	vector<psMergeRecord> _MergeQueue;
	vector<unsigned> _NSEW[4];

	typedef std::vector<psSplitRecord>::iterator psSplitIterator;
	typedef std::vector<psMergeRecord>::iterator psMergeIterator;
	typedef std::vector<unsigned>::iterator psNSEWIterator;

	unsigned _CompactOffset;
	unsigned _Side;
	unsigned _NbrTextureLevel;
	psTextureBlockInfo* _Textures;
	bool _Enforced;

	void ProcessTerrain();
	void Merge(psMergeIterator p1);
	void Split(unsigned index);
	void Split2(unsigned index);
	void CleanMergeQueue();
	void CleanSplitQueue();
	void CalcWedgies(unsigned level);
	void UpdateFrustumFlags(unsigned index);
	void __fastcall UpdateFrustumFlags(unsigned index,unsigned flags);
	void UpdateFrustumFlags();
	void UpdateQueues();
	void CountTris(unsigned index,unsigned &r,unsigned &max);
	void InitTextures();
	void EnforceMinimumSplitLevel();
	float CalcPriority(unsigned v);
	void CalcNormals();
};

////////////////////////////////////////////////////////////////////////

class PVDLL psLandscapePartPV : public psLandscapePart
{
	DECLARE_POMIZED(psLandscapePartPV);
	
private:
	PVMaterial *_DummyMat;

protected:
	unsigned _LastNbrOutputedTris;

	void __fastcall RenderRecursive(unsigned index,unsigned level);

public:
	virtual void SetupRender();
	void Render();
	psLandscapePartPV();
	~psLandscapePartPV();

	inline unsigned GetLastNbrRenderedTris() const {return _LastNbrOutputedTris;};
};

#endif
/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
// 3Dfx's Glide driver
//
// Before using this library consult the LICENSE file

#ifndef __PV3DFX_H__
#define __PV3DFX_H__

#include "pvision.h"

#ifdef __cplusplus
extern "C" {
#endif

PVEXPORT PVHardwareDriver PVDriver;

#ifdef __cplusplus
}
#endif

#endif

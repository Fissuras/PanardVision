
 FLEXPORTER SDK version 1.04

 Any bug or comment should be reported to:

 p.terdiman@codercorner.com


 Folders:

 \FlexporterSDK		includes & libs needed to build your own exporters
 \IceASCIIExporter	source code for the ASCII Flexporter plug-in
 \IceZCBExporter	source code for the ZCB Flexporter plug-in
 \VoidExporter		skeleton code to build your own Flexporter plug-in


 I use two extra libs:

 - ZLib by Jean-loup Gailly and Mark Adler
 - BZip2 by Julian Seward


 FLEXPORTER 1.11

 Any bug or comment should be reported to:

 p.terdiman@codercorner.com

 That's completely free code, so I'm working for you,
 and the more bugs you report, the more this program
 will serve your needs in a robust way.

 Feel free to even ask for a new feature if you think
 something is missing. I can't promise anything, but
 I'll try upgrading that plug-in on a regular basis.


 What's new in current build?
 => read \Doc\News.pdf


 Pierre
 June, 18, 2001

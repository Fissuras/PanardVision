/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// 3DFX Driver for the Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//
// Before using this library consult the LICENSE file
//
//---------------------------------------------------------------------------
#ifdef WIN32
#include <windows.h>
#endif
#include <string.h>
#include <glide.h>
#include "texus.h"				// I have patched this texus.h to include __cdecl calling convention to the API since 3dfx forgot to do so
#include "pvision.h"
#include "pv3dfx.h"
#include "voofill.h"
#include "fpu.h"
#include "cache3dfx.h"

static PVFLAGS PVM;
PVMaterial *lastm;
static PVFLAGS oldpvf=0;
static char FogEnabled;

#ifdef WIN32
LONG OldWndProc;
HWND Wnd;

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
    {        
	case WM_ACTIVATEAPP:
		if(wParam) 
			grSstControl(GR_CONTROL_ACTIVATE);
		else
			grSstControl(GR_CONTROL_DEACTIVATE);
	}

    return CallWindowProc((WNDPROC)OldWndProc,hwnd, msg, wParam, lParam);
}

#endif

/////////////////////////////////////////////////////////////////////////////////

static int PVAPI VoodooDetect(void)
{
	GrHwConfiguration hw;

	grSstQueryBoards(&hw);

	return  hw.num_sst;
}

static int PVAPI VoodooFillSurface(unsigned surfacenum,float r,float g,float b,float a); // forward declaration
static int PVAPI VoodooInitSupport(long wnd)
{
	FxBool hr;
	char Inited;
	unsigned a,b;
	GrHwConfiguration hw;

	grGlideInit();

	if (! grSstQueryHardware(&hw)) return NO_ACCELSUPPORT;

	grSstSelect(0);

	// Double Buffering  + Depth buffer
#ifdef WIN32
	if(!IsWindow((HWND)wnd)) wnd=(long)GetActiveWindow();

	SetFocus((HWND)wnd);

	// SubClass WindowProc
	OldWndProc=GetWindowLong((HWND)wnd, GWL_WNDPROC );
	SetWindowLong((HWND)wnd,GWL_WNDPROC,(LONG)WindowProc); 

	Wnd=(HWND)wnd;
#endif
	Inited=0;
	if(getenv("PV3DFX")!=NULL)
	{
		if(strcmp(getenv("PV3DFX"),"WINDOWED")==0)
		{
			hr=grSstWinOpen(wnd,GR_RESOLUTION_NONE,GR_REFRESH_60Hz, GR_COLORFORMAT_RGBA,
					GR_ORIGIN_UPPER_LEFT, 2,1);
			Inited=1;
		}
	}
	if(!Inited)
		hr=grSstWinOpen(wnd,GR_RESOLUTION_640x480,GR_REFRESH_60Hz, GR_COLORFORMAT_RGBA,
				GR_ORIGIN_UPPER_LEFT, 2,1);

	if(!hr) return BIZAR_ERROR;

	VoodooFillSurface(0,0,0,0,0);
	VoodooFillSurface(1,0,0,0,0);

	grHints(GR_HINT_ALLOW_MIPMAP_DITHER,1);

	// Init cache subsystem
	MultiTexture=0;
	printf("Voodoo subsytsem INFOS:\n");

	switch(hw.SSTs[0].type)
	{
		case GR_SSTTYPE_VOODOO:
			if(hw.SSTs[0].sstBoard.VoodooConfig.nTexelfx>1)
			{
				MultiTexture=2;
				
				a=grTexMinAddress(GR_TMU0);
				b=grTexMaxAddress(GR_TMU0);
				printf("\tTMU0 has %u bytes for textures.\n",b-a);
				InitCachePool(0,b-a);
				BaseAdress0=a;

				a=grTexMinAddress(GR_TMU1);
				b=grTexMaxAddress(GR_TMU1);
				printf("\tTMU1 has %u bytes for textures.\n",b-a);
				InitCachePool(1,b-a);
				BaseAdress1=a;
			}
			else
			{
				a=grTexMinAddress(GR_TMU0);
				b=grTexMaxAddress(GR_TMU0);
				printf("\tTMU0 has %u bytes for textures.\n",b-a);
				InitCachePool(0,b-a);
				BaseAdress0=a;
			}
			break;
		case GR_SSTTYPE_SST96:
			if(hw.SSTs[0].sstBoard.SST96Config.nTexelfx>1)
			{
				MultiTexture=2;
				
				a=grTexMinAddress(GR_TMU0);
				b=grTexMaxAddress(GR_TMU0);
				printf("\tTMU0 has %u bytes for textures.\n",b-a);
				InitCachePool(0,b-a);
				BaseAdress0=a;
				
				a=grTexMinAddress(GR_TMU1);
				b=grTexMaxAddress(GR_TMU1);
				printf("\tTMU1 has %u bytes for textures.\n",b-a);
				InitCachePool(1,b-a);
				BaseAdress1=a;
			}
			else
			{
				a=grTexMinAddress(GR_TMU0);
				b=grTexMaxAddress(GR_TMU0);
				printf("\tTMU0 has %u bytes for textures.\n",b-a);
				InitCachePool(0,b-a);
				BaseAdress0=a;
			}
			break;
		case GR_SSTTYPE_AT3D:
		default:
			printf("\tUnknow SST type !\n");
	}
	if(MultiTexture) 
	{
		printf("\tUsing Multitexture capabilities\n");
		
		grTexCombine(	GR_TMU1, GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
								 GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
						FXFALSE, FXFALSE );

		grTexFilterMode(GR_TMU1,GR_TEXTUREFILTER_BILINEAR,GR_TEXTUREFILTER_BILINEAR);
		grTexMipMapMode(GR_TMU1,GR_MIPMAP_DISABLE,FXFALSE );
		grTexClampMode(GR_TMU1,GR_TEXTURECLAMP_CLAMP,GR_TEXTURECLAMP_CLAMP);
	}

	// Setting pipeline word
	PV_SetPipelineControl(PVP_NO_TRIANGULATE);

	return COOL;
}

static void PVAPI VoodooEndSupport(void)
{
#ifdef WIN32
	SetWindowLong((HWND)Wnd,GWL_WNDPROC,(LONG)WindowProc); 
#endif
	EndCacheSystem();
	grSstWinClose();
	grGlideShutdown();
}

static int PVAPI VoodooSetViewPort(unsigned int cmx,unsigned int cMx,unsigned int cmy,unsigned int cMy)
{
	grClipWindow(cmx,cmy,cMx,cMy);
	return COOL;
}

static int PVAPI VoodooLoadTexture(PVMaterial *m)
{
	Gu3dfInfo info;
	size_t tex_mem_required;
	int target_width, target_height;
	unsigned i,j;
	FxBool r;
	static GrTextureClampMode_t Texm[]={GR_TEXTURECLAMP_WRAP,GR_TEXTURECLAMP_CLAMP};
	GrTextureFormat_t TexType;
	PVVoodoo *sc;
	UPVD32 h,h2;

	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return COOL;

	target_width=m->Tex[0].Width;
	target_height=m->Tex[0].Height;

	if(!(m->TextureFlags&TEXTURE_RGBA))
	{
		// Sets Texture type accroding to quality hint
		if(m->Hint.Quality&PHQ_LOW) TexType=GR_TEXFMT_YIQ_422;
		else
		TexType=GR_TEXFMT_RGB_565;

		if(m->TextureFlags&TEXTURE_MIPMAP)
		tex_mem_required = txInit3dfInfo( &info, TexType,
										&target_width, &target_height,
										(m->NbrMipMaps<=9)?m->NbrMipMaps:-1, TX_AUTORESIZE_GROW );
		else
		tex_mem_required = txInit3dfInfo( &info, TexType,
										&target_width, &target_height,
										1, TX_AUTORESIZE_GROW );
	}
	else
	{
		// Convert PV's texture RGBA to ARGB
		for(j=0;j<m->Tex[0].Height;j++)
		for(i=0;i<m->Tex[0].Width;i++)
		{
			h=((PVD32*)m->Tex[0].Texture)[j*m->Tex[0].Width+i];
			h2=h&0xFF000000;
			h<<=8;
			h|=h2>>24;
			((PVD32*)m->Tex[0].Texture)[j*m->Tex[0].Width+i]=h;
		}

		// Sets Texture type accroding to quality hint
		if(m->Hint.Quality&PHQ_LOW) TexType=GR_TEXFMT_AYIQ_8422;
		else
		TexType=GR_TEXFMT_ARGB_4444;

		if(m->TextureFlags&TEXTURE_MIPMAP)
		tex_mem_required = txInit3dfInfo( &info, TexType,
										&target_width, &target_height,
										(m->NbrMipMaps<=9)?m->NbrMipMaps:-1, TX_AUTORESIZE_GROW );
		else
		tex_mem_required = txInit3dfInfo( &info, TexType,
										&target_width, &target_height,
										1, TX_AUTORESIZE_GROW );
	}

	if (tex_mem_required==0) return ACCEL_NO_MEMORY;
	info.data=(void*)malloc(tex_mem_required);
	if(info.data==NULL) return NO_MEMORY;

    if(m->TextureFlags&TEXTURE_RGBA)
		r=txConvert( &info, GR_TEXFMT_ARGB_8888,
				 m->Tex[0].Width, m->Tex[0].Height,
				 &m->Tex[0].Texture[0],TX_COMPRESSION_HEURISTIC|TX_DITHER_NONE, NULL );
	else
		r=txConvert( &info, GR_TEXFMT_RGB_888,
				 m->Tex[0].Width, m->Tex[0].Height,
				 &m->Tex[0].Texture[0],TX_COMPRESSION_HEURISTIC|TX_DITHER_NONE, NULL );

	if(r==FXFALSE) return ACCEL_NO_MEMORY;

	// Init du contexte
	m->HardwarePrivate=calloc(sizeof(PVVoodoo),2);
	if(m->HardwarePrivate==NULL) return NO_MEMORY;
	sc=m->HardwarePrivate;

	sc[0].texinfo.smallLod=info.header.small_lod;
	sc[0].texinfo.largeLod=info.header.large_lod;
	sc[0].texinfo.aspectRatio=info.header.aspect_ratio;
	sc[0].texinfo.format=info.header.format;
	sc[0].texinfo.data=info.data;
	sc[0].Size=grTexTextureMemRequired(GR_MIPMAPLEVELMASK_BOTH, &sc[0].texinfo);
	sc[0].table=info.table.nccTable;

	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{
			// Preprocess lightmap to be darker
			for(i=0;i<m->AuxiliaryTexture.Width;i++)
				for(j=0;j<m->AuxiliaryTexture.Height;j++)
				{
					m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]=max(0,m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]-1.3*(255-m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]));
				}

			target_width=m->AuxiliaryTexture.Width;
			target_height=m->AuxiliaryTexture.Height;

			tex_mem_required = txInit3dfInfo( &info, GR_TEXFMT_INTENSITY_8,
											&target_width, &target_height,
											1, TX_AUTORESIZE_GROW );
			if (tex_mem_required==0) return ACCEL_NO_MEMORY;
			info.data=(void*)malloc(tex_mem_required);
			if(info.data==NULL) return NO_MEMORY;

			r=txConvert( &info, GR_TEXFMT_INTENSITY_8,
						 m->AuxiliaryTexture.Width, m->AuxiliaryTexture.Height,
						 &m->AuxiliaryTexture.Texture[0],0, NULL );

			if(r==FXFALSE) return ACCEL_NO_MEMORY;

			sc[1].texinfo.smallLod=info.header.small_lod;
			sc[1].texinfo.largeLod=info.header.large_lod;
			sc[1].texinfo.aspectRatio=info.header.aspect_ratio;
			sc[1].texinfo.format=info.header.format;
			sc[1].texinfo.data=info.data;						
			sc[1].Size=grTexTextureMemRequired(GR_MIPMAPLEVELMASK_BOTH, &sc[1].texinfo);
	}
	return COOL;
}

static void PVAPI VoodooDeleteTexture(PVMaterial *m)
{
	PVVoodoo *sc;

	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return;
	
	sc=m->HardwarePrivate;

	free(sc[0].texinfo.data);

	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{
		free(sc[1].texinfo.data);
	}

	free(m->HardwarePrivate);
	m->HardwarePrivate=NULL;
}

//////////////////////////////////////////////////////////////////////////// LIGHTMAPS
#define MAXLIGHTMAPS	100000
#define LMAPW			256
#define LMAPH			256

static PVLightMap **LMaps=NULL;
static unsigned nbrlmaps=0,LMapComputed=0;
static unsigned running=0;
static UPVD16 tmpmap[LMAPW*LMAPH];
static PVVoodoo LMSurf[100];

static int PVAPI VoodooLoadLightMap(PVLightMap *m)
{
	if(LMapComputed) return COOL;
	if(m->Flags&LIGHTMAP_PROCESSED) return COOL;
	
	// On alloue le tablo pseudo statique
	if(LMaps==NULL)
	{
		LMaps=(PVLightMap**)calloc(MAXLIGHTMAPS,sizeof(PVLightMap*));
		if(LMaps==NULL) return NO_MEMORY;
		nbrlmaps=0;
	}
	
	LMaps[nbrlmaps++]=m;
	m->Flags|=LIGHTMAP_PROCESSED;

    return COOL;
}

static int __cdecl LMCompare( const void *arg1, const void *arg2 )
{
	PVLightMap *m1,*m2;
	
	m1=*(PVLightMap**)arg1;
	m2=*(PVLightMap**)arg2;
	
	if(m1->Height==m2->Height)
	{
		if(m1->Width>m2->Width) return -1;
		else return 1;
	}

	if(m1->Height<m2->Height) return 1;
	else return -1;
}

static int DownloadLightMaps(void)
{
	unsigned CurrentW=0,CurrentH=0,MaxH=0;
	UPVD16 *tex16,r,g,b;
	UPVD32 c;
	unsigned i,j,k,z,*sc3;	
	PVLightMap *m;		

	Gu3dfInfo info;
	size_t tex_mem_required;
	int target_width, target_height;

	int NbrBitsRed=5;
	int NbrBitsGreen=6;
	int NbrBitsBlue=5;
	int BluePos=0;
	int GreenPos=5;
	int RedPos=11;
					
	if(nbrlmaps==0) return COOL;
	
	// Sort lightmaps
	qsort( (void*)LMaps, nbrlmaps, sizeof( PVLightMap * ), LMCompare );	
		
	CurrentW=CurrentH=MaxH=0;
	LMapComputed=1;
	running=0;

	info.data=NULL;
	
	for(k=0;k<nbrlmaps;k++)
	{
		m=LMaps[k];

		sc3=calloc(sizeof(unsigned),m->NbrLightMaps);
		if(sc3==NULL) return NO_MEMORY;		
		m->HardwarePrivate=sc3;
		
		for(z=0;z<m->NbrLightMaps;z++)
		{			
			if((CurrentW==0)&&(CurrentH==0))
			{
				// Alloactes room
				target_width=LMAPW;
				target_height=LMAPH;
				tex_mem_required = txInit3dfInfo( &info, GR_TEXFMT_YIQ_422,
										&target_width, &target_height,
										1, TX_AUTORESIZE_GROW );
				if (tex_mem_required==0) return ACCEL_NO_MEMORY;
				
				info.data=(void*)malloc(tex_mem_required);
				if(info.data==NULL) return NO_MEMORY;

				LMSurf[running].texinfo.smallLod=info.header.small_lod;
				LMSurf[running].texinfo.largeLod=info.header.large_lod;
				LMSurf[running].texinfo.aspectRatio=info.header.aspect_ratio;
				LMSurf[running].texinfo.format=info.header.format;
				LMSurf[running].texinfo.data=info.data;	
				LMSurf[running].Size=grTexTextureMemRequired(GR_MIPMAPLEVELMASK_BOTH, &LMSurf[running].texinfo);
				running++;
			}
			
			// Now fills the surface with the texture						
			// Init the filling process			
			tex16=tmpmap;			
			
			// Decal
			if((CurrentW+m->Width<LMAPW)&&(CurrentH+m->Height<LMAPH))
			{				
				tex16+=CurrentH*LMAPW+CurrentW;				
				CurrentW+=m->Width;
				if(m->Height+CurrentH>MaxH) MaxH=m->Height+CurrentH;
			}
			else
			{
				// not enough room, try a lower band				
				if(MaxH+m->Height<LMAPH)
				{
					CurrentH=MaxH;
					CurrentW=0;
					z--;
					continue;
				}
				else
				{
					// Convert texture
					r=txConvert( &info, GR_TEXFMT_RGB_565,LMAPW,LMAPH,tmpmap,TX_COMPRESSION_HEURISTIC|TX_DITHER_NONE, NULL );
					if(r==FXFALSE) return ACCEL_NO_MEMORY;

					LMSurf[running-1].table=info.table.nccTable;

					CurrentW=CurrentH=MaxH=0;
					z--;
					continue;
				}
			}		
			
			for(i=0;i<m->Height;i++)
			{
				for(j=0;j<m->Width;j++)
				{				
					if(m->Flags&LIGHTMAP_RGB)
					{
						r=(UPVD8)m->Maps[z][3*(i*m->Width+j)];
						g=(UPVD8)m->Maps[z][3*(i*m->Width+j)+1];
						b=(UPVD8)m->Maps[z][3*(i*m->Width+j)+2];
					}
					else
					{
						r=g=b=(UPVD8)m->Maps[z][(i*m->Width+j)];
					}
										
					r=(float)r*(float)((1<<NbrBitsRed)-1)/255.0;
					g=(float)g*(float)((1<<NbrBitsGreen)-1)/255.0;
					b=(float)b*(float)((1<<NbrBitsBlue)-1)/255.0;					
					
					c=(b<<BluePos);
					c|=(g<<GreenPos);
					c|=(r<<RedPos);	
					
					*tex16=c;
					tex16++;									
				}				
				tex16+=LMAPW-m->Width;				
			}

			// Fixup ccord
			m->su[z]*=(float)m->Width/(float)LMAPW;
			m->sv[z]*=(float)m->Height/(float)LMAPH;
					
			m->su[z]+=(float)(CurrentW-m->Width+0.75)/(float)LMAPW;
			m->sv[z]+=(float)(CurrentH+0.75)/(float)LMAPH;
						
			// Save infos
			sc3[z]=running-1;
		}

		// Setup lightmaps scaling
		m->ScaleU*=(float)(m->Width)/(float)LMAPW;
		m->ScaleV*=(float)(m->Height)/(float)LMAPH;
		m->ScaleU-=0.75/(float)LMAPW;
		m->ScaleV-=0.75/(float)LMAPH;
		m->ScaleU*=(1.0/(float)(m->MaxU-m->MinU));
		m->ScaleV*=(1.0/(float)(m->MaxV-m->MinV));
	}
	
	// Convert texture
	r=txConvert( &info, GR_TEXFMT_RGB_565,LMAPW,LMAPH,tmpmap,TX_COMPRESSION_HEURISTIC|TX_DITHER_NONE, NULL );
	if(r==FXFALSE) return ACCEL_NO_MEMORY;

	LMSurf[running-1].table=info.table.nccTable;

	// Setup cache infos
	for(k=0;k<nbrlmaps;k++)
	{
		m=LMaps[k];
		sc3=m->HardwarePrivate;
		
		for(z=0;z<m->NbrLightMaps;z++)
		{
			sc3[z]=(unsigned)&LMSurf[sc3[z]];
		}
	}

	
	return COOL;
}

static void PVAPI VoodooDeleteLightMap(PVLightMap *m)
{	
	unsigned k;
	
	if(!(m->Flags&LIGHTMAP_PROCESSED)) return;
	if(m==NULL) return;
	
	free(m->HardwarePrivate);
	m->HardwarePrivate=NULL;
	
	nbrlmaps--;
	if(nbrlmaps==0)
	{
		for(k=0;k<running;k++)
		{
			free(LMSurf[k].texinfo.data);
		}
		LMapComputed=0;
	}
	REMOVEFLAG(m->Flags,LIGHTMAP_PROCESSED);
}

////////////////////////////////////////////////////////////////////////////////////////////

static void *PVAPI VoodooGetFiller(PVFLAGS flags)
{
	if(flags&MULTITEXTURE)
	{
		flags&=~MULTITEXTURE;
		flags|=MAPPING;
	}

	flags&=~PERSPECTIVE;

	switch (flags&(RENDER_MASK|SHADE_MASK))
	{
		case FLAT|NOTHING:return (void*)TriVoodooFlat;break;
		case GOURAUD|NOTHING:return (void*)TriVoodooGouraud;break;
		case U_PHONG|NOTHING:
		case PHONG|NOTHING:
		case NOTHING|AMBIENT_MAPPING:
		case NOTHING|MAPPING:return (void*)TriVoodooMapping;break;

		case FLAT|AMBIENT_MAPPING:
		case FLAT|MAPPING:return (void*)TriVoodooFlatMapping;break;

		case GOURAUD|AMBIENT_MAPPING:
		case GOURAUD|MAPPING:return (void*)TriVoodooGouraudMapping;break;

		// Bump is treated as Phong
		case U_BUMP|AMBIENT_MAPPING:
		case U_BUMP|MAPPING:
		case BUMP|AMBIENT_MAPPING:
		case BUMP|MAPPING:

		case U_PHONG|AMBIENT_MAPPING:
		case U_PHONG|MAPPING:
		case PHONG|AMBIENT_MAPPING:
		case PHONG|MAPPING:if(MultiTexture) return (void*)TriVoodooBiMappingBi; else return (void*)TriVoodooBiMapping;break;

        case LIGHTMAP|MAPPING:if(MultiTexture) return (void*)TriVoodooLightmapBi; else return (void*)TriVoodooLightmap;break;

		default:return NULL;
	}
}

static void PVAPI VoodooBeginFrame(PVFLAGS PVMode,PVFLAGS PVPipe)
{
	// Generates lightmaps
	if(LMapComputed==0)
	{
		int hr=DownloadLightMaps();
		if(hr!=COOL) return;
	}

	// Clear the depth buffer
	if((PVMode&PVM_ZBUFFER)&&((!(PVPipe&PVP_NO_ZBUFFERCLEAR))))
	{
		grDepthBufferMode( GR_DEPTHBUFFER_ZBUFFER );
		grDepthMask( FXTRUE );
		grColorMask(FXFALSE,FXFALSE);
		grBufferClear(0,0, GR_ZDEPTHVALUE_NEAREST);
		grColorMask(FXTRUE,FXFALSE);
		grDepthMask( FXFALSE );
	}

	// For vertex snapping
	SetFPU_IEE24();

	lastm=NULL;
}

static void PVAPI VoodooEndFrame(void)
{
	SetFPU_IEE53();
}

static int PVAPI VoodooPreRender(PVWorld *w,unsigned surfacenum,PVFLAGS PVMode,PVFLAGS PVPipe)
{
	AmbientLight=&w->AmbientLight;
	fp=w->Camera->FrontDist;
	bp=w->Camera->BackDist;

	switch(surfacenum)
	{
		case 1:grRenderBuffer(GR_BUFFER_FRONTBUFFER);break;
		default:grRenderBuffer(GR_BUFFER_BACKBUFFER);
	}

	PVM=PVMode;

	depthval=65535*(bp/(bp-fp));
	depthval2=65535*(bp*fp)/(bp-fp);

	// Fog support
	if(w->Fog.Type!=PVF_NONE)
	{	
		GrFog_t FogTable[GR_FOG_TABLE_SIZE];
		static PVFogInfo LastFog;
		
		grFogMode(GR_FOG_WITH_TABLE);
		grFogColorValue(((int)(w->Fog.Color.r*255)<<24)|
						((int)(w->Fog.Color.g*255)<<16)|
						((int)(w->Fog.Color.b*255)<<8));
		FogEnabled=1;
		if(memcmp(&LastFog,&w->Fog,sizeof(LastFog))!=0)
		{
			switch(w->Fog.Type)
			{															
			case PVF_LINEAR:guFogGenerateLinear(FogTable,w->Fog.Start,w->Fog.End);break;
			case PVF_EXP2:guFogGenerateExp2(FogTable,w->Fog.Density);break;
			case PVF_EXP:guFogGenerateExp(FogTable,w->Fog.Density);break;
			default:
				PV_Fatal("Voodoo Driver: Unknown fog mode !",w->Fog.Type);
			}
			grFogTable(FogTable);
			
			LastFog=w->Fog;
		}
	}
	else 
	{
		grFogMode(GR_FOG_DISABLE);
		FogEnabled=0;
	}

	return COOL;
}

static void PVAPI VoodooPrepareFace(PVFace *f)
{
	static int Alphaf[]={GR_BLEND_ZERO,GR_BLEND_ONE,GR_BLEND_DST_COLOR,GR_BLEND_ONE_MINUS_DST_COLOR,GR_BLEND_SRC_ALPHA,GR_BLEND_ONE_MINUS_SRC_ALPHA,GR_BLEND_DST_ALPHA,GR_BLEND_ONE_MINUS_DST_ALPHA,GR_BLEND_ALPHA_SATURATE,GR_BLEND_SRC_COLOR,GR_BLEND_ONE_MINUS_SRC_COLOR};

	if(oldpvf==PVM)
        if(lastm==f->MaterialInfo) return;
	
	// sets up Alpha testing
	if(PVM&PVM_ALPHATESTING)
	{
		switch(f->MaterialInfo->AlphaTest)
		{
		case CMP_LESS:grAlphaTestFunction(GR_CMP_LESS);break;
		case CMP_NEVER:grAlphaTestFunction(GR_CMP_NEVER);break;
		case CMP_EQUAL:grAlphaTestFunction(GR_CMP_EQUAL);break;
		case CMP_LEQUAL:grAlphaTestFunction(GR_CMP_LEQUAL);break;
		case CMP_GREATER:grAlphaTestFunction(GR_CMP_GREATER);break;
		case CMP_NOTEQUAL:grAlphaTestFunction(GR_CMP_NOTEQUAL);break;
		case CMP_GEQUAL:grAlphaTestFunction(GR_CMP_GEQUAL);break;
		case CMP_ALWAYS:
		default:grAlphaTestFunction(GR_CMP_ALWAYS);break;
		}
		grAlphaTestReferenceValue(f->MaterialInfo->AlphaReference*255);
	}
	else grAlphaTestFunction(GR_CMP_ALWAYS);

	// Sets up alpha combine and some other things	
	if(f->MaterialInfo->Type&MAPPED_MATERIAL)
	{
		if(f->MaterialInfo->Type&FLAT) 
            guColorCombineFunction(GR_COLORCOMBINE_TEXTURE_TIMES_CCRGB);	
		else
		    if(f->MaterialInfo->Type&GOURAUD) 
                guColorCombineFunction(GR_COLORCOMBINE_TEXTURE_TIMES_ITRGB);
		    else 
                guColorCombineFunction(GR_COLORCOMBINE_DECAL_TEXTURE);

		guTexCombineFunction(GR_TMU0,GR_TEXTURECOMBINE_DECAL);
	}
	else
	{
		if(f->MaterialInfo->Type&GOURAUD) 
            guColorCombineFunction(GR_COLORCOMBINE_ITRGB); 
        else 
            guColorCombineFunction(GR_COLORCOMBINE_CCRGB);
		guTexCombineFunction(GR_TMU0,GR_TEXTURECOMBINE_ZERO);
	}

	// Sets up Depth Buffering
	if((PVM&PVM_ZBUFFER)&&(f->MaterialInfo->Type&ZBUFFER))
	{
		switch(f->MaterialInfo->DepthTest)
		{
		case CMP_LESS:grDepthBufferFunction(GR_CMP_LESS);break;
		case CMP_NEVER:grDepthBufferFunction(GR_CMP_NEVER);break;
		case CMP_EQUAL:grDepthBufferFunction(GR_CMP_EQUAL);break;
		case CMP_LEQUAL:grDepthBufferFunction(GR_CMP_LEQUAL);break;
		case CMP_GREATER:grDepthBufferFunction(GR_CMP_GREATER);break;
		case CMP_NOTEQUAL:grDepthBufferFunction(GR_CMP_NOTEQUAL);break;
		case CMP_GEQUAL:grDepthBufferFunction(GR_CMP_GEQUAL);break;
		case CMP_ALWAYS:
		default:grDepthBufferFunction(GR_CMP_ALWAYS);break;
		}
		if(f->MaterialInfo->ZWrite) grDepthMask( FXTRUE ); else grDepthMask( FXFALSE );
		grDepthBufferMode( GR_DEPTHBUFFER_ZBUFFER );
	}
	else
	{
		grDepthBufferMode( GR_DEPTHBUFFER_DISABLE );
		grDepthMask( FXFALSE );
	}

	// Fog Powah!
	if((!(f->MaterialInfo->Type&FOGABLE))||(!FogEnabled))
		grFogMode(GR_FOG_DISABLE);
	else
		grFogMode(GR_FOG_WITH_TABLE);
		
	// Sets up Alpha Blending
	if(PVM&PVM_ALPHABLENDING)
	{
		if(f->MaterialInfo->TextureFlags&TEXTURE_RGBA)
		    guAlphaSource(GR_ALPHASOURCE_TEXTURE_ALPHA);
	    else
	    if(f->MaterialInfo->Type&MAPPED_MATERIAL)
	    {
		    if(f->MaterialInfo->Type&GOURAUD) 
                guAlphaSource(GR_ALPHASOURCE_TEXTURE_ALPHA_TIMES_ITERATED_ALPHA);                
		    else 
                guAlphaSource(GR_ALPHASOURCE_CC_ALPHA);
	    }
	    else
	    {
		    if(f->MaterialInfo->Type&GOURAUD) 
                guAlphaSource(GR_ALPHASOURCE_ITERATED_ALPHA);
		    else 
                guAlphaSource(GR_ALPHASOURCE_CC_ALPHA);
	    }

        grAlphaBlendFunction(Alphaf[f->MaterialInfo->BlendRgbSrcFactor],Alphaf[f->MaterialInfo->BlendRgbDstFactor],
					         Alphaf[f->MaterialInfo->BlendAlphaSrcFactor],Alphaf[f->MaterialInfo->BlendAlphaDstFactor]);
	}
	else
	{
	    grAlphaBlendFunction(GR_BLEND_ONE,GR_BLEND_ZERO,
					 	     GR_BLEND_ONE,GR_BLEND_ZERO);
        guAlphaSource(GR_ALPHASOURCE_TEXTURE_ALPHA);
	}

	lastm=f->MaterialInfo;
    oldpvf=PVM;
}

static void PVAPI VoodooPostRender(void)
{
}

static int PVAPI VoodooFlipSurface(void)
{
	grBufferSwap(0);
	return COOL;
}

static int PVAPI VoodooFillSurface(unsigned surfacenum,float r,float g,float b,float a)
{
	GrColor_t color=0;
	UPVD8 rb,gb,bb;

	switch(surfacenum)
	{
		case 1:grRenderBuffer(GR_BUFFER_FRONTBUFFER);break;
		default:grRenderBuffer(GR_BUFFER_BACKBUFFER);
	}

	rb=r*255;
	gb=g*255;
	bb=b*255;

	color=(rb<<24)+(gb<<16)+(bb<<8);

	// Do not clear depth buffer
	grDepthMask(FXFALSE);
	grBufferClear(color, a*255, 0);
	return COOL;
}

static void PVAPI VoodooRefreshMaterial(PVMaterial *m)
{
	lastm=NULL;
}

extern PVHardwareCaps VoodooCaps;
static PVHardwareCaps * PVAPI VoodooGetInfo(void)
{
	return &VoodooCaps;
}

static void * PVAPI VoodooLockFB(unsigned surfacenum,PVFLAGS mode)
{
    GrLfbInfo_t info;
	FxBool r;
	unsigned surf;

	switch(surfacenum)
	{
		case 1:surf=GR_BUFFER_FRONTBUFFER;break;
		default:surf=GR_BUFFER_BACKBUFFER;
	}

	info.size = sizeof( GrLfbInfo_t );

	switch(mode)
	{
		case PFB_READONLY:
        r=grLfbLock( GR_LFB_READ_ONLY,
                        surf,
                        GR_LFBWRITEMODE_565,
                        GR_ORIGIN_UPPER_LEFT,
                        FXFALSE,
                        &info );
						break;
		case PFB_WRITEONLY:
        r=grLfbLock( GR_LFB_WRITE_ONLY,
                        surf,
                        GR_LFBWRITEMODE_565,
                        GR_ORIGIN_UPPER_LEFT,
                        FXFALSE,
                        &info );
						break;
	}

	VoodooCaps.RowStride=info.strideInBytes;

	if(r==FXFALSE) return NULL;
	else return info.lfbPtr;
}

static void PVAPI VoodooUnLockFB(unsigned surfacenum,PVFLAGS mode)
{
	int surf;

	switch(surfacenum)
	{
		case 1:surf=GR_BUFFER_FRONTBUFFER;break;
		default:surf=GR_BUFFER_BACKBUFFER;
	}

	switch(mode)
	{
		case PFB_READONLY:
        grLfbUnlock( GR_LFB_READ_ONLY,
                        surf);
						break;
		case PFB_WRITEONLY:
        grLfbUnlock( GR_LFB_WRITE_ONLY,
                        surf);
						break;
	}
}

static void * PVAPI VoodooLockDB(PVFLAGS mode)
{
    GrLfbInfo_t info;
	FxBool r;

	info.size = sizeof( GrLfbInfo_t );

	switch(mode)
	{
		case PFB_READONLY:
        r=grLfbLock( GR_LFB_READ_ONLY,
                        GR_BUFFER_AUXBUFFER,
                        GR_LFBWRITEMODE_ZA16,
                        GR_ORIGIN_UPPER_LEFT,
                        FXFALSE,
                        &info );
						break;
		case PFB_WRITEONLY:
        r=grLfbLock( GR_LFB_WRITE_ONLY,
                        GR_BUFFER_AUXBUFFER,
                        GR_LFBWRITEMODE_ZA16,
                        GR_ORIGIN_UPPER_LEFT,
                        FXFALSE,
                        &info );
						break;
	}

	VoodooCaps.RowStride=info.strideInBytes;

	if(r==FXFALSE) return NULL;
	else return info.lfbPtr;
}

static void PVAPI VoodooUnLockDB(PVFLAGS mode)
{
	switch(mode)
	{
		case PFB_READONLY:
        grLfbUnlock( GR_LFB_READ_ONLY,
                        GR_BUFFER_AUXBUFFER);
						break;
		case PFB_WRITEONLY:
        grLfbUnlock( GR_LFB_WRITE_ONLY,
                        GR_BUFFER_AUXBUFFER);
						break;
	}
}

static int PVAPI VoodooBitBltFB(unsigned surfacenum,unsigned xdst,unsigned ydst,void *src,unsigned width, unsigned height,unsigned stride)
{
	int surf;

	switch(surfacenum)
	{
		case 1:surf=GR_BUFFER_FRONTBUFFER;break;
		default:surf=GR_BUFFER_BACKBUFFER;
	}

    if(grLfbWriteRegion(surf,xdst,ydst,GR_LFB_SRC_FMT_8888,width,height,stride,src)==FXFALSE) return BIZAR_ERROR; else return COOL;

}

static int PVAPI VoodooBitBltDB(unsigned xdst,unsigned ydst,void *src,unsigned width, unsigned height,unsigned stride)
{
    if(grLfbWriteRegion(GR_BUFFER_AUXBUFFER,xdst,ydst,GR_LFB_SRC_FMT_ZA16,width,height,stride,src)==FXFALSE) return BIZAR_ERROR; else return COOL;
}

static UPVD8* PVAPI VoodooLockProceduralMaterial(PVMaterial *m,PVRGBFormat *rgb,PVFLAGS access)
{
	PVVoodoo *sc;

	rgb->NbrBitsPerPixel=16;
	rgb->Pitch=m->Tex[0].Width*2;
	if(m->TextureFlags&TEXTURE_RGBA)
	{		
		rgb->RedSize=4;
		rgb->BlueSize=4;
		rgb->GreenSize=4;
		rgb->AlphaSize=4;
		rgb->RedPos=12;
		rgb->GreenPos=8;
		rgb->BluePos=4;
		rgb->AlphaPos=0;
	}
	else
	{
		rgb->RedSize=5;
		rgb->BlueSize=5;
		rgb->GreenSize=6;
		rgb->AlphaSize=0;
		rgb->RedPos=11;
		rgb->GreenPos=5;
		rgb->BluePos=0;
		rgb->AlphaPos=0;
	}
	sc=m->HardwarePrivate;
	return sc[0].texinfo.data;
}

static void PVAPI VoodooUnlockProceduralMaterial(PVMaterial *m)
{	
	PVVoodoo *sc;

	sc=m->HardwarePrivate;
	if(sc[0].Loaded) grTexDownloadMipMap(GR_TMU0, BaseAdress0+sc[0].Cache->Start, GR_MIPMAPLEVELMASK_BOTH, &sc[0].texinfo );		
}

///////////////////////////////////////////////////////////////////////////////

PVHardwareCaps VoodooCaps={
	PHG_ZBUFFER|PHG_ALPHATEST,
	PHF_FRAMEBUFFER|PHF_DEPTHBUFFER|PHF_BITBLTFB|PHF_BITBLTDB,
	PHT_BILINEAR|PHT_TRILINEAR|PHT_MIPMAP,
	PHB_SRCRGBBLEND|PHB_DSTRGBBLEND|PHB_SRCALPHABLEND|PHB_DSTALPHABLEND,
	PHD_DEPTHPROP,
	16,
	5,6,5,0,
	11,5,0,0,
	1024,
	640,480,
	2,
	16,
	0
};

PVHardwareDriver PVDriver={
	1,
	PV_MN2,
	sizeof(PVHardwareCaps),
	"Panard Vision Voodoo Driver V2.03 (Glide 2.4)",
	VoodooDetect,
	VoodooInitSupport,
	VoodooEndSupport,
	VoodooSetViewPort,
	VoodooLoadTexture,
	VoodooDeleteTexture,
	VoodooGetFiller,
	VoodooPreRender,
	VoodooPrepareFace,
	VoodooPostRender,
	VoodooBeginFrame,
	VoodooEndFrame,
	VoodooFlipSurface,
	VoodooFillSurface,
	VoodooRefreshMaterial,
	VoodooGetInfo,
	VoodooLockFB,
	VoodooUnLockFB,
	VoodooLockDB,
	VoodooUnLockDB,
	NULL,
	NULL,
	VoodooBitBltFB,
	VoodooBitBltDB,
	NULL,
    VoodooLoadLightMap,
    VoodooDeleteLightMap,
	VoodooLockProceduralMaterial,
	VoodooUnlockProceduralMaterial,
	NULL
};

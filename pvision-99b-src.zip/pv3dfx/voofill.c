/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// 3DFX Driver for the Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//
// Before using this library consult the LICENSE file
//
//---------------------------------------------------------------------------

#include <string.h>
#include <glide.h>
#include "pvision.h"
#include "pv3dfx.h"
#include "voofill.h"
#include "cache3dfx.h"

PVRGBF *AmbientLight;
float bp,fp,depthval,depthval2;						// BackClipping plane
extern PVMaterial *lastm;
unsigned BaseAdress0,BaseAdress1;
char MultiTexture;

//--------------------------------------------------------------------------------

static GrVertex v[MAX_VERTICES_PER_POLY*2];
static unsigned nbrv;

static float vertex_snapper = ( float ) ( 3L << 18 );

/*
 * This structure contains the factors to multiply normalized [0.0, 1.0]
 * texture coordinates by in order to get the texture coordinates that
 * Voodoo Graphics expect.
 */
typedef struct
{
  float sMult;
  float tMult;
} TexCoordFactors;

/*
 * An array which is indexed by GrAspectRatio_t to convert from normalized
 * texture coordinates to Voodoo texture coordinates.
 */
TexCoordFactors aspectToTexCoordFactors[7] = {
  { 255.0f,        255.0f / 8.0f },  /* GR_ASPECT_8x1 */
  { 255.0f,        255.0f / 4.0f },  /* GR_ASPECT_4x1 */
  { 255.0f,        255.0f / 2.0f },  /* GR_ASPECT_2x1 */
  { 255.0f,        255.0f        },  /* GR_ASPECT_1x1 */
  { 255.0f / 2.0f, 255.0f        },  /* GR_ASPECT_1x2 */
  { 255.0f / 4.0f, 255.0f        },  /* GR_ASPECT_1x4 */
  { 255.0f / 8.0f, 255.0f        }   /* GR_ASPECT_1x8 */
};
static float smult, tmult,smult1,tmult1;

//-------------------------------------------------------------------------------------------

#define SnapVertex(b) \
	b.x +=vertex_snapper;	\
	b.y +=vertex_snapper;	\
	b.x -=vertex_snapper;	\
	b.y -=vertex_snapper;

#define LoadColor(x,p) \
	x.r=255*min(1,(o->Shading[p].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r); \
	x.g=255*min(1,(o->Shading[p].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g); \
	x.b=255*min(1,(o->Shading[p].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b); \
	x.a=255*(f->MaterialInfo->AlphaConstant*o->Shading[p].Color.a);

#define LoadMapCoord(x,a) \
	if(f->Flags&(PHONG|U_PHONG))		\
	{									\
		x.tmuvtx[0].oow = x.oow;	\
		x.tmuvtx[0].sow = o->Mapping[a].AmbientU*smult*x.oow;	\
		x.tmuvtx[0].tow = o->Mapping[a].AmbientV*tmult*x.oow;	\
	}	\
	else	\
	{	\
		x.tmuvtx[0].oow = x.oow;	\
		x.tmuvtx[0].sow = o->Mapping[a].u*smult*x.oow;	\
		x.tmuvtx[0].tow = o->Mapping[a].v*tmult*x.oow;	\
	}

#define LoadMapCoord1(x,a) \
		x.tmuvtx[0].oow = x.oow;	\
		x.tmuvtx[0].sow = o->Mapping[a].u*smult*x.oow;	\
		x.tmuvtx[0].tow = o->Mapping[a].v*tmult*x.oow;

#define LoadMapCoord2(x,a) \
	x.tmuvtx[0].oow = x.oow;	\
	x.tmuvtx[0].sow = o->Mapping[a].AmbientU*smult*x.oow; \
	x.tmuvtx[0].tow = o->Mapping[a].AmbientV*tmult*x.oow;

#define LoadMapCoord22(x,a) \
	x.tmuvtx[1].oow = x.oow;	\
	x.tmuvtx[1].sow = o->Mapping[a].AmbientU*smult1*x.oow; \
	x.tmuvtx[1].tow = o->Mapping[a].AmbientV*tmult1*x.oow;

#define LoadMapCoord3(x,a) \
		x.tmuvtx[0].oow = x.oow;	\
		x.tmuvtx[0].sow = (f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU)*smult*x.oow;	\
		x.tmuvtx[0].tow = (f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV)*tmult*x.oow;

#define LoadMapCoord32(x,a) \
		x.tmuvtx[1].oow = x.oow;	\
		x.tmuvtx[1].sow = (f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU)*smult1*x.oow;	\
		x.tmuvtx[1].tow = (f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV)*tmult1*x.oow;

#define LoadZ(x,a) \
	x.oow = 1/(1+65534*((-fp/o->Projected[a].InvertZ)-fp)/(bp-fp)); \
	x.ooz = 65535-depthval+o->Projected[a].InvertZ*depthval2;

//////////////////////////////////////////////////////////////////

static PVVoodoo *LastMip0=NULL,*LastMip1=NULL;
static GuNccTable *ncc0=NULL,*ncc1=NULL,*ncc02=NULL,*ncc12=NULL;

static void SetTexState(PVMaterial *m)
{
	unsigned clamp[]={GR_TEXTURECLAMP_WRAP,GR_TEXTURECLAMP_CLAMP};
	
	if(m->TextureFlags&TEXTURE_MIPMAP)
		grTexMipMapMode( GR_TMU0, GR_MIPMAP_NEAREST, FXFALSE );
	else	
		grTexMipMapMode( GR_TMU0, GR_MIPMAP_DISABLE, FXFALSE );

	if(m->TextureFlags&TEXTURE_TRILINEAR)
	{
		grTexMipMapMode(GR_TMU0, GR_MIPMAP_NEAREST_DITHER, FXFALSE );
		grTexFilterMode(GR_TMU0,GR_TEXTUREFILTER_BILINEAR,GR_TEXTUREFILTER_BILINEAR);
	}
	else
	if(m->TextureFlags&TEXTURE_BILINEAR)
		grTexFilterMode(GR_TMU0,GR_TEXTUREFILTER_BILINEAR,GR_TEXTUREFILTER_BILINEAR);
	else
		grTexFilterMode(GR_TMU0,GR_TEXTUREFILTER_BILINEAR,GR_TEXTUREFILTER_POINT_SAMPLED);
	
	grTexClampMode(	GR_TMU0,clamp[m->RepeatU],clamp[m->RepeatV]);
}

////////////////////////////////////////

static void LoadTexture(PVMaterial *m)
{
	PVVoodoo *sc;

	sc=m->HardwarePrivate;

	if(!sc[0].Loaded)
	{
		sc[0].Cache=AllocateEntry(0,sc[0].Size,&sc[0]);		
		grTexDownloadMipMap(GR_TMU0, BaseAdress0+sc[0].Cache->Start+sc[0].Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[0].texinfo );	
	}
	
	if(LastMip0!=sc)
	{																
		grTexSource( GR_TMU0, BaseAdress0+sc[0].Cache->Start+sc[0].Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[0].texinfo );
		
		smult = aspectToTexCoordFactors[sc[0].texinfo.aspectRatio].sMult;	
		tmult = aspectToTexCoordFactors[sc[0].texinfo.aspectRatio].tMult;	

		SetTexState(m);
		LastMip0=sc;

		if((sc[0].texinfo.format==GR_TEXFMT_YIQ_422)||(sc[0].texinfo.format==GR_TEXFMT_AYIQ_8422))
		{
			if(ncc0!=&sc[0].table)
			{
				grTexDownloadTable( GR_TMU0, GR_TEXTABLE_NCC0, &sc[0].table);
				ncc0=&sc[0].table;
			}
			grTexNCCTable(GR_TMU0, GR_TEXTABLE_NCC0);
		}
	}
}

static void LoadTextureAmb0(PVMaterial *m)
{
	PVVoodoo *sc;

	sc=m->HardwarePrivate;

	if(!sc[1].Loaded)
	{
		sc[1].Cache=AllocateEntry(0,sc[1].Size,&sc[1]);		
		grTexDownloadMipMap(GR_TMU0, BaseAdress0+sc[1].Cache->Start+sc[1].Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[1].texinfo );		
	}
	
	grTexSource( GR_TMU0, BaseAdress0+sc[1].Cache->Start+sc[1].Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[1].texinfo );
	
	smult = aspectToTexCoordFactors[sc[1].texinfo.aspectRatio].sMult;	
	tmult = aspectToTexCoordFactors[sc[1].texinfo.aspectRatio].tMult;	

	grTexFilterMode(GR_TMU0,GR_TEXTUREFILTER_BILINEAR,GR_TEXTUREFILTER_BILINEAR);
	grTexMipMapMode(GR_TMU0,GR_MIPMAP_DISABLE,FXFALSE );
	grTexClampMode(GR_TMU0,GR_TEXTURECLAMP_CLAMP,GR_TEXTURECLAMP_CLAMP);
	
	LastMip0=NULL;	
}

static void LoadLM0(PVLightMap *m,unsigned n)
{
	PVVoodoo **sc;

	sc=m->HardwarePrivate;

	if(!sc[n]->Loaded)
	{
		sc[n]->Cache=AllocateEntry(0,sc[n]->Size,sc[n]);		
		grTexDownloadMipMap(GR_TMU0, BaseAdress0+sc[n]->Cache->Start+sc[n]->Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[n]->texinfo );	
	}
	
	grTexSource( GR_TMU0, BaseAdress0+sc[n]->Cache->Start+sc[n]->Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[n]->texinfo );
	
	smult = aspectToTexCoordFactors[sc[n]->texinfo.aspectRatio].sMult;	
	tmult = aspectToTexCoordFactors[sc[n]->texinfo.aspectRatio].tMult;	
	
	grTexFilterMode(GR_TMU0,GR_TEXTUREFILTER_BILINEAR,GR_TEXTUREFILTER_BILINEAR);
	grTexMipMapMode(GR_TMU0,GR_MIPMAP_DISABLE,FXFALSE );

	LastMip0=NULL;

	if(ncc1!=&sc[n]->table)
	{
		grTexDownloadTable( GR_TMU0, GR_TEXTABLE_NCC1, &sc[n]->table);
		ncc1=&sc[n]->table;
	}
	grTexNCCTable(GR_TMU0, GR_TEXTABLE_NCC1);
}

////////////////////////////////////////

static void LoadTextureAmb1(PVMaterial *m)
{
	PVVoodoo *sc;

	sc=m->HardwarePrivate;

	if(!sc[1].Loaded)
	{
		sc[1].Cache=AllocateEntry(1,sc[1].Size,&sc[1]);		
		grTexDownloadMipMap(GR_TMU1, BaseAdress1+sc[1].Cache->Start+sc[1].Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[1].texinfo );		
	}
	
	if(LastMip1!=&sc[1])
	{
		grTexSource( GR_TMU1, BaseAdress1+sc[1].Cache->Start+sc[1].Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[1].texinfo );
		
		smult1 = aspectToTexCoordFactors[sc[1].texinfo.aspectRatio].sMult;	
		tmult1 = aspectToTexCoordFactors[sc[1].texinfo.aspectRatio].tMult;	
		
		LastMip1=&sc[1];	
	}
}

static void LoadLM1(PVLightMap *m,unsigned n)
{
	PVVoodoo **sc;

	sc=m->HardwarePrivate;

	if(!sc[n]->Loaded)
	{
		sc[n]->Cache=AllocateEntry(1,sc[n]->Size,sc[n]);		
		grTexDownloadMipMap(GR_TMU1, BaseAdress1+sc[n]->Cache->Start+sc[n]->Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[n]->texinfo );	
	}

	if(LastMip1!=sc[n])
	{																
		grTexSource( GR_TMU1, BaseAdress1+sc[n]->Cache->Start+sc[n]->Cache->decal, GR_MIPMAPLEVELMASK_BOTH, &sc[n]->texinfo );

		smult1 = aspectToTexCoordFactors[sc[n]->texinfo.aspectRatio].sMult;	
		tmult1 = aspectToTexCoordFactors[sc[n]->texinfo.aspectRatio].tMult;	

		LastMip1=sc[n];

		if(ncc12!=&sc[n]->table)
		{
			grTexDownloadTable( GR_TMU1, GR_TEXTABLE_NCC1, &sc[n]->table);
			ncc12=&sc[n]->table;
		}
		grTexNCCTable(GR_TMU1, GR_TEXTABLE_NCC1);
	}
}

///////////////////////////////////////////////////////

#define LoadTex LoadTexture(f->MaterialInfo);
#define LoadTex2 LoadTextureAmb0(f->MaterialInfo);
#define LoadTex3 LoadLM0(f->LightMap,f->LightMap->CurrentLightMap);

#define DrawPoly(w) \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			v[i].x = o->Projected[a].xf; \
			v[i].y = o->Projected[a].yf; \
			LoadZ(v[i],a); \
			w; \
			SnapVertex(v[i]); \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			v[i].x = o->Projected[a].xf; \
			v[i].y = o->Projected[a].yf; \
			LoadZ(v[i],a); \
			w; \
			SnapVertex(v[i]);	\
} \
} \
grDrawPolygonVertexList(nbrv, v);

#define DrawPoly2(w) \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			w; \
} \
} \
grDrawPolygonVertexList(nbrv, v);

//------------------------------------------------------------------------------------------

void PVAPI TriVoodooGouraud(PVFace *f)
{    
	unsigned a,i;
	PVMesh *o=f->Father;

	DrawPoly(LoadColor(v[i],a));
}

void PVAPI TriVoodooFlat(PVFace *f)
{
	unsigned a=f->V[0],i;
	PVMesh *o=f->Father;
	GrColor_t col;

	col=255*(f->MaterialInfo->AlphaConstant*o->Shading[a].Color.a);
	col|=((int)(255*min(1,(o->Shading[a].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r)))<<24;
	col|=((int)(255*min(1,(o->Shading[a].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g)))<<16;
	col|=((int)(255*min(1,(o->Shading[a].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b)))<<8;

	grConstantColorValue(col);

	DrawPoly(;);    
}

void PVAPI TriVoodooMapping(PVFace *f)
{ 
	unsigned a,i;
	PVMesh *o=f->Father;
	GrColor_t col;

	LoadTex;
	col=f->MaterialInfo->AlphaConstant*255;
	grConstantColorValue(col);

	DrawPoly(LoadMapCoord(v[i],a))
}

void PVAPI TriVoodooFlatMapping(PVFace *f)
{
	unsigned a=f->V[0],i;
	PVMesh *o=f->Father;
	GrColor_t col;

	LoadTex;

	col=255*(o->Shading[a].Color.a*f->MaterialInfo->AlphaConstant);
	col|=((int)(255*min(1,(o->Shading[a].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r)))<<24;
	col|=((int)(255*min(1,(o->Shading[a].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g)))<<16;
	col|=((int)(255*min(1,(o->Shading[a].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b)))<<8;

	grConstantColorValue(col);

	DrawPoly(LoadMapCoord(v[i],a))
}

void PVAPI TriVoodooGouraudMapping(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;

	LoadTex;

	DrawPoly(LoadColor(v[i],a);LoadMapCoord(v[i],a));
}

void PVAPI TriVoodooBiMapping(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;
	GrColor_t col;

	//2 Pass rasterization
	LoadTex;
	col=f->MaterialInfo->AlphaConstant*255;
	grConstantColorValue(col);

	DrawPoly(LoadMapCoord1(v[i],a));

	// Second Pass	
	grDepthBufferFunction(GR_CMP_LEQUAL);
	grAlphaBlendFunction(GR_BLEND_DST_COLOR, GR_BLEND_ZERO, GR_BLEND_DST_COLOR, GR_BLEND_ZERO);

	LoadTex2;
	DrawPoly2(LoadMapCoord2(v[i],a));

	lastm=NULL;
	PVDriver.PrepareFace(f);
}

void PVAPI TriVoodooBiMappingBi(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;
	GrColor_t col;

	LoadTex;
	LoadTextureAmb1(f->MaterialInfo);

	col=f->MaterialInfo->AlphaConstant*255;
	grConstantColorValue(col);

	grHints(GR_HINT_STWHINT,GR_STWHINT_ST_DIFF_TMU1);

	grTexCombine(	GR_TMU0, 
	GR_COMBINE_FUNCTION_SCALE_OTHER, GR_COMBINE_FACTOR_LOCAL,
	GR_COMBINE_FUNCTION_SCALE_OTHER, GR_COMBINE_FACTOR_LOCAL,
	FXFALSE, FXFALSE ); 

	DrawPoly(LoadMapCoord1(v[i],a);LoadMapCoord22(v[i],a));

	grTexCombine( GR_TMU0, GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
 	GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
 	FXFALSE, FXFALSE ); 

	grHints(GR_HINT_STWHINT,0);
}

void PVAPI TriVoodooLightmap(PVFace *f)
{    
	unsigned a,i;
	PVMesh *o=f->Father;
	GrColor_t col;

	//2 Pass rasterization	
	LoadTex;
	col=f->MaterialInfo->AlphaConstant*255;
	grConstantColorValue(col);

	DrawPoly(LoadMapCoord1(v[i],a));

	// Second Pass	
	grDepthBufferFunction(GR_CMP_LEQUAL);
	grAlphaBlendFunction(GR_BLEND_DST_COLOR, GR_BLEND_ZERO, GR_BLEND_DST_COLOR, GR_BLEND_ZERO);

	LoadTex3;

	DrawPoly2(LoadMapCoord3(v[i],a));

	lastm=NULL;	
	PVDriver.PrepareFace(f);
}

void PVAPI TriVoodooLightmapBi(PVFace *f)
{    
	unsigned a,i;
	PVMesh *o=f->Father;
	GrColor_t col;

	LoadTex;
	LoadLM1(f->LightMap,f->LightMap->CurrentLightMap);
	
	col=f->MaterialInfo->AlphaConstant*255;
	grConstantColorValue(col);

	grHints(GR_HINT_STWHINT,GR_STWHINT_ST_DIFF_TMU1);

	grTexCombine(	GR_TMU0, 
	GR_COMBINE_FUNCTION_SCALE_OTHER, GR_COMBINE_FACTOR_LOCAL,
	GR_COMBINE_FUNCTION_SCALE_OTHER, GR_COMBINE_FACTOR_LOCAL,
	FXFALSE, FXFALSE ); 

	DrawPoly(LoadMapCoord1(v[i],a);LoadMapCoord32(v[i],a));

	grTexCombine( GR_TMU0, GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
 	GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
 	FXFALSE, FXFALSE ); 
	
	grHints(GR_HINT_STWHINT,0);
}


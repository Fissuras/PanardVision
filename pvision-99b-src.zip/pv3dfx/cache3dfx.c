/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// 3DFX Driver for the Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//
// Before using this library consult the LICENSE file
//
//---------------------------------------------------------------------------

#include <stdlib.h>
#include "cache3dfx.h"

typedef struct __PVCachePool
{
	unsigned Size;
	PVCacheEntry *Cache,*Rover;
} PVCachePool;

static PVCachePool Pools[MAX_CACHE_POOL];

//////////////////////////////////////////////////////////

static PVCacheEntry *CreateEntry(unsigned size)
{
	PVCacheEntry *c;

	c=(PVCacheEntry*)malloc(sizeof(PVCacheEntry));
	if(c!=NULL)
	{
		c->Size=size;
		c->decal=0;
		c->User=NULL;
		c->Next=NULL;
	}
	return c;
}

int PVAPI FlushCachePool(unsigned pool)
{
	PVCacheEntry *c,*c2;

	c=Pools[pool].Cache;
	while(c!=NULL)
	{
		c2=c->Next;
		free(c);
		c=c2;
	}

	Pools[pool].Cache=CreateEntry(Pools[pool].Size);
	Pools[pool].Cache->Start=0;
	Pools[pool].Rover=Pools[pool].Cache;
	return COOL;
}

int PVAPI InitCachePool(unsigned pool,unsigned size)
{
	Pools[pool].Size=size;
	FlushCachePool(pool);
	return COOL;
}

void PVAPI EndCacheSystem(void)
{
	unsigned i;

	for(i=0;i<MAX_CACHE_POOL;i++)
	{
		FlushCachePool(i);
		free(Pools[i].Cache);
	}
}

PVCacheEntry *PVAPI AllocateEntry(unsigned pool,unsigned size,PVVoodoo *id)
{
	PVCacheEntry *rov=Pools[pool].Rover,*cur,*cur2;
	unsigned n;

	rov=rov->Next;
	if(rov==NULL) rov=Pools[pool].Cache;

	n=2*1024*1024;
	while(n<Pools[pool].Size)
	{
		if((rov->Start<n)&&(rov->Start+size>n))
		{
			// Prevent 2Mb cross boundary
			size+=n-rov->Start;
			rov->decal=n-rov->Start;
			break;
		}
		n+=2*1024*1024;
	}

	// Test pour le wrap
	if((rov->Start+size)>Pools[pool].Size) rov=Pools[pool].Cache;
	
	// Collecte des blocs
	cur=rov->Next;
	while(rov->Size<size)
	{
		cur2=cur;	
		if(cur2->User!=NULL) cur2->User->Loaded=0;
		rov->Size+=cur2->Size;
		cur=cur2->Next;
		free(cur2);		
	}
	rov->Next=cur;
	if(rov->User!=NULL) rov->User->Loaded=0;
	rov->User=id;
	id->Loaded=1;

	Pools[pool].Rover=rov;

	// si on a la taille exacte
	if(rov->Size==size) return rov;
	else
	{
		cur2=CreateEntry(rov->Size-size);
		cur2->Next=cur;
		cur2->Start=rov->Start+size; 
		rov->Size=size;		
		rov->Next=cur2;

		return rov;
	}	
	
	return NULL; // unreachable
}

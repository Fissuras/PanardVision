/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "pvision.h"
#include "glide.h"

#ifdef __cplusplus
extern "C" {
#endif


#define MAX_CACHE_POOL	8

struct __PVCacheEntry;
typedef struct __PVVoodoo
{
	char Loaded;
	GrTexInfo texinfo;
	struct __PVCacheEntry *Cache;
	unsigned Size;	
	GuNccTable table;
} PVVoodoo;

typedef struct __PVCacheEntry
{
	unsigned Start;
	unsigned Size;
	PVVoodoo *User;
	struct __PVCacheEntry *Next;
	unsigned decal;
} PVCacheEntry;

int PVAPI FlushCachePool(unsigned pool);
int PVAPI InitCachePool(unsigned pool,unsigned size);
void PVAPI EndCacheSystem(void);
PVCacheEntry *PVAPI AllocateEntry(unsigned pool,unsigned size,PVVoodoo *id);

#ifdef __cplusplus
}
#endif

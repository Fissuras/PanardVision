#ifndef __FSQRT_H__
#define __FSQRT_H__

#ifdef __cplusplus
extern "C" {
#endif

void init_sqrt_tab(void);
double fsqrt(double f);

#ifdef __cplusplus
}
#endif

#endif
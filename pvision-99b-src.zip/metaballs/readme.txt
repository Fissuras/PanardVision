							3D METABALL SAMPLE
							==================

This sample uses the marching cube algorithm. This algo is used to
polygonise a scalar field (ie: render iso surfaces).
Details of this algorithm can be found in any decent graphics book.
(see Watt&Watt for instance), or on the WWW.
This implementation use an edge table and triangle table to speed up 
the decision process. These tables are taken from an article of Paul Bourke.

This source shows the marching cube algorithm in action to render 3D blobs, 
it's not the fastest implementation available since the isosurface sampling 
is done by a non-adaptative octree recursion. This causes *A LOT* of triangles
to be sent to the 3D pipeline.

One thing that will greatly improve performances is to do adptative sampling 
to get more precision where blobs are touching, and less elsewhere.
Another thing, is to share vertices and edges when sending triangles to the 3D
engine. 

There is different functions to generate iso-surfaces. One classical for "blob",
another that generates "blob-cubes", and "blob-diams".

No time for better explanations, sorry.

COMPILATION
===========
This is a VC5 project, you will need DX5 SDK to recompile this.
A minimum Panard Vision runtime is included to recompile the package.

PORT
====
You should be able to recompile the same source (meta.cpp) under Linux or DOS, using
the framework included in the Panard Vision SDK for Linux or DOS. No time to do this
myself :)
Same for hardware acceleration.

CONTACT
=======

If you make improvements, have comments or whatever you may
think about regarding this package contact me at:
                Olivier.Brunet@capway.com

Don't forget to visit the Panard Vision Home Page for updates:
        http://www.inforoute.capway.com/brunet3/

And the GMF Homepage:
	http://www.efrei.fr/~bruneto/gmf/

                                                SMKaribou/GMF                                                                        

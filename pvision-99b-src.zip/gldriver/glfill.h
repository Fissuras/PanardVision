/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// OpenGL Driver for the Panard Vision 3D Engine
// (C) 1997-98, Olivier Brunet

// Before using this library consult the LICENSE file

#ifndef __GLFILL_H__
#define __GLFILL_H__


#ifdef __cplusplus
extern "C" {
#endif

extern PVRGBF *AmbientLight;
extern int lastmip[2];
extern float bp,fp,depthval,depthval2;

///////////////////////////////////////////////////////////////////
// GL extensions

#ifndef __UNIX__
#define GL_CLIP_VOLUME_CLIPPING_HINT_EXT	0x80F0
#endif

#define GL_RGB2_EXT							0x804E
#define GL_RGB5_EXT							0x8050
#define GL_RGB8_EXT							0x8051
#define GL_RGBA2_EXT						0x8055
#define GL_RGBA4_EXT						0x8056
#define GL_RGBA8_EXT						0x8058

#define GL_RGB_S3TC							0x83A0
#define GL_RGB4_S3TC						0x83A1
#define GL_RGBA_S3TC						0x83A2
#define GL_RGBA4_S3TC						0x83A3

#define GL_COMPRESSED_RGB_S3TC_DXT1_EXT		0x83F0
#define GL_COMPRESSED_RGBA_S3TC_DXT1_EXT	0x83F1
#define GL_COMPRESSED_RGBA_S3TC_DXT3_EXT	0x83F2
#define GL_COMPRESSED_RGBA_S3TC_DXT5_EXT	0x83F3

#define GL_COMPRESSED_RGB_FXT1_3DFX			0x86B0
#define GL_COMPRESSED_RGBA_FXT1_3DFX		0x86B1

#define GL_COMPRESSED_ALPHA_ARB				0x84E9
#define GL_COMPRESSED_LUMINANCE_ARB			0x84EA
#define GL_COMPRESSED_LUMINANCE_ALPHA_ARB	0x84EB
#define GL_COMPRESSED_INTENSITY_ARB			0x84EC
#define GL_COMPRESSED_RGB_ARB				0x84ED
#define GL_COMPRESSED_RGBA_ARB				0x84EE

#define GL_TEXTURE_COMPRESSION_HINT_ARB		0x84EF

#define GL_FOG_DISTANCE_MODE_NV				0x855A
#define GL_EYE_RADIAL_NV					0x855b
#define GL_EYE_PLANE_ABSOLUTE_NV			0x855c

#define GL_MIRRORED_REPEAT_IBM				0x8370

/* GL_EXT_stencil_wrap */
#ifndef __UNIX__
#define GL_INCR_WRAP_EXT			0x8507
#define GL_DECR_WRAP_EXT			0x8508
#endif

extern unsigned GL_MAX_TEXTURES_SGIS;
extern unsigned GL_TEXTURE0_SGIS;
extern unsigned GL_TEXTURE1_SGIS;

#ifndef __UNIX__
typedef void (__stdcall * SelectTextureSGIS)(enum target);
typedef void (__stdcall * MultiTexCoord2fSGIS)(enum target, float s, float t);
typedef void (__stdcall * MultiTexCoord2fvSGIS)(enum target, float *s);
typedef void (__stdcall * MultiTexCoord4fSGIS)(enum target, float s, float t,float q,float r);
#else
typedef void ( * SelectTextureSGIS)(int);
typedef void ( * MultiTexCoord2fSGIS)(int, float s, float t);
typedef void ( * MultiTexCoord2fvSGIS)(int, float *s);
typedef void ( * MultiTexCoord4fSGIS)(int, float s, float t,float q,float r);
#endif

extern SelectTextureSGIS glSelectTextureSGIS;
extern MultiTexCoord2fSGIS glMultiTexCoord2fSGIS;
extern MultiTexCoord2fvSGIS glMultiTexCoord2fvSGIS;
extern MultiTexCoord4fSGIS glMultiTexCoord4fSGIS;

///////////////////////////////////////////////////////////////////

void PVAPI TriGLFlat(PVFace *f);
void PVAPI TriGLGouraud(PVFace *f);
void PVAPI TriGLMapping(PVFace *f);
void PVAPI TriGLFlatMapping(PVFace *f);
void PVAPI TriGLGouraudMapping(PVFace *f);
void PVAPI TriGLPhongMapping(PVFace *f);
void PVAPI TriGLPhongMappingBi(PVFace *f);
void PVAPI TriGLLightmap(PVFace *f);
void PVAPI TriGLLightmapBi(PVFace *f);
void PVAPI TriGLMultiTextureMT(PVFace *f);
void PVAPI TriGLMultiTexture(PVFace *f);

#ifdef __cplusplus
}
#endif

#endif

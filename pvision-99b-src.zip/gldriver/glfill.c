/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// OpenGL Driver for the Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//

// Fillers
// Not especially optimized :)

#ifdef WIN32
#include <windows.h>
#endif
#include <stdlib.h>
#include "pvision.h"
#include "pvgl.h"
#include "glfill.h"
#include <GL/gl.h>

PVRGBF *AmbientLight;
float bp,fp,depthval,depthval2;
extern PVMaterial *lastm;

//---------------------------------------------------------------------------------------
static unsigned nbrv;

#ifndef PVLIGHT
#define LoadVertex(x) glVertex3fv(&o->Vertex[x].xf);
#else
	static GLfloat xg,yg,zg;
#define LoadVertex(x) \
	xg=o->Projected[x].xf; yg=o->Projected[x].yf; zg=1-(depthval+o->Projected[x].InvertZ*depthval2); \
	glVertex4f(xg*-o->Rotated[x].zf,yg*-o->Rotated[x].zf,zg*-o->Rotated[x].zf,-o->Rotated[x].zf);
#endif

static float col[4];
#ifndef PVLIGHT
#define LoadNormal(x) glNormal3fv(&o->Vertex[x].Normal.xf);
#else
#define LoadNormal(x) \
			col[0]=min(1,(o->Shading[x].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r);	\
			col[1]=min(1,(o->Shading[x].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g);	\
			col[2]=min(1,(o->Shading[x].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b);	\
			col[3]=o->Shading[x].Color.a*f->MaterialInfo->AlphaConstant;	\
			glColor4fv(col);
#define LoadColor(x,a) \
			col[0]=min(1,(o->Shading[x].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r);	\
			col[1]=min(1,(o->Shading[x].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g);	\
			col[2]=min(1,(o->Shading[x].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b);	\
			col[3]=a;	\
			glColor4fv(col);
#endif

#ifndef PVLIGHT
#define SetMatParm {															\
		glMaterialfv(GL_FRONT,GL_DIFFUSE,&f->MaterialInfo->Diffuse.r);			\
		glMaterialfv(GL_FRONT,GL_EMISSION,&f->MaterialInfo->Emissive.r);		\
		glMaterialfv(GL_FRONT,GL_SPECULAR,&f->MaterialInfo->Specular.r);		\
		glMaterialiv(GL_FRONT,GL_SHININESS,&f->MaterialInfo->SpecularPower);	\
		}
#else
#define SetMatParm
#endif

GLint lastmip[2];

#define LoadTextureStage(x,y) \
		if(lastmip[x]!=(GLint)y) \
		{	 \
			glBindTexture(GL_TEXTURE_2D,lastmip[x]=(GLint)y);  \
		}	

#define LoadMapCoord(a) \
	if(f->Flags&(PHONG|U_PHONG))		\
	{									\
		glTexCoord2fv(&o->Mapping[a].AmbientU); \
	}	\
	else	\
	{	\
		glTexCoord2fv(&o->Mapping[a].u); \
	}

#define DrawPoly(w) \
	glBegin(GL_TRIANGLE_FAN); \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			w;\
			LoadVertex(a); \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			w;\
			LoadVertex(a); \
} \
} \
glEnd();

//------------------------------------------------------------------

void PVAPI TriGLFlat(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;	

		SetMatParm;
		DrawPoly(LoadNormal(f->V[0]));		
}

void PVAPI TriGLGouraud(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;

		SetMatParm;
		DrawPoly(LoadNormal(a));		
}

void PVAPI TriGLMapping(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;			

#ifndef PVLIGHT
		glDisable(GL_LIGHTING);
#endif
		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);
		DrawPoly(glColor4f(1,1,1,f->MaterialInfo->AlphaConstant);LoadMapCoord(a););

#ifndef PVLIGHT
		glEnable(GL_LIGHTING);
#endif
}

void PVAPI TriGLFlatMapping(PVFace *f)
{
		unsigned a=f->V[0],i;
		PVMesh *o=f->Father;
		
		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);		
		SetMatParm;
		DrawPoly(LoadMapCoord(a);LoadNormal(a));
}

void PVAPI TriGLGouraudMapping(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;
		
		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);		
		SetMatParm;
		DrawPoly(LoadMapCoord(a);LoadNormal(a));		
}

void PVAPI TriGLPhongMapping(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;		
		GLboolean abs;
		GLint as,ad,az;
		
		// 2 Pas fill
		// 1st pass, mapping
#ifndef PVLIGHT
		glDisable(GL_LIGHTING);
#endif
		
		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);				

		DrawPoly(glColor4f(1,1,1,f->MaterialInfo->AlphaConstant);glTexCoord2fv(&o->Mapping[a].u));

		//2nd Pass : luminance by blending a light map over the 1st triangle
		LoadTextureStage(0,&f->MaterialInfo->AuxiliaryTexture.Texture[0]);

		abs=glIsEnabled(GL_BLEND);
		glGetIntegerv(GL_BLEND_SRC,&as);
		glGetIntegerv(GL_BLEND_DST,&ad);
		glGetIntegerv(GL_DEPTH_FUNC ,&az);
		
		glEnable(GL_BLEND);
		glBlendFunc(GL_ZERO,GL_SRC_COLOR);		
		glDepthFunc(GL_LEQUAL);
			
		DrawPoly(glTexCoord2fv(&o->Mapping[a].AmbientU));

#ifndef PVLIGHT
		glEnable(GL_LIGHTING);
#endif			
		if(!abs)
			glDisable(GL_BLEND);
		glBlendFunc(as,ad);
		glDepthFunc(az);		
}

void PVAPI TriGLPhongMappingBi(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;		
		
		// 2 Pas fill
		// 1st pass, mapping
#ifndef PVLIGHT
		glDisable(GL_LIGHTING);
#endif
		
		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);				

		glSelectTextureSGIS(GL_TEXTURE1_SGIS);
		glEnable(GL_TEXTURE_2D);
		LoadTextureStage(1,&f->MaterialInfo->AuxiliaryTexture.Texture[0]);				

		DrawPoly(glColor4f(1,1,1,f->MaterialInfo->AlphaConstant);
		glMultiTexCoord2fvSGIS(GL_TEXTURE0_SGIS,&o->Mapping[a].u);
		glMultiTexCoord2fvSGIS(GL_TEXTURE1_SGIS,&o->Mapping[a].AmbientU);
		);

#ifndef PVLIGHT
		glEnable(GL_LIGHTING);
#endif					
		glDisable(GL_TEXTURE_2D);
		glSelectTextureSGIS(GL_TEXTURE0_SGIS);
}

/////////////////////////////////////////////////////////////////////////////////////////

void PVAPI TriGLLightmap(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;		
		float uv[2];		
		GLboolean abs;
		GLint as,ad,az;
		
		// 2 Pas fill
		// 1st pass, mapping
#ifndef PVLIGHT
		glDisable(GL_LIGHTING);
#endif
		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);				

		DrawPoly(glColor4f(1,1,1,f->MaterialInfo->AlphaConstant);glTexCoord2fv(&o->Mapping[a].u));

		//2nd Pass : luminance by blending a light map over the 1st triangle
		LoadTextureStage(0,*((GLint*)(&f->LightMap->Maps[f->LightMap->CurrentLightMap][0])));				

		abs=glIsEnabled(GL_BLEND);
		glGetIntegerv(GL_BLEND_SRC,&as);
		glGetIntegerv(GL_BLEND_DST,&ad);
		glGetIntegerv(GL_DEPTH_FUNC ,&az);

		glEnable(GL_BLEND);
		glBlendFunc(GL_ZERO,GL_SRC_COLOR);
		glDepthFunc(GL_LEQUAL);		
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

		DrawPoly(
			uv[0]=f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU;
			uv[1]=f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV;
			glTexCoord2fv(uv));

#ifndef PVLIGHT
		glEnable(GL_LIGHTING);
#endif					
		if(!abs)
			glDisable(GL_BLEND);
		glBlendFunc(as,ad);
		glDepthFunc(az);		
}

void PVAPI TriGLLightmapBi(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;		
		float uv[2];
		
#ifndef PVLIGHT
		glDisable(GL_LIGHTING);
#endif
		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);				

		glSelectTextureSGIS(GL_TEXTURE1_SGIS);
		glEnable(GL_TEXTURE_2D);
		LoadTextureStage(1,*(GLint*)(&f->LightMap->Maps[f->LightMap->CurrentLightMap][0]));				

		DrawPoly(glColor4f(1,1,1,f->MaterialInfo->AlphaConstant);
		glMultiTexCoord2fvSGIS(GL_TEXTURE0_SGIS,&o->Mapping[a].u);
		uv[0]=f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU;
		uv[1]=f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV;
		glMultiTexCoord2fvSGIS(GL_TEXTURE1_SGIS,uv);
		);

		glDisable(GL_TEXTURE_2D);
		glSelectTextureSGIS(GL_TEXTURE0_SGIS);

#ifndef PVLIGHT
		glEnable(GL_LIGHTING);
#endif					
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

void PVAPI TriGLMultiTexture(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;		
		float uv[2];		
		GLboolean abs;
		GLint as,ad,az;

		if(f->MaterialInfo->TexStage[0].ColorOp!=PVTSO_DETAILTEXTURE) return;

		// 2 Pas fill
		// 1st pass, mapping
#ifndef PVLIGHT
		glDisable(GL_LIGHTING);
#endif
		if(f->Flags&LIGHTMAP)
		{
			TriGLLightmap(f);
		}
		else
		{
			LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);				
			
			if((o->Shading!=NULL)&&(f->Flags&(FLAT|GOURAUD)))
			{
				DrawPoly(LoadColor(a,0.3);glTexCoord2fv(&o->Mapping[a].u));
			}
			else
			{
				DrawPoly(glColor4f(1,1,1,0.3);glTexCoord2fv(&o->Mapping[a].u));
			}
		}		

		abs=glIsEnabled(GL_BLEND);
		glGetIntegerv(GL_BLEND_SRC,&as);
		glGetIntegerv(GL_BLEND_DST,&ad);
		glGetIntegerv(GL_DEPTH_FUNC ,&az);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
		glDepthFunc(GL_LEQUAL);

		//2nd Pass 
		LoadTextureStage(0,&f->MaterialInfo->TexStage[0].Mat->Tex[0].Texture[0]);	
		
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		DrawPoly(
			glColor4f(1,1,1,0.3);
			uv[0]=o->Mapping[a].u*f->MaterialInfo->TexStage[0].Data1;
			uv[1]=o->Mapping[a].v*f->MaterialInfo->TexStage[0].Data2;
			glTexCoord2fv(uv));

#ifndef PVLIGHT
		glEnable(GL_LIGHTING);
#endif					
		if(!abs)
			glDisable(GL_BLEND);
		glBlendFunc(as,ad);
		glDepthFunc(az);		
}

void PVAPI TriGLMultiTextureMT(PVFace *f)
{
		unsigned a,i;
		PVMesh *o=f->Father;		
		float uv[2];
		GLboolean abs;
		GLint as,ad,az;

		if(f->MaterialInfo->TexStage[0].ColorOp!=PVTSO_DETAILTEXTURE) return;

#ifndef PVLIGHT
		glDisable(GL_LIGHTING);
#endif

		if(f->Flags&LIGHTMAP)
		{
			TriGLLightmapBi(f);

			abs=glIsEnabled(GL_BLEND);
			glGetIntegerv(GL_BLEND_SRC,&as);
			glGetIntegerv(GL_BLEND_DST,&ad);
			glGetIntegerv(GL_DEPTH_FUNC ,&az);

			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
			glDepthFunc(GL_LEQUAL);		
			
			LoadTextureStage(0,&f->MaterialInfo->TexStage[0].Mat->Tex[0].Texture[0]);

			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

			DrawPoly(glColor4f(1,1,1,0.3);			
			uv[0]=o->Mapping[a].u*f->MaterialInfo->TexStage[0].Data1;
			uv[1]=o->Mapping[a].v*f->MaterialInfo->TexStage[0].Data2;
			glTexCoord2fv(uv);
			);


	#ifndef PVLIGHT
			glEnable(GL_LIGHTING);
	#endif					
			if(!abs)
				glDisable(GL_BLEND);
			glBlendFunc(as,ad);
			glDepthFunc(az);		

			return;
		}

		LoadTextureStage(0,&f->MaterialInfo->Tex[0].Texture[0]);				

		glSelectTextureSGIS(GL_TEXTURE1_SGIS);
		glEnable(GL_TEXTURE_2D);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);								
		
		LoadTextureStage(1,&f->MaterialInfo->TexStage[0].Mat->Tex[0].Texture[0]);				

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if((o->Shading!=NULL)&&(f->Flags&(FLAT|GOURAUD)))
		{
			DrawPoly(
			LoadColor(a,0.3);
			glMultiTexCoord2fvSGIS(GL_TEXTURE0_SGIS,&o->Mapping[a].u);
			uv[0]=o->Mapping[a].u*f->MaterialInfo->TexStage[0].Data1;
			uv[1]=o->Mapping[a].v*f->MaterialInfo->TexStage[0].Data2;
			glMultiTexCoord2fvSGIS(GL_TEXTURE1_SGIS,uv);
			);
		}
		else
		{
			DrawPoly(
			glColor4f(1,1,1,0.3);
			glMultiTexCoord2fvSGIS(GL_TEXTURE0_SGIS,&o->Mapping[a].u);
			uv[0]=o->Mapping[a].u*f->MaterialInfo->TexStage[0].Data1;
			uv[1]=o->Mapping[a].v*f->MaterialInfo->TexStage[0].Data2;
			glMultiTexCoord2fvSGIS(GL_TEXTURE1_SGIS,uv);
			);
		}

		glDisable(GL_TEXTURE_2D);
		glSelectTextureSGIS(GL_TEXTURE0_SGIS);

#ifndef PVLIGHT
		glEnable(GL_LIGHTING);
#endif					
}

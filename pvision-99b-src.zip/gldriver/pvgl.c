/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// OpenGL Driver for the Panard Vision 3D Engine
// (C) 1997-2001, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//
// See include/pvgl.h for compile time defines
// This driver requires the texture object extension (bind)
// This driver uses a little trick enabling perspective correct mapping
// without letting GL do the transformations/projections.

// NOTES:
// This driver has been tested succesfully with the following GL implementation:
//		* MS OpenGL 1.1.0 (win95)
//		* SGI's Cosmo GL
		
// It runs in RGB modes on X running machine (no 256 colors modes)
// It runs in RGB or paletized modes under Windows (RGB recommended) 
// (paletized modes can results in somewhat trashed colors, it dpends on the colors used by the desktop (I think))

// You can compile this driver in 2 modes
//		* PVLIGHT defined
//			In this mode the lighting computations are done by Panard Vision, OpenGL is used
//			for rasterisation only
//		* PVLIGHT not defined
//			GL will do the lighting calculations allowing for specular by example. But you will have
//			no support for PVLUSERLIGHT type nor PVL_PARRALEL.
//			NOTE: the results of the lighting may be slightly different of the Panard Vision original lighting

// LIMITATIONS:
//		* This driver does not take into account window clipping of PV (PV_SetClipLimit)
//		* This driver does not handle alpha buffer
//              * This driver does not check the maximum texture size supported by hardware.

// If you do improvements in it, or succesfully (or unsuccesfully) tests it
// under other platforms/implementations (SGI?), please let me know.

//---------------------------------------------------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include "pvision.h"
#include "glfill.h"
#include "pvgl.h"
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/gl.h>
#include <GL/glu.h>
#ifdef GLX
#include <GL/glx.h>
#include <dlfcn.h>
#endif

static PVFLAGS PVM;
static PVWorld *ZeWorld;
static unsigned maxl,width,height;
static PVMesh *LastMesh=NULL;
PVMaterial *lastm=NULL;
static PVFLAGS oldpvf=0;
unsigned MultiTexture=0,StencilSupported;
static char FogEnabled;

// GL extensions
SelectTextureSGIS glSelectTextureSGIS;
MultiTexCoord2fSGIS glMultiTexCoord2fSGIS;
MultiTexCoord2fvSGIS glMultiTexCoord2fvSGIS;
MultiTexCoord4fSGIS glMultiTexCoord4fSGIS;

unsigned GL_MAX_TEXTURES_SGIS;
unsigned GL_TEXTURE0_SGIS;
unsigned GL_TEXTURE1_SGIS;

static unsigned StencilWrapEXT;

GLint 	Tex3Low,Tex3Norm,Tex3High,Tex4Low,Tex4Norm,Tex4High;

/////////////////////////////////////////////////////////////////////////////////

static void __cdecl DebugString(char *fmt, ...)
{
    char ach[8192];
    va_list va;
	FILE *f;

	if(getenv("PVGL")!=NULL)
	{
		if(strcmp(getenv("PVGL"),"QUIET")==0)
		{
			return;
		}
	}

    va_start( va, fmt );
#ifdef WIN32
    wvsprintf( ach, fmt, va );
#else
    vsprintf(ach,fmt,va);
#endif
    va_end( va );
	
	f=fopen("pvgl.log","a+");
	fprintf(stderr,"%s",ach);
	fprintf(f,"%s",ach);
#ifdef WIN32
	OutputDebugString(ach);
#endif
	fclose(f);
}

static int isExtensionSupported(const char *extension)
{
	const GLubyte *extensions = NULL;
	const GLubyte *start;
	GLubyte *where, *terminator;
	
	/* Extension names should not have spaces. */
	where = (GLubyte *) strchr(extension, ' ');
	if (where || *extension == '\0')
		return 0;
	extensions = glGetString(GL_EXTENSIONS);
	
	/* It takes a bit of care to be fool-proof about parsing the
	OpenGL extensions string. Don't be fooled by sub-strings,
	etc. */
	start = extensions;
	for (;;) {
		where = (GLubyte *) strstr((const char *) start, extension);
		if (!where)
			break;
		terminator = where + strlen(extension);
		if (where == start || *(where - 1) == ' ')
			if (*terminator == ' ' || *terminator == '\0')
				return 1;
			start = terminator;
	}
	return 0;
}

static int PVAPI GLDetect(void)
{
	/// Wooooooow this is a cool "Are you there" routine !
	return 1;
}

extern PVHardwareCaps GLCaps;
static GLvoid initializeGL(void)
{
    GLfloat SpecLight[4]={1.0,1.0,1.0,1.0};
	GLfloat vp[4];

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

#ifndef PVLIGHT
	glEnable(GL_LIGHTING);
	glMaterialfv(GL_FRONT,GL_AMBIENT,&SpecLight[0]);		   // Enable gloabl ambient light
#else
	glDisable(GL_LIGHTING);
#endif
	
	glDrawBuffer(GL_BACK);
		
	glDisable(GL_CULL_FACE);

	glGetFloatv(GL_VIEWPORT,vp);
	width=vp[2];
	height=vp[3];

	// Hints
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);
	glHint(GL_FOG_HINT,GL_FASTEST);

	DebugString("Starting up %s\n",PVDriver.Desc);
	DebugString("\tGL_VERSION : %s\n",glGetString(GL_VERSION));
	DebugString("\tGL_VENDOR : %s\n",glGetString(GL_VENDOR));
	DebugString("\tGL_RENDERER : %s\n",glGetString(GL_RENDERER));
	DebugString("\tGL_EXTENSIONS : %s\n",glGetString(GL_EXTENSIONS));
	DebugString("\n");

	// detecting extensions
	if(isExtensionSupported("GL_IBM_texture_mirrored_repeat"))
	{		
		DebugString("Using: GL_IBM_texture_mirrored_repeat\n");
	}

	if(isExtensionSupported("GL_EXT_clip_volume_hint"))
	{
		DebugString("Using: GL_EXT_clip_volume_hint\n");
		glHint(GL_CLIP_VOLUME_CLIPPING_HINT_EXT,GL_FASTEST);
	}

	StencilWrapEXT=0;
	if(isExtensionSupported("GL_EXT_stencil_wrap"))
	{
		DebugString("Using: GL_EXT_stencil_wrap\n");
		StencilWrapEXT=1;
	}

	Tex3Low=Tex3Norm=Tex3High=GL_RGB;
	Tex4Low=Tex4Norm=Tex4High=GL_RGBA;
	if(isExtensionSupported("GL_EXT_texture"))
	{
		DebugString("Using: GL_EXT_texture\n");
		Tex3Low=GL_RGB2_EXT;
		Tex3Norm=GL_RGB5_EXT;
		Tex3High=GL_RGB8_EXT;
		Tex4Low=GL_RGBA2_EXT;
		Tex4Norm=GL_RGBA4_EXT;
		Tex4High=GL_RGBA8_EXT;
	}

	if(isExtensionSupported("GL_3DFX_texture_compression_FXT1"))
	{
		DebugString("Using: GL_3DFX_texture_compression_FXT1\n");
		Tex3Low=Tex3Norm=GL_COMPRESSED_RGB_FXT1_3DFX;
		Tex4Low=Tex4Norm=GL_COMPRESSED_RGBA_FXT1_3DFX;
	}
	else
	if(isExtensionSupported("GL_EXT_texture_compression_s3tc"))
	{
		DebugString("Using: GL_EXT_texture_compression_s3tc\n");
		Tex3Low=Tex3Norm=GL_COMPRESSED_RGB_S3TC_DXT1_EXT;
		Tex4Low=Tex4Norm=GL_COMPRESSED_RGBA_S3TC_DXT5_EXT;
	}
	else
	if(isExtensionSupported("GL_S3_s3tc"))
	{
		DebugString("Using: GL_S3_s3tc\n");
		Tex3Low=Tex3Norm=GL_RGB_S3TC;
		Tex4Low=Tex4Norm=GL_RGBA_S3TC;
		glHint(GL_TEXTURE_COMPRESSION_HINT_ARB,GL_NICEST);
	}
	else
	if(isExtensionSupported("GL_ARB_texture_compression"))
	{
		DebugString("Using: GL_ARB_texture_compression\n");
		Tex3Low=Tex3Norm=GL_COMPRESSED_RGB_ARB;
		Tex4Low=Tex4Norm=GL_COMPRESSED_RGBA_ARB;
	}

	if(isExtensionSupported("GL_NV_fog_distance"))
	{
		DebugString("Using: GL_NV_fog_distance\n");
		glFogi(GL_FOG_DISTANCE_MODE_NV,GL_EYE_RADIAL_NV);
	}

	MultiTexture=0;

	if(isExtensionSupported("GL_ARB_multitexture"))
	{
		#ifdef WIN32
		glSelectTextureSGIS=(SelectTextureSGIS)wglGetProcAddress("glActiveTextureARB");
		glMultiTexCoord2fSGIS=(MultiTexCoord2fSGIS)wglGetProcAddress("glMultiTexCoord2fARB");
		glMultiTexCoord2fvSGIS=(MultiTexCoord2fvSGIS)wglGetProcAddress("glMultiTexCoord2fvARB");
		glMultiTexCoord4fSGIS=(MultiTexCoord4fSGIS)wglGetProcAddress("glMultiTexCoord4fARB");
		#else
		void *hInst;
		hInst=dlopen("libGL.so",RTLD_NOW|RTLD_GLOBAL);
		if(hInst)
		{
			glSelectTextureSGIS=(SelectTextureSGIS)dlsym(hInst,"glActiveTextureARB");
			glMultiTexCoord2fSGIS=(MultiTexCoord2fSGIS)dlsym(hInst,"glMultiTexCoord2fARB");
			glMultiTexCoord2fvSGIS=(MultiTexCoord2fvSGIS)dlsym(hInst,"glMultiTexCoord2fvARB");
			glMultiTexCoord4fSGIS=(MultiTexCoord4fSGIS)dlsym(hInst,"glMultiTexCoord4fARB");
			dlclose(hInst);
		}
		else
		{
			DebugString("Using: GL_ARB_multitexture (Unable to load libGL.so, NVidia Bug?\n");
			MultiTexture=0;
		}
		#endif

		GL_MAX_TEXTURES_SGIS=0x84E2;
		GL_TEXTURE0_SGIS=0x84C0;
		GL_TEXTURE1_SGIS=0x84C1;

		if((glSelectTextureSGIS!=NULL)&&(glMultiTexCoord2fSGIS!=NULL)&&(glMultiTexCoord4fSGIS!=NULL)&&(glMultiTexCoord2fvSGIS!=NULL))
		{
			glGetIntegerv(GL_MAX_TEXTURES_SGIS, &MultiTexture);
			DebugString("Using: GL_ARB_multitexture (%u textures)\n",MultiTexture);		
		}
	}
	else
	if(isExtensionSupported("GL_SGIS_multitexture"))
	{
		#ifdef WIN32
		glSelectTextureSGIS=(SelectTextureSGIS)wglGetProcAddress("glSelectTextureSGIS");
		glMultiTexCoord2fSGIS=(MultiTexCoord2fSGIS)wglGetProcAddress("glMultiTexCoord2fSGIS");
		glMultiTexCoord2fvSGIS=(MultiTexCoord2fvSGIS)wglGetProcAddress("glMultiTexCoord2fvSGIS");
		glMultiTexCoord4fSGIS=(MultiTexCoord4fSGIS)wglGetProcAddress("glMultiTexCoord4fSGIS");
		#else
		void *hInst;
		hInst=dlopen("libGL.so",RTLD_NOW|RTLD_GLOBAL);
		glSelectTextureSGIS=(SelectTextureSGIS)dlsym(hInst,"glSelectTextureSGIS");
		glMultiTexCoord2fSGIS=(MultiTexCoord2fSGIS)dlsym(hInst,"glMultiTexCoord2fSGIS");
		glMultiTexCoord2fvSGIS=(MultiTexCoord2fvSGIS)dlsym(hInst,"glMultiTexCoord2fvSGIS");
		glMultiTexCoord4fSGIS=(MultiTexCoord4fSGIS)dlsym(hInst,"glMultiTexCoord4fSGIS");		
		dlclose(hInst);
		#endif

		GL_MAX_TEXTURES_SGIS=0x835D;
		GL_TEXTURE0_SGIS=0x835E;
		GL_TEXTURE1_SGIS=0x835F;

		if((glSelectTextureSGIS!=NULL)&&(glMultiTexCoord2fSGIS!=NULL)&&(glMultiTexCoord4fSGIS!=NULL)&&(glMultiTexCoord2fvSGIS!=NULL))
		{
			glGetIntegerv(GL_MAX_TEXTURES_SGIS, &MultiTexture);
			DebugString("Using: GL_SGIS_multitexture (%u textures)\n",MultiTexture);		
			MultiTexture=2;
		}
	}	
	
	DebugString("\nRendering buffers infos:\n");
	{
		GLint i,r,g,b,a;
		GLboolean B;
		glGetBooleanv(GL_DOUBLEBUFFER,&B);
		glGetIntegerv(GL_AUX_BUFFERS,&i);
		DebugString("\t%s with %u aux buffers ",B==1?"Double Buffering":"Single Buffering",i);
		glGetIntegerv(GL_RED_BITS,&r);
		glGetIntegerv(GL_GREEN_BITS,&g);
		glGetIntegerv(GL_BLUE_BITS,&b);
		glGetIntegerv(GL_ALPHA_BITS,&a);
		DebugString("(%u-%u-%u-%u)\n",r,g,b,a);
		glGetIntegerv(GL_DEPTH_BITS,&i);
		DebugString("\tDepth buffer: %u bits\n",i);
		glGetIntegerv(GL_STENCIL_BITS,&i);
		StencilSupported=i;
		DebugString("\tStencil buffer: %u bits\n",i);
		glGetIntegerv(GL_MAX_TEXTURE_SIZE,&i);
		DebugString("\tMaximum texture size: %u pixels\n\n",i);
	}

	// Some caps setup
	if(StencilSupported) 
	{
		GLCaps.GeneralCaps|=PHG_STENCILBUFFER;
		GLCaps.BitsPerStencil=StencilSupported;
	}
	else
	{
		GLCaps.GeneralCaps&=~PHG_STENCILBUFFER;
		GLCaps.BitsPerStencil=StencilSupported;
	}

	// Pipline control
#ifndef PVLIGHT
	PV_SetPipelineControl(PVP_DISABLELIGHTING|PVP_DISABLESORTING|PVP_DISABLETRANSFORM|PVP_NO_TRIANGULATE);
#else
	PV_SetPipelineControl(PVP_NO_TRIANGULATE);
#endif

	glClearDepth( 1.0 );
	glClearStencil((1<<(StencilSupported-1))+(1<<(StencilSupported-2)));
	glClearColor( 0.0, 0.0, 0.0, 1.0 );
}

////////////////////////////////////////////////////////////////////// WIN32 Specific

#ifdef WIN32

static HPALETTE ghPalette = (HPALETTE) 0;
static HDC	  hDC;
static HWND ZeWnd;

static unsigned char threeto8[8] = {
    0, 0111>>1, 0222>>1, 0333>>1, 0444>>1, 0555>>1, 0666>>1, 0377
};

static unsigned char twoto8[4] = {
    0, 0x55, 0xaa, 0xff
};

static unsigned char oneto8[2] = {
    0, 255
};

static int defaultOverride[13] = {
    0, 3, 24, 27, 64, 67, 88, 173, 181, 236, 247, 164, 91
};

static PALETTEENTRY defaultPalEntry[20] = {
    { 0,   0,   0,    0 },
    { 0x80,0,   0,    0 },
    { 0,   0x80,0,    0 },
    { 0x80,0x80,0,    0 },
    { 0,   0,   0x80, 0 },
    { 0x80,0,   0x80, 0 },
    { 0,   0x80,0x80, 0 },
    { 0xC0,0xC0,0xC0, 0 },

    { 192, 220, 192,  0 },
    { 166, 202, 240,  0 },
    { 255, 251, 240,  0 },
    { 160, 160, 164,  0 },

    { 0x80,0x80,0x80, 0 },
    { 0xFF,0,   0,    0 },
    { 0,   0xFF,0,    0 },
    { 0xFF,0xFF,0,    0 },
    { 0,   0,   0xFF, 0 },
    { 0xFF,0,   0xFF, 0 },
    { 0,   0xFF,0xFF, 0 },
    { 0xFF,0xFF,0xFF, 0 }
};

static unsigned char ComponentFromIndex(int i, UINT nbits, UINT shift)
{
    unsigned char val;

    val = (unsigned char) (i >> shift);
    switch (nbits) {

    case 1:
        val &= 0x1;
        return oneto8[val];

    case 2:
        val &= 0x3;
        return twoto8[val];

    case 3:
        val &= 0x7;
        return threeto8[val];

    default:
        return 0;
    }
}

static void CreateRGBPalette(HDC hDC)
{
    PIXELFORMATDESCRIPTOR pfd;
    LOGPALETTE *pPal;
    int n, i;
	HPALETTE ghpalOld;

    n = GetPixelFormat(hDC);
    DescribePixelFormat(hDC, n, sizeof(PIXELFORMATDESCRIPTOR), &pfd);

    if (pfd.dwFlags & PFD_NEED_PALETTE) {
        n = 1 << pfd.cColorBits;
        pPal = (PLOGPALETTE)LocalAlloc(LMEM_FIXED, sizeof(LOGPALETTE) +
                n * sizeof(PALETTEENTRY));
        pPal->palVersion = 0x300;
        pPal->palNumEntries = n;
        for (i=0; i<n; i++) {
            pPal->palPalEntry[i].peRed =
                    ComponentFromIndex(i, pfd.cRedBits, pfd.cRedShift);
            pPal->palPalEntry[i].peGreen =
                    ComponentFromIndex(i, pfd.cGreenBits, pfd.cGreenShift);
            pPal->palPalEntry[i].peBlue =
                    ComponentFromIndex(i, pfd.cBlueBits, pfd.cBlueShift);
            pPal->palPalEntry[i].peFlags = 0;
        }

        /* fix up the palette to include the default GDI palette */
        if ((pfd.cColorBits == 8)                           &&
            (pfd.cRedBits   == 3) && (pfd.cRedShift   == 0) &&
            (pfd.cGreenBits == 3) && (pfd.cGreenShift == 3) &&
            (pfd.cBlueBits  == 2) && (pfd.cBlueShift  == 6)
           ) {
            for (i = 1 ; i <= 12 ; i++)
                pPal->palPalEntry[defaultOverride[i]] = defaultPalEntry[i];
        }

        ghPalette = CreatePalette(pPal);
        LocalFree(pPal);

        ghpalOld = SelectPalette(hDC, ghPalette, FALSE);
        n = RealizePalette(hDC);
    }
}

static BOOL bSetupPixelFormat(HDC hDC)
{
    static PIXELFORMATDESCRIPTOR pfd = {
	sizeof(PIXELFORMATDESCRIPTOR),	// size of this pfd
	1,				// version number
	PFD_DRAW_TO_WINDOW |		// support window
	PFD_SUPPORT_OPENGL |		// support OpenGL
	PFD_DOUBLEBUFFER,		// double buffered
	PFD_TYPE_RGBA,			// RGBA type
	32,					// 32 bit color depth
	0, 0, 0, 0, 0, 0,	// color bits ignored
	0,				// no alpha buffer
	0,				// shift bit ignored
	0,				// no accumulation buffer
	0, 0, 0, 0, 	// accum bits ignored
	32,				// 32-bit z-buffer
	8,				// 8-bit stencil buffer
	0,				// no auxiliary buffer
	PFD_MAIN_PLANE,	// main layer
	0,				// reserved
	0, 0, 0				// layer masks ignored
    };
    int pixelformat;
	PIXELFORMATDESCRIPTOR pfd_new;
	int generic_format,generic_accelerated;

    if ( (pixelformat = ChoosePixelFormat(hDC, &pfd)) == 0 )
    {
        PV_Fatal("PVGL: ChoosePixelFormat failed", 0);
        return FALSE;
    }
	
	DebugString("PVGL: DescribePixelFormat\n");
	DescribePixelFormat(hDC,pixelformat,sizeof(PIXELFORMATDESCRIPTOR),&pfd_new);

	generic_format=pfd_new.dwFlags&PFD_GENERIC_FORMAT;
	generic_accelerated=pfd_new.dwFlags&PFD_GENERIC_ACCELERATED;

	if(generic_format&& ! generic_accelerated)
	{
		DebugString("INFO: OpenGL running software.\n");
	}
	else if(generic_format && generic_accelerated)
	{
		DebugString("INFO: OpenGL running hardware (MCD).\n");
	}
	else if(!generic_format && !generic_accelerated)
	{
		DebugString("INFO: OpenGL running hardware (ICD).\n");
	}

    if (SetPixelFormat(hDC, pixelformat, &pfd) == FALSE)
    {      
		LPVOID lpMsgBuf;

		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		);

		DebugString("PVGL: ERROR: SetPixelFormat failed: %s\n",lpMsgBuf);
		PV_Fatal("PVGL: SetPixelFormat failed",0);
		return FALSE;                
    }

    CreateRGBPalette(hDC);

    return TRUE;
}

static int PVAPI GLInitSupport(long wnd)
{		
	HWND hwnd=(HWND)wnd;

	DebugString("PVGL: Begin Init\n");
	if(!IsWindow(hwnd)) 
	{
		hwnd=GetActiveWindow();
		if(hwnd==NULL) return BIZAR_ERROR;

		DebugString("PVGL: provided hWnd is not a window, picking active window\n");
	}

	ZeWnd=hwnd;
	hDC = GetDC(hwnd);
	if(!hDC) DebugString("PVGL: hDC is NULL !!!!\n");
	if(!bSetupPixelFormat(hDC)) return NO_ACCELSUPPORT;
	if(!wglMakeCurrent( hDC, wglCreateContext( hDC ) )) DebugString("PVGL: MakeCurrent failed !!\n");
	
	initializeGL();	

	return COOL;
}

static void PVAPI GLEndSupport(void)
{
	wglMakeCurrent( NULL, NULL );
	DeleteObject(ghPalette);
	ReleaseDC(ZeWnd,hDC);

	// Should delete binded textures ?
}
#endif

/////////////////////////////////////////////////////////////////////////////// X Specific

#ifdef GLX
static Display *dpy;
static long Win;
static GLXContext cx;

static int PVAPI GLInitSupport(long wnd)
{
      XVisualInfo *vi;
      static int attributeList[] = {GLX_RGBA,GLX_DOUBLEBUFFER,GLX_DEPTH_SIZE,1,GLX_RED_SIZE,1,GLX_STENCIL_SIZE,1,None };          
     
      Win=wnd;

      /* get a connection */
      if((dpy = XOpenDisplay(NULL)) == NULL) 
      {
	fprintf(stderr, "Error: Can't open display\n");
	return BIZAR_ERROR;
      }   
      
      /* get an appropriate visual */
      vi = glXChooseVisual(dpy, DefaultScreen(dpy), attributeList);
      if (!vi) 
      {
        fprintf(stderr, "Error: Can't choose visual\n");
      	return NO_ACCELSUPPORT;
      }      

      /* create a GLX context */
      cx = glXCreateContext(dpy, vi, 0, GL_TRUE);
      if(cx==NULL)
      {
	 fprintf(stderr, "Error: Can't create context\n");
	 return NO_ACCELSUPPORT;
      }

      /* connect the context to the window */
      if(!glXMakeCurrent(dpy, wnd, cx))
      {
	 fprintf(stderr, "Error: Can't bind context\n");
	 return NO_ACCELSUPPORT;      
      }
            	  
      initializeGL();
      	
      return COOL;
}

static void PVAPI GLEndSupport(void)
{
	glXMakeCurrent(dpy, None, NULL);
	glXDestroyContext(dpy,cx);
	XCloseDisplay(dpy);
}
#endif

////////////////////////////////////////////////////////////////////////////////////////////////

static int PVAPI GLSetViewPort(unsigned int cmx,unsigned int cMx,unsigned int cmy,unsigned int cMy)
{		
	return COOL;
}

static void PVAPI GLRefreshMaterial(PVMaterial *m);
static int PVAPI GLLoadTexture(PVMaterial *m)
{
	GLint mem;
	unsigned i,j;

	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return COOL;
	
	if(MultiTexture)
		glSelectTextureSGIS(GL_TEXTURE0_SGIS);
	
	glEnable(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D,(GLint)&m->Tex[0].Texture[0]);			
	
	if(m->Type&PROCEDURAL)
	{
		if(m->TextureFlags&TEXTURE_RGBA)
			glTexImage2D(GL_TEXTURE_2D, 0, 4, m->Tex[0].Width, m->Tex[0].Height, 0,GL_RGBA, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
		else
			glTexImage2D(GL_TEXTURE_2D, 0, 3, m->Tex[0].Width, m->Tex[0].Height, 0,GL_RGB, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
	}
	else
	if(m->TextureFlags&TEXTURE_MIPMAP)
	{      
	  // This is not a good mipmap management method, since the number of mipmaps
	  // from PV is discarded.
	  if(m->TextureFlags&TEXTURE_RGBA)
	  {
		if(m->Hint.Quality&PHQ_LOW)
			gluBuild2DMipmaps(GL_TEXTURE_2D,Tex4Low,m->Tex[0].Width,m->Tex[0].Height,GL_RGBA,GL_UNSIGNED_BYTE,&m->Tex[0].Texture[0]);
		else
		if(m->Hint.Quality&PHQ_HIGH)
			gluBuild2DMipmaps(GL_TEXTURE_2D,Tex4High,m->Tex[0].Width,m->Tex[0].Height,GL_RGBA,GL_UNSIGNED_BYTE,&m->Tex[0].Texture[0]);
		else
			gluBuild2DMipmaps(GL_TEXTURE_2D,Tex4Norm,m->Tex[0].Width,m->Tex[0].Height,GL_RGBA,GL_UNSIGNED_BYTE,&m->Tex[0].Texture[0]);
	  }
	  else
	  {
		if(m->Hint.Quality&PHQ_LOW)
			gluBuild2DMipmaps(GL_TEXTURE_2D,Tex3Low,m->Tex[0].Width,m->Tex[0].Height,GL_RGB,GL_UNSIGNED_BYTE,&m->Tex[0].Texture[0]);
		else
		if(m->Hint.Quality&PHQ_HIGH)
			gluBuild2DMipmaps(GL_TEXTURE_2D,Tex3High,m->Tex[0].Width,m->Tex[0].Height,GL_RGB,GL_UNSIGNED_BYTE,&m->Tex[0].Texture[0]);
		else
			gluBuild2DMipmaps(GL_TEXTURE_2D,Tex3Norm,m->Tex[0].Width,m->Tex[0].Height,GL_RGB,GL_UNSIGNED_BYTE,&m->Tex[0].Texture[0]);
	  }
	}	
	else		
	{								
		if(m->TextureFlags&TEXTURE_RGBA)
		{
			if(m->Hint.Quality&PHQ_LOW)
				glTexImage2D(GL_TEXTURE_2D, 0, Tex4Low, m->Tex[0].Width, m->Tex[0].Height, 0,Tex4Low, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
			else
			if(m->Hint.Quality&PHQ_HIGH)
				glTexImage2D(GL_TEXTURE_2D, 0, Tex4High, m->Tex[0].Width, m->Tex[0].Height, 0,Tex4High, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
			else
				glTexImage2D(GL_TEXTURE_2D, 0, Tex4Norm, m->Tex[0].Width, m->Tex[0].Height, 0,Tex4Norm, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
		}
		else
		{
			if(m->Hint.Quality&PHQ_LOW)
				glTexImage2D(GL_TEXTURE_2D, 0, Tex3Low, m->Tex[0].Width, m->Tex[0].Height, 0,GL_RGB, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
			else
			if(m->Hint.Quality&PHQ_HIGH)
				glTexImage2D(GL_TEXTURE_2D, 0, Tex3High, m->Tex[0].Width, m->Tex[0].Height, 0,GL_RGB, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
			else
				glTexImage2D(GL_TEXTURE_2D, 0, Tex3Norm, m->Tex[0].Width, m->Tex[0].Height, 0,GL_RGB, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
		}
	}

	// Test if Texture succesfully downloaded to hard
	glGetTexLevelParameteriv(GL_TEXTURE_2D,0,GL_TEXTURE_WIDTH,&mem);
	if(mem==0) return ACCEL_NO_MEMORY;

	// Sets material state
	GLRefreshMaterial(m);

	// Try to handle fake phong 
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{
			// Preprocess lightmap to be darker
			for(i=0;i<m->AuxiliaryTexture.Width;i++)
				for(j=0;j<m->AuxiliaryTexture.Height;j++)
				{
					m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]=max(0,m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]-1.3*(255-m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]));
				}
			
			if(MultiTexture)
				glSelectTextureSGIS(GL_TEXTURE1_SGIS);
	
			glBindTexture(GL_TEXTURE_2D,(GLint)&m->AuxiliaryTexture.Texture[0]);			
			glTexImage2D(GL_TEXTURE_2D, 0, 1, m->AuxiliaryTexture.Width, m->AuxiliaryTexture.Height, 0,GL_LUMINANCE, GL_UNSIGNED_BYTE, &m->AuxiliaryTexture.Texture[0]);

			glGetTexLevelParameteriv(GL_TEXTURE_2D,0,GL_TEXTURE_WIDTH,&mem);
			if(mem==0) return ACCEL_NO_MEMORY;

			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

			if(MultiTexture)
				glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			else
				glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	}

	if(MultiTexture)
			glSelectTextureSGIS(GL_TEXTURE0_SGIS);
	
	glDisable(GL_TEXTURE_2D);

	if(MultiTexture)
			glSelectTextureSGIS(GL_TEXTURE1_SGIS);
	
	glDisable(GL_TEXTURE_2D);

	if(MultiTexture)
			glSelectTextureSGIS(GL_TEXTURE0_SGIS);
	
	return COOL;
}

static void PVAPI GLDeleteTexture(PVMaterial *m)
{
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return;
	
	glDeleteTextures(1,(GLuint*)m->Tex[0].Texture);
	
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
		glDeleteTextures(1,(GLuint*)m->AuxiliaryTexture.Texture);
}

//////////////////////////////////////////////////////////////////////////// LIGHTMAPS
#define MAXLIGHTMAPS	100000
#define LMAPW			256
#define LMAPH			256

static PVLightMap **LMaps=NULL;
static unsigned nbrlmaps=0,LMapComputed=0;
static unsigned nbrsurflm=0;
static GLuint bindings[1000];
static unsigned nbrbind=0;

static int PVAPI GLLoadLightMap(PVLightMap *m)
{
	if(LMapComputed) return COOL;
	if(m->Flags&LIGHTMAP_PROCESSED) return COOL;
	
	// On alloue le tablo pseudo statique
	if(LMaps==NULL)
	{
		LMaps=(PVLightMap**)calloc(MAXLIGHTMAPS,sizeof(PVLightMap*));
		if(LMaps==NULL) return NO_MEMORY;
		nbrlmaps=0;
	}
	
	LMaps[nbrlmaps++]=m;
	m->Flags|=LIGHTMAP_PROCESSED;

    return COOL;
}

static int __cdecl LMCompare( const void *arg1, const void *arg2 )
{
	PVLightMap *m1,*m2;
	
	m1=*(PVLightMap**)arg1;
	m2=*(PVLightMap**)arg2;
	
	if(m1->Height==m2->Height)
	{
		if(m1->Width>m2->Width) return -1;
		else return 1;
	}

	if(m1->Height<m2->Height) return 1;
	else return -1;
}

static int DownloadLightMaps(void)
{
	unsigned CurrentW=0,CurrentH=0,MaxH=0;
	
	UPVD16 r,g,b;
	unsigned i,j,k,z;
	PVLightMap *m;		
	GLuint running=0;

	int NbrBitsRed=5;
	int NbrBitsGreen=6;
	int NbrBitsBlue=5;
	int BluePos=0;
	int GreenPos=5;
	int RedPos=11;

	UPVD8 *h,*tmpmap,*tex8,*tex24;
					
	if(nbrlmaps==0) return COOL;
	
	// Sort lightmaps
	qsort( (void*)LMaps, nbrlmaps, sizeof( PVLightMap * ), LMCompare );	
		
	CurrentW=CurrentH=MaxH=0;
	LMapComputed=1;
	running=0;
	nbrbind=0;

	tmpmap=NULL;

	if(MultiTexture)
		glSelectTextureSGIS(GL_TEXTURE1_SGIS);
	
	glEnable(GL_TEXTURE_2D);
	
	for(k=0;k<nbrlmaps;k++)
	{
		m=LMaps[k];
		
		for(z=0;z<m->NbrLightMaps;z++)
		{
			if((CurrentW==0)&&(CurrentH==0))
			{
				// Allocates room
				running++;				
				glBindTexture(GL_TEXTURE_2D,running);
				bindings[nbrbind++]=running;

				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

				if(MultiTexture)
					glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
				else
					glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
				
				if(tmpmap!=NULL) free(tmpmap);
				if(m->Flags&LIGHTMAP_MONO)
					tmpmap=(UPVD8*)malloc(LMAPW*LMAPH);
				else
					tmpmap=(UPVD8*)malloc(LMAPW*LMAPH*3);								
			}
			
			// Now fills the surface with the texture						
			// Init the filling process			
			tex8=tmpmap;			
			tex24=tmpmap;
			
			// Decal
			if((CurrentW+m->Width<LMAPW)&&(CurrentH+m->Height<LMAPH))
			{				
				tex8+=CurrentH*LMAPW+CurrentW;				
				tex24+=3*(CurrentH*LMAPW+CurrentW);				
				CurrentW+=m->Width;
				if(m->Height+CurrentH>MaxH) MaxH=m->Height+CurrentH;
			}
			else
			{
				// not enough room, try a lower band				
				if(MaxH+m->Height<LMAPH)
				{
					CurrentH=MaxH;
					CurrentW=0;
					z--;
					continue;
				}
				else
				{
					// Download to hardware	
					if(m->Flags&LIGHTMAP_MONO) 
						glTexImage2D(GL_TEXTURE_2D, 0, 1, LMAPW, LMAPH, 0,GL_LUMINANCE, GL_UNSIGNED_BYTE, tmpmap);
					else
						glTexImage2D(GL_TEXTURE_2D, 0, 3, LMAPW, LMAPH, 0,GL_RGB, GL_UNSIGNED_BYTE, tmpmap);

					CurrentW=CurrentH=MaxH=0;
					z--;
					continue;
				}
			}		
			
			for(i=0;i<m->Height;i++)
			{
				for(j=0;j<m->Width;j++)
				{				
					// definitevly sloooowww
					if(m->Flags&LIGHTMAP_RGB)
					{
						r=(UPVD8)m->Maps[z][3*(i*m->Width+j)];
						g=(UPVD8)m->Maps[z][3*(i*m->Width+j)+1];
						b=(UPVD8)m->Maps[z][3*(i*m->Width+j)+2];
						
						*tex24=r;
						*(tex24+1)=g;
						*(tex24+2)=b;
					}
					else
					{
						r=(UPVD8)m->Maps[z][(i*m->Width+j)];
						*tex8=r;
					}

					tex24+=3;
					tex8++;
				}				
				tex8+=LMAPW-m->Width;				
				tex24+=3*(LMAPW-m->Width);				
			}

			// Hack hack			
			h=(UPVD8*)malloc(4*4);
			memcpy(&h[12],&m->Maps[z],4);
			m->Maps[z]=h;
			
			memcpy(&m->Maps[z][0],&running,sizeof(GLuint));
			
			// Fixup ccord
			m->su[z]*=(float)m->Width/(float)LMAPW;
			m->sv[z]*=(float)m->Height/(float)LMAPH;
					
			m->su[z]+=(float)(CurrentW-m->Width+0.75)/(float)LMAPW;
			m->sv[z]+=(float)(CurrentH+0.75)/(float)LMAPH;			
		}

		// Setup lightmaps scaling
		m->ScaleU*=(float)(m->Width)/(float)LMAPW;
		m->ScaleV*=(float)(m->Height)/(float)LMAPH;
		m->ScaleU-=0.75/(float)LMAPW;
		m->ScaleV-=0.75/(float)LMAPH;
		m->ScaleU*=(1.0/(float)(m->MaxU-m->MinU));
		m->ScaleV*=(1.0/(float)(m->MaxV-m->MinV));
	}
	
	// Download to hardware
	if(m->Flags&LIGHTMAP_MONO) 
		glTexImage2D(GL_TEXTURE_2D, 0, 1, LMAPW, LMAPH, 0,GL_LUMINANCE, GL_UNSIGNED_BYTE, tmpmap);
	else
		glTexImage2D(GL_TEXTURE_2D, 0, 3, LMAPW, LMAPH, 0,GL_RGB, GL_UNSIGNED_BYTE, tmpmap);
	
	free(tmpmap);

	glDisable(GL_TEXTURE_2D);

	return COOL;
}

static void PVAPI GLDeleteLightMap(PVLightMap *m)
{
	// So what ?
	unsigned k,TotMips;
	UPVD8 *h;
	
	if(!(m->Flags&LIGHTMAP_PROCESSED)) return;
	if(m==NULL) return;
	
	glDeleteTextures(nbrbind,bindings);

	TotMips=m->NbrLightMaps;	
	for(k=0;k<TotMips;k++)
	{
	  if(m->Maps[k]==NULL) break;
	  
	  h=m->Maps[k];
	  memcpy(&m->Maps[k],&m->Maps[k][12],4);
      free(h);		
	}
	LMapComputed=0;
	REMOVEFLAG(m->Flags,LIGHTMAP_PROCESSED);
}

////////////////////////////////////////////////////////////////////////////////////////////
	
static void *PVAPI GLGetFiller(PVFLAGS flags)
{
		flags&=~PERSPECTIVE;
		switch (flags&(RENDER_MASK|SHADE_MASK))
		{
			case FLAT|NOTHING:return TriGLFlat;break;
			case GOURAUD|NOTHING:return TriGLGouraud;break;

			case U_PHONG|NOTHING:
			case PHONG|NOTHING:			
			case NOTHING|AMBIENT_MAPPING:
			case NOTHING|MAPPING:return TriGLMapping;break;
			
			case FLAT|AMBIENT_MAPPING:
			case FLAT|MAPPING:return TriGLFlatMapping;break;
			
			case GOURAUD|AMBIENT_MAPPING:			
			case GOURAUD|MAPPING:return TriGLGouraudMapping;break;

			// Bump is treated as Phong
			case U_BUMP|AMBIENT_MAPPING:
			case U_BUMP|MAPPING:
			case BUMP|AMBIENT_MAPPING:
			case BUMP|MAPPING:

			case U_PHONG|AMBIENT_MAPPING:
			case U_PHONG|MAPPING:
			case PHONG|AMBIENT_MAPPING:
			case PHONG|MAPPING:if(MultiTexture) return TriGLPhongMappingBi; else return TriGLPhongMapping;break;

			case MULTITEXTURE|GOURAUD:
			case MULTITEXTURE|FLAT:
			case MULTITEXTURE|LIGHTMAP:
			case MULTITEXTURE: if(MultiTexture) return TriGLMultiTextureMT; else return TriGLMultiTexture; break;

	        case LIGHTMAP|MAPPING:if(MultiTexture) return TriGLLightmapBi; else return TriGLLightmap;break;

			default:return NULL;
		}	
}

static void PVAPI GLBeginFrame(PVFLAGS pvmode,PVFLAGS PVPipe)
{
	
	GLint flags=0;
	
	if((!(PVPipe&PVP_NO_ZBUFFERCLEAR))&&(pvmode&PVM_ZBUFFER)) flags|=GL_DEPTH_BUFFER_BIT;
	if((!(PVPipe&PVP_NO_STENCILCLEAR))&&(pvmode&PVM_STENCILBUFFER)&&(StencilSupported)) flags|=GL_STENCIL_BUFFER_BIT;

	if(flags!=0)
	{
		GLboolean z,z2;
			
		glGetBooleanv(GL_DEPTH_WRITEMASK,&z);
		glGetBooleanv(GL_STENCIL_WRITEMASK,&z2);
		glDepthMask(1);
		glStencilMask(~0);
		glClear( flags);
		glDepthMask(z);
		glStencilMask(z2);
	}	

	lastm=NULL;

	// Generates lightmaps
	if(LMapComputed==0)
	{
		int hr=DownloadLightMaps();
		if(hr!=COOL) return;
	}

	if(MultiTexture)
			glSelectTextureSGIS(GL_TEXTURE0_SGIS);
}

static void PVAPI GLEndFrame(void)
{
	glFinish();
}

static int PVAPI GLPreRender(PVWorld *w,unsigned surafecnum,PVFLAGS PV_Mode,PVFLAGS PVPipe)
{
	static float aLight[4]={0.0,0.0,0.0,0.0};
	PVLight *l;
	float li[4],ZeColor[4]={0,0,0,0};
	
	switch(surafecnum)
	{
		case 1:glDrawBuffer(GL_FRONT);break;
		default:glDrawBuffer(GL_BACK);
	}

	// Fog support
	if(w->Fog.Type!=PVF_NONE)
	{	
		float col[4];
		float fe,fs;
		
		fe=-w->Fog.End;
		fs=-w->Fog.Start;
		glEnable(GL_FOG);
		glFogf(GL_FOG_DENSITY,w->Fog.Density);
		glFogf(GL_FOG_END,-fe*(1-(depthval+(1/fe)*depthval2)));
		glFogf(GL_FOG_START,-fs*(1-(depthval+(1/fs)*depthval2)));

		col[0]=w->Fog.Color.r;
		col[1]=w->Fog.Color.g;
		col[2]=w->Fog.Color.b;
		col[3]=1.0;
		glFogfv(GL_FOG_COLOR,col);

		FogEnabled=1;
		
		switch(w->Fog.Type)
		{
		case PVF_LINEAR:glFogi(GL_FOG_MODE,GL_LINEAR);break;
		case PVF_EXP:glFogi(GL_FOG_MODE,GL_EXP);break;
		case PVF_EXP2:glFogi(GL_FOG_MODE,GL_EXP2);break;
		default:
			PV_Fatal("GL Driver: Unknown fog mode !",w->Fog.Type);
		}
	}
	else 
	{
		glDisable(GL_FOG);
		FogEnabled=0;
	}
				
#ifndef PVLIGHT
	// Lights load
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();  
	
	l=w->Lights; maxl=0;
	while((l!=NULL)&&(maxl<GL_MAX_LIGHTS))
	{
		if(l->Flags&LIGHT_FORGET) 
		{
			l=l->Next;
			continue;
		}

		switch(l->Type)
		{
			case PVL_DIRECTIONAL:
					li[0]=-l->Direction.xf;
					li[1]=-l->Direction.yf;
					li[2]=-l->Direction.zf;
					li[3]=0;   // Directionnal light
					glLightfv(GL_LIGHT0+maxl,GL_POSITION,&li[0]);
					break;
			case PVL_INFINITEPOINT:
					li[0]=l->Position.xf;
					li[1]=l->Position.yf;
					li[2]=l->Position.zf;
					li[3]=1;   
					glLightfv(GL_LIGHT0+maxl,GL_POSITION,&li[0]);
					
					// No Attenuation
					glLightf(GL_LIGHT0+maxl,GL_CONSTANT_ATTENUATION,1);
					glLightf(GL_LIGHT0+maxl,GL_LINEAR_ATTENUATION,0);
					glLightf(GL_LIGHT0+maxl,GL_QUADRATIC_ATTENUATION,0);							
                    break;
    		case PVL_POINT:
		    		li[0]=l->Position.xf;
					li[1]=l->Position.yf;
					li[2]=l->Position.zf;
					li[3]=1;   
					glLightfv(GL_LIGHT0+maxl,GL_POSITION,&li[0]);
					
					// Attenuation
					glLightf(GL_LIGHT0+maxl,GL_CONSTANT_ATTENUATION,l->Attenuation0);
					glLightf(GL_LIGHT0+maxl,GL_LINEAR_ATTENUATION,l->Attenuation1);
					glLightf(GL_LIGHT0+maxl,GL_QUADRATIC_ATTENUATION,l->Attenuation2);							
                   	break;

  			  case PVL_SPOT:
  					li[0]=l->Position.xf;
					li[1]=l->Position.yf;
					li[2]=l->Position.zf;
					li[3]=1;   
					glLightfv(GL_LIGHT0+maxl,GL_POSITION,&li[0]);
					
					// Attenuation
					glLightf(GL_LIGHT0+maxl,GL_CONSTANT_ATTENUATION,l->Attenuation0);
					glLightf(GL_LIGHT0+maxl,GL_LINEAR_ATTENUATION,l->Attenuation1);
					glLightf(GL_LIGHT0+maxl,GL_QUADRATIC_ATTENUATION,l->Attenuation2);							
					
					// Spot Direction
					glLightfv(GL_LIGHT0+maxl,GL_SPOT_DIRECTION,&l->Direction.xf);
					
					// Spot parms
					glLightf(GL_LIGHT0+maxl,GL_SPOT_CUTOFF,l->Phi*180/PI);
                	glLightf(GL_LIGHT0+maxl,GL_SPOT_EXPONENT,64);
                   	break;
  			case PVL_PARALLEL:
			case PVL_USER_LIGHT:
  					break;
		}
		
		// Common to each light
		// Quick hack to take intensity into account
		ZeColor[0]=l->Color.r*l->Intensity;
		ZeColor[1]=l->Color.g*l->Intensity;			
		ZeColor[2]=l->Color.b*l->Intensity;			
		glLightfv(GL_LIGHT0+maxl,GL_DIFFUSE,&ZeColor[0]);
		
		// Ambient light is global
		glLightfv(GL_LIGHT0+maxl,GL_AMBIENT,&aLight[0]);
		
		// PV builtin shading model doesn't support Specular component for lighs
		glLightfv(GL_LIGHT0+maxl,GL_SPECULAR,&aLight[0]);

		glEnable(GL_LIGHT0+maxl);

		maxl++;
		l=l->Next;
	}
	LastMesh=NULL;
#else		
		glMatrixMode(GL_PROJECTION);			
		glLoadIdentity();
		glOrtho(0,width,height,0,-1.0,0.0);
		glMatrixMode(GL_MODELVIEW);	
		glLoadIdentity();
#endif
		AmbientLight=&w->AmbientLight;
		PVM=PV_Mode;
		ZeWorld=w;
		bp=w->Camera->BackDist;
		fp=w->Camera->FrontDist;
		depthval=(bp/(bp-fp));		
		depthval2=(bp*fp)/(bp-fp);
		return COOL;
}

static void PVAPI GLPrepareFace(PVFace *f)
{
	static GLfloat Mat[4][4]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	static GLfloat MyMat[4][4]={1,0,0,0,0,-1,0,0,0,0,1,0,0,0,0,1};
	static int Alphaf[]={GL_ZERO,GL_ONE,GL_DST_COLOR,GL_ONE_MINUS_DST_COLOR,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA,GL_DST_ALPHA,GL_ONE_MINUS_DST_ALPHA,GL_SRC_ALPHA_SATURATE,GL_SRC_COLOR,GL_ONE_MINUS_SRC_COLOR};	
	PVMesh *m;
	PVPoint c,a;
	float li[4];

#ifndef PVLIGHT			
	if(LastMesh!=f->Father)
	{
		LastMesh=f->Father;
		m=f->Father;

		// Setup Matrices		
		Mat[0][0]=m->Matrix[0][0]*m->ScaleX;
		Mat[1][0]=m->Matrix[0][1]*m->ScaleY;
		Mat[2][0]=m->Matrix[0][2]*m->ScaleZ;
		Mat[0][1]=m->Matrix[1][0]*m->ScaleX;
		Mat[1][1]=m->Matrix[1][1]*m->ScaleY;
		Mat[2][1]=m->Matrix[1][2]*m->ScaleZ;
		Mat[0][2]=m->Matrix[2][0]*m->ScaleX;
		Mat[1][2]=m->Matrix[2][1]*m->ScaleY;
		Mat[2][2]=m->Matrix[2][2]*m->ScaleZ;
		Mat[3][3]=1;
		
		c.xf=m->Pivot.xf+m->Position.xf;
		c.yf=m->Pivot.yf+m->Position.yf;
		c.zf=m->Pivot.zf+m->Position.zf;
		RotatePoint3x3(&m->Pivot,m->Matrix,&a);
		c.xf-=a.xf;
		c.yf-=a.yf;
		c.zf-=a.zf;

		Mat[3][0]=c.xf;
		Mat[3][1]=c.yf;
		Mat[3][2]=c.zf;

		glMatrixMode(GL_MODELVIEW);
		glLoadMatrixf(&Mat[0][0]);		

		glMatrixMode(GL_PROJECTION);	
		glLoadMatrixf(&MyMat[0][0]);  		
		gluPerspective(30,1.5*ZeWorld->Camera->fieldofview,ZeWorld->Camera->FrontDist,ZeWorld->Camera->BackDist);
		RotatePoint3x3(&ZeWorld->Camera->pos,ZeWorld->Camera->Matrix,&a);
		Mat[0][0]=ZeWorld->Camera->Matrix[0][0];
		Mat[0][1]=ZeWorld->Camera->Matrix[1][0];
		Mat[0][2]=ZeWorld->Camera->Matrix[2][0];
		Mat[1][0]=ZeWorld->Camera->Matrix[0][1];
		Mat[1][1]=ZeWorld->Camera->Matrix[1][1];
		Mat[1][2]=ZeWorld->Camera->Matrix[2][1];
		Mat[2][0]=ZeWorld->Camera->Matrix[0][2];
		Mat[2][1]=ZeWorld->Camera->Matrix[1][2];
		Mat[2][2]=ZeWorld->Camera->Matrix[2][2];
		Mat[3][0]=-a.xf;
		Mat[3][1]=-a.yf;
		Mat[3][2]=-a.zf;
		Mat[3][3]=1;
		glMultMatrixf(&Mat[0][0]);

		// Awful hack to make GL have the same result than PV
		// when using Ambiant light
		li[0]=AmbientLight->r*f->MaterialInfo->Diffuse.r;
		li[1]=AmbientLight->g*f->MaterialInfo->Diffuse.g;
		li[2]=AmbientLight->b*f->MaterialInfo->Diffuse.b;
		li[3]=1;
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT,li);
	}
#endif
	if(oldpvf==PVM)
        if(lastm==f->MaterialInfo) return;

	// Sets for wireframe
	if(f->MaterialInfo->Type&WIREFRAME)
		glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
	else
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

	// Alpha Blendig
	if(PVM&PVM_ALPHABLENDING)	
	{
		glBlendFunc(Alphaf[f->MaterialInfo->BlendRgbSrcFactor],Alphaf[f->MaterialInfo->BlendRgbDstFactor]);	
		glEnable(GL_BLEND);
	}
	else glDisable(GL_BLEND);		

	// Alpha Testing
	if(PVM&PVM_ALPHATESTING)	
	{
		switch(f->MaterialInfo->AlphaTest)
		{
		case CMP_LESS:glAlphaFunc(GL_LESS,f->MaterialInfo->AlphaReference);break;
		case CMP_NEVER:glAlphaFunc(GL_NEVER,f->MaterialInfo->AlphaReference);break;
		case CMP_EQUAL:glAlphaFunc(GL_EQUAL,f->MaterialInfo->AlphaReference);break;
		case CMP_LEQUAL:glAlphaFunc(GL_LEQUAL,f->MaterialInfo->AlphaReference);break;
		case CMP_GREATER:glAlphaFunc(GL_GREATER,f->MaterialInfo->AlphaReference);break;
		case CMP_NOTEQUAL:glAlphaFunc(GL_NOTEQUAL,f->MaterialInfo->AlphaReference);break;
		case CMP_GEQUAL:glAlphaFunc(GL_GEQUAL,f->MaterialInfo->AlphaReference);break;
		case CMP_ALWAYS:
		default:glAlphaFunc(GL_ALWAYS,0);break;
		}
		glEnable(GL_ALPHA_TEST);
	}
	else glDisable(GL_ALPHA_TEST);

	// Depth Testing
	// Sets up Depth Buffering
	if((PVM&PVM_ZBUFFER)&&(f->MaterialInfo->Type&ZBUFFER))
	{
		switch(f->MaterialInfo->DepthTest)
		{
		case CMP_LESS:glDepthFunc(GL_LESS);break;
		case CMP_NEVER:glDepthFunc(GL_NEVER);break;
		case CMP_EQUAL:glDepthFunc(GL_EQUAL);break;
		case CMP_LEQUAL:glDepthFunc(GL_LEQUAL);break;
		case CMP_GREATER:glDepthFunc(GL_GREATER);break;
		case CMP_NOTEQUAL:glDepthFunc(GL_NOTEQUAL);break;
		case CMP_GEQUAL:glDepthFunc(GL_GEQUAL);break;
		case CMP_ALWAYS:
		default:glDepthFunc(GL_ALWAYS);break;
		}
		glEnable(GL_DEPTH_TEST);
		glDepthMask(f->MaterialInfo->ZWrite);
	}
	else 
	{
		glDisable(GL_DEPTH_TEST);
		glDepthMask(0);
	}

	// Stencil Buffer
	if((PVM&PVM_STENCILBUFFER)&&(f->MaterialInfo->Type&STENCILBUFFER))
	{		
		static GLint sfunc[]={GL_LESS,GL_NEVER,GL_EQUAL,GL_LEQUAL,GL_GREATER,GL_NOTEQUAL,GL_GEQUAL,GL_ALWAYS};
		static GLint sop[]={GL_KEEP,GL_ZERO,GL_REPLACE,GL_INCR,GL_DECR,GL_INVERT,GL_INCR,GL_DECR};
		static GLint sop2[]={GL_KEEP,GL_ZERO,GL_REPLACE,GL_INCR,GL_DECR,GL_INVERT,GL_INCR_WRAP_EXT,GL_DECR_WRAP_EXT};

		glEnable(GL_STENCIL_TEST);

		glStencilFunc(sfunc[f->MaterialInfo->StencilFunc],(GLint)f->MaterialInfo->StencilRef,f->MaterialInfo->StencilMask);
		if(StencilWrapEXT)
			glStencilOp(sop2[f->MaterialInfo->StencilFail],sop2[f->MaterialInfo->StencilZFail],sop2[f->MaterialInfo->StencilPass]);
		else
			glStencilOp(sop[f->MaterialInfo->StencilFail],sop[f->MaterialInfo->StencilZFail],sop[f->MaterialInfo->StencilPass]);
		glStencilMask(f->MaterialInfo->StencilWriteMask);			
	}
	else 
	{
		glDisable(GL_STENCIL_TEST);
	}


	// Fog Powah!
	if((!(f->MaterialInfo->Type&FOGABLE))||(!FogEnabled))
		glDisable(GL_FOG);
	else
		glEnable(GL_FOG);

	if(f->MaterialInfo->Type&MAPPED_MATERIAL)
		glEnable(GL_TEXTURE_2D);
	else
		glDisable(GL_TEXTURE_2D);
	
	if(f->MaterialInfo->Type&GOURAUD) glShadeModel(GL_SMOOTH); else glShadeModel(GL_FLAT);

	lastm=f->MaterialInfo;
    oldpvf=PVM;
}

static void PVAPI GLPostRender(void)
{
	unsigned i;

	// Disable all enabled lights
#ifndef PVLIGHT
	for(i=0;i<maxl;i++) glDisable(GL_LIGHT0+i);
#endif
}

static	int PVAPI GLFlipSurface(void)
{	
#ifdef WIN32
	SwapBuffers(hDC);
	return COOL;
#endif	
#ifdef GLX
	glXSwapBuffers( dpy, Win );
	return COOL;
#endif
}

static int PVAPI GLFillSurface(unsigned surfacenum,float r,float g,float b,float a)
{
	glClearColor(r,g,b,a);
	glDisable(GL_DITHER);
	glClear( GL_COLOR_BUFFER_BIT); 
	glEnable(GL_DITHER);
	return COOL;
}

static void PVAPI GLRefreshMaterial(PVMaterial *m)
{
	static int Texm[]={GL_REPEAT,GL_CLAMP,GL_MIRRORED_REPEAT_IBM};
	
	if(m->Type&(MAPPED_MATERIAL))
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D,(GLint)&m->Tex[0].Texture[0]);

		// Wrap modes
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, Texm[m->RepeatU]);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, Texm[m->RepeatV]);

		// Filtering modes
		if(m->TextureFlags&TEXTURE_BILINEAR)
		{
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

			if(m->TextureFlags&TEXTURE_MIPMAP)
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
			else
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		}
		else
		if(m->TextureFlags&TEXTURE_TRILINEAR)
		{
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

			if(m->TextureFlags&TEXTURE_MIPMAP)
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
			else
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		}
		else
		{
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

			if(m->TextureFlags&TEXTURE_MIPMAP)
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
			else
				glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		}

		// Combine mode
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		glDisable(GL_TEXTURE_2D);
	}

	lastm=NULL;
}

static PVHardwareCaps * PVAPI GLGetInfo(void)
{
	return &GLCaps;
}

static UPVD8* PVAPI GLLockProceduralMaterial(PVMaterial *m,PVRGBFormat *rgb,PVFLAGS access)
{
	if(m->TextureFlags&TEXTURE_RGBA)
	{
		rgb->NbrBitsPerPixel=32;
		rgb->Pitch=m->Tex[0].Width*4;
		rgb->RedSize=8;
		rgb->BlueSize=8;
		rgb->GreenSize=8;
		rgb->AlphaSize=8;
		rgb->RedPos=0;
		rgb->GreenPos=8;
		rgb->BluePos=16;
		rgb->AlphaPos=24;
	}
	else
	{
		rgb->NbrBitsPerPixel=24;
		rgb->Pitch=m->Tex[0].Width*3;
		rgb->RedSize=8;
		rgb->BlueSize=8;
		rgb->GreenSize=8;
		rgb->AlphaSize=0;
		rgb->RedPos=0;
		rgb->GreenPos=8;
		rgb->BluePos=16;
		rgb->AlphaPos=0;
	}
	return &m->Tex[0].Texture[0];
}

static void PVAPI GLUnlockProceduralMaterial(PVMaterial *m)
{
	glBindTexture(GL_TEXTURE_2D,(GLint)&m->Tex[0].Texture[0]);			

	if(m->TextureFlags&TEXTURE_RGBA)
		glTexImage2D(GL_TEXTURE_2D, 0, 4, m->Tex[0].Width, m->Tex[0].Height, 0,GL_RGBA, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
	else
		glTexImage2D(GL_TEXTURE_2D, 0, 3, m->Tex[0].Width, m->Tex[0].Height, 0,GL_RGB, GL_UNSIGNED_BYTE, &m->Tex[0].Texture[0]);
}


///////////////////////////////////////////////////////////////////////////////
PVHardwareCaps GLCaps={
	PHG_ZBUFFER|PHG_ALPHATEST,
	0,
	PHT_BILINEAR|PHT_MIPMAP|PHT_TRILINEAR,
	PHB_SRCRGBBLEND|PHB_DSTRGBBLEND,
	0,	
	24,
	8,8,8,0,
	16,8,0,0,
	-1,
	-1,-1,
	2,
	0,
	0,
	0
};

PVHardwareDriver PVDriver={
	1,
	PV_MN2,
	sizeof(PVHardwareCaps),
	"Panard Vision Generic OpenGL Driver V1.28",
	GLDetect,
	GLInitSupport,
	GLEndSupport,
	GLSetViewPort,
	GLLoadTexture,
	GLDeleteTexture,
	GLGetFiller,	
	GLPreRender,
	GLPrepareFace,
	GLPostRender,
	GLBeginFrame,
	GLEndFrame,
	GLFlipSurface,
	GLFillSurface,
	GLRefreshMaterial,
	GLGetInfo,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	GLLoadLightMap,
	GLDeleteLightMap,
	GLLockProceduralMaterial,
	GLUnlockProceduralMaterial,
	NULL
};


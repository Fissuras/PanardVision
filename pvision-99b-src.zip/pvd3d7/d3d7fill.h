/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Direct3D v6 Driver for the Panard Vision 3D Engine
// (C) 1997-99, Olivier Brunet

// Before using this library consult the LICENSE file

#ifndef __D3DFILL_H__
#define __D3DFILL_H__

#include "pvision.h"
#define DIRECT3D_VERSION		0x700
#include <d3d.h>

#ifdef _MSC_VER
#pragma warning(disable:4786)
#endif

#include <map>
using std::multimap;

#define LoadTextureStage(x,m) \
	if(lastmip[x]!=m) \
		lpD3DDEV->SetTexture(x,lastmip[x]=m);

struct PVSurfCtrl
{
	LPDIRECTDRAWSURFACE7 d3dsurf[MAX_LIGHTMAPS];	
	DDPIXELFORMAT d3dddpf;
};

#define MESHCTRL_FACES_UNIFORM		1	// Some Wrap flags, same clip flags
#define MESHCTRL_VALID				2
#define MESHCTRL_VERTEX_PER_FACE	4
#define MESHCTRL_HAS_LIGHTMAP		8
#define MESHCTRL_MAPPING			16

struct PVFacesPerMat
{
	unsigned StartIndex;
	unsigned NbrIndex;
	unsigned MinVBIndex,NumVBIndex;
	PVFLAGS Wrap;
	PVMaterial *Mat;
};

struct PVFaceInfosBundle
{
	PVFacesPerMat *FacesPerMat;
	unsigned NbrMats;
	WORD* Indexes;
	PVFace** RefFaces;
	unsigned NbrIndexes;
	PVFLAGS Flags;
	PVFaceInfosBundle() {Flags=0;FacesPerMat=NULL;};
};

typedef	std::multimap<unsigned,PVFaceInfosBundle>::iterator BoxIter;

struct PVMeshCtrl
{
	LPDIRECT3DVERTEXBUFFER7 vb;
	unsigned NbrVertices;
	multimap<unsigned,PVFaceInfosBundle> Boxes;
	unsigned Flags;
	PVMeshCtrl() {vb=NULL;Flags=0;};
};

extern LPDIRECT3DDEVICE7		lpD3DDEV;
extern PVRGBF *AmbientLight;
extern float fp,bp,depthval,depthval2;
extern IDirectDrawSurface7* lastmip[MAX_TEXTURE_STAGE];
extern unsigned MultiTexture;
extern bool D3DTransform;

void PVAPI D3DPrepareFace(PVMaterial *f);

void PVAPI TriD3DFlat(PVFace *f);
void PVAPI TriD3DGouraud(PVFace *f);
void PVAPI TriD3DMapping(PVFace *f);
void PVAPI TriD3DFlatMapping(PVFace *f);
void PVAPI TriD3DGouraudMapping(PVFace *f);
void PVAPI TriD3DBiMapping(PVFace *f);
void PVAPI TriD3DLightMap(PVFace *f);
void PVAPI TriD3DLightMapMT(PVFace *f);
void PVAPI TriD3DBiMappingMT(PVFace *f);
void PVAPI TriD3DMT(PVFace *f);
void PVAPI TriD3DMTMT(PVFace *f);

void PVAPI D3DTLMaterialUniform(PVMesh *m,PVFaceInfosBundle *bu,unsigned index);
void PVAPI D3DTLMaterialLightMap(PVMesh *m,PVFaceInfosBundle *bu,unsigned index);
void PVAPI D3DTLMaterialMTMT(PVMesh *m,PVFaceInfosBundle *bu,unsigned index);
void PVAPI D3DTLMaterialMT(PVMesh *m,PVFaceInfosBundle *bu,unsigned index);

#endif

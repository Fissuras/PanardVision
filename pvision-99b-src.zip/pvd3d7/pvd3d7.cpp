/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// xxx gerer les user lights en important le tablo shading

// Generic Directx7 driver for the Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//

// If there is no hardware found, defaults to software D3D rendering 
// (mainly for debugging purposes), and it's damn slow !

//---------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#define INITGUID
#define STRICT
#define DIRECTDRAW_VERSION		0x700
#define D3D_OVERLOADS
#include <ddraw.h>
#include <math.h>
#include "d3d7fill.h"
#include "pvd3d7.h"
#include <d3dxcore.h>
#include <d3dxmath.h>
#include <map>
using std::multimap;

/////////////////////////////////////////////////////////////////////////////////
static LPDIRECTDRAW7	lpDD;
static LPDIRECT3D7		lpD3D;
LPDIRECT3DDEVICE7		lpD3DDEV;

static LPDIRECTDRAWSURFACE7 lpDDS,lpDDSPrimary,lpZBuffer=NULL;

static LPDIRECTDRAWPALETTE lpDDPalette=NULL;

static LPDIRECTDRAWCLIPPER lpClipper=NULL;
static D3DVIEWPORT7 viewport;

static D3DDEVICEDESC7	HalCaps;

static PVFLAGS PVM;

static PVMaterial *lastm=NULL;
static PVFLAGS oldpvf=0;

bool HWTL,D3DTransform;
static bool soft=FALSE,FogTable,OverrideLighting,FogEnabled;
static unsigned StencilSupported;
static D3DZBUFFERTYPE zbuftype;
static unsigned frame=0;
static unsigned OverrideCull;

/////////////////////////////////////////////////////////////////////////////////

static void __cdecl DebugString(char *fmt, ...)
{
    char ach[128];
    va_list va;
	FILE *f;

	if(getenv("PVD3D7")!=NULL)
	{
		if(strcmp(getenv("PVD3D7"),"QUIET")==0)
		{
			return;
		}
	}

    va_start( va, fmt );
    wvsprintf( ach, fmt, va );
    va_end( va );
	
	f=fopen("pvd3d7.log","a+");
	fprintf(stderr,"%s",ach);
	fprintf(f,"%s",ach);
	OutputDebugString(ach);
	fclose(f);
}

//////////////////////////////////////////////////////////////////////////////////////

typedef struct {
    DWORD           bpp;        // we want a texture format of this bpp
    DDPIXELFORMAT   ddpf;       // place the format here
}   FindTextureData;

HRESULT CALLBACK FindTextureCallback (DDPIXELFORMAT *pixelfmt, LPVOID lParam)
{

	if( NULL==pixelfmt || NULL==lParam )
        return DDENUMRET_OK;

    FindTextureData * FindData = (FindTextureData *)lParam;
    DDPIXELFORMAT ddpf;

	memcpy(&ddpf,pixelfmt,sizeof(ddpf));
		
   	if (ddpf.dwFlags & (DDPF_ALPHA | DDPF_ZBUFFER |
		DDPF_YUV | DDPF_ZPIXELS | DDPF_FOURCC|DDPF_ALPHAPIXELS|
		DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4 | DDPF_PALETTEINDEXED2 | DDPF_PALETTEINDEXED1))
        return DDENUMRET_OK;
	
    // Only RGB textures
	if (!(ddpf.dwFlags & DDPF_RGB))
        return DDENUMRET_OK;
	
    // FInd the nearest surface
    if (FindData->ddpf.dwRGBBitCount == 0 ||
		(ddpf.dwRGBBitCount >= FindData->bpp &&
		(UINT)(ddpf.dwRGBBitCount - FindData->bpp) < (UINT)(FindData->ddpf.dwRGBBitCount - FindData->bpp)))
    {
        FindData->ddpf = ddpf;
    }
	
    return DDENUMRET_OK;
}

static HRESULT CALLBACK FindAlphaTextureCallback (DDPIXELFORMAT *pixelfmt, LPVOID lParam)
{
	if( NULL==pixelfmt || NULL==lParam )
        return DDENUMRET_OK;

    FindTextureData * FindData = (FindTextureData *)lParam;
    DDPIXELFORMAT ddpf;

	memcpy(&ddpf,pixelfmt,sizeof(ddpf));
	
    /*DebugString("FindTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		ddpf.dwRGBBitCount, 
        (ddpf.dwFlags & (DDPF_ALPHA|DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (ddpf.dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (ddpf.dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		ddpf.dwRBitMask,
		ddpf.dwGBitMask,
		ddpf.dwBBitMask,
		ddpf.dwRGBAlphaBitMask);*/
	
	// No Alpha Only formats
	// No ZBuffer only formats
	// No YUV formats
	// No RGBZ formats
	// No FourCC formats
	if (ddpf.dwFlags & ( DDPF_ZBUFFER |
		DDPF_YUV | DDPF_ZPIXELS | DDPF_FOURCC  |DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4 | 
		DDPF_PALETTEINDEXED2 | DDPF_PALETTEINDEXED1))
        return DDENUMRET_OK;
	
	// We only want RGB formats for now !!!
    if (! (ddpf.dwFlags & DDPF_RGB))
        return DDENUMRET_OK;

	// We only want texture formats with an alpha channel
    if (!(ddpf.dwFlags & DDPF_ALPHAPIXELS))
        return DDENUMRET_OK;
    //
    // keep the alpha texture format with the largest
	// alpha channel
    //
    if ((FindData->ddpf.dwRGBAlphaBitMask == 0) ||
		(ddpf.dwRGBAlphaBitMask > FindData->ddpf.dwRGBAlphaBitMask))
    {
        FindData->ddpf = ddpf;
    }
    return DDENUMRET_OK;
}

static HRESULT WINAPI EnumZBufferFormatsCallback( DDPIXELFORMAT* pddpf,
                                                  VOID* pddpfDesired )
{
    if( NULL==pddpf || NULL==pddpfDesired )
        return D3DENUMRET_CANCEL;

	DDPIXELFORMAT* pddpf2=(DDPIXELFORMAT*)pddpfDesired;

    // If the current pixel format's match the desired ones (DDPF_ZBUFFER and
    // possibly DDPF_STENCILBUFFER), lets copy it and return. This function is
    // not choosy...it accepts the first valid format that comes along.

    if( pddpf->dwFlags == pddpf2->dwFlags )
    {        		
		// We're happy with a 16-bit z-buffer. Otherwise, keep looking.
		if( pddpf->dwZBufferBitDepth == pddpf2->dwZBufferBitDepth )		
		{			
			memcpy( pddpfDesired, pddpf, sizeof(DDPIXELFORMAT) );
			return D3DENUMRET_OK;
		}
    }

    return D3DENUMRET_OK;
}

static void ChooseTextureFormat(IDirect3DDevice7 *Device, DWORD bpp, DDPIXELFORMAT *pddpf)
{
    FindTextureData FindData;
    ZeroMemory(&FindData, sizeof(FindData));
    FindData.bpp = bpp;
    Device->EnumTextureFormats(FindTextureCallback, (LPVOID)&FindData);
    *pddpf = FindData.ddpf;
}

static BOOL ChooseAlphaTextureFormat(IDirect3DDevice7 *Device, DDPIXELFORMAT *pddpf)
{
    FindTextureData FindData;
    ZeroMemory(&FindData, sizeof(FindData));
	
    Device->EnumTextureFormats (FindAlphaTextureCallback, (LPVOID)&FindData);
    *pddpf = FindData.ddpf;
	
	if (FindData.ddpf.dwAlphaBitDepth == 0)
		return FALSE;
	
    /*DebugString("ChooseAlphaTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		pddpf->dwRGBBitCount, 
        (pddpf->dwFlags &   (DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (pddpf->dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (pddpf->dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		pddpf->dwRBitMask,
		pddpf->dwGBitMask,
		pddpf->dwBBitMask,
		pddpf->dwRGBAlphaBitMask);*/
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////

static HRESULT WINAPI EnumSurfacesCallback(
										   LPDIRECTDRAWSURFACE7 lpDDSurface,  
										   LPDDSURFACEDESC2 lpDDSurfaceDesc,  
										   LPVOID lpContext                  
										   )
{
	// 0 = Front buffer
	// 1 = Back buffer
	unsigned h;
		
	if((unsigned)lpContext==0)
		h=lpDDSurfaceDesc->ddsCaps.dwCaps&(DDSCAPS_FRONTBUFFER|DDSCAPS_PRIMARYSURFACE|DDSCAPS_VISIBLE);
	else
	{
		h=lpDDSurfaceDesc->ddsCaps.dwCaps&(DDSCAPS_BACKBUFFER|DDSCAPS_OFFSCREENPLAIN);
		if(!(lpDDSurfaceDesc->ddsCaps.dwCaps&DDSCAPS_3DDEVICE)) h=0;
	}

	// Look for a 3d surface not directly visible (probably the back buffer)	
	if(h)
	{
		lpDDS=lpDDSurface;
		return DDENUMRET_CANCEL;
	}
	else 
	{
		lpDDSurface->Release();
		return DDENUMRET_OK;	
	}
}

static int GetMaskSize(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
	}
	
	while(x&1)
	{
		x>>=1;
		i++;
	}
	return i;
}

static int GetMaskPos(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
		i++;
	}
	
	return i;
}

static void RestoreAllSurfaces(void)
{		
	// Assumes Primarrysurface state=Other surfaces state	
	if(lpDDSPrimary->IsLost())	lpDDSPrimary->Restore(); else return;	
	if(lpDDS->IsLost())	lpDDS->Restore();	
	if(lpZBuffer!=NULL) 
		if(lpZBuffer->IsLost()) lpZBuffer->Restore();	

	lpDD->RestoreAllSurfaces();
}

extern PVHardwareCaps D3DCaps;
extern PVHardwareCaps D3DCapsOrg;
static void InitSurfaceCaps(LPDIRECTDRAWSURFACE7 surf)
{
	DDPIXELFORMAT  ddpf;	
	
	surf->GetPixelFormat(&ddpf);
	D3DCaps.BitsPerPixel=ddpf.dwRGBBitCount;
	D3DCaps.NbrBitsRed=GetMaskSize(ddpf.dwRBitMask);
	D3DCaps.NbrBitsGreen=GetMaskSize(ddpf.dwGBitMask);
	D3DCaps.NbrBitsBlue=GetMaskSize(ddpf.dwBBitMask);
	D3DCaps.NbrBitsAlpha=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	D3DCaps.RedPos=GetMaskPos(ddpf.dwRBitMask);
	D3DCaps.GreenPos=GetMaskPos(ddpf.dwGBitMask);
	D3DCaps.BluePos=GetMaskPos(ddpf.dwBBitMask);
	D3DCaps.AlphaPos=GetMaskSize(ddpf.dwRGBAlphaBitMask);
}

void SetPal(LPDIRECTDRAWSURFACE7 surf)
{		
	unsigned i;
	PALETTEENTRY Pal[256];
	HRESULT hr;
	
	//
    // build a 332 palette as the default.
    //
	if(lpDDPalette==NULL)
	{
		for (i=0; i<256; i++)
		{
			Pal[i].peRed   = (BYTE)(((i >> 5) & 0x07) * 255 / 7);
			Pal[i].peGreen = (BYTE)(((i >> 2) & 0x07) * 255 / 7);
			Pal[i].peBlue  = (BYTE)(((i >> 0) & 0x03) * 255 / 3);
			Pal[i].peFlags = PC_NOCOLLAPSE;;
		}
		
		hr=lpDD->CreatePalette(DDPCAPS_8BIT|DDPCAPS_ALLOW256,Pal,&lpDDPalette,NULL); 
		if(hr!=DD_OK)
		{
			DebugString("PVDX: CreatePal %x\n",hr);
		}
	}
	hr=surf->SetPalette(lpDDPalette);	
}

/////////////////////////////////////////////////////////////////////////////////
static int InitDevice(bool hard)
{
	HRESULT hr;
	DDSURFACEDESC2 ddsd;
	bool FirstTry=true;
	
	soft=!hard;

	if(lpZBuffer!=NULL) lpZBuffer->Release();
	if(lpD3DDEV!=NULL) lpD3DDEV->Release();
	lpZBuffer=NULL;
	lpD3DDEV=NULL;

	if(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_ZBUFFERLESSHSR)
	{
		DebugString("This device does not need z-buffer, skipping");
	}
	else
	{
retry:
		memset(&ddsd,0,sizeof(ddsd));
		ddsd.dwSize=sizeof(ddsd);
		ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT;
		lpDDS->GetSurfaceDesc(&ddsd);

		ddsd.dwSize=sizeof(ddsd);
		ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT|DDSD_CAPS|DDSD_PIXELFORMAT;
		ddsd.ddsCaps.dwCaps=DDSCAPS_ZBUFFER;
		
		if(!hard) 
			ddsd.ddsCaps.dwCaps|=DDSCAPS_SYSTEMMEMORY;
		else
			ddsd.ddsCaps.dwCaps|=DDSCAPS_VIDEOMEMORY;		

		ddsd.ddpfPixelFormat.dwSize=sizeof(DDPIXELFORMAT);
		
		if(FirstTry)
		{
			ddsd.ddpfPixelFormat.dwFlags=DDPF_ZBUFFER|DDPF_STENCILBUFFER;
			ddsd.ddpfPixelFormat.dwZBufferBitDepth=32;
			ddsd.ddpfPixelFormat.dwStencilBitDepth=8;
		}
		else
		{
			ddsd.ddpfPixelFormat.dwFlags=DDPF_ZBUFFER;
			ddsd.ddpfPixelFormat.dwZBufferBitDepth=16;
			ddsd.ddpfPixelFormat.dwStencilBitDepth=0;
		}

		if(HWTL)
			lpD3D->EnumZBufferFormats(IID_IDirect3DTnLHalDevice, EnumZBufferFormatsCallback,(VOID*)&ddsd.ddpfPixelFormat);
		else
		if(hard)
			lpD3D->EnumZBufferFormats(IID_IDirect3DHALDevice, EnumZBufferFormatsCallback,(VOID*)&ddsd.ddpfPixelFormat);
		else
			lpD3D->EnumZBufferFormats(IID_IDirect3DRGBDevice, EnumZBufferFormatsCallback,(VOID*)&ddsd.ddpfPixelFormat);

		hr=lpDD->CreateSurface(&ddsd,&lpZBuffer,NULL);
		if(hr!=DD_OK)
		{
			if(FirstTry)			// this case for devices that don't support ZTENCILBUFFER and fal the first time
			{
				FirstTry=false;
				goto retry;
			}
			DebugString("WARNING : Unable to create ZBuffer\n");
			DebugString("Error code 0x%x\n",hr);
			return 0;
		}
		
		if(lpZBuffer!=NULL)
		{			
			lpDDS->Restore();
			lpZBuffer->Restore();
			hr=lpDDS->AddAttachedSurface(lpZBuffer);
			if(hr!=DD_OK)
			{
				lpZBuffer->Release();
				lpZBuffer=NULL;

				DebugString("WARNING : Unable to attach ZBuffer\n");
				DebugString("Error code 0x%x\n",hr);
				return 0;
			}
		}
	}

	// Gets a Direct3DDevice
	// Creates a default palette if needed	
	IDirectDrawPalette *pal;
	lpDDS->GetPalette(&pal);
	if(pal==NULL) SetPal(lpDDS);
	else pal->Release();

	lpDDSPrimary->GetPalette(&pal);
	if(pal==NULL) SetPal(lpDDSPrimary);
	else pal->Release();

	// first try HAL then RGB (for debugging)		
	if(HWTL)
		hr=lpD3D->CreateDevice(IID_IDirect3DTnLHalDevice,lpDDS,&lpD3DDEV);
	else
	if(hard)
		hr=lpD3D->CreateDevice(IID_IDirect3DHALDevice,lpDDS,&lpD3DDEV);
	else 
		hr=lpD3D->CreateDevice(IID_IDirect3DRGBDevice,lpDDS,&lpD3DDEV);

	if(hr!=DD_OK) 
	{
		if(FirstTry) // This case for TNT like devices, where ZBuffer+Stencil==Depth fram
		{
			lpDDS->DeleteAttachedSurface(0,lpZBuffer);
			lpZBuffer->Release();
			lpZBuffer=NULL;

			FirstTry=false;
			goto retry;
		}
		return 0;
	}
	
	// Infos
	DDSURFACEDESC2 ddsdz;

	ddsdz.dwSize=sizeof(ddsdz);
	lpZBuffer->GetSurfaceDesc(&ddsdz);

	DebugString("INFO: ZBuffer is %u bits\n",ddsdz.ddpfPixelFormat.dwZBufferBitDepth);
	DebugString("INFO: StencilBuffer is %u bits\n",ddsdz.ddpfPixelFormat.dwStencilBitDepth);
	
	StencilSupported=ddsdz.ddpfPixelFormat.dwStencilBitDepth;

	return 1;
}

static void PVAPI D3DEndSupport(void);
static void PVAPI D3DHint(char *hint,UPVD32 val);

static int PVAPI D3DDetect(void)
{	
	HINSTANCE h = LoadLibrary("ddraw.dll");         
	void *lpDD;

    lpDD =  GetProcAddress(h,"DirectDrawCreateEx");
     
	FreeLibrary(h);
	
	if(lpDD==NULL)
	{
		DebugString("PVDX : Directx7 not detected\n");
		return 0;
	}

	// Ok, let's try to load d3d8 instead
	HINSTANCE hInst=NULL;
	
	hInst=LoadLibrary("pvd3d8.dll");	
	if(hInst!=NULL)
	{
		PVHardwareDriver *hd=(PVHardwareDriver*)GetProcAddress(hInst,"PVDriver");

		if(hd!=NULL)
		{
			if(hd->Detect())
			{
				memcpy(&PVDriver,hd,sizeof(PVHardwareDriver));
			}
			else
			{
				DebugString("PVDX Driver: Unable to initialize pvd3d8.dll, switching back to pvd3d7.dll\n");
			}
		}
	}


	return 1;
}

static void PVAPI SetFogTable(int t)
{
	if((t)&&(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_FOGTABLE))
	{
		FogTable=TRUE;
		DebugString("INFO: Using Fog Table functions\n");
	}
	else
	{
		FogTable=FALSE;
		DebugString("INFO: Using Vertex Fog functions\n");		
	}
}

// This driver does not take a window handle, but a pointer to a DirectDraw object attached to 
// the rendering window
// This permits the client program to choose cooperative level and rendering device
// assumes Clipper have been already created for windowed rendering
static int PVAPI D3DFillSurface(unsigned surfacenum,float r,float g,float b,float a);
static int PVAPI D3DInitSupport(long _lpDD)
{
	DDSURFACEDESC2 ddsd;
	HRESULT hr;
	DDCAPS ddcaps;
		
	DebugString("Panard Vision Dx7 Driver : Starting (%s)\n",PVDriver.Desc);
	soft=FALSE;
	
	if(lpDD!=NULL) return ALREADY_ASSIGNED;
	lpDD=(LPDIRECTDRAW7)_lpDD;
	if(lpDD==NULL) return ARG_INVALID;
	
	// Test for d3d7 compliant init, and goes for d3d7 if possible
	if(FAILED(lpDD->QueryInterface(IID_IDirect3D7,(LPVOID*)&lpD3D))) 
	{
		lpDD=NULL;

		DebugString("Panard Vision DirectX driver : DDraw init is not d3d7 compliant, switching back to d3d6\n");

		HINSTANCE hInst=NULL;
	
		hInst=LoadLibrary("pvd3d6.dll");	
		if(hInst!=NULL)
		{
			PVHardwareDriver *hd=(PVHardwareDriver*)GetProcAddress(hInst,"PVDriver");
			PVHardwareDriver *hd2=(PVHardwareDriver*)GetProcAddress(hInst,"PVDriverOrg");
			memcpy(hd,hd2,sizeof(PVHardwareDriver));

			PV_SetHardwareDriverWithoutDetect(hd);
			return hd->InitSupport(_lpDD);
		}
		return NO_ACCELSUPPORT;
	}
	
	lpDD->AddRef();

	// reinit caps
	memcpy(&D3DCaps,&D3DCapsOrg,sizeof(D3DCaps));
	ddsd.dwSize=sizeof(ddsd);
		
	// Look for client a created surface which could be the frontbuffer
	lpDDS=NULL;	
	hr=lpDD->EnumSurfaces(DDENUMSURFACES_DOESEXIST|DDENUMSURFACES_ALL,NULL,0,EnumSurfacesCallback);
	if(hr!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : Error during surfaces enumeration (0x%x)\n",hr);
		D3DEndSupport();
		return NO_ACCELSUPPORT;	
	}
	if(lpDDS==NULL)
	{
		DebugString("Panard Vision DirectX driver : No attached surface with 3D caps and front buffer caps\n");		
		D3DEndSupport();
		return NO_ACCELSUPPORT;		
	}
	lpDDSPrimary=lpDDS;
	
	// Look for client a created surface which could be the backbuffer
	lpDDS=NULL;
	hr=lpDD->EnumSurfaces(DDENUMSURFACES_DOESEXIST|DDENUMSURFACES_ALL,NULL,(void*)1,EnumSurfacesCallback);
	if(hr!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : Error during 2nd surfaces enumeration\n");
		D3DEndSupport();
		return NO_ACCELSUPPORT;	
	}
	if(lpDDS==NULL)
	{
		DebugString("WARNING : No attached surface with 3D caps and back buffer caps, running single frame !!\n");
		
		// no backbuffer => backbuf=frontbuffer
		lpDDS=lpDDSPrimary;
		lpDDS->AddRef();
		D3DCaps.NbrSurf=1;
	}
	else D3DCaps.NbrSurf=2;

	// Gets an IDirect3D Interface
	if(lpDD->QueryInterface(IID_IDirect3D7,(LPVOID*)&lpD3D)!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : failed to get IID_IDirect3D7 (no dx7 installed or non-dx7 compliant DirectDraw Init?)\n");
		D3DEndSupport();
		return NO_ACCELSUPPORT;
	}

	// Try to find T&L
	HWTL=false;
	hr=lpD3D->CreateDevice(IID_IDirect3DTnLHalDevice,lpDDS,&lpD3DDEV); 
	if(hr==COOL)
	{
		lpD3DDEV->GetCaps(&HalCaps);
		lpD3DDEV->Release();
		lpD3DDEV=NULL;
		HWTL=true;
	}
	else
	{
		hr=lpD3D->CreateDevice(IID_IDirect3DHALDevice,lpDDS,&lpD3DDEV); 
		if(hr==COOL)
		{
			lpD3DDEV->GetCaps(&HalCaps);
			lpD3DDEV->Release();
			lpD3DDEV=NULL;
		}
	}
	
	if(!InitDevice(true))
	{
		hr=lpD3D->CreateDevice(IID_IDirect3DRGBDevice,lpDDS,&lpD3DDEV);
		if(hr==COOL)
		{
			lpD3DDEV->GetCaps(&HalCaps);
			lpD3DDEV->Release();
			lpD3DDEV=NULL;
		}
		
		if(!InitDevice(false))
		{
			DebugString("Panard Vision DirectX driver : unable to init 3D device\n");
			return NO_ACCELSUPPORT;
		}
	}
						
	if(soft)
	{		
		DebugString("WARNING : Running with Direct3D sofware emulation !!!\n");
		DebugString("          The modes/options you selected are not supported by hardware\n");		
	}	
	else DebugString("INFO: Using hardware acceleration\n");
	
	// Creates the Viewport
    memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT;
	lpDDS->GetSurfaceDesc(&ddsd);

	viewport.dwX=0;
	viewport.dwY=0;
	viewport.dwHeight=ddsd.dwHeight;
	viewport.dwWidth=ddsd.dwWidth;
	viewport.dvMinZ=0.0f;
	viewport.dvMaxZ=1.0f;

	lpD3DDEV->SetViewport(&viewport);
	
	// Sets the rendering state 
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_DITHERENABLE,TRUE);      // nice with some harware, ugly otherwise
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_SPECULARENABLE,FALSE);
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_TEXTUREPERSPECTIVE,TRUE);
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZENABLE,FALSE);
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);    
	
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_EXTENTS,FALSE);
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_CLIPPING,FALSE);

	lpD3DDEV->SetRenderState(D3DRENDERSTATE_COLORVERTEX,FALSE);
	lpD3DDEV->SetRenderState(D3DRENDERSTATE_AMBIENT, 0);

	lpD3DDEV->SetRenderState(D3DRENDERSTATE_NORMALIZENORMALS,FALSE);
	
	lpD3DDEV->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );    
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
	

	lpD3DDEV->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 1 );
    lpD3DDEV->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    lpD3DDEV->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT ); 

	lpD3DDEV->SetTextureStageState( 1,D3DTSS_ADDRESSU,D3DTADDRESS_CLAMP);
	lpD3DDEV->SetTextureStageState( 1,D3DTSS_ADDRESSV,D3DTADDRESS_CLAMP);

	lpD3DDEV->SetTextureStageState( 1, D3DTSS_MINFILTER, D3DTFN_LINEAR );
	lpD3DDEV->SetTextureStageState( 1, D3DTSS_MIPFILTER, D3DTFP_POINT);
    lpD3DDEV->SetTextureStageState( 1, D3DTSS_MAGFILTER, D3DTFG_LINEAR );

	// Texture Matrix for ambient mapping
	D3DXMATRIX matTrans;
	D3DXMatrixIdentity(&matTrans);
	matTrans.m[0][0]=0.5;
	matTrans.m[1][1]=0.5;
	matTrans.m[3][0]=0.5;
	matTrans.m[3][1]=0.5;
	lpD3DDEV->SetTransform(D3DTRANSFORMSTATE_TEXTURE0, matTrans);
	lpD3DDEV->SetTransform(D3DTRANSFORMSTATE_TEXTURE1, matTrans);
	
	// Clear front buffer
	D3DFillSurface(1,0,0,0,0);
	
	// Check to see if we run in full screen or windowed mode
	lpClipper=NULL;	
	lpDDSPrimary->GetClipper(&lpClipper);	

	// Check for render in a window caps
	if(lpClipper!=NULL)
	{	
		ddcaps.dwSize=sizeof(ddcaps);
		lpDD->GetCaps(&ddcaps,NULL);
		if(!(ddcaps.dwCaps2&DDCAPS2_CANRENDERWINDOWED))
		{
			DebugString("Panard Vision DirectX driver : No hardware support in a window. Try FullScreen\n",hr);
			MessageBox(NULL,"Your hardware is unable to render accelerated 3D graphics in a window ! If you have multimonitors, then your primary device doesn't support windowed rendering\nSwitch to full screen mode.","WARNING",0); 			
			D3DEndSupport();
			return NO_ACCELSUPPORT;	

		}
	}
		
	// Init PV's Caps
	if(lpZBuffer!=NULL) 
	{
		D3DCaps.GeneralCaps|=PHG_ZBUFFER;
		D3DCaps.FrameCaps|=PHF_DEPTHBUFFER;
	}
	if(HalCaps.dpcTriCaps.dwAlphaCmpCaps!=0) D3DCaps.GeneralCaps|=PHG_ALPHATEST;
	if(StencilSupported) 
	{
		D3DCaps.GeneralCaps|=PHG_STENCILBUFFER;
		D3DCaps.BitsPerStencil=StencilSupported;
	}
	
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_LINEAR) D3DCaps.TextureCaps|=PHT_BILINEAR;
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_MIPNEAREST ) D3DCaps.TextureCaps|=PHT_MIPMAP;
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_LINEARMIPLINEAR) D3DCaps.TextureCaps|=PHT_TRILINEAR;
	
	if(HalCaps.dpcTriCaps.dwSrcBlendCaps!=0) D3DCaps.BlendCaps|=PHB_SRCRGBBLEND;
	if(HalCaps.dpcTriCaps.dwDestBlendCaps!=0) D3DCaps.BlendCaps|=PHB_DSTRGBBLEND;
	
	// if no alpha is present enable stippling just in case of, who said ugly ???	
	if(!(D3DCaps.BlendCaps&(PHB_SRCRGBBLEND|PHB_DSTRGBBLEND))) 
	{	
		DebugString("WARNING : Enabling stippling\n");
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STIPPLEDALPHA,TRUE);
	}
	
	switch(HalCaps.dwDeviceZBufferBitDepth)
	{
	case DDBD_8:D3DCaps.BitsPerDepth=8;break;
	case DDBD_16:D3DCaps.BitsPerDepth=16;break;
	case DDBD_24:D3DCaps.BitsPerDepth=24;break;
	case DDBD_32:D3DCaps.BitsPerDepth=32;break;
	}
	
	InitSurfaceCaps(lpDDS);

	// Init some runtime decision variables
	if(HalCaps.wMaxSimultaneousTextures>1) 
	{
		MultiTexture=HalCaps.wMaxSimultaneousTextures; 
		DebugString("INFO: Multitexture enabled (%u)\n",HalCaps.wMaxSimultaneousTextures);
	}
	else 
	{
		MultiTexture=0;
		DebugString("INFO: Multitexture not supported, LeelooMultipass enabled\n");
	}

	// Pipeline
	PV_SetPipelineControl(PVP_NO_TRIANGULATE);

	// Some tests
	if(HalCaps.dpcTriCaps.dwTextureCaps&D3DPTEXTURECAPS_SQUAREONLY) DebugString("WARNING : Device only supports square textures, problems are coming !!!\n");

	// Hardware TnL
	PV_SetPipelineControl(PV_GetPipelineControl()|PVP_HARDWARETL); // xxx 
	D3DTransform=true; // xxxx

	if(HalCaps.dwDevCaps&D3DDEVCAPS_HWTRANSFORMANDLIGHT) 
	{
		DebugString("INFO: Device supports Hardware T&L\n");
		//PV_SetPipelineControl(PV_GetPipelineControl()|PVP_HARDWARETL);
		D3DCaps.GeneralCaps|=PHG_HARDWARETL;
		//D3DTransform=true; xxxx

		DebugString("INFO: Number of lights supported: %u\n",HalCaps.dwMaxActiveLights); 
		DebugString("INFO: Number of user clip planes supported: %u\n",HalCaps.wMaxUserClipPlanes);
	}
	else
		DebugString("INFO: Device does NOT supports Hardware T&L\n");

	// Fog Testing
	D3DHint("PV_FOG_TABLE",0);
	D3DHint("PV_FOG_RANGE",0);

	// W-Buffer
	D3DHint("PV_WBUFFER",0);

	return COOL;
}

static void PVAPI D3DEndSupport(void)
{
	// The magic is done	
	if(lpDDS!=NULL) lpDDS->Release();
	if(lpDDSPrimary!=NULL) lpDDSPrimary->Release();
	if(lpClipper!=NULL) lpClipper->Release();
	if(lpZBuffer!=NULL) lpZBuffer->Release();
	if(lpDDPalette!=NULL) lpDDPalette->Release();
	if(lpD3DDEV!=NULL) lpD3DDEV->Release();
	if(lpD3D!=NULL) lpD3D->Release();
	if(lpDD!=NULL) lpDD->Release();

	lpDD=NULL;
	lpDDS=NULL;
	lpDDSPrimary=NULL;
	lpClipper=NULL;
	lpZBuffer=NULL;
	lpDD=NULL;
	lpD3D=NULL;
	
	DebugString("Panard Vision DX Driver : Ending\n");
}

static int PVAPI D3DSetViewPort(unsigned int cmx,unsigned int cMx,unsigned int cmy,unsigned int cMy)
{
	// Set up viewport for direct rasterization (no transformation by d3d)
	viewport.dwX=cmx;
	viewport.dwY=cmy;
	viewport.dwWidth=cMx-cmx;
	viewport.dwHeight=cMy-cmy;
	lpD3DDEV->SetViewport(&viewport);
	
	return COOL;
}

static int PVAPI D3DLoadTexture(PVMaterial *m)
{
	HRESULT hr;
    static DDSURFACEDESC2       ddsd;
	LPDIRECTDRAWSURFACE7 surf=NULL,FirstSurf2=NULL,LastSurf=NULL;
	UPVD16 *tex16,r,g,b,a;
	UPVD32 c,*tex32;
	UPVD8 *tex8,t;
	unsigned i,j,k,TotMips;
	
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return COOL;
	
//DebugString("Downloading %s\n",m->Name);
	
	// Gosh, dx surafce caps is a hell to manage correctly	   
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_MIPNEAREST) TotMips=(m->NbrMipMaps==0?1:m->NbrMipMaps);
	else TotMips=1;

	if(m->Type&PROCEDURAL) TotMips=1;
	
	// Choose texture type
	ddsd.dwSize=sizeof(ddsd);		
	if(m->TextureFlags&TEXTURE_RGBA)
	{
			ChooseAlphaTextureFormat(lpD3DDEV, &ddsd.ddpfPixelFormat);
	}
	else
	{		
			if(m->Hint.Quality&PHQ_HIGH) ChooseTextureFormat(lpD3DDEV, 24, &ddsd.ddpfPixelFormat);
			else
				if(m->Hint.Quality&PHQ_LOW) ChooseTextureFormat(lpD3DDEV, 8, &ddsd.ddpfPixelFormat);
				else
					ChooseTextureFormat(lpD3DDEV, 16, &ddsd.ddpfPixelFormat);
	}

	// Try to create a a surface in system memory	
	ddsd.dwFlags = DDSD_TEXTURESTAGE|DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT | DDSD_MIPMAPCOUNT;
	ddsd.dwWidth = m->Tex[0].Width;
	ddsd.dwHeight = m->Tex[0].Height;
	ddsd.dwMipMapCount=TotMips;
	ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE |DDSCAPS_MIPMAP|DDSCAPS_COMPLEX;		
	ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE|DDSCAPS2_OPAQUE; 
	ddsd.dwTextureStage=0;
	ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);

	// Check maximum texture size
	if((HalCaps.dwMaxTextureWidth<ddsd.dwWidth)||
	   (HalCaps.dwMaxTextureHeight<ddsd.dwHeight))
	{
		ddsd.dwWidth=HalCaps.dwMaxTextureWidth;
		ddsd.dwHeight=HalCaps.dwMaxTextureHeight;

		PVTexture *newtex;

		for(k=0;k<TotMips;k++)
		{
			DebugString("Resizing incoming %ux%u texture to %ux%u\n",m->Tex[k].Width,m->Tex[k].Height,ddsd.dwWidth>>k,ddsd.dwHeight>>k);
			newtex=PV_MipResample2(m->Tex[k].Texture,m->Tex[k].Width,m->Tex[k].Height, ddsd.dwWidth>>k,ddsd.dwHeight>>k,m->TextureFlags&TEXTURE_RGBDIRECT?TEXTURE_RGB:m->TextureFlags,NULL,0);
			if(newtex==NULL) return NO_MEMORY;

			if(!(m->TextureFlags&TEXTURE_TEX_DONT_FREE)) free(m->Tex[k].Texture);
			m->TextureFlags&=~TEXTURE_TEX_DONT_FREE;

			m->Tex[k].Height=newtex->Width;
			m->Tex[k].Width=newtex->Height;
			m->Tex[k].Texture=newtex->Texture;
		}
	}

	// Handles procedural textures
	if(m->Type&PROCEDURAL)
	{
		ddsd.ddsCaps.dwCaps2&=~DDSCAPS2_OPAQUE;
		ddsd.ddsCaps.dwCaps2|=DDSCAPS2_HINTDYNAMIC;
	}

	hr=lpDD->CreateSurface(&ddsd,&surf,NULL);
	if(hr!=DD_OK)
	{			
		// failed					
		DebugString("Panard Vision Direct X Driver : Unable to get a proper surface\n");
		DebugString("Error code 0x%x\n",hr);
		return ACCEL_NO_MEMORY;
	}
	surf->AddRef();
	FirstSurf2=surf;

	// Setup constants
	unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned NbrBitsAlpha=GetMaskSize(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);
	unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned AlphaPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);

	unsigned Multiplier;

	if(m->TextureFlags&TEXTURE_RGBA) Multiplier=4; else Multiplier=3;
		
	for(k=0;k<TotMips;k++)
	{		   		   
		ddsd.dwSize=sizeof(ddsd);
				
		// Now fills the surface with the texture				
		hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
		if(hr!=DD_OK) 
		{
			surf->Release();
			
			DebugString("Panard Vision Direct X Driver : Unable to lock surface\n");
			DebugString("Error code 0x%x\n",hr);			
			return ACCEL_NO_MEMORY;
		}
		
		// Init the filling process
		tex8=(UPVD8 *)ddsd.lpSurface;
		tex16=(UPVD16 *)ddsd.lpSurface;
		tex32=(UPVD32 *)ddsd.lpSurface;
		UPVD8 *rov=(UPVD8*)m->Tex[k].Texture;
		float c1,c2,c3,c4;
		unsigned c5,c6,c7;

		c1=((1<<NbrBitsRed)-1)/255.0;
		c2=((1<<NbrBitsGreen)-1)/255.0;
		c3=((1<<NbrBitsBlue)-1)/255.0;
		c4=((1<<NbrBitsAlpha)-1)/255.0;

		c5=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width;
		c6=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width/2;
		c7=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width/4;

		for(i=0;i<m->Tex[k].Height;i++)
		{
			for(j=0;j<m->Tex[k].Width;j++,rov+=Multiplier)
			{				
				r=*rov;
				g=*(rov+1);
				b=*(rov+2);
				if(m->TextureFlags&TEXTURE_RGBA) a=*(rov+3);

				r=(float)r*c1;
				g=(float)g*c2;
				b=(float)b*c3;
				a=(float)a*c4;
				
				c=(b<<BluePos);
				c|=(g<<GreenPos);
				c|=(r<<RedPos);
				c|=(a<<AlphaPos);				

				switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
				{
				case 8:
					*tex8=c;
					tex8++;
					break;
				case 16:
					*tex16=c;
					tex16++;
					break;
				case 24:
					*tex8=c;
					*(tex8+1)=(c>>8);
					*(tex8+2)=(c>>16);
					tex8+=3;
					break;
				case 32:
					*tex32=c;
					tex32++;
					break;
				default:
					DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
					D3DEndSupport();
					return BIZAR_ERROR;
				}
			}
			tex8+=c5;
			tex16+=c6;
			tex32+=c7;
		}
				
		surf->Unlock(NULL);		

		// Manages Mipmaps
		DDSCAPS2 ddsCaps; 

		ddsCaps.dwCaps = DDSCAPS_TEXTURE | DDSCAPS_MIPMAP; 
        ddsCaps.dwCaps2 = 0;
        ddsCaps.dwCaps3 = 0;
        ddsCaps.dwCaps4 = 0;

		hr=surf->GetAttachedSurface(&ddsCaps, &LastSurf); 
		if((hr!=DD_OK)&&(hr!=DDERR_NOTFOUND))
		{
			// not possible
			DebugString("Panard Vision Direct X driver : Unable to step system mipmaps\n");
			return BIZAR_ERROR;
		}
		surf->Release(); 
		surf = LastSurf; 
	}
	   
	// Try to use compressed textures
	// RGB     555/565     DXT1
	// ARGB    1555        DXT1
	// ARGB    4444        DXT2/3
	// RGB     888         DXT1
	// ARGB    8888        DXT4/5
	// ARGB    8332        DXT4/5
	if(!(m->Hint.Quality&PHQ_HIGH))
	if(!(m->Type&PROCEDURAL))
	{
		DDSURFACEDESC2       ddsdc;
		static dinfo=0;

		if(dinfo!=2)
		{		
			ddsdc=ddsd;	
			ddsdc.ddsCaps.dwCaps&=~(DDSCAPS_VIDEOMEMORY|DDSCAPS_SYSTEMMEMORY);
			
			memset(&ddsdc.ddpfPixelFormat,0,sizeof(ddsdc.ddpfPixelFormat));
			ddsdc.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);
			ddsdc.ddpfPixelFormat.dwFlags|=DDPF_FOURCC;
			if(m->TextureFlags&TEXTURE_RGBA)
			{
				switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
				{
				case 15:
				case 16:
					ddsdc.ddpfPixelFormat.dwFourCC=MAKEFOURCC('D','X','T','2');	break;
				default:
					ddsdc.ddpfPixelFormat.dwFourCC=MAKEFOURCC('D','X','T','4');	break;
				}
			}
			else
			{
				ddsdc.ddpfPixelFormat.dwFourCC=MAKEFOURCC('D','X','T','1');
			}

			LPDIRECTDRAWSURFACE7 surfcomp;
			hr=lpDD->CreateSurface(&ddsdc,&surfcomp,NULL);
			if(!FAILED(hr))
			{		
				surfcomp->Blt(NULL,FirstSurf2,NULL,DDBLT_WAIT,0);
				hr=lpD3DDEV->PreLoad(surfcomp);
				if(!FAILED(hr))
				{
					if(!dinfo) DebugString("INFO: Using texture compression\n");
					FirstSurf2->Release();
					FirstSurf2=surfcomp;
					ddsd=ddsdc;
					dinfo=1;
				}
				else
				{
					if(!dinfo) DebugString("INFO: Texture compression not supported\n");
					surfcomp->Release();
					dinfo=2;
				}
			}
			else
			{
				if(!dinfo) DebugString("INFO: Texture compression not supported\n");
				dinfo=2;
			}
		}
		
	}
	
	// Saves texture infos
	PVSurfCtrl *sc;
	sc=(PVSurfCtrl*)calloc(sizeof(PVSurfCtrl),1);
	if(sc==NULL) return NO_MEMORY;
	sc->d3dsurf[0]=FirstSurf2;
	sc->d3dddpf=ddsd.ddpfPixelFormat;
	m->HardwarePrivate=sc;		

	// Sets priority
	FirstSurf2->SetPriority(ddsd.dwWidth*ddsd.dwHeight);
	
	// --------------------------------------------------- Now the 'Phong Texture'
	// Hey boys this an horrible D3D Hack. I was unable to figure out a clean and
	// portable way of creating a Luminance map (like in GL or Glide), so I create
	// a 16 bits texturing whith R=G=B=AlphaFromPhongTex
	// Memory consuming
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{			
		// Preprocess lightmap to be darker
		for(i=0;i<m->AuxiliaryTexture.Width;i++)
			for(j=0;j<m->AuxiliaryTexture.Height;j++)
			{
				m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]=max(0,m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]-1.3*(255-m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]));
			}
			
			// Try to create a 16 bits surface in system memory
			memset(&ddsd,0,sizeof(ddsd));
			ddsd.dwSize=sizeof(ddsd);
			ChooseTextureFormat(lpD3DDEV, 16, &ddsd.ddpfPixelFormat);
			
			ddsd.dwFlags = DDSD_TEXTURESTAGE|DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
			ddsd.dwWidth = m->AuxiliaryTexture.Width;
			ddsd.dwHeight = m->AuxiliaryTexture.Height;	   		   
			ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE;
			ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE|DDSCAPS2_OPAQUE;			
			if(MultiTexture)
				ddsd.dwTextureStage=1;
			else
				ddsd.dwTextureStage=0;
			ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);

			hr=lpDD->CreateSurface(&ddsd,&surf,NULL);
			if(hr!=DD_OK)
			{			
				// failed					
				DebugString("Panard Vision Direct X Driver : Unable to create a proper phong surface\n");
				DebugString("Error code 0x%x\n",hr);
				return ACCEL_NO_MEMORY;
			}
									
			// Now fills the surface with the texture
			ddsd.dwSize=sizeof(ddsd);
			
			hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
			if(hr!=DD_OK) 
			{
				surf->Release();
				
				DebugString("Panard Vision Direct X Driver : Unable to lock phong surface\n");
				DebugString("Error code 0x%x\n",hr);				
				return ACCEL_NO_MEMORY;
			}
			
			// Init the filling process
			tex8=(UPVD8 *)ddsd.lpSurface;
			tex16=(UPVD16 *)ddsd.lpSurface;
			tex32=(UPVD32 *)ddsd.lpSurface;
			
			unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);					
			unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
			
			for(i=0;i<m->AuxiliaryTexture.Height;i++)
			{
				for(j=0;j<m->AuxiliaryTexture.Width;j++)
				{
					t=m->AuxiliaryTexture.Texture[i*m->AuxiliaryTexture.Width+j];
				
					r=(float)t*((1<<NbrBitsRed)-1)/255.0;
					g=(float)t*((1<<NbrBitsGreen)-1)/255.0;
					b=(float)t*((1<<NbrBitsBlue)-1)/255.0;
					
					c=(b<<BluePos);
					c|=(g<<GreenPos);
					c|=(r<<RedPos);
					
					switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
					{
					case 8:
						*tex8=c;
						tex8++;
						break;
					case 16:
						*tex16=c;
						tex16++;
						break;
					case 24:
						*tex8=c;
						*(tex8+1)=(c>>8);
						*(tex8+2)=(c>>16);
						tex8+=3;
						break;
					case 32:
						*tex32=c;
						tex32++;
						break;
					default:
						DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
						D3DEndSupport();
						return BIZAR_ERROR;
					}
				}
				tex8+=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width;
				tex16+=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width/2;
				tex32+=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width/4;

			}
			surf->Unlock(NULL);
									
			// Saves texture interface to destroy them or reload them
			sc->d3dsurf[1]=surf;
	}
	return COOL;
}

static void PVAPI D3DDeleteTexture(PVMaterial *m)
{
	PVSurfCtrl *sc;
	
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return;
		
	sc=(PVSurfCtrl*)m->HardwarePrivate;
	sc->d3dsurf[0]->Release();
	
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{
		sc->d3dsurf[1]->Release();
	}
	free(sc);
	m->HardwarePrivate=NULL;
}

//////////////////////////////////////////////////////////////////////////// LIGHTMAPS
#define MAXLIGHTMAPS	100000
#define LMAPW			256
#define LMAPH			256

static PVLightMap **LMaps=NULL;
static unsigned nbrlmaps=0,LMapComputed=0;
static LPDIRECTDRAWSURFACE7 LMSurf[100];
static unsigned nbrsurflm=0;

static int PVAPI D3DLoadLightMap(PVLightMap *m)
{
	if(LMapComputed) return COOL;
	if(m->Flags&LIGHTMAP_PROCESSED) return COOL;
	
	// On alloue le tablo pseudo statique
	if(LMaps==NULL)
	{
		LMaps=(PVLightMap**)calloc(MAXLIGHTMAPS,sizeof(PVLightMap*));
		if(LMaps==NULL) return NO_MEMORY;
		nbrlmaps=0;
	}
	
	LMaps[nbrlmaps++]=m;
	m->Flags|=LIGHTMAP_PROCESSED;
	
    return COOL;
}

static int __cdecl LMCompare( const void *arg1, const void *arg2 )
{
	PVLightMap *m1,*m2;
	
	m1=*(PVLightMap**)arg1;
	m2=*(PVLightMap**)arg2;
	
	if(m1->Height==m2->Height)
	{
		if(m1->Width>m2->Width) return -1;
		else return 1;
	}

	if(m1->Height<m2->Height) return 1;
	else return -1;
}

static int DownloadLightMaps(void)
{
	HRESULT hr;
	LPDIRECTDRAWSURFACE7 surf=NULL;    
	static DDSURFACEDESC2       ddsd;		
	unsigned CurrentW=0,CurrentH=0,MaxH=0;
	
	UPVD16 *tex16,r,g,b,a;
	UPVD32 c,*tex32;
	UPVD8 *tex8;
	unsigned i,j,k;	
	PVLightMap *m;
	PVSurfCtrl *sc;
	
	if(nbrlmaps==0) return COOL;
	
	DebugString("Processing %u lightmaps ...\n",nbrlmaps);
	
	// Sort lightmaps
	qsort( (void*)LMaps, nbrlmaps, sizeof( PVLightMap * ), LMCompare );	
	
	ddsd.dwSize=sizeof(ddsd);
	ChooseTextureFormat(lpD3DDEV, 16, &ddsd.ddpfPixelFormat);

	unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned NbrBitsAlpha=GetMaskSize(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);
	unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned AlphaPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);

	float c1,c2,c3,c4;

	c1=(float)((1<<NbrBitsRed)-1)/255.0;
	c2=(float)((1<<NbrBitsGreen)-1)/255.0;
	c3=(float)((1<<NbrBitsBlue)-1)/255.0;
	c4=(float)((1<<NbrBitsAlpha)-1)/255.0;
	
	CurrentW=CurrentH=MaxH=0;
	LMapComputed=1;
	nbrsurflm=0;
	
	for(k=0;k<nbrlmaps;k++)
	{
		m=LMaps[k];
		sc=(PVSurfCtrl*)calloc(sizeof(PVSurfCtrl),1);
		if(sc==NULL) return NO_MEMORY;
		m->HardwarePrivate=sc;
		
		for(int z=0;z<m->NbrLightMaps;z++)
		{
			if((CurrentW==0)&&(CurrentH==0))
			{
				// Try to create a a surface in system memory
				ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT|DDSD_TEXTURESTAGE;;
				ddsd.dwWidth = LMAPW;
				ddsd.dwHeight = LMAPH;	   		   
				ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE;
				ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE|DDSCAPS2_OPAQUE;			
				ddsd.dwTextureStage=1;
				ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);
				
				hr=lpDD->CreateSurface(&ddsd,&surf,NULL);
				if(hr!=DD_OK)
				{			
					// failed					
					DebugString("Panard Vision Direct X Driver : (Lightmap) Unable to get a proper surface\n");
					DebugString("Error code 0x%x\n",hr);
					return ACCEL_NO_MEMORY;
				}
				LMSurf[nbrsurflm]=surf;				
				nbrsurflm++;
			}
			
			// Now fills the surface with the texture
			ddsd.dwSize=sizeof(ddsd);
			
			hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
			if(hr!=DD_OK) 
			{
				surf->Release();
				
				DebugString("Panard Vision Direct X Driver : (Lightmap) Unable to lock surface\n");
				DebugString("Error code 0x%x\n",hr);			
				return ACCEL_NO_MEMORY;
			}
			
			// Init the filling process
			tex8=(UPVD8 *)ddsd.lpSurface;
			tex16=(UPVD16 *)ddsd.lpSurface;
			tex32=(UPVD32 *)ddsd.lpSurface;
			
			// Decal
			if((CurrentW+m->Width<LMAPW)&&(CurrentH+m->Height<LMAPH))
			{
				tex8+=CurrentH*LMAPW+CurrentW;
				tex16+=CurrentH*LMAPW+CurrentW;
				tex32+=CurrentH*LMAPW+CurrentW;			
				CurrentW+=m->Width;
				if(m->Height+CurrentH>MaxH) MaxH=m->Height+CurrentH;
			}
			else
			{
				// not enough room, try a lower band
				surf->Unlock(NULL);
				if(MaxH+m->Height<LMAPH)
				{
					CurrentH=MaxH;
					CurrentW=0;
					z--;
					continue;
				}
				else
				{					
					// New surface
					CurrentW=CurrentH=MaxH=0;
					z--;
					continue;
				}
			}					

			unsigned c5=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW;
			unsigned c6=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW/2;
			unsigned c7=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW/4;

			UPVD8 *rov=&m->Maps[z][0];

			for(i=0;i<m->Height;i++)
			{
				for(j=0;j<m->Width;j++)
				{				
					if(m->Flags&LIGHTMAP_RGB)
					{
						r=*rov;
						g=*(rov+1);
						b=*(rov+2);
						a=255;
						rov+=3;
					}
					else
					{
						r=g=b=*rov;
						a=255;
						rov++;
					}
										
					r=(float)r*c1;
					g=(float)g*c2;
					b=(float)b*c3;
					a=(float)a*c4;
					
					c=(b<<BluePos);
					c|=(g<<GreenPos);
					c|=(r<<RedPos);
					c|=(a<<AlphaPos);
					
					switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
					{
					case 8:
						*tex8=c;
						tex8++;
						break;
					case 16:
						*tex16=c;
						tex16++;
						break;
					case 24:
						*tex8=c;
						*(tex8+1)=(c>>8);
						*(tex8+2)=(c>>16);
						tex8+=3;
						break;
					case 32:
						*tex32=c;
						tex32++;
						break;
					default:
						DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
						D3DEndSupport();
						return BIZAR_ERROR;
					}
				}
				
				tex8+=LMAPW-m->Width;
				tex16+=LMAPW-m->Width;
				tex32+=LMAPW-m->Width;
				
				tex8+=c5;
				tex16+=c6;
				tex32+=c7;
			}
			surf->Unlock(NULL);
						
			// Saves texture interface to destroy them or reload them									
			sc->d3dsurf[z]=surf;
			
			// Fixup ccord		
			m->su[z]*=(float)m->Width/(float)LMAPW;
			m->sv[z]*=(float)m->Height/(float)LMAPH;
			
			m->su[z]+=(float)(CurrentW-m->Width)/(float)LMAPW;
			m->sv[z]+=(float)(CurrentH)/(float)LMAPH;	
		}
		// Setup lightmaps scaling
		m->ScaleU*=(float)m->Width/(float)LMAPW;
		m->ScaleV*=(float)m->Height/(float)LMAPH;
		m->ScaleU*=(1.0/(float)(m->MaxU-m->MinU));
		m->ScaleV*=(1.0/(float)(m->MaxV-m->MinV));
	}
	DebugString("Lightmap done\n");
						
	return COOL;
}

static void PVAPI D3DDeleteLightMap(PVLightMap *m)
{
	unsigned k;
	PVSurfCtrl *sc;
	
	if(!(m->Flags&LIGHTMAP_PROCESSED)) return;
	if(m==NULL) return;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	
	nbrlmaps--;
	if(nbrlmaps==0)
	{
		DebugString("Freeing lightmaps...\n");
		for(k=0;k<nbrsurflm;k++)
		{
			LMSurf[k]->Release();	
		}		
		LMapComputed=0;
	}
	
	free(sc);
	m->HardwarePrivate=NULL;
	REMOVEFLAG(m->Flags,LIGHTMAP_PROCESSED);
}

////////////////////////////////////////////////////////////////////////////////////////////

static void *PVAPI D3DGetFiller(PVFLAGS flags)
{
	flags&=~PERSPECTIVE;

	switch (flags&(RENDER_MASK|SHADE_MASK))
	{
	case FLAT|NOTHING:return TriD3DFlat;break;
	case GOURAUD|NOTHING:return TriD3DGouraud;break;
		
	case U_PHONG|NOTHING:
	case PHONG|NOTHING:
	case NOTHING|AMBIENT_MAPPING:
	case NOTHING|MAPPING:return TriD3DMapping;break;
		
	case FLAT|AMBIENT_MAPPING:
	case FLAT|MAPPING:return TriD3DFlatMapping;break;
		
	case GOURAUD|AMBIENT_MAPPING:
	case GOURAUD|MAPPING:return TriD3DGouraudMapping;break;
		
		// Bump is treated as Phong
	case U_BUMP|AMBIENT_MAPPING:
	case U_BUMP|MAPPING:
	case BUMP|AMBIENT_MAPPING:
	case BUMP|MAPPING:
			
	case U_PHONG|AMBIENT_MAPPING:
	case U_PHONG|MAPPING:				
	case PHONG|AMBIENT_MAPPING:
	case PHONG|MAPPING:if(MultiTexture) return TriD3DBiMappingMT; else return TriD3DBiMapping;break;

	case MULTITEXTURE|GOURAUD:
	case MULTITEXTURE|FLAT:
	case MULTITEXTURE|LIGHTMAP:
	case MULTITEXTURE: if(MultiTexture) return TriD3DMTMT; else return TriD3DMT; break;
		
	case LIGHTMAP|MAPPING:
		if(MultiTexture) return TriD3DLightMapMT; else return TriD3DLightMap;break;
		
	default:return NULL;
	}
}

static void PVAPI D3DBeginFrame(PVFLAGS PVMode,PVFLAGS PVPipe)
{
	D3DRECT rect;

	RestoreAllSurfaces();

	// Sync hardware
	if(lpClipper!=NULL)
		while(lpDDS->GetBltStatus(DDGBS_ISBLTDONE)==DDERR_WASSTILLDRAWING);
	while(lpDDS->GetFlipStatus(DDGFS_ISFLIPDONE)==DDERR_WASSTILLDRAWING);
	
	// Generates lightmaps
	if(LMapComputed==0)
	{		
		int hr=DownloadLightMaps();
		if(hr!=COOL) return;
	}
			
	// Clear ZBuffer+Stencil
	DWORD flags=0;
	
	if((!(PVPipe&PVP_NO_ZBUFFERCLEAR))&&(PVMode&PVM_ZBUFFER)&&(lpZBuffer!=NULL)) flags|=D3DCLEAR_ZBUFFER;
	if((!(PVPipe&PVP_NO_STENCILCLEAR))&&(PVMode&PVM_STENCILBUFFER)&&(StencilSupported)) flags|=D3DCLEAR_STENCIL;

	if(flags!=0)
	{
		rect.x1=viewport.dwX;
		rect.y1=viewport.dwY;
		rect.x2=viewport.dwX+viewport.dwWidth;
		rect.y2=viewport.dwY+viewport.dwHeight;

		lpD3DDEV->Clear(1, &rect,flags,0,1.0,(1<<(StencilSupported-1))|(1<<(StencilSupported-2)));
	}

	lpD3DDEV->BeginScene();

	lastm=NULL;
	frame++;
	OverrideCull=0xFFFFFFFF;
}

static int PVAPI D3DPreRender(PVWorld *w,unsigned surfacenum,PVFLAGS PVMode,PVFLAGS PVPipe)
{		
	AmbientLight=&w->AmbientLight;	
	PVM=PVMode;
	fp=w->Camera->FrontDist;
	bp=w->Camera->BackDist;	
	depthval=(bp/(bp-fp));
	depthval2=(bp*fp)/(bp-fp);

    // Set the transform matrices
	D3DXMATRIX matView1,matView,matProj,matScale;
	D3DXVECTOR3 from;
	D3DXVECTOR4 r;
	
	D3DXMatrixIdentity(&matView1);
	D3DXMatrixScaling(&matScale,1,-1,-1);
	for(unsigned i=0;i<3;i++)
		for(unsigned j=0;j<3;j++) matView1.m[i][j]=w->Camera->Matrix[j][i];
	D3DXMatrixMultiply(&matView,&matView1,&matScale);;	
	from.x=w->Camera->pos.xf;
	from.y=w->Camera->pos.yf;
	from.z=w->Camera->pos.zf;
	D3DXVec3Transform(&r,&from,&matView);
	matView.m[3][0]=-r.x;
	matView.m[3][1]=-r.y;
	matView.m[3][2]=-r.z;

	lpD3DDEV->SetTransform(D3DTRANSFORMSTATE_VIEW,matView);
	
	D3DMATRIX mp;
	float W,H,Q;
	ZeroMemory(&mp,sizeof(mp));

	Q=depthval;
	W=1.0/tan((atan(2.0/(w->Camera->fieldofview*w->Camera->fscale/w->Camera->xscreenscale)))/2.0);
	H=1.0/tan((atan(2.0/(w->Camera->fieldofview*w->Camera->fscale/w->Camera->yscreenscale)))/2.0);

	/*W=1.0/tan(w->Camera->xscreenscale);
	H=1.0/tan(w->Camera->yscreenscale);

	W=1.0/tan((atan(2.0/w->Camera->xscreenscale))/2.0);
	H=1.0/tan((atan(2.0/w->Camera->yscreenscale))/2.0);*/

	mp(0,0)=W;
	mp(1,1)=H;
	mp(2,2)=Q;
	mp(3,2)=-Q*fp;
	mp(2,3)=1;
	
	lpD3DDEV->SetTransform(D3DTRANSFORMSTATE_PROJECTION, &mp );

	// Setup clip planes
	D3DVALUE d[4];
	DWORD clipf=0;
	unsigned nclip=0;

	for(i=0;(i<MAX_USER_CLIPPLANES)&&(nclip<HalCaps.wMaxUserClipPlanes);i++)
	{
		if(w->Camera->UserPlanesEnabled[i])
		{
			d[0]=-w->Camera->UserPlanes[i].Plane.Normal.xf;
			d[1]=-w->Camera->UserPlanes[i].Plane.Normal.yf;
			d[2]=-w->Camera->UserPlanes[i].Plane.Normal.zf;
			d[3]=w->Camera->UserPlanes[i].Plane.d;
			lpD3DDEV->SetClipPlane(i,d);
			clipf|=(1<<i);
			nclip++;
		}
	}
	lpD3DDEV->SetRenderState( D3DRENDERSTATE_CLIPPLANEENABLE,clipf);

	// Set up lights
	unsigned nlight=0,totlight;
	static unsigned lastnl=0;
	PVLight *l;
	D3DLIGHT7 li;

	totlight=HalCaps.dwMaxActiveLights;
	l=w->Lights;
	while(l!=NULL)
	{
		if(nlight==totlight) break;

		if(!(l->Flags&LIGHT_FORGET))
		{
			li.dcvDiffuse.r=l->Color.r;
			li.dcvDiffuse.g=l->Color.g;
			li.dcvDiffuse.b=l->Color.b;
			li.dcvDiffuse.a=l->Color.a;

			li.dcvSpecular.r=1.0;		// xxxx 
			li.dcvSpecular.g=1.0;
			li.dcvSpecular.b=1.0;
			li.dcvSpecular.a=1.0;

			li.dcvAmbient.r=w->AmbientLight.r;
			li.dcvAmbient.g=w->AmbientLight.g;
			li.dcvAmbient.b=w->AmbientLight.b;
			li.dcvAmbient.a=w->AmbientLight.a;

			li.dltType=(D3DLIGHTTYPE)0xffffffff;
			switch(l->Type)
			{
			case PVL_PARALLEL:
			case PVL_DIRECTIONAL:
				if(HalCaps.dwVertexProcessingCaps&D3DVTXPCAPS_DIRECTIONALLIGHTS )
				{
					li.dltType=D3DLIGHT_DIRECTIONAL;
					li.dvDirection=D3DVECTOR(l->Direction.xf,l->Direction.yf,l->Direction.zf);
					li.dvRange=D3DLIGHT_RANGE_MAX;
				}
				break;
			case PVL_INFINITEPOINT:
				if(HalCaps.dwVertexProcessingCaps&D3DVTXPCAPS_POSITIONALLIGHTS )
				{
					li.dltType=D3DLIGHT_POINT;
					li.dvPosition.x=l->Position.xf;
					li.dvPosition.y=l->Position.yf;
					li.dvPosition.z=l->Position.zf;
					li.dvAttenuation0=1;
					li.dvAttenuation1=0;
					li.dvAttenuation2=0;
					li.dvRange=D3DLIGHT_RANGE_MAX;
				}
				break;
			case PVL_POINT:
				if(HalCaps.dwVertexProcessingCaps&D3DVTXPCAPS_POSITIONALLIGHTS )
				{
					li.dltType=D3DLIGHT_POINT;
					li.dvPosition.x=l->Position.xf;
					li.dvPosition.y=l->Position.yf;
					li.dvPosition.z=l->Position.zf;
					li.dvAttenuation0=l->Attenuation0;
					li.dvAttenuation1=l->Attenuation1;
					li.dvAttenuation2=l->Attenuation2;
					li.dvRange=l->Range;
				}
				break;
			case PVL_SPOT:
				if(HalCaps.dwVertexProcessingCaps&D3DVTXPCAPS_POSITIONALLIGHTS )
				{
					li.dltType=D3DLIGHT_SPOT;
					li.dvPosition.x=l->Position.xf;
					li.dvPosition.y=l->Position.yf;
					li.dvPosition.z=l->Position.zf;
					li.dvAttenuation0=l->Attenuation0;
					li.dvAttenuation1=l->Attenuation1;
					li.dvAttenuation2=l->Attenuation2;
					li.dvRange=l->Range;
					li.dvTheta=l->Theta;
					li.dvPhi=l->Phi;
					li.dvFalloff=l->FallOff;
					li.dvDirection=D3DVECTOR(l->Direction.xf,l->Direction.yf,l->Direction.zf);
				}
				break;
			case PVL_USER_LIGHT: // xxxx
			case PVL_POINT_FOG: // xxxx
				break;

			}
			if(li.dltType!=0xffffffff)
			{
				lpD3DDEV->SetLight(nlight,&li);
				lpD3DDEV->LightEnable(nlight,TRUE);
				nlight++;
			}
		}
		l=l->Next;
	}
	for(i=nlight;i<lastnl;i++) lpD3DDEV->LightEnable(i,FALSE);
	lastnl=nlight;
	
	// Fog support
	if(w->Fog.Type!=PVF_NONE)		
	{			
		float s,e;

		lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);
        lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGCOLOR,D3DRGB(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b));

		FogEnabled=true;

		if(FogTable)
		{
			s=w->Fog.Start;
			e=w->Fog.End;		

			lpD3DDEV->SetRenderState(D3DRENDERSTATE_RANGEFOGENABLE,FALSE);
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGVERTEXMODE,D3DFOG_NONE);
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLESTART,*( LONG* ) &s);
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLEEND,*( LONG* ) &e);
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLEDENSITY,*( LONG* ) &w->Fog.Density);				

			switch(w->Fog.Type)
			{
			case PVF_LINEAR:lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_LINEAR);break;
			case PVF_EXP:lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_EXP);break;
			case PVF_EXP2:lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_EXP2);break;
			default:
				PV_Fatal("DX Driver: Unknown fog mode !",w->Fog.Type);
			}
			OverrideLighting=FALSE;
		}
		else
		{			
			s=w->Fog.Start;
			e=w->Fog.End;

			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_NONE);
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGSTART,*( LONG* ) &s);
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGEND,*( LONG* ) &e);
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGDENSITY,*( LONG* ) &w->Fog.Density);				

			switch(w->Fog.Type)
			{
			case PVF_LINEAR:lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGVERTEXMODE,D3DFOG_LINEAR);break;
			case PVF_EXP:lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGVERTEXMODE,D3DFOG_EXP);break;
			case PVF_EXP2:lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGVERTEXMODE,D3DFOG_EXP2);break;
			default:
				PV_Fatal("DX Driver: Unknown fog mode !",w->Fog.Type);
			}

			//OverrideLighting=TRUE;
			OverrideLighting=FALSE;		// Bug TNT & pb voodoo
		}
	}
	else 
	{		
        if(PVMode&PVM_VERTEXFOGGING)
        {
            lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);
            lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_NONE);		
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGVERTEXMODE,D3DFOG_NONE);		
		    lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGCOLOR,D3DRGB(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b));
			//OverrideLighting=TRUE;
			OverrideLighting=FALSE;		// Bug TNT & pb voodoo
			FogEnabled=true;
        }
        else
		{
            lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGENABLE,FALSE);
			OverrideLighting=FALSE;
			FogEnabled=false;
		}
	}
	
	return COOL;
}

void PVAPI D3DPrepareFace(PVMaterial *m)
{
	static int Alphaf[]={D3DBLEND_ZERO,D3DBLEND_ONE,D3DBLEND_DESTCOLOR,D3DBLEND_INVDESTCOLOR,D3DBLEND_SRCALPHA,D3DBLEND_INVSRCALPHA,D3DBLEND_DESTALPHA,D3DBLEND_INVDESTALPHA,D3DBLEND_SRCALPHASAT,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR};    

    if(oldpvf==PVM)
        if(lastm==m) return;

	// Setup Cull
	if(OverrideCull!=0xFFFFFFFF)
	{
		switch(OverrideCull)
		{
		case PV_CULL_NONE:lpD3DDEV->SetRenderState(D3DRENDERSTATE_CULLMODE,D3DCULL_NONE);break;
		case PV_CULL_CW:  lpD3DDEV->SetRenderState(D3DRENDERSTATE_CULLMODE,D3DCULL_CW);break;
		case PV_CULL_CCW: lpD3DDEV->SetRenderState(D3DRENDERSTATE_CULLMODE,D3DCULL_CCW);break;
		}
	}
	else		
	{
		if(m->Type&DOUBLE_SIDED)
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_CULLMODE,D3DCULL_NONE);
		else
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_CULLMODE,D3DCULL_CW);
	}

	// Setup Material
	if(m->Type&(FLAT|GOURAUD))
	{
		D3DMATERIAL7 mat; 
		mat.dcvDiffuse.r = m->Diffuse.r;
		mat.dcvDiffuse.g = m->Diffuse.g;
		mat.dcvDiffuse.b = m->Diffuse.b;
		mat.dcvDiffuse.a = m->Diffuse.a;
		mat.dcvAmbient.r = m->Diffuse.r;
		mat.dcvAmbient.g = m->Diffuse.g;
		mat.dcvAmbient.b = m->Diffuse.b;
		mat.dcvAmbient.a = m->Diffuse.a;
		mat.dcvSpecular.r = m->Specular.r;
		mat.dcvSpecular.g = m->Specular.g;
		mat.dcvSpecular.b = m->Specular.b;
		mat.dcvSpecular.a = m->Specular.a;
		mat.dvPower = m->SpecularPower;
		mat.dcvEmissive.r=m->Emissive.r;
		mat.dcvEmissive.g=m->Emissive.g;
		mat.dcvEmissive.b=m->Emissive.b;
		mat.dcvEmissive.a=m->Emissive.a;
		lpD3DDEV->SetMaterial(&mat);

		lpD3DDEV->SetRenderState(D3DRENDERSTATE_LIGHTING,TRUE);
		lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	}
	else
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_LIGHTING,FALSE);
		lpD3DDEV->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
	}

	// Sets for wireframe
	if(m->Type&WIREFRAME)
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_FILLMODE,D3DFILL_WIREFRAME);
	else
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_FILLMODE,D3DFILL_SOLID);

	// Sets for zbuffer
	if((PVM&PVM_ZBUFFER)&&(m->Type&ZBUFFER))
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZENABLE,zbuftype);
		if(m->ZWrite) 
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,TRUE);
		else
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);

		switch(m->DepthTest)
		{
		case CMP_LESS:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_ALWAYS);break;
		}
	}
	else  
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZENABLE,FALSE);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);
	}

	// Stencil Buffer
	if((PVM&PVM_STENCILBUFFER)&&(m->Type&STENCILBUFFER))
	{
		static D3DSTENCILOP sop[]={D3DSTENCILOP_KEEP,D3DSTENCILOP_ZERO,D3DSTENCILOP_REPLACE, D3DSTENCILOP_INCRSAT,
								   D3DSTENCILOP_DECRSAT, D3DSTENCILOP_INVERT,D3DSTENCILOP_INCR, D3DSTENCILOP_DECR};				

		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILENABLE,TRUE);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILREF,m->StencilRef);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILMASK,m->StencilMask);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILWRITEMASK,m->StencilWriteMask);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFAIL,sop[m->StencilFail]);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILZFAIL,sop[m->StencilZFail]);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILPASS,sop[m->StencilPass]);
		
		switch(m->StencilFunc)
		{
		case CMP_LESS:lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_ALWAYS);break;
		}
	}
	else 
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_STENCILENABLE,FALSE);
	}
	
	// Sets for AlphaBlending
	if(PVM&PVM_ALPHABLENDING)
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_SRCBLEND,Alphaf[m->BlendRgbSrcFactor]);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_DESTBLEND,Alphaf[m->BlendRgbDstFactor]);
		
		if(m->AlphaConstant!=1.0)
		{
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_TEXTUREFACTOR,D3DRGBA(0,0,0,m->AlphaConstant));
			lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_TFACTOR);    
		}
		else
			lpD3DDEV->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	}
	else lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,FALSE);
	
	// Sets for Alpha testing
	if(PVM&PVM_ALPHATESTING)
	{
		switch(m->AlphaTest)
		{
		case CMP_LESS:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_ALWAYS);break;
		}
		
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAREF,(unsigned)((float)m->AlphaReference*255.0)); //16.16 fixed, bah non en fait avec dx7
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHATESTENABLE,TRUE);
	}
	else 
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHATESTENABLE,FALSE);
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_ALWAYS); // Voodoo 1 Hack
	}
	
	// The following is for textured faces only	
	if(m->Type&(MAPPED_MATERIAL))
	{
		// Sets wrapping modes
		switch(m->RepeatU)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);break;
		}
		
		switch(m->RepeatV)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);break;
		}
		
		// Sets up mag filtering
		if((m->TextureFlags&TEXTURE_BILINEAR)||(m->TextureFlags&TEXTURE_TRILINEAR))
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DFILTER_LINEAR);
		else
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DFILTER_NEAREST);
		
		// Sets for min filtering
		if((m->TextureFlags&TEXTURE_BILINEAR)||(m->TextureFlags&TEXTURE_TRILINEAR))
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MINFILTER,D3DFILTER_LINEAR);
		else 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MINFILTER,D3DFILTER_NEAREST);

		if(m->TextureFlags&TEXTURE_TRILINEAR) 
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTFP_LINEAR);
		else
		{
			if(m->TextureFlags&TEXTURE_MIPMAP) 
				lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTFP_POINT);
			else
				lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTFP_NONE);
		}

		// Loads texture
		if(m->HardwarePrivate!=NULL)
		{
			LoadTextureStage(0,((PVSurfCtrl*)m->HardwarePrivate)->d3dsurf[0]);
			
			if(m->Filler==TriD3DBiMappingMT)
				LoadTextureStage(1,((PVSurfCtrl*)m->HardwarePrivate)->d3dsurf[1]);
		}

		// Ambienbt mapping
		if(D3DTransform)
		{
			if(m->Type&AMBIENT_MAPPING)
			{
				lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXCOORDINDEX,D3DTSS_TCI_CAMERASPACENORMAL|0);
				lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);
			}
			else
			{
				lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXCOORDINDEX,0);
				lpD3DDEV->SetTextureStageState(0,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
			}
		}
	}
	else 
	{
		lpD3DDEV->SetTexture(0,NULL);
		lastmip[0]=NULL;
	}

	// Fog Powah!
	if((!(m->Type&FOGABLE))||(!FogEnabled))
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGENABLE,FALSE);		
		
		// Shading mode
		if(m->Type&GOURAUD)
		{
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_GOURAUD);
		}
		else
		{
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_FLAT);		
		}
	}
	else
	{
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);

		// Shading mode
		if((m->Type&GOURAUD)||(OverrideLighting))
		{
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_GOURAUD);
		}
		else
		{
			lpD3DDEV->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_FLAT);
		}
	}
		
	lastm=m;
    oldpvf=PVM;
}

static void PVAPI D3DPrepareFace(PVFace *f)
{	
	D3DPrepareFace(f->MaterialInfo);
}

static void PVAPI D3DPostRender(void)
{
}

static void PVAPI D3DEndFrame(void)
{
	if(lpD3DDEV!=NULL)
		lpD3DDEV->EndScene();	
}

static int PVAPI D3DFlipSurface(void)
{
	if(lpClipper!=NULL)
	{
		RECT srcr,dstr;
		POINT pt;
		HWND win;
		
		lpClipper->GetHWnd(&win);
		GetClientRect(win,&srcr);
		pt.x=pt.y=0;
		ClientToScreen(win,&pt);
		dstr=srcr;
		dstr.left+=pt.x;
		dstr.right+=pt.x;
		dstr.top+=pt.y;
		dstr.bottom+=pt.y;
		lpDDSPrimary->Blt(&dstr,lpDDS,&srcr,DDBLT_ASYNC,0);
	}
	else lpDDSPrimary->Flip(NULL,0);

	return COOL;
}

static int PVAPI D3DFillSurface(unsigned surfacenum,float r,float g,float b,float a)
{
	DDBLTFX ddbltfx;	
	LPDIRECTDRAWSURFACE7 surf;
	DDPIXELFORMAT  ddpf;
	unsigned rs,gs,bs,rp,gp,bp,as,ap,rf,gf,bf,af;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}	
	if(surf==NULL) return COOL;

	// Looking for the correct color mask
	ddpf.dwSize=sizeof(ddpf);
	surf->GetPixelFormat(&ddpf);
	rs=GetMaskSize(ddpf.dwRBitMask);
	gs=GetMaskSize(ddpf.dwGBitMask);
	bs=GetMaskSize(ddpf.dwBBitMask);
	as=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	rp=GetMaskPos(ddpf.dwRBitMask);
	gp=GetMaskPos(ddpf.dwGBitMask);
	bp=GetMaskPos(ddpf.dwBBitMask);
	ap=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	
	// Compute colors
	rf=r*(float)((1<<rs)-1);
	rf<<=rp;
	bf=b*(float)((1<<bs)-1);
	bf<<=bp;
	gf=g*(float)((1<<gs)-1);
	gf<<=gp;
	af=a*(float)((1<<as)-1);
	af<<=ap;
	
	memset(&ddbltfx,0,sizeof(ddbltfx));
	ddbltfx.dwSize=sizeof(ddbltfx);
	ddbltfx.dwFillColor=rf|gf|bf|af;

	// Sync hardware
	while(surf->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
	
	if(surf->Blt(NULL,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx)!=DD_OK) return BIZAR_ERROR;
	return COOL;
}

static void PVAPI D3DRefreshMaterial(PVMaterial *)
{
	// Direct3D driver don't need this function because the material state is set each time a render is made
	lastm=NULL;
}

extern PVHardwareCaps D3DCaps;
static PVHardwareCaps * PVAPI D3DGetInfo(void)
{
	return &D3DCaps;
}

static void * PVAPI D3DLockFB(unsigned surfacenum,PVFLAGS mode)
{
	LPDIRECTDRAWSURFACE7 surf;
	DDSURFACEDESC2      ddsd2;
	unsigned flags=0;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}
	
	switch(mode)
	{
	case PFB_READONLY:flags=DDLOCK_READONLY;break;
	case PFB_WRITEONLY:flags=DDLOCK_WRITEONLY;break;
	}

	memset(&ddsd2,0,sizeof(ddsd2));
	ddsd2.dwSize=sizeof(ddsd2);
	surf->Lock(NULL,&ddsd2,DDLOCK_SURFACEMEMORYPTR|DDLOCK_WAIT|DDLOCK_NOSYSLOCK|flags,NULL);
	
	D3DCaps.RowStride=ddsd2.lPitch;
	
	return ddsd2.lpSurface;
}

static void PVAPI D3DUnLockFB(unsigned surfacenum,PVFLAGS mode)
{
	LPDIRECTDRAWSURFACE7 surf;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}
	
	surf->Unlock(NULL);
}

static void * PVAPI D3DLockDB(PVFLAGS mode)
{
	unsigned flags;
	DDSURFACEDESC       ddsd;
	
	if(lpZBuffer==NULL) return NULL;
	
	switch(mode)
	{
	case PFB_READONLY:flags=DDLOCK_READONLY;break;
	case PFB_WRITEONLY:flags=DDLOCK_WRITEONLY;break;
	default:return NULL;
	}
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	lpZBuffer->Lock(NULL,NULL,DDLOCK_SURFACEMEMORYPTR|DDLOCK_WAIT|flags,NULL);
	
	D3DCaps.RowStride=ddsd.lPitch;
	
	return ddsd.lpSurface;
}

static void PVAPI D3DUnLockDB(PVFLAGS mode)
{
	if(lpZBuffer==NULL) return;
	
	lpZBuffer->Unlock(NULL);
}

static UPVD8* PVAPI D3DLockProcedural(PVMaterial *m,PVRGBFormat *rgb,PVFLAGS access)
{
	PVSurfCtrl *sc;
	DDSURFACEDESC2       ddsd;	
	HRESULT hr;
	DWORD flags;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL) return NULL;

	rgb->RedSize=GetMaskSize(sc->d3dddpf.dwRBitMask);
	rgb->GreenSize=GetMaskSize(sc->d3dddpf.dwGBitMask);
	rgb->BlueSize=GetMaskSize(sc->d3dddpf.dwBBitMask);
	rgb->AlphaSize=GetMaskSize(sc->d3dddpf.dwRGBAlphaBitMask);
	rgb->RedPos=GetMaskPos(sc->d3dddpf.dwRBitMask);
	rgb->GreenPos=GetMaskPos(sc->d3dddpf.dwGBitMask);
	rgb->BluePos=GetMaskPos(sc->d3dddpf.dwBBitMask);
	rgb->AlphaPos=GetMaskPos(sc->d3dddpf.dwRGBAlphaBitMask);
	rgb->NbrBitsPerPixel=sc->d3dddpf.dwRGBBitCount;

	ddsd.dwSize=sizeof(ddsd);

	flags=0;
	if(access==PV_READ_ONLY) flags|=DDLOCK_READONLY;
	else
	if(access==PV_WRITE_ONLY) flags|=DDLOCK_WRITEONLY;
			
	hr=sc->d3dsurf[0]->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR|flags,NULL);
	if(hr!=DD_OK) return NULL;

	rgb->Pitch=ddsd.lPitch;
		
	return (UPVD8 *)ddsd.lpSurface;
}

static void PVAPI D3DUnLockProcedural(PVMaterial *m)
{
	PVSurfCtrl *sc;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL) return;

	sc->d3dsurf[0]->Unlock(NULL);
}

static void PVAPI D3DHint(char *hint,UPVD32 val)
{
	if(strcmp(hint,"PV_FOG_RANGE")==0)	
	{
		if(val)
			DebugString("INFO: Using Fog-Range\n");
		else
			DebugString("INFO: Using Fog-plane\n");
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_RANGEFOGENABLE ,val==1?TRUE:FALSE);
	}	

	if(strcmp(hint,"PV_FOG_TABLE")==0)	
	{
		if(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_FOGTABLE)
		{
			SetFogTable(val);
		}
		else SetFogTable(0);		
	}

	if(strcmp(hint,"PV_WBUFFER")==0)
	{
		if((val)&&(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_WBUFFER))
		{
			DebugString("INFO: Using W-Buffer\n");
			zbuftype=D3DZB_USEW;		
		}
		else
		{
			DebugString("INFO: Using Z-Buffer\n");
			zbuftype=D3DZB_TRUE;
		}
	}

	if(strcmp(hint,"PV_MIPMAPLODBIAS")==0)
	{
		if(val!=NULL)
			lpD3DDEV->SetTextureStageState(0,D3DTSS_MIPMAPLODBIAS, *((LPDWORD) (val)));
	}
}

///////////////////////////////////////////////////////////////////////////////

struct VBRecordM
{
	float xyz[3];
	float n[3];
	float uv[2];
	float luv[2];
};

static void CreateIndexForBox(PVMesh *m,PVBox *b)
{
	if(b->Flags)
	{
		// Creation de l'index DP
		unsigned cat[1024][2]; // xxx 256 materiaux/objects, 256 cat par mat (xxxx modifier le nombre de categorie/materiaux est born�e, faire les cas)
		unsigned nbrtris=0;
		std::multimap<PVMaterial*,unsigned> mats;
		std::multimap<PVMaterial*,unsigned>::iterator matsi,matsie;
		unsigned nbrmats=0,curmat;		
		PVFaceInfosBundle bu;

		bu.Flags=0;
		bu.Flags|=MESHCTRL_FACES_UNIFORM;

		if(m->NbrMapIndex>m->NbrVertices) bu.Flags|=MESHCTRL_VERTEX_PER_FACE;

		for(unsigned f=0;f<b->NbrFaces;f++)
		{
			unsigned i;

			i=b->FaceIndex[f];

			if(m->Face[i].MaterialInfo!=NULL)
			{
				if(m->Face[i].NbrVertices>=3)
					nbrtris+=m->Face[i].NbrVertices-2;    // xxx faire un scan par pointeur speed
				else
					continue;

				matsi=mats.find(m->Face[i].MaterialInfo);
				if(matsi==mats.end())
					matsi=mats.find((PVMaterial*)(0x80000000|((int)m->Face[i].MaterialInfo)));

				if(matsi==mats.end())
				{
					curmat=nbrmats;
					
					// Makes blended mats rendered last
					if((m->Face[i].MaterialInfo->AlphaConstant!=1.0)||
					   (m->Face[i].MaterialInfo->BlendRgbSrcFactor!=BLEND_ONE)||
					   (m->Face[i].MaterialInfo->BlendRgbDstFactor!=BLEND_ZERO))
						mats.insert(std::make_pair((PVMaterial*)(0x80000000|((int)m->Face[i].MaterialInfo)),nbrmats));
					else
						mats.insert(std::make_pair(m->Face[i].MaterialInfo,nbrmats));
					
					cat[curmat][1]=0xffffffff;
					cat[curmat][0]=0;
					nbrmats++;
					if(nbrmats>=1024) 
					{
						DebugString("ERROR: Too many mats !!");
						break;
					}
				}
				else
				{
					curmat=(*matsi).second;
				}

				cat[curmat][0]+=m->Face[i].NbrVertices-2;
				
				
				cat[curmat][1]=0;

				/* xxx on en fait koi de ca deja ?.if(cat[curmat][1]==0xffffffff)
					cat[curmat][1]=(m->Face[i].Flags&(U_WRAP|V_WRAP));
				else
					if(!((m->Face[i].Flags&(U_WRAP|V_WRAP))==cat[curmat][1])) 
					{
						mesh_uniform=false;					 
						bu.Flags&=~MESHCTRL_FACES_UNIFORM;
					}*/
				if(m->Face[i].Flags&TEXTURE_BASIS) bu.Flags|=MESHCTRL_VERTEX_PER_FACE;
				if(m->Face[i].Flags&LIGHTMAP) bu.Flags|=MESHCTRL_HAS_LIGHTMAP;
				if(m->Face[i].Flags&MAPPED_MATERIAL) bu.Flags|=MESHCTRL_MAPPING;
			}
		}

		if(nbrtris==0) return; // xxxx ?? comment c possible ?

		// Mise � jour des index de mat
		for(unsigned ma=1;ma<nbrmats;ma++) cat[ma][0]+=cat[ma-1][0];
		for(ma=nbrmats-1;ma>0;ma--) cat[ma][0]=cat[ma-1][0];
		cat[0][0]=0;

		// Mesh Uniform
		if(bu.Flags&MESHCTRL_FACES_UNIFORM)
		{
			if(m->Name!=NULL)
				DebugString("INFO: %s is a mesh uniform, building optimized index (%u mats, %u tris).\n",m->Name,nbrmats,nbrtris);

			// remplissage des infos mesh uniform
			bu.NbrMats=nbrmats;
			bu.FacesPerMat=(PVFacesPerMat*)malloc(sizeof(PVFacesPerMat)*nbrmats);
			matsi=mats.begin();
			matsie=mats.end();
			while(matsi!=matsie)
			{
				bu.FacesPerMat[(*matsi).second].Wrap=cat[(*matsi).second][1];
				bu.FacesPerMat[(*matsi).second].Mat=(PVMaterial*)((int)((*matsi).first)&(~0x80000000));
				bu.FacesPerMat[(*matsi).second].StartIndex=cat[(*matsi).second][0]*3;
				if((*matsi).second!=(nbrmats-1))
					bu.FacesPerMat[(*matsi).second].NbrIndex=(cat[(*matsi).second+1][0]-cat[(*matsi).second][0])*3;
				else
					bu.FacesPerMat[(*matsi).second].NbrIndex=(nbrtris-cat[(*matsi).second][0])*3;
								
				matsi++;
			}			

			bu.Indexes=(WORD*)malloc(sizeof(WORD)*nbrtris*3);
			bu.RefFaces=(PVFace**)malloc(sizeof(PVFace*)*nbrtris*3);
			bu.NbrIndexes=nbrtris*3;
			unsigned curindex;

			for(unsigned f=0;f<b->NbrFaces;f++)
			{
				unsigned i=b->FaceIndex[f];

				if(m->Face[i].MaterialInfo!=NULL)
				{
					matsi=mats.find(m->Face[i].MaterialInfo);
					if(matsi==mats.end())
						matsi=mats.find((PVMaterial*)(0x80000000|((int)m->Face[i].MaterialInfo)));

					curindex=cat[(*matsi).second][0]*3;
					
					if(m->NbrMapIndex>m->NbrVertices)
					{
						// Gestion des mesh avec mappings additionels
						for(unsigned j=1;j<m->Face[i].NbrVertices-1;j++)
						{
							bu.RefFaces[curindex]=&m->Face[i];
							bu.RefFaces[curindex+1]=&m->Face[i];
							bu.RefFaces[curindex+2]=&m->Face[i];
							bu.Indexes[curindex]=m->Face[i].MapInfos.MapIndex+0;
							bu.Indexes[curindex+1]=m->Face[i].MapInfos.MapIndex+j;
							bu.Indexes[curindex+2]=m->Face[i].MapInfos.MapIndex+j+1;
							cat[(*matsi).second][0]++;;
							curindex+=3;
						}
					}
					else
					if(bu.Flags&MESHCTRL_VERTEX_PER_FACE)
					{
						// Gestion des mesh avec texture basis
						unsigned a=(m->Face[i].V-m->VerticesIndex);

						for(unsigned j=1;j<m->Face[i].NbrVertices-1;j++)
						{
							bu.RefFaces[curindex]=&m->Face[i];
							bu.RefFaces[curindex+1]=&m->Face[i];
							bu.RefFaces[curindex+2]=&m->Face[i];
							bu.Indexes[curindex]=a;
							bu.Indexes[curindex+1]=j+a;
							bu.Indexes[curindex+2]=j+1+a;	/// xxx merger ca avec le cas du dessus
							cat[(*matsi).second][0]++;;
							curindex+=3;
						}
					}
					else
					{
						// Mesh normaux
						for(unsigned j=1;j<m->Face[i].NbrVertices-1;j++)
						{
							bu.RefFaces[curindex]=&m->Face[i];
							bu.RefFaces[curindex+1]=&m->Face[i];
							bu.RefFaces[curindex+2]=&m->Face[i];
							bu.Indexes[curindex]=m->Face[i].V[0];
							bu.Indexes[curindex+1]=m->Face[i].V[j];
							bu.Indexes[curindex+2]=m->Face[i].V[j+1];
							cat[(*matsi).second][0]++;;
							curindex+=3;
						}
					}
				}
			}

			// Recherche des limites mini/maxi pour les VB				
			matsi=mats.begin();
			matsie=mats.end();
			while(matsi!=matsie)
			{
				bu.FacesPerMat[(*matsi).second].MinVBIndex=0xFFFFFFFF;
				unsigned max=0;

				for(unsigned h=bu.FacesPerMat[(*matsi).second].StartIndex;h<bu.FacesPerMat[(*matsi).second].StartIndex+bu.FacesPerMat[(*matsi).second].NbrIndex;h++)
				{
					if(bu.Indexes[h]<bu.FacesPerMat[(*matsi).second].MinVBIndex)
						bu.FacesPerMat[(*matsi).second].MinVBIndex=bu.Indexes[h];

					if(bu.Indexes[h]>max)
						max=bu.Indexes[h];
				}
				bu.FacesPerMat[(*matsi).second].NumVBIndex=max-bu.FacesPerMat[(*matsi).second].MinVBIndex+1;

				for(h=bu.FacesPerMat[(*matsi).second].StartIndex;h<bu.FacesPerMat[(*matsi).second].StartIndex+bu.FacesPerMat[(*matsi).second].NbrIndex;h++)
				{
					bu.Indexes[h]-=bu.FacesPerMat[(*matsi).second].MinVBIndex;					
				}
												
				matsi++;
			}			

			PVMeshCtrl *mc;
			mc=(PVMeshCtrl*)m->HardwarePrivate;

			bu.Flags|=MESHCTRL_VALID;

			mc->Boxes.insert(std::make_pair((unsigned)b,bu));
			mc->Flags|=bu.Flags;
		}
	}
	else 
		for(unsigned i=0;i<8;i++) if (b->Child[i]!=NULL) CreateIndexForBox(m,b->Child[i]);
}

static unsigned PVAPI D3DUpdateMesh(PVMesh *m)
{
	PVMeshCtrl *mc;
	D3DVERTEXBUFFERDESC vbd;
	HRESULT hr;
	UPVD8 *vbdata;
	unsigned i,size;

	if(m->Flags&MESH_SWITCHNODE) return COOL;
	if((m->NbrFaces==0)||(m->NbrVertices==0)) return COOL;
	
	mc=(PVMeshCtrl*)m->HardwarePrivate;
	if(mc==NULL)
	{
		mc=new PVMeshCtrl;
		m->HardwarePrivate=mc;
		if(mc==NULL) return BIZAR_ERROR;
	}

	if(m->Box==NULL)
	{
		PVFLAGS oldf=m->Flags;
		m->Flags|=MESH_DYNAMIC;
		PV_MeshBuildBoxes(m,1);
		m->Flags=oldf;
	}
	CreateIndexForBox(m,m->Box); 	

	if(mc->vb==NULL)
	{
		// First time, create vb		
		ZeroMemory( &vbd, sizeof(vbd) );
		vbd.dwSize=sizeof(vbd);
		if(HWTL)
			vbd.dwCaps=D3DVBCAPS_WRITEONLY;
		else
			vbd.dwCaps=D3DVBCAPS_WRITEONLY|D3DVBCAPS_SYSTEMMEMORY;
		
		if(mc->Flags&MESHCTRL_VERTEX_PER_FACE)			
			vbd.dwNumVertices=max(m->LastMapIndex,m->NbrIndex);
		else
			vbd.dwNumVertices=m->NbrVertices;
		mc->NbrVertices=vbd.dwNumVertices;

		vbd.dwFVF=D3DFVF_NORMAL|D3DFVF_XYZ;
		size=2*3*sizeof(float);

		if(mc->Flags&MESHCTRL_MAPPING) 
		{
			vbd.dwFVF|=D3DFVF_TEX1|D3DFVF_TEXCOORDSIZE2(0);
			size+=2*sizeof(float);
		}
		if(mc->Flags&MESHCTRL_HAS_LIGHTMAP) 
		{
			vbd.dwFVF&=~D3DFVF_TEX1;
			vbd.dwFVF|=D3DFVF_TEX2|D3DFVF_TEXCOORDSIZE2(1);
			size+=2*sizeof(float);
		}

/*		if(m->Mapping==NULL) // xxx optimiser ce test en le faisant 
			vbd.dwFVF=D3DFVF_NORMAL|D3DFVF_XYZ;
		else
			vbd.dwFVF=D3DFVF_NORMAL|D3DFVF_XYZ|D3DFVF_TEX1|D3DFVF_TEXCOORDSIZE2(0);		*/

		hr=lpD3D->CreateVertexBuffer(&vbd,&mc->vb,0);
		if(FAILED(hr)) return BIZAR_ERROR;
	}

	// Fill in VB
	// xxxx gestion du flag dirty
	hr=mc->vb->Lock(DDLOCK_DISCARDCONTENTS|DDLOCK_SURFACEMEMORYPTR|DDLOCK_WAIT|DDLOCK_WRITEONLY,(LPVOID*)&vbdata,NULL);
	if(FAILED(hr)) return BIZAR_ERROR;

	// xxx speed
/*	if(m->Mapping==NULL)
	{
		for(i=0,p=vbdata;i<m->NbrVertices;i++,p++)
		{
			memcpy(&p->n[0],&m->Vertex[i].Normal.xf,sizeof(float)*3);
			memcpy(&p->xyz[0],&m->Vertex[i].xf,sizeof(float)*3);
		}
	}
	else*/
	{		
		//vbdatauv=(VBRecordUV*)vbdata;
//		vbdatam=(VBRecordM*)vbdata;

		// xxx if(m->NbrMapIndex>m->NbrVertices)
		if(mc->Flags&MESHCTRL_VERTEX_PER_FACE)
		{
			// Gestion des mesh avec mappings additionels (par face) ou base
			// xxx puv=vbdatauv;
			for(i=0;i<m->NbrFaces;i++)
			{
				PVFace *f=&m->Face[i];
				PV_PrepareFace(f);
				for(unsigned j=0;j<f->NbrVertices;j++)
				{
					unsigned ind=f->V[j];										
					
					memcpy(&vbdata[0],&m->Vertex[ind].xf,sizeof(float)*3);
					memcpy(&vbdata[3*sizeof(float)],&m->Vertex[ind].Normal.xf,sizeof(float)*3);
									
					// xxx memcpy(&puv->uv[0],&m->Mapping[m->NbrVertices+m->MaxNbrClippedVertexes+f->MapIndex+j].u,sizeof(float)*2);				
					if(mc->Flags&MESHCTRL_MAPPING) 
						memcpy(&vbdata[6*sizeof(float)],&m->Mapping[ind].u,sizeof(float)*2);

					if(mc->Flags&MESHCTRL_HAS_LIGHTMAP) 
						memcpy(&vbdata[8*sizeof(float)],&m->Mapping[ind].u,sizeof(float)*2);
					// xxxx puv++;
					vbdata+=size;
				}
				PV_PrepareFace(f);
			}
		}
		else
		{			
			for(i=0;i<m->NbrVertices;i++,vbdata+=size)
			{
				memcpy(&vbdata[0],&m->Vertex[i].xf,sizeof(float)*3);
				
				/* xxxx float t=m->Vertex[i].Normal.yf;
				m->Vertex[i].Normal.yf=-m->Vertex[i].Normal.yf;
				//m->Vertex[i].Normal.zf=-t;*/

				memcpy(&vbdata[3*sizeof(float)],&m->Vertex[i].Normal.xf,sizeof(float)*3);								
				
				if(mc->Flags&MESHCTRL_MAPPING) 
					memcpy(&vbdata[6*sizeof(float)],&m->Mapping[i].u,sizeof(float)*2);
				
				if(mc->Flags&MESHCTRL_HAS_LIGHTMAP) 
					memcpy(&vbdata[8*sizeof(float)],&m->Mapping[i].u,sizeof(float)*2);
			}	
		/* xxxx for(i=0,puv=vbdatauv;i<m->NbrVertices;i++,puv++)
			{
				memcpy(&puv->n[0],&m->Vertex[i].Normal.xf,sizeof(float)*3);
				memcpy(&puv->xyz[0],&m->Vertex[i].xf,sizeof(float)*3);
				memcpy(&puv->uv[0],&m->Mapping[i].u,sizeof(float)*2);
			}*/
		}
	}

	mc->vb->Unlock();
	mc->vb->Optimize(lpD3DDEV,0L);
	
	return COOL;
}

static void PVAPI D3DFinalizeMesh(PVMesh *m)
{
	PVMeshCtrl *mc;

	mc=(PVMeshCtrl*)m->HardwarePrivate;
	if(mc==NULL) return;

	if(mc->vb!=NULL)
	{
		mc->vb->Release();
	}

	BoxIter ie,is;

	is=mc->Boxes.begin();
	ie=mc->Boxes.end();
	while(is!=ie)
	{
		free((*is).second.Indexes);
		free((*is).second.RefFaces);
		free((*is).second.FacesPerMat);
		is++;
	}

	delete mc;
	m->HardwarePrivate=NULL;
}

static void SetupTransforms(PVMesh *m)
{
	// setup transforms
	D3DXMATRIX matWorld,matScale,matWorld1;
	D3DXVECTOR4 piv;
	
	D3DXMatrixIdentity(&matWorld1);
	D3DXMatrixScaling(&matScale,m->ScaleX,m->ScaleY,m->ScaleZ);
			
	for(unsigned i=0;i<3;i++)
		for(unsigned j=0;j<3;j++) matWorld1.m[i][j]=m->WorldMatrix[j][i];
	
	D3DXVec3Transform(&piv,&D3DXVECTOR3(-m->Pivot.xf,-m->Pivot.yf,-m->Pivot.zf),&matWorld1);

	D3DXMatrixMultiply(&matWorld,&matWorld1,&matScale);
	matWorld.m[3][0]=m->WorldPos.xf+piv.x+m->Pivot.xf;
	matWorld.m[3][1]=m->WorldPos.yf+piv.y+m->Pivot.yf;
	matWorld.m[3][2]=m->WorldPos.zf+piv.z+m->Pivot.zf;
	lpD3DDEV->SetTransform(D3DTRANSFORMSTATE_WORLD,matWorld);
}

static void PVAPI D3DRenderMesh(PVMesh *m,PVBox *b,PVFLAGS clipflags,unsigned Scr)
{
	static unsigned lframe=1;

	if(m==NULL) return;

	PVMeshCtrl *mc;	

	if(m->Flags&MESH_INSTANCE)	
		mc=(PVMeshCtrl*)m->Face[0].Father->HardwarePrivate;
	else
		mc=(PVMeshCtrl*)m->HardwarePrivate;

	if(!clipflags)
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_CLIPPING,FALSE);
	else
		lpD3DDEV->SetRenderState(D3DRENDERSTATE_CLIPPING,TRUE);	

	// xxx trouver un moyen de faire ca un poil plus propre
	if(frame!=lframe)
		D3DPreRender(m->Owner,(unsigned int)Scr,PV_GetMode(),PV_GetPipelineControl());

	SetupTransforms(m);

	if(b!=NULL)
	{
		// Boite + VB
		// PP3D Display List
		unsigned bi=(unsigned)b;
		BoxIter bo=mc->Boxes.find(bi);

		if((*bo).second.Flags&MESHCTRL_VALID)
		{
			PVFaceInfosBundle *bu=&(*bo).second;

			for(unsigned i=0;i<bu->NbrMats;i++)
			{				
				switch (bu->FacesPerMat[i].Mat->Type&(RENDER_MASK|SHADE_MASK))
				{
				case MULTITEXTURE|GOURAUD:
				case MULTITEXTURE|FLAT:
				case MULTITEXTURE|LIGHTMAP:
				case MULTITEXTURE:
					if(!MultiTexture) D3DTLMaterialMT(m,bu,i); else D3DTLMaterialMTMT(m,bu,i); break;
				case LIGHTMAP|MAPPING:				
					D3DTLMaterialLightMap(m,bu,i);break;
				default:
					D3DTLMaterialUniform(m,bu,i);break;
				}

			}
		}
	}
	else
	{
		unsigned bi=(unsigned)b;
		BoxIter bo=mc->Boxes.find(bi);

		// Jamais deviiur arriver l�
		PV_Log("minou.log"," error: %s\n",m->Name);

		std::multimap<unsigned,PVFaceInfosBundle>::iterator bb,be;

		bb=mc->Boxes.begin();
		be=mc->Boxes.end();

		while(bb!=be)
		{
			if((*bb).second.Flags&MESHCTRL_VALID)
			{
				PVFaceInfosBundle *bu=&(*bb).second;

				for(unsigned i=0;i<bu->NbrMats;i++)
				{				
					switch (bu->FacesPerMat[i].Mat->Type&(RENDER_MASK|SHADE_MASK))
					{
					case MULTITEXTURE|GOURAUD:
					case MULTITEXTURE|FLAT:
					case MULTITEXTURE|LIGHTMAP:
					case MULTITEXTURE:						
						if(!MultiTexture) D3DTLMaterialMT(m,bu,i); else D3DTLMaterialMTMT(m,bu,i); break;
					case LIGHTMAP|MAPPING:				
						D3DTLMaterialLightMap(m,bu,i);break;
					default:
						D3DTLMaterialUniform(m,bu,i);break;
					}
				}
			}
			
			bb++;
		}
	}

	/*else
	{
		// Custom Pipe
		PVMaterial *lastmat=NULL;
		PVFace **fv;

		fv=&m->Visible[0];
		
		if(mc!=NULL)
		// xxx if(0)
		{
			// Custom Pipe + VB
			// Pipe pour mesh API sans Custom pipe
			for(unsigned i=0;i<m->NbrVisibles;i++,fv++)
			{
				if((*fv)->MaterialInfo!=NULL)
				{
					D3DPrepareFace(*fv);				
					PV_TriangulateFace(*fv,TriD3DTnL,m); // xxx virer ca grace � l'index ?
				}
			}
		}
		else
		{
			// Custom Pipe sans VB
			for(unsigned i=0;i<m->NbrVisibles;i++,fv++)
			{
				if((*fv)->MaterialInfo!=NULL)
				{
					PV_PrepareFace(*fv);
					D3DPrepareFace(*fv);

					void *func=NULL;
					
					switch ((*fv)->MaterialInfo->Type&(RENDER_MASK|SHADE_MASK))
					{
						case U_BUMP|AMBIENT_MAPPING:
						case U_BUMP|MAPPING:
						case BUMP|AMBIENT_MAPPING:
						case BUMP|MAPPING:
								
						case U_PHONG|AMBIENT_MAPPING:
						case U_PHONG|MAPPING:				
						case PHONG|AMBIENT_MAPPING:
						case PHONG|MAPPING:if(MultiTexture) func=TriD3DBiMappingMT; else func=TriD3DBiMapping;break;

						case MULTITEXTURE|GOURAUD:
						case MULTITEXTURE|FLAT:
						case MULTITEXTURE|LIGHTMAP:
						case MULTITEXTURE: if(MultiTexture) func=TriD3DMTMT; else func=TriD3DMT; break;
							
						case LIGHTMAP|MAPPING:
							if(MultiTexture) func=TriD3DLightMapMT; else func=TriD3DLightMap;break;
						default:
							func=TriD3DTnLWithoutVB;
					}

					PV_TriangulateFace(*fv,(void (PVAPI*)(PVFace *))func,m);
					PV_PrepareFace(*fv);
				}
			}
		}
	}
	
/*; xxx	if(frame!=lframe)
		D3DPostRender();*/
	lframe=frame;
}

static void PVAPI D3DOverrideCullMode(pvCULL mode)
{
	OverrideCull=mode;
}

///////////////////////////////////////////////////////////////////////////////
static PVHardwareCaps D3DCapsOrg={
	0,
		PHF_FRAMEBUFFER,
		0,
		0,
		PHD_DEPTHPROP,	
		0,0,0,0,
		0,0,0,0,
		0,
		-1,-1,
		0,
		16,
		0,
		0
};

static PVHardwareCaps D3DCaps;

PVEXPORT PVHardwareDriver PVDriver={
	1,
		PV_MN2,
		sizeof(PVHardwareCaps),
		"Panard Vision DirectX7 Generic Driver V1.01",
		D3DDetect,
		D3DInitSupport,
		D3DEndSupport,
		D3DSetViewPort,
		D3DLoadTexture,
		D3DDeleteTexture,
		D3DGetFiller,
		D3DPreRender,
		D3DPrepareFace,
		D3DPostRender,
		D3DBeginFrame,
		D3DEndFrame,
		D3DFlipSurface,
		D3DFillSurface,
		D3DRefreshMaterial,
		D3DGetInfo,
		D3DLockFB,
		D3DUnLockFB,
		D3DLockDB,
		D3DUnLockDB,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		D3DLoadLightMap,
		D3DDeleteLightMap,
		D3DLockProcedural,
		D3DUnLockProcedural,
		D3DHint,
		D3DUpdateMesh,
		D3DFinalizeMesh,
		D3DRenderMesh,
		D3DOverrideCullMode,
		NULL,
};

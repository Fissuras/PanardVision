/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// DDWin.cpp : implementation file

// Panard Viewer Main window (.3ds and quake's .bsp viewer)
// (C) 1997-2000, Olivier Brunet

// Quick'n dirty hack to the original 3dsview.c file

// Here you will find source for the pvview program. This is an example
// of usage of Panard Vision (think of this like a tutorial).

// For a mirror example see PVSetup function (at the end)

#include "stdafx.h"
#include "resource.h"

#include <fstream.h>
#include <stdio.h>
#include "DDWin.h"
#include "3dsread.h"
#include "3dspm.h"
#include "qkread.h"
#include "qk2read.h"
#include "pvbread.h"
#include "pvut.h"
#include "timer.h"
#include "directdraweasy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DDWin

static DDWin *TheWin;

#define fatal(x)  throw x

int DDWin::GetMaskSize(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
	}

	while(x&1)
	{
		x>>=1;
		i++;
	}
	return i;
}

int DDWin::GetMaskPos(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
		i++;
	}

	return i;
}

//////////////////////////////////////////////////////////////////////////// CallBack Functions

static void PVAPI UserCleanUp(unsigned t)
{
	TheWin->DestroyWindow();
}

struct PivPos
{
	float x,y,z;
};

static int PVAPI ComputeCollision(PVMesh *o,int userarg)
{
	if(o->NbrFaces!=0) 
		if(PV_MeshComputeCollisionTree(o)!=COOL) 
			fatal("Not enough memory for collision infos");
	
	printf("\t� %s (%lu vertices, %lu faces, %lu boxes)\n",o->Name,o->NbrVertices,o->NbrFaces,o->NodeInfos.NbrBoxes);
	((PivPos*)userarg)->x+=o->Pivot.xf; 
	((PivPos*)userarg)->y+=o->Pivot.yf; 
	((PivPos*)userarg)->z+=o->Pivot.zf;

	return COOL;
}

static int PVAPI ReadyForHardware(PVMesh *o,int userarg)
{
	REMOVEFLAG(o->Flags,MESH_NOSORT);

	return COOL;
}

struct CollisionInfos
{
	DDWin *w;
	bool collide;
};

static int PVAPI CollisionTest(PVMesh *o,int userarg)
{
	CollisionInfos *ci;

	ci=(CollisionInfos*)userarg;

	if (PV_CollisionTest(o,ci->w->DummyCam,COLLISION_NO_REPORT)==COLLIDE_YES)
	{
			ci->collide=true;
			return 1;
	}
	
	return COOL;
}

static void CALLBACK TimerHandler(HWND hwnd, UINT msg, UINT id, DWORD time) 
{
	if(id==1)
	{
		PM_SetCurrentTime(TheWin->Anim,TheWin->Anim->CurrentTime+TheWin->ANIMSPEED);
		PM_ComputeCurrentTime(TheWin->Anim);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void DDWin::PVSetup()
{
	HICON m_hIcon;

	SetWindowText("Thinking.... please wait.");
	::ShowWindow(m_hWnd,SW_RESTORE);
	
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	SetIcon(m_hIcon,FALSE);
	
	InitPVision();
	PV_UserCleanUp=UserCleanUp;
	if((Wor=PV_CreateWorld())==NULL) fatal("Not enough memory for PVWorld.");
	if((Anim=PM_CreateTree())==NULL) fatal("Not enough memory to create root node for animation.\n");
	if((Cam=PV_CreateCam("CAMERA"))==NULL) fatal("Not enough memory to create camera.\n");

	// Need to create and assign a cam before calling LoadAnimFrom3DS()	
	Wor->Camera=Cam;
	if(windowed)Wor->ReservedColors=1; else Wor->ReservedColors=0;		// Reserve 1 colors for desktop in windowed mode
    if(tv==0)
    {
		PV_SetCamFieldOfView(Cam,(float)resx/(float)resy);
		Cam->Height=resy;
        Cam->Width=resx;
		Cam->CenterX=resx/2;
		Cam->CenterY=resy/2;
    }
    else
    {
        PV_SetCamFieldOfView(Cam,2*(float)resx/(float)resy);
		Cam->Height=resy/2;
        Cam->Width=resx;
		Cam->CenterX=resx/2;
		Cam->CenterY=resy/4;
    }
	Cam->BackDist=300000;
	Cam->FrontDist=10;

	// Let's load the meshes	
	if(strcmp(file,"")==0) fatal("No mesh file specified");
	printf("Loading %s...\n",file);
	_strlwr(file);

	if(strstr(file,".pvb"))
	{
		PVBFileReader pvb;
		ifstream ef(file,ios::in|ios::binary|ios::nocreate);

		if(!ef.is_open()) fatal("Unable to load PVB file.");

		if(pvb.LoadFromStream(ef,Wor)!=COOL) fatal("Unable to load PVB file.");
	}
	else
	if(strstr(file,".bsp"))
    {
		// First try a Quake2Bsp, then Quake1
		if(LoadMeshesFromQuake2(file,Wor)!=COOL)
			if(LoadMeshesFromQuake(file,Wor)!=COOL) fatal("Error loading quake map");
    }
    else
    {
		if(LoadMeshFrom3DS(file,Wor)!=COOL) fatal("Unable to load 3ds file.");
		if(anim)
		{
			printf("Loading animation...\n");
			if(LoadAnimFrom3DS(file,Anim,Wor,NULL)!=COOL) fatal("Unable to load animation from 3ds file.");
		}
	}
	
	// Loads materials
	pvuMatInfo MatInfo;
	
	MatInfo.CACHESIZE=CACHESIZE;
	MatInfo.STEP=STEP;
	MatInfo.SPEED=ANIMSPEED;

	if(pvuLoadMaterialsDefinitions(Wor,matfile,&MatInfo)!=COOL) fatal("Error during material loading");
	
	ANIMSPEED=MatInfo.SPEED;
	STEP=MatInfo.STEP;
	CACHESIZE=MatInfo.CACHESIZE;
	
	if(Gl) CACHESIZE=0; // no texture cache needed in hardware
	
	printf("Allocating %uMb texture cache...\n",CACHESIZE/(1024*1024));
	PV_InitTextureCache(CACHESIZE);	

	// Go ! Panard Vision	
	PV_SetMode((PV_Mode&~PVM_PALETIZED8)|(mode==0?PVM_PALETIZED8:mode==1?PVM_RGB16:PVM_RGB)|PVM_ALPHABLENDING);

	// DirectX Setup (for everything but 3dfx glide driver)
	if(Gl!=2) if(ddi.SetMode(lpguid,m_hWnd,resx,resy,depth,!windowed)!=0) throw "Error during DDraw init";	
	SetFocus();
	
	// Hardware Setup
	if(Gl)	
	{
		HINSTANCE hInst=NULL;
		switch(Gl)
		{
			// Open gl driver
			case 1:hInst=LoadLibrary("pvgl.dll");break;
			// 3dfx driver 
			case 2:hInst=LoadLibrary("pv3dfx.dll");break;
			// DX Driver
			case 3:hInst=LoadLibrary("pvd3d.dll");break;
		}
		if(hInst==NULL) fatal("Error loading required driver");

		if(PV_SetHardwareDriver((PVHardwareDriver*)GetProcAddress(hInst,"PVDriver"))!=COOL) throw "No hardware found or bad driver version";
		
		if(Gl==3)
		{
			if(PV_InitAccelSupport((unsigned int)ddi.lpDD)!=COOL) throw "Error during hardware init.";
		}
		else
		{
			if(PV_InitAccelSupport((unsigned int)m_hWnd)!=COOL) throw "Error during hardware init.";
		}
		SetFocus();
		
		PV_SetMode(PV_Mode|PVM_USEHARDWARE|PVM_ZBUFFER);		

		printf("Succesfully initialized %s\n",PV_GetHardwareDriver()->Desc);

		// Hardware don't like states change
		PV_SetSortOrder(Wor,PVW_MATERIAL);

		// Iterates through all meshes, to make them sorted, the Quake drivers for instance
		// Sets the NO_SORT flag by default, which would anihilates the materials sorting
		PV_IterateMeshList(Wor->Objs,ReadyForHardware,NULL);
	
		// To prevent sorting glitches, (Quake drivers uses BSPs) enable ZBuffer
		PVMaterial *m;
		m=Wor->Materials;
		while(m!=NULL)
		{
			m->Type|=ZBUFFER;
			m->Type|=FOGABLE;		// Fog test
			m=m->Next;
		}
	}	
	RenderMode=PV_Mode;
		
	// Sets up RGB indexes
	printf("Thinking....\n");
	if(!(PV_Mode&PVM_PALETIZED8)) 
	   if(PV_SetRGBIndexingMode(GetMaskSize(ddi.RedMask),GetMaskSize(ddi.GreenMask),GetMaskSize(ddi.BlueMask),
						GetMaskPos(ddi.RedMask),GetMaskPos(ddi.GreenMask),GetMaskPos(ddi.BlueMask),GetMaskSize(ddi.AlphaMask))!=COOL) fatal("RGB Setup : Bad RGB values\n");

	// The order of the 3 next operations does matter
	if(PV_CompileMeshes(Wor)!=COOL) fatal("Error during meshes compilation.");
	if(PV_CompileMaterials(Wor,NULL,NULL)!=COOL) fatal("Error during materials compilation.");

	// Sets the final palette
	if(PV_Mode&PVM_PALETIZED8)
	{
		char pal[256*3];
		unsigned i;

		for(i=0;i<Wor->ReservedColors;i++) pal[i*3]=pal[i*3+1]=pal[i*3+2]=0;
		for(i=Wor->ReservedColors;i<256;i++)
		{			
			pal[i*3]=Wor->Global256Palette[i].r*4;
			pal[i*3+1]=Wor->Global256Palette[i].g*4;
			pal[i*3+2]=Wor->Global256Palette[i].b*4;			
		}
        ddi.SetPal(pal);
	}

	// Defines the clipping window
	if(tv==0)
	{
		if(PV_Mode&PVM_USEHARDWARE)
		{
			if (PV_SetClipLimit(0,resx-1,0,resy-1,resx)!=COOL) fatal("Not enough memory for S-Buffer.\n");
		}
		else
		if (PV_SetClipLimit(0,resx-1,0,resy-1,ddi.Pitch)!=COOL) fatal("Not enough memory for S-Buffer.\n");
	}
	else
	{
		// NOTE: TV mode will never work with hardware :)
		if(PV_Mode&PVM_USEHARDWARE)
		{
			if (PV_SetClipLimit(0,resx-1,0,resy-1,resx*2)!=COOL) fatal("Not enough memory for S-Buffer.\n");
		}
		else
		if (PV_SetClipLimit(0,resx-1,0,resy/2,ddi.Pitch*2)!=COOL) fatal("Not enough memory for S-Buffer.\n");
	}
    
	// Collision Info
    PivPos pp;
	printf("Computing collision infos...\n");

    pp.x=pp.y=pp.z=0;
	PV_IterateMeshList(Wor->Objs,ComputeCollision,(int)&pp);

	printf("World : %lu vertices, %lu faces\n",Wor->NbrVertices,Wor->NbrFaces);
    printf("%lu objects in the world.\n",Wor->NbrObjs);    
    
	DummyCam=PV_CreateDummyMesh(STEP/2+5,STEP/2+5,STEP/2+5);
    if(DummyCam==NULL) fatal("Not enough memory for dummy cam.\n");
    PV_AddMesh(Wor,DummyCam);
	
	pp.x/=Wor->NbrObjs; pp.y/=Wor->NbrObjs; pp.z/=Wor->NbrObjs;
    if(Cam->pos.xf==0) 
		PV_SetCamPos(Cam,pp.x,pp.y,pp.z);
	PV_SetCamAngles(Cam,0,0,0);
		
	// Integrated Mirror tutorial :)
	// Uncomment the follwoing code to create 2 mirrors, 
	// these are setup to appear with cowssol.3ds
/*    PV_AddMirror(Wor,PV_CreateMirror());
    Wor->Mirrors->NbrVertexes=4;
    Wor->Mirrors->Vertex[0].xf=-30;
    Wor->Mirrors->Vertex[0].yf=-30;
    Wor->Mirrors->Vertex[0].zf=0;
    Wor->Mirrors->Vertex[1].xf=30;
    Wor->Mirrors->Vertex[1].yf=-30;
    Wor->Mirrors->Vertex[1].zf=0;
    Wor->Mirrors->Vertex[2].xf=30;
    Wor->Mirrors->Vertex[2].yf=30;
    Wor->Mirrors->Vertex[2].zf=0;
    Wor->Mirrors->Vertex[3].xf=-30;
    Wor->Mirrors->Vertex[3].yf=30;
    Wor->Mirrors->Vertex[3].zf=0;
    PV_SetupMirror(Wor->Mirrors);

    PV_AddMirror(Wor,PV_CreateMirror());
    Wor->Mirrors->NbrVertexes=4;
    Wor->Mirrors->Vertex[0].xf=50;
    Wor->Mirrors->Vertex[0].yf=-30;
    Wor->Mirrors->Vertex[0].zf=-30;
    Wor->Mirrors->Vertex[1].xf=50;
    Wor->Mirrors->Vertex[1].yf=-30;
    Wor->Mirrors->Vertex[1].zf=30;
    Wor->Mirrors->Vertex[2].xf=50;
    Wor->Mirrors->Vertex[2].yf=30;
    Wor->Mirrors->Vertex[2].zf=30;
    Wor->Mirrors->Vertex[3].xf=50;
    Wor->Mirrors->Vertex[3].yf=30;
    Wor->Mirrors->Vertex[3].zf=-30;
    PV_SetupMirror(Wor->Mirrors);*/
	
	// Fog Sphere Try
    /*PVMesh *fogs=PVFX_AddFogSphere(Wor,150,4);
	PVFX_SetFogSphereColor(fogs,0.4,0.9,0.9);
	PVFX_SetFogSphereAttenuation(fogs,0,0.1,0.1);
	PVFX_SetFogSpherePosition(fogs,Cam->pos.xf,Cam->pos.yf+100,Cam->pos.zf);
    PV_SetMode(PV_Mode|PVM_VERTEXFOGGING);
    */

	// Linear Fog  Test
	Wor->Fog.Type=PVF_LINEAR;
	Wor->Fog.Color.r=0;
	Wor->Fog.Color.g=0;
	Wor->Fog.Color.b=0;
	Wor->Fog.Color.a=0;
	Wor->Fog.Start=Cam->FrontDist;
	Wor->Fog.End=Cam->BackDist/100;

	PV_Hint("PV_FOG_RANGE",1);
	PV_Hint("PV_FOG_TABLE",0);

	SetWindowText(file);
	if(anim) SetTimer(1,1000/70,TimerHandler);
	else Redraw();
}

#define TestKey(x) (((signed char)keyb[x])<0)

void DDWin::RunIt()
{	
	PVPoint OldCamT;
	
	CloseRequested=FALSE;

	// faster keys processing
	while (!CloseRequested) 
	{ 
		MSG msg;

		while ( ::PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) )     
		{ 
			if ( !AfxGetApp()->PumpMessage( ) )
			{ 
				CloseRequested=TRUE; 
				::PostQuitMessage(0);             
				break;         
			}     
		} 
		
		if(CloseRequested) break;

		// let MFC do its idle processing
//		LONG lIdle = 0;
//		while ( AfxGetApp()->OnIdle(lIdle++ ) );

		// Perform some background processing here 
		// using another call to OnIdle				

	   char keyb[256];
	   GetKeyboardState((BYTE*)keyb);
	
	   // Key pressed ? 
	   for(int i=0;i<256;i++) 
		   if (keyb[i]<0) break;
	   if(!anim)
			if(i==256) continue;

		OldCamT=Cam->pos;
		
		if(TestKey(VK_UP)) PV_CamAhead(Cam,-STEP);
		if(TestKey(VK_DOWN)) PV_CamAhead(Cam,STEP);
		if(TestKey(VK_ADD)) PV_ScaleWorld(Wor,1.1,1.1,1.1);
		if(TestKey(VK_SUBTRACT)) PV_ScaleWorld(Wor,0.9,0.9,0.9);
		if(TestKey('A')) PV_SetCamAngles(Cam,Cam->yaw,Cam->pitch-0.1,Cam->roll);
		if(TestKey('Q')) PV_SetCamAngles(Cam,Cam->yaw,Cam->pitch+0.1,Cam->roll);
		if(TestKey(VK_LEFT)) PV_SetCamAngles(Cam,Cam->yaw+0.1,Cam->pitch,Cam->roll);
		if(TestKey(VK_RIGHT)) PV_SetCamAngles(Cam,Cam->yaw-0.1,Cam->pitch,Cam->roll);
		if(TestKey('Z')) PV_SetCamAngles(Cam,Cam->yaw,Cam->pitch,Cam->roll-0.1);
		if(TestKey('S')) PV_SetCamAngles(Cam,Cam->yaw,Cam->pitch,Cam->roll+0.1);
		if(TestKey('N'))
		{
			PV_SetMode(RenderMode);
			PV_SetSortOrder(Wor,PVW_BACK_2_FRONT);
			collision=0;
		}
		if(TestKey('M')) PV_SetMode(PV_Mode|PVM_MIPMAPPING);
		if(TestKey('X')) if(Wor->Lights!=NULL) PV_SetLightDirection(Wor->Lights,Wor->Lights->Direction.xf+0.1,Wor->Lights->Direction.yf,Wor->Lights->Direction.zf);
		if(TestKey('C')) if(Wor->Lights!=NULL) PV_SetLightDirection(Wor->Lights,Wor->Lights->Direction.xf-0.1,Wor->Lights->Direction.yf,Wor->Lights->Direction.zf);
		if(TestKey('V')) PV_SetMode(PV_Mode|PVM_ZBUFFER);
		if(TestKey('B')) PV_SetMode(PV_Mode|PVM_BILINEAR);
		if(TestKey('J')) PV_SetMode(PV_Mode|PVM_SBUFFER);
		if(TestKey('F')) PV_SetCamFieldOfView(Cam,Cam->fieldofview+0.1);
		if(TestKey('G')) PV_SetCamFieldOfView(Cam,Cam->fieldofview-0.1);
		if(TestKey('H')) collision=1;
		if(TestKey('D')) Wor->AmbientLight.b+=0.05;
		if(TestKey('E')) Wor->AmbientLight.b-=0.05;
		if(TestKey('P')) if(Wor->Fog.Type==PVF_LINEAR) Wor->Fog.Type=PVF_NONE; else Wor->Fog.Type=PVF_LINEAR;

		if(TestKey(VK_ESCAPE)) 
		{
			PostMessage(WM_CLOSE,0,0);
			return;
		}

	   // Perform basic collision detection
	   if(collision)
	   {
		   CollisionInfos ci;
		   
		   DummyCam->Position=Cam->pos;
		   
		   ci.w=this;
		   ci.collide=false;
		   PV_IterateMeshList(Wor->Objs,CollisionTest,(int)&ci);
		   if(ci.collide)
			   	Cam->pos=OldCamT;
	   }	   

	   Redraw();
	}
}

DDWin::DDWin(LPGUID _lpguid,unsigned resx,unsigned resy,unsigned depth,unsigned mode,char *file,char *matfile,int anim,int tv,BOOL windowed,BOOL gl)
{
	this->resx=resx;
	this->resy=resy;
	this->depth=depth;
	this->mode=mode;
	this->file=strdup(file);
	this->matfile=strdup(matfile);
	this->anim=anim;
	this->tv=tv;
	this->windowed=windowed;
	this->Gl=gl;
	this->lpguid=_lpguid;
	collision=0;
	STEP=30;
	ANIMSPEED=1;
	CACHESIZE=8*1024*1024; // 8Mb Cache size by default

	TotalTime=TotalFrame=0;

	TheWin=this;
}

DDWin::~DDWin()
{
}

BEGIN_MESSAGE_MAP(DDWin, CFrameWnd)
	//{{AFX_MSG_MAP(DDWin)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_QUERYNEWPALETTE()
	ON_WM_CLOSE()
	ON_WM_SYSKEYDOWN()
	ON_WM_SYSKEYUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void DDWin::Redraw()
{
	UPVD8 *Screen;
	
	if(PV_Mode&PVM_USEHARDWARE)	
		PV_FillSurface(0,0,0,0,0);
	else
		ddi.Fill(0,0,0,resy,resx,0);
    
	// Timing
	timer.start();
	
	PV_BeginFrame();
	if(!Gl) Screen=ddi.Lock(); else Screen=0;
    
	UpdateQuake2World(Wor);				// If Wor contains Quake2 entities , do something with them
	PV_RenderWorld(Wor,Screen);
	
	if(!Gl) ddi.Unlock();
	PV_EndFrame();

	TotalTime+=timer.stop();
	TotalFrame++;
   	
	if(PV_Mode&PVM_USEHARDWARE)
		PV_FlipSurface();
	else
		ddi.Flip();
}

/////////////////////////////////////////////////////////////////////////////
// DDWin message handlers

int DDWin::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	RECT r;
	
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here	
	try
	{	
		GetWindowRect(&r);
		r.right=r.left+resx;
		r.bottom=r.top+resy;
		SetWindowPos(NULL,r.left,r.top,r.right-r.left,r.bottom-r.top,SWP_NOZORDER);
		PVSetup();
	}
	catch(char *e)
	{
		PV_EndAccelSupport();
		ddi.Error(e);
		return -1;
	}
		
	return 0;
}
 
void DDWin::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	Redraw();	
	// Do not call CFrameWnd::OnPaint() for painting messages
}

BOOL DDWin::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class	
	Sleep(1000);

	if(anim) KillTimer(1);
		
	PV_GarbageCollector(Wor);
	PV_KillWorld(Wor);
	PM_KillTree(Anim);
	PV_KillCam(Cam);						// The cam is the only object we need to destroy, others
											// are automagically cleaned by KillWorld (if they were
											// attached to the world of course.
	Wor=NULL;
	Anim=NULL;
	Cam=NULL;

	PV_EndAccelSupport();					// Should be the last thing done, since this destroy
											// all downloaded materials. 
											// hence, PV_KillWorld() should be called before.
	ddi.UnInit();

	PV_ReleaseTextureCache();

	char tmp[255];
	sprintf(tmp,"Average FPS : %f\n",1000/((float)TotalTime/(float)TotalFrame));
	if(TotalFrame) MessageBox(tmp);
	
	return CFrameWnd::DestroyWindow();
}

BOOL DDWin::OnQueryNewPalette() 
{
	// TODO: Add your message handler code here and/or call default
	ddi.RestorePalette();

	return CFrameWnd::OnQueryNewPalette();
}

void DDWin::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	CloseRequested=TRUE;
	
	CFrameWnd::OnClose();
}

void DDWin::OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
//	CFrameWnd::OnSysKeyDown(nChar, nRepCnt, nFlags);
}

void DDWin::OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
//	CFrameWnd::OnSysKeyUp(nChar, nRepCnt, nFlags);
}

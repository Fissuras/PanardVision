Here you will find source for the pvview program. This is an example
of usage of Panard Vision (think of this like a tutorial).

see pvview.doc for some details

If you make improvements, let me know.

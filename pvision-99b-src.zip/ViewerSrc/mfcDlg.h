/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// mfcDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMfcDlg dialog

class CMfcDlg : public CDialog
{
// Construction
public:
	CMfcDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMfcDlg)
	enum { IDD = IDD_MFC_DIALOG };
	CComboBox	m_RenderM;
	CButton	m_Window;
	CButton	m_ButMesh;
	CButton	m_ButMat;
	CComboBox	m_DDriver;
	CListBox	m_lboxes;
	CString	m_3dsfiles;
	CString	m_matfile;
	CString	m_resx;
	CString	m_resy;
	BOOL	m_tv;
	BOOL	m_anim;
	int		m_depth;
	int		m_render;
	BOOL	m_Windowed;
	int		m_RenderMode;
	int		m_DDriverNum;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMfcDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CButton m_brgb;
	CButton m_bf16;
	CButton	m_b256;
	CButton m_b15;
	CButton m_b16;
	CButton m_b24;
	CButton m_b32;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMfcDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButmat();
	afx_msg void OnButmesh();
	virtual void OnOK();
	afx_msg void On256col();
	afx_msg void OnFakergb();
	afx_msg void OnRgb();
	afx_msg void OnAbout();
	afx_msg void OnButton1();
	afx_msg void OnSelchangeDDDriver();
	afx_msg void OnDblclkModes();
	afx_msg void OnWindowed();
	afx_msg void OnSelchangeRendermode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

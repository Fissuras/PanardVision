/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mfc.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MFC_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDD_HELP                        132
#define IDI_ICONOPEN                    135
#define IDC_256COL                      1001
#define IDC_FAKERGB                     1002
#define IDC_RGB                         1003
#define IDC_MET                         1006
#define IDC_MESHES                      1007
#define IDC_RESX                        1008
#define IDC_RESY                        1009
#define IDC_ANIM                        1012
#define IDC_TV                          1013
#define IDC_15BITS                      1014
#define IDC_16BITS                      1015
#define IDC_24BITS                      1016
#define IDC_32BITS                      1017
#define IDC_BUTMAT                      1023
#define IDC_BUTMESH                     1024
#define IDC_WINDOWED                    1025
#define IDC_MODES                       1027
#define IDC_ABOUT                       1028
#define IDC_PVVERSION                   1029
#define IDC_PMVERSION                   1030
#define IDC_BUILD                       1031
#define IDC_GL                          1032
#define IDC_RENDERMODE                  1034
#define IDC_BUTTON1                     1038
#define IDC_DDDriver                    1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif

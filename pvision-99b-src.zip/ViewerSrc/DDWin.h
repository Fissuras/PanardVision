/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// DDWin.h : header file
// Very Quick'n Dirty hack to the 3dsview.c dos version (very very dirty)

#include <pvision.h>
#include <pmotion.h>
#include "directdraweasy.h"
/////////////////////////////////////////////////////////////////////////////
// DDWin frame

class DDWin : public CFrameWnd
{
	
protected:
	DDrawEasy ddi;

	PVWorld *Wor;	
	PVCam   *Cam;	
	
	int RenderMode;

	unsigned resx,resy;
	unsigned depth;
	unsigned mode;
	char* file;
	char* matfile;
	unsigned anim;
	unsigned tv;

	BOOL windowed;
	int Gl;

	unsigned TotalTime,TotalFrame;

    unsigned CACHESIZE;	

	bool CloseRequested;

// Operations
public:	
	PVMesh* DummyCam;
    PMotion *Anim;
    float ANIMSPEED;	

	DDWin(LPGUID _lpguid,unsigned resx,unsigned resy,unsigned depth,unsigned mode,char *file,char *matfile,int anim,int tv,BOOL windowed,int gl);  
	virtual ~DDWin();

	void RunIt(void);
    void Redraw();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DDWin)
	public:
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

protected:
	LPGUID lpguid;
	int collision;
	float STEP;	
	void PVSetup();
	int LoadJpeg (char * filename,PVMaterial *m);
	int filesize(FILE *fp);
	void LoadRaw(char *na,PVMaterial *mat);
	void LoadBump(char *na,PVMaterial *mat);
	char *ReadLine(FILE *f);
	int DecodeFlags(char *a2);
	void LoadMaterialsDefinitions(char *s);
	int GetMaskSize(unsigned x);
	int GetMaskPos(unsigned x);

	// Generated message map functions
	//{{AFX_MSG(DDWin)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg BOOL OnQueryNewPalette();
	afx_msg void OnClose();
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// mfc.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "mfc.h"
#include "mfcDlg.h"
#include "ddwin.h"
#include "ddriver.h"
#include <eh.h>
#include <conio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMfcApp

BEGIN_MESSAGE_MAP(CMfcApp, CWinApp)
	//{{AFX_MSG_MAP(CMfcApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfcApp construction

CMfcApp::CMfcApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMfcApp object

CMfcApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMfcApp initialization

//--------------------------------------------------------

#define StepSpace	cur++;if(*cur==' ') cur++;

BOOL CMfcApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
	
		CMfcDlg dlg;
		char dir[255];
		int nResponse;
		unsigned Resx=320,Resy=200,depth=8,gl=0;
		PVFLAGS RenderMode=PVM_PALETIZED8;
		bool TV=FALSE,ANIMATION=FALSE,WINDOWED=FALSE;
		char MatFile[255],_3dsfiles[255],cmdline[255];

		// Status console setup
		AllocConsole();
		SetConsoleTitle("Panard Viewer status");
		freopen( "CONOUT$", "w", stdout );
		freopen( "CONOUT$", "w", stderr );
		printf("Panard Viewer console started....\n");

		// Registers file types
		// Runs 640*480*16 Direct3D
		HKEY key;
		char maintype[]="PanardViewer.File.Auto";
		char t[4096];

		RegCreateKeyEx(HKEY_CLASSES_ROOT,".pvb",0,"",REG_OPTION_NON_VOLATILE,KEY_WRITE,NULL,&key,NULL);
		RegSetValueEx(key,"",0,REG_SZ,(unsigned char*)&maintype,strlen(maintype)+1);
		RegCloseKey(key);

		RegCreateKeyEx(HKEY_CLASSES_ROOT,".bsp",0,"",REG_OPTION_NON_VOLATILE,KEY_WRITE,NULL,&key,NULL);
		RegSetValueEx(key,"",0,REG_SZ,(unsigned char*)&maintype,strlen(maintype)+1);
		RegCloseKey(key);

		RegCreateKeyEx(HKEY_CLASSES_ROOT,"PanardViewer.File.Auto\\Shell\\Open\\Command",0,"",REG_OPTION_NON_VOLATILE,KEY_WRITE,NULL,&key,NULL);
		strcpy(t,m_pszHelpFilePath);
		t[strlen(t)-3]=0;
		strcat(t,"exe -x640 -y480 -w -g3 \"%1\"");
		RegSetValueEx(key,"",0,REG_SZ,(unsigned char*)t,strlen(t)+1);
		RegCloseKey(key);
						
		// Basic/ugly/unclean command line parser
		strncpy(cmdline,m_lpCmdLine,255);
		if(cmdline[0]!='\0')
		{
			char *cur=cmdline;
		
			// Remove trailing spaces
			unsigned g=strlen(cmdline)-1;
			while(cmdline[g]==' ')
			{
				cmdline[g]='\0';
				g--;
			}
			
			strcat(cmdline," ");
			MatFile[0]=0;
			_3dsfiles[0]=0;

			while(cur[0]!='\0')
			{
				if((*cur=='-')||(*cur=='/'))
				{
					// A param
					cur++;
					switch(*cur)
					{
						case 'x':StepSpace;Resx=atoi(cur);break;
						case 'y':StepSpace;Resy=atoi(cur);break;
						case 'r':RenderMode=PVM_RGB16;depth=16;break;
						case 'z':StepSpace;
								RenderMode=PVM_RGB;
								if(!strncmp(cur,"15",2)) depth=15;
								if(!strncmp(cur,"16",2)) depth=16;
								if(!strncmp(cur,"24",2)) depth=24;
								if(!strncmp(cur,"32",2)) depth=32;
								break;
						case 't':TV=TRUE;break;
						case 'a':ANIMATION=TRUE;break;
						case 'f':StepSpace;strcpy(MatFile,strtok(cur," "));while(*cur!='\0') cur++;*cur=' ';break;
						case 'g':StepSpace;gl=atoi(cur);break;
						case 'w':WINDOWED=TRUE;break;
						default:
							ZeHelp();							
							return FALSE;

					}
					while((*cur!=' ')&&(*cur!='\0')) cur++;
				}
				else
				{
					if(*cur!=' ')
					{
						if(*cur=='"')
						{
							cur++;
							strcpy(_3dsfiles,strtok(cur,"\""));
						}
						else
						{
							strcpy(_3dsfiles,strtok(cur," "));
						}
						
						// Skips after strok
						while(*cur!='\0') cur++;
						*cur=' ';
						while((*cur!=' ')&&(*cur!='\0')) cur++;
					}
				}
								
				if(*cur!='\0') cur++;
			}

			DDWin *ZeWin=new DDWin(NULL,Resx,Resy,depth,(RenderMode==PVM_PALETIZED8?0:RenderMode==PVM_RGB16?1:2),_3dsfiles,MatFile,ANIMATION,TV,WINDOWED,gl);
			m_pMainWnd=ZeWin;
			if(ZeWin->Create(NULL, "ploc",/*WS_SYSMENU|*/WS_OVERLAPPED|WS_BORDER|WS_CAPTION|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS, CFrameWnd::rectDefault))
			{
				ZeWin->ShowWindow(m_nCmdShow);
				ZeWin->UpdateWindow();
				ZeWin->RunIt();
			}

			return TRUE;
		}
		else 
		{
			GetCurrentDirectory(255,dir);
			nResponse = dlg.DoModal();
			SetCurrentDirectory(dir);

			if (nResponse == IDOK)
			{
					// TODO: Place code here to handle when the dialog is
					//  dismissed with OK				
						
					if(dlg.m_render==0) dlg.m_depth=8;
					
					DDWin *ZeWin=new DDWin(&((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(dlg.m_DDriverNum)))->GUID,atoi(LPCSTR(dlg.m_resx)),atoi(LPCSTR(dlg.m_resy)),dlg.m_depth==0?15:dlg.m_depth==1?16:dlg.m_depth==2?24:dlg.m_depth==8?8:32,dlg.m_render,(char*)LPCSTR(dlg.m_3dsfiles),(char*)LPCSTR(dlg.m_matfile),dlg.m_anim,dlg.m_tv,dlg.m_Windowed,dlg.m_RenderMode);
					m_pMainWnd=ZeWin;
					if(ZeWin->Create(NULL, "ploc",/*WS_SYSMENU|*/WS_OVERLAPPED|WS_BORDER|WS_CAPTION|WS_VISIBLE|WS_CLIPCHILDREN | WS_CLIPSIBLINGS, CFrameWnd::rectDefault))
					{
						ZeWin->ShowWindow(m_nCmdShow);
						ZeWin->UpdateWindow();
						ZeWin->RunIt();
					}
								
					return TRUE;
			}
			else if (nResponse == IDCANCEL)
			{
				// TODO: Place code here to handle when the dialog is
				//  dismissed with Cancel
			}	

		}
		
	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CMfcApp::ZeHelp()
{
    printf("\n\npvviewer [options] [file1.3DS]\n");
    printf("\tex: pvviewer -a zob.3ds -x640 -y480 -fplouf.def\n");
    printf("Options:\n");
    printf("\t  -xNNN   where NNN is the horizontal resolution\n");
    printf("\t  -yNNN   where NNN is the vertical resolution\n");
    printf("\t  -r      use fake 16bits render mode.\n");
    printf("\t  -znn    use RGB (nn bits) render mode (currently 15,16,24,32).\n");
    printf("\t  -t      TV mode.\n");
    printf("\t  -a      Use animation info from .3ds. (MUST be first on the command line)\n");
    printf("\t  -ffile  Use file for material definitions.\n");
    printf("\t  -gx     Specify a driver to render with:\n");
	printf("\t				-g0 Software rendering\n");
	printf("\t				-g1 OpenGL driver\n");
	printf("\t				-g2 3Dfx driver\n");
	printf("\t				-g3 Direct3D driver\n");
	printf("\t  -w      Windowed mode\n");
	getch();
}

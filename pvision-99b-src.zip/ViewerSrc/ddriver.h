/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __DDRIVER_H__
#define __DDRIVER_H__

#include <afxcoll.h>
#define DIRECTDRAW_VERSION		0x300
#include <ddraw.h>
#include <d3d.h>

struct DDDriverInfo {
	GUID	GUID;
	LPSTR	lpDesc;
	LPSTR	lpName;
	bool	CanRenderWindowed;
};

struct DDModeInfo
{
	unsigned RGBBitCount;
	unsigned Width,Height;
};

extern CPtrList DDDevices;
extern CPtrList DDModeList;
extern CPtrList D3DDevices;

void EnumerateDDDevices();
void EnumerateDDModes(LPGUID lpGUID,HWND wnd);
void EnumerateD3DDevices(LPGUID lpGUID);

#endif
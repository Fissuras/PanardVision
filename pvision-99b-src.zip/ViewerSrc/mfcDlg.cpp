/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// mfcDlg.cpp : implementation file
//

#include "stdafx.h"
#include "mfc.h"
#include "mfcDlg.h"
#include "help.h"
#include <dos.h>
#include <direct.h>
#include <pvision.h>
#include <pmotion.h>
#include "ddriver.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CString	m_PMV;
	CString	m_PVV;
	CString	m_btime;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:	
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_PMV = _T("");
	m_PVV = _T("");
	m_btime = _T("");
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Text(pDX, IDC_PMVERSION, m_PMV);
	DDX_Text(pDX, IDC_PVVERSION, m_PVV);
	DDX_Text(pDX, IDC_BUILD, m_btime);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfcDlg dialog

CMfcDlg::CMfcDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMfcDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMfcDlg)
	m_3dsfiles = _T("");
	m_matfile = _T("");
	m_resx = _T("320");
	m_resy = _T("200");
	m_tv = FALSE;
	m_anim = FALSE;
	m_depth = -1;
	m_render = 0;
	m_Windowed = FALSE;
	m_RenderMode = 0;
	m_DDriverNum = -1;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMfcDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMfcDlg)
	DDX_Control(pDX, IDC_RENDERMODE, m_RenderM);
	DDX_Control(pDX, IDC_WINDOWED, m_Window);
	DDX_Control(pDX, IDC_BUTMESH, m_ButMesh);
	DDX_Control(pDX, IDC_BUTMAT, m_ButMat);
	DDX_Control(pDX, IDC_DDDriver, m_DDriver);
	DDX_Control(pDX, IDC_MODES, m_lboxes);
	DDX_Text(pDX, IDC_MESHES, m_3dsfiles);
	DDX_Text(pDX, IDC_MET, m_matfile);
	DDX_Text(pDX, IDC_RESX, m_resx);
	DDX_Text(pDX, IDC_RESY, m_resy);
	DDX_Check(pDX, IDC_TV, m_tv);
	DDX_Check(pDX, IDC_ANIM, m_anim);
	DDX_Radio(pDX, IDC_15BITS, m_depth);
	DDX_Radio(pDX, IDC_256COL, m_render);
	DDX_Check(pDX, IDC_WINDOWED, m_Windowed);
	DDX_CBIndex(pDX, IDC_RENDERMODE, m_RenderMode);
	DDX_CBIndex(pDX, IDC_DDDriver, m_DDriverNum);
	DDX_Control(pDX, IDC_256COL, m_b256);
	DDX_Control(pDX, IDC_FAKERGB, m_bf16);
	DDX_Control(pDX, IDC_RGB, m_brgb);
	DDX_Control(pDX, IDC_15BITS, m_b15);
	DDX_Control(pDX, IDC_16BITS, m_b16);
	DDX_Control(pDX, IDC_24BITS, m_b24);
	DDX_Control(pDX, IDC_32BITS, m_b32);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMfcDlg, CDialog)
	//{{AFX_MSG_MAP(CMfcDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTMAT, OnButmat)
	ON_BN_CLICKED(IDC_BUTMESH, OnButmesh)
	ON_BN_CLICKED(IDC_256COL, On256col)
	ON_BN_CLICKED(IDC_FAKERGB, OnFakergb)
	ON_BN_CLICKED(IDC_RGB, OnRgb)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_CBN_SELCHANGE(IDC_DDDriver, OnSelchangeDDDriver)
	ON_LBN_DBLCLK(IDC_MODES, OnDblclkModes)
	ON_BN_CLICKED(IDC_WINDOWED, OnWindowed)
	ON_CBN_SELCHANGE(IDC_RENDERMODE, OnSelchangeRendermode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfcDlg message handlers

struct ModeInfo
{
	unsigned RGBBitCount;
	unsigned Width,Height;
};
static CPtrList ModeList;

static HRESULT CALLBACK ModeCallback(LPDDSURFACEDESC pdds, LPVOID lParam)
{
	ModeInfo *mi;

	mi=new ModeInfo;
	
	mi->RGBBitCount=pdds->ddpfPixelFormat.dwRGBBitCount;
	mi->Width=pdds->dwWidth;
	mi->Height=pdds->dwHeight;

	ModeList.AddTail(mi);
    
    return DDENUMRET_OK;
}


BOOL CMfcDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	CString strAboutMenu;
	strAboutMenu.LoadString(IDS_ABOUTBOX);
	if (!strAboutMenu.IsEmpty())
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here	
	// Check for DDraw devices
	EnumerateDDDevices();
	POSITION pos = DDDevices.GetHeadPosition();
	while( pos != NULL )
	{
		DDDriverInfo* mi = (DDDriverInfo*)DDDevices.GetNext( pos );
		m_DDriver.AddString(mi->lpDesc);
	}

	m_DDriver.SetCurSel(0);
	OnSelchangeDDDriver();

    m_ButMat.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONOPEN));
    m_ButMesh.SetIcon(AfxGetApp()->LoadIcon(IDI_ICONOPEN));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMfcDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMfcDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMfcDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CAboutDlg::OnInitDialog()
{

	m_PVV=PVISION_VERSION;
	m_PMV=PMOTION_VERSION;
	m_btime=__DATE__;
	m_btime+=" ";
	m_btime+=__TIME__;	
	UpdateData(FALSE);
	return TRUE;
}

void CMfcDlg::OnButmat() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CFileDialog dlg( TRUE,_T("DEF"),_T("*.DEF"),
	                 OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,
	                 _T("Material files (*.DEF)|*.DEF|All files (*.*)|*.*|"));
	
	if( dlg.DoModal()==IDOK )
	{
		m_matfile=dlg.GetPathName();		
		UpdateData(FALSE);
	}
}

void CMfcDlg::OnButmesh() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CFileDialog dlg( TRUE,_T("3DS"),NULL,
	                 OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,
	                 _T("Mesh files (*.3DS;*.BSP;*.PVB)|*.3DS; *.BSP; *.PVB|"));
	
	if( dlg.DoModal()==IDOK )
	{
		m_3dsfiles=dlg.GetPathName();		
		UpdateData(FALSE);
	}
}

void CMfcDlg::OnOK() 
{	
	// TODO: Add extra validation here
	UpdateData(TRUE);

	if((m_render<2)&&(m_RenderMode==0)) MessageBox("Warning : Rendering in non Full-RGB modes can result in a slow program startup, so be patient !","Be patient !");
	
	CDialog::OnOK();
}

void CMfcDlg::On256col() 
{
	// TODO: Add your control notification handler code here
	m_b15.EnableWindow(FALSE);
	m_b16.EnableWindow(FALSE);
	m_b24.EnableWindow(FALSE);
	m_b32.EnableWindow(FALSE);
	m_b15.SetCheck(FALSE);
	m_b16.SetCheck(FALSE);
	m_b24.SetCheck(FALSE);
	m_b32.SetCheck(FALSE);
}

void CMfcDlg::OnFakergb() 
{
	// TODO: Add your control notification handler code here
	m_b15.EnableWindow(TRUE);
	m_b16.EnableWindow(TRUE);
	m_b24.EnableWindow(FALSE);
	m_b32.EnableWindow(FALSE);
	m_b15.SetCheck(FALSE);
	m_b16.SetCheck(TRUE);
	m_b24.SetCheck(FALSE);
	m_b32.SetCheck(FALSE);
}

void CMfcDlg::OnRgb() 
{
	// TODO: Add your control notification handler code here
	if(m_Windowed) return;
	m_b15.EnableWindow(TRUE);
	m_b16.EnableWindow(TRUE);
	m_b24.EnableWindow(TRUE);
	m_b32.EnableWindow(TRUE);
	m_b15.SetCheck(FALSE);
	m_b16.SetCheck(TRUE);
	m_b24.SetCheck(FALSE);
	m_b32.SetCheck(FALSE);
}

void CMfcDlg::OnAbout() 
{
	// TODO: Add your control notification handler code here
	CHelp dlgAbout;
	dlgAbout.DoModal();
}

void CMfcDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CMfcDlg::OnSelchangeDDDriver() 
{
	char zob[255];
	
	// TODO: Add your control notification handler code here
	while(m_lboxes.DeleteString(0)>0);	
	
	if(m_DDriver.GetCurSel()!=CB_ERR)
	{
		LPGUID lpGuid=&((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(m_DDriver.GetCurSel())))->GUID;

		if(!(((DDDriverInfo*)DDDevices.GetAt(DDDevices.FindIndex(m_DDriver.GetCurSel())))->CanRenderWindowed))
		{
			m_Window.EnableWindow(FALSE);
			m_Window.SetCheck(FALSE);
			m_Windowed=FALSE;
			OnWindowed();
		}
		else
		{
			m_Window.EnableWindow(TRUE);
		}

		// modes list
		EnumerateDDModes(lpGuid,m_hWnd);
		POSITION pos = DDModeList.GetHeadPosition();
		while( pos != NULL )
		{
			DDModeInfo* mi = (DDModeInfo*)DDModeList.GetNext( pos );
			wsprintf(zob,"%ux%u\t%u bits",mi->Width,mi->Height,mi->RGBBitCount);

			m_lboxes.AddString(zob);
		}
	}
}

void CMfcDlg::OnDblclkModes() 
{
	// TODO: Add your control notification handler code here
	char zob[255];
	UpdateData(TRUE);
	wsprintf(zob,"%u",((DDModeInfo*)DDModeList.GetAt(DDModeList.FindIndex(m_lboxes.GetCurSel())))->Width);
	m_resx=zob;
	wsprintf(zob,"%u",((DDModeInfo*)DDModeList.GetAt(DDModeList.FindIndex(m_lboxes.GetCurSel())))->Height);	
	m_resy=zob;

	int bits=((DDModeInfo*)DDModeList.GetAt(DDModeList.FindIndex(m_lboxes.GetCurSel())))->RGBBitCount;
	if(bits==8)
	{
		On256col();
		m_render=0;
		m_depth=-1;
	}
	else
	{
		OnRgb();
		m_depth=(bits==15?0:bits==16?1:bits==24?2:3);
		m_render=2;
	}

	UpdateData(FALSE);
}

void CMfcDlg::OnWindowed() 
{
	// TODO: Add your control notification handler code here
	HDC dc;
	
	UpdateData(TRUE);
	if(m_Windowed)
	{
		dc=CreateDC("DISPLAY",NULL,NULL,NULL);
		int col=GetDeviceCaps(dc,BITSPIXEL);
		DeleteDC(dc);	

		if(col==8)
		{
			On256col();
			m_render=0;
		
			m_brgb.EnableWindow(FALSE);
			m_bf16.EnableWindow(FALSE);
		}
		else
		{
			OnRgb();

			m_b15.EnableWindow(FALSE);
			m_b16.EnableWindow(FALSE);
			m_b24.EnableWindow(FALSE);
			m_b32.EnableWindow(FALSE);

			m_render=2;
			m_depth=(col==15?0:col==16?1:col==24?2:3);

			switch(m_depth)
			{
			case 0:m_b15.EnableWindow(TRUE);break;
			case 1:m_b16.EnableWindow(TRUE);m_b15.EnableWindow(TRUE);break;
			case 2:m_b24.EnableWindow(TRUE);break;
			default:m_b32.EnableWindow(TRUE);break;
			}

			m_b256.EnableWindow(FALSE);
			if(col>16) m_bf16.EnableWindow(FALSE);
		}
	}	
	else
	{
			m_brgb.EnableWindow(TRUE);
			m_bf16.EnableWindow(TRUE);
			m_b256.EnableWindow(TRUE);

			if(m_render==2) OnRgb();
			if(m_render==1) OnFakergb();
			if(m_render==0) On256col();

			OnSelchangeRendermode();
	}

	UpdateData(FALSE);	
}

void CMfcDlg::OnSelchangeRendermode() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_RenderM.GetCurSel()!=0)
	{
		OnRgb();
		m_render=2;
		m_depth=1;

		m_brgb.EnableWindow(TRUE);
		m_bf16.EnableWindow(FALSE);
		m_b256.EnableWindow(FALSE);
	}	
	else
	{
		m_brgb.EnableWindow(TRUE);
		m_bf16.EnableWindow(TRUE);
		m_b256.EnableWindow(TRUE);
	}
	UpdateData(FALSE);
}

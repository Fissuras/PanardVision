/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "stdafx.h"
#include "ddriver.h"

CPtrList DDDevices;

static BOOL WINAPI DriverEnumCallbackEx(
    GUID FAR *  lpGuid,
    LPTSTR      lpDesc, 
    LPTSTR      lpName,
    LPVOID      lpExtra,
	HMONITOR	hm)
{
    CPtrList		*lpInfo;
    DDDriverInfo    *lpDriver;
	LPDIRECTDRAW	lpDD;
	DDCAPS			DDcaps,HELcaps;

	if (! lpExtra) return DDENUMRET_OK;
    lpInfo = (CPtrList *)lpExtra;

    // Get Pointer to driver info
    lpDriver = new DDDriverInfo;
    if (! lpDriver) return DDENUMRET_OK;

	// Test it
	if(DirectDrawCreate(lpGuid,&lpDD,NULL)!=DD_OK) return DDENUMRET_OK;

	memset(&DDcaps,0,sizeof(DDcaps));
	DDcaps.dwSize=sizeof(DDcaps);
	memset(&HELcaps,0,sizeof(HELcaps));
	HELcaps.dwSize=sizeof(HELcaps);
	if(lpDD->GetCaps(&DDcaps,&HELcaps)!=DD_OK)
	{
		lpDD->Release();
		lpDD=NULL;
		return DDENUMRET_OK;
	}

    lpDriver->CanRenderWindowed=true;

	if(lpGuid!=NULL)
	{
		if( DDcaps.dwCaps2 & DDCAPS2_CANRENDERWINDOWED )
			lpDriver->CanRenderWindowed=true;
		else
			lpDriver->CanRenderWindowed=false;
	}

	// Valid
	if(lpGuid==NULL)
		memset(&lpDriver->GUID,0,sizeof(GUID));	
	else
		memcpy(&lpDriver->GUID,lpGuid,sizeof(GUID));
	lpDriver->lpDesc=strdup(lpDesc);
	lpDriver->lpName=strdup(lpName);
	lpInfo->AddTail(lpDriver);

	lpDD->Release();

    // Success
    return DDENUMRET_OK;
} 

static BOOL WINAPI DriverEnumCallback(
    GUID FAR *  lpGuid,
    LPTSTR      lpDesc, 
    LPTSTR      lpName,
    LPVOID      lpExtra)
{
	return DriverEnumCallbackEx(lpGuid,lpDesc,lpName,lpExtra,NULL);
} 

void EnumerateDDDevices()
{
	// Free old list
	if(!DDDevices.IsEmpty())
	{
		POSITION pos = DDDevices.GetHeadPosition();
		while( pos != NULL )
		{
			DDDriverInfo* mi = (DDDriverInfo*)DDDevices.GetNext( pos );
			free(mi->lpDesc);
			free(mi->lpName);
			delete mi;
		}
		DDDevices.RemoveAll();

	}

	// Multimonitor support
	HINSTANCE h = LoadLibrary("ddraw.dll"); 
    
    // Note that you must know which version of the
    // function to retrieve (see the following text).
    // For this example, we use the ANSI version.
    
	LPDIRECTDRAWENUMERATEEX lpDDEnumEx;
    lpDDEnumEx = (LPDIRECTDRAWENUMERATEEX) GetProcAddress(h,"DirectDrawEnumerateExA");
     // If the function is there, call it to enumerate all display 
    // devices attached to the desktop, and any non-display DirectDraw
    // devices.    
	if (lpDDEnumEx) 
	{
		lpDDEnumEx(DriverEnumCallbackEx, (LPVOID)&DDDevices,DDENUM_ATTACHEDSECONDARYDEVICES|DDENUM_DETACHEDSECONDARYDEVICES|DDENUM_NONDISPLAYDEVICES);    
	}
	else    
	{        
		/*
         * We must be running on an old version of DirectDraw.
         * Therefore MultiMon isn't supported. Fall back on
         * DirectDrawEnumerate to enumerate standard devices on a 
         * single-monitor system.         */		
        DirectDrawEnumerate(DriverEnumCallback,(LPVOID)&DDDevices); 
	} 
    // If the library was loaded by calling LoadLibrary(),
    // then you must use FreeLibrary() to let go of it.    
	FreeLibrary(h);
}

////////////////////////////////////////////////////////////////////////////////////////////

CPtrList DDModeList;

static HRESULT CALLBACK ModeCallback(LPDDSURFACEDESC pdds, LPVOID lParam)
{
	DDModeInfo *mi;

	mi=new DDModeInfo;
	
	mi->RGBBitCount=pdds->ddpfPixelFormat.dwRGBBitCount;
	mi->Width=pdds->dwWidth;
	mi->Height=pdds->dwHeight;

	DDModeList.AddTail(mi);
    
    return DDENUMRET_OK;
}

void EnumerateDDModes(LPGUID lpGUID,HWND wnd)
{
	LPDIRECTDRAW lpDD;
	HRESULT hr;
	GUID NullGUID={0,0,0,0,0,0,0,0,0,0,0};
		
	// Free Old list
	if(!DDModeList.IsEmpty())
	{
		POSITION pos = DDModeList.GetHeadPosition();
		while( pos != NULL )
		{
			DDModeInfo* mi = (DDModeInfo*)DDModeList.GetNext( pos );
			delete mi;			
		}
		DDModeList.RemoveAll();
	}

	if(memcmp(lpGUID,&NullGUID,sizeof(GUID))==0)
		hr=DirectDrawCreate( NULL, &lpDD, NULL );
	else
		hr=DirectDrawCreate( lpGUID, &lpDD, NULL );
	if(hr!=DD_OK) return;

	lpDD->SetCooperativeLevel(wnd,DDSCL_FULLSCREEN|DDSCL_EXCLUSIVE|DDSCL_NOWINDOWCHANGES);
	lpDD->EnumDisplayModes(0,NULL,NULL,ModeCallback);
	lpDD->SetCooperativeLevel(wnd,DDSCL_NORMAL);
	lpDD->Release();	
}

/////////////////////////////////////////////////////////////////////////////////////

/* Not finished

CPtrList D3DDevices;

static HRESULT WINAPI
EnumDeviceCallback(LPGUID          lpGUID, 
                   LPSTR           lpDesc,
                   LPSTR           lpName,
                   LPD3DDEVICEDESC lpd3dHWDeviceDesc,
                   LPD3DDEVICEDESC lpd3dSWDeviceDesc,
                   LPVOID          lpUserArg)
{
    BOOL            fIsHardware;
    LPD3DDEVICEDESC lpd3dDeviceDesc;
	DDDriverInfo *lpDriver;
  
	// Get Pointer to driver info
    lpDriver = new DDDriverInfo;
    if (!lpDriver) return DDENUMRET_OK;
    
	if(0UL != lpd3dHWDeviceDesc->dcmColorModel)
	{
		// hardware Device
		

	}
	else
	{
		// Software
	}

	if(lpGUID==NULL)
		memset(&lpDriver->GUID,0,sizeof(GUID));	
	else
		memcpy(&lpDriver->GUID,lpGUID,sizeof(GUID));

	lpDriver->lpDesc=strdup(lpDesc);
	lpDriver->lpName=strdup(lpName);
	D3DDevices.AddTail(lpDriver);

    //lpd3dDeviceDesc = (fIsHardware ? lpd3dHWDeviceDesc : lpd3dSWDeviceDesc);

    
    /*
     * This is a device we are interested in - cache the details away.
     */
    /*fDeviceFound = TRUE;
    CopyMemory(&guidDevice, lpGUID, sizeof(GUID));
    strcpy(szDeviceDesc, lpszDeviceDesc);
    strcpy(szDeviceName, lpszDeviceName);
    CopyMemory(&d3dHWDeviceDesc, lpd3dHWDeviceDesc, sizeof(D3DDEVICEDESC));
    CopyMemory(&d3dSWDeviceDesc, lpd3dSWDeviceDesc, sizeof(D3DDEVICEDESC));

    //If this is a hardware device we have found what we are looking
    if (fIsHardware)
        return D3DENUMRET_CANCEL;

    //Keep looking...
     
    return D3DENUMRET_OK;
}


void EnumerateD3DDevices(LPGUID lpGUID)
{
	LPDIRECTDRAW lpDD;
	LPDIRECT3D	lpD3D;
	
	D3DDevices.RemoveAll();

	if(DirectDrawCreate( lpGUID, &lpDD, NULL ) != DD_OK ) return;		
	if(lpDD->QueryInterface(IID_IDirect3D,(LPVOID*)&lpD3D)!=DD_OK) return;
	lpD3D->EnumDevices(EnumDeviceCallback,NULL);
	
	lpD3D->Release();
	lpDD->Release();	
}
*/
/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Direct3D v5 Driver for the Panard Vision 3D Engine
// (C) 1997-98, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//

#define D3D_OVERLOADS
#include "d3dfill.h"
#include <string.h>

PVRGBF *AmbientLight;
float bp,fp,depthval,depthval2;

//--------------------------------------------------------------------------------

static D3DTLVERTEX v[MAX_VERTICES_PER_POLY*2];
static unsigned nbrv;

#define Color(p) \
	D3DRGBA( \
	min(1,(o->Shading[p].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r), \
	min(1,(o->Shading[p].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g), \
	min(1,(o->Shading[p].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b), \
	o->Shading[p].Color.a*f->MaterialInfo->AlphaConstant)

unsigned long lastmip=-1;
#define LoadTexture \
	if(lastmip!=((unsigned long*)f->MaterialInfo->Tex[0].Texture)[0]) \
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREHANDLE,lastmip=((unsigned long*)f->MaterialInfo->Tex[0].Texture)[0]);

#define LoadTexture2 \
	if(lastmip!=((unsigned long*)f->MaterialInfo->AuxiliaryTexture.Texture)[0]) \
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREHANDLE,lastmip=((unsigned long*)f->MaterialInfo->AuxiliaryTexture.Texture)[0]);

#define LoadTexture3 \
	if(lastmip!=((unsigned long*)f->LightMap->Maps[f->LightMap->CurrentLightMap])[0]) \
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREHANDLE,lastmip=((unsigned long*)f->LightMap->Maps[f->LightMap->CurrentLightMap])[0]);

// The magic formula, don't ask me why, ask the DX developement team :)
#define LoadZ(a) \
	(depthval+o->Projected[a].InvertZ*depthval2)

#define DrawPoly(w) \
{ \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			v[i] = w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			v[i] = w; \
} \
} \
lpD3DDEV2->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DVT_TLVERTEX,(LPVOID)v,nbrv,D3DDP_DONOTUPDATEEXTENTS); \
}

#define DrawPoly2(w) \
{ \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			w; \
} \
} \
lpD3DDEV2->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DVT_TLVERTEX,(LPVOID)v,nbrv,D3DDP_DONOTUPDATEEXTENTS); \
}
	
//------------------------------------------------------------------------------------------
void PVAPI TriD3DGouraud(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;	

	DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,Color(a),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),0,0));	
}

void PVAPI TriD3DFlat(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;
		
	D3DCOLOR col=Color(f->V[0]);

	DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,col,D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),0,0));	
}

void PVAPI TriD3DMapping(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;		

	LoadTexture;
	if(f->Flags&(PHONG|U_PHONG))
	{		
		if(o->Shading!=NULL)
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].AmbientU,o->Mapping[a].AmbientV))
        else
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].AmbientU,o->Mapping[a].AmbientV));
	}
	else
	{
		if(o->Shading!=NULL)
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
        else
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].u,o->Mapping[a].v));
	}	
}

void PVAPI TriD3DFlatMapping(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;
	
	D3DCOLOR col=Color(f->V[0]);
	D3DCOLOR spe=D3DRGBA(0,0,0,1-o->Shading[f->V[0]].Specular.a);

	LoadTexture;
	DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,col,spe,o->Mapping[a].u,o->Mapping[a].v));
}

void PVAPI TriD3DGouraudMapping(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;	

	LoadTexture;
	DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,Color(a),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v));
}

void PVAPI TriD3DBiMapping(PVFace *f)
{
	unsigned a,i;
	DWORD as,a1,a2,zws;
	PVMesh *o=f->Father;		
	
	// 2 Pas fill
	// 1st pass, mapping			
	LoadTexture;
	if(o->Shading!=NULL)
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
    else
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].u,o->Mapping[a].v));
	
	//2nd Pass : luminance by blending a light map over the 1st triangle	
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_DESTBLEND,&a1);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_ZERO);
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_SRCBLEND,&a2);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SRCBLEND,D3DBLEND_DESTCOLOR);
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,&as);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_ZFUNC,&zws);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);			

	LoadTexture2;	
	DrawPoly2(
		v[i].tu=o->Mapping[a].AmbientU;
	    v[i].tv=o->Mapping[a].AmbientV
			)

	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,as);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_DESTBLEND,a1);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SRCBLEND,a2);	
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,zws);			
}

void PVAPI TriD3DLightMap(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;		
	DWORD as,a1,a2,zws;
	
	// 2 Pas fill
	// 1st pass, mapping			
	LoadTexture;	
	if(o->Shading!=NULL)
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
    else
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].u,o->Mapping[a].v));	

	//2nd Pass : luminance by blending a light map over the 1st triangle	
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_DESTBLEND,&a1);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_ZERO);
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_SRCBLEND,&a2);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SRCBLEND,D3DBLEND_DESTCOLOR);
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,&as);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);			
	lpD3DDEV2->GetRenderState(D3DRENDERSTATE_ZFUNC,&zws);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);			
		
	LoadTexture3;
	DrawPoly2(
		    v[i].tu=f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU;
		    v[i].tv=f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV;
			)

	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,as);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_DESTBLEND,a1);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SRCBLEND,a2);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,zws);			
}

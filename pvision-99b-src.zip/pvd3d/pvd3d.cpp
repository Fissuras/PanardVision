/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Generic DirectX5 driver for the Panard Vision 3D Engine
// (C) 1997-98, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//

// If there is no hardware found, defaults to software D3D rendering 
// (mainly for debugging purposes), and it's damn slow !

// NOTE: Should test the maximum texture size supported by hardware and resize the incoming
//		 textures if needed.

//---------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <math.h>
#define INITGUID
#define DIRECTDRAW_VERSION		0x500
#include <ddraw.h>
#include "d3dfill.h"
#include "pvd3d.h"

/////////////////////////////////////////////////////////////////////////////////
static LPDIRECTDRAW		lpDD=NULL;
static LPDIRECTDRAW2	lpDD2;
static LPDIRECT3D2		lpD3D2;
LPDIRECT3DDEVICE2		lpD3DDEV2;
static LPDIRECT3DVIEWPORT2		lpViewport2=NULL;

static LPDIRECTDRAWSURFACE lpDDS,lpDDSPrimary,lpZBuffer=NULL;

static LPDIRECTDRAWPALETTE lpDDPalette=NULL;

static LPDIRECTDRAWCLIPPER lpClipper=NULL;
static D3DVIEWPORT2 viewport;

D3DDEVICEDESC	HalCaps;
static D3DDEVICEDESC	HelCaps;

static PVFLAGS PVM;

static PVMaterial *lastm=NULL;
static PVFLAGS oldpvf=0;

static bool soft=FALSE,FogTable,OverrideLighting,FogEnabled;

/////////////////////////////////////////////////////////////////////////////////

static void __cdecl DebugString(char *fmt, ...)
{
    char ach[128];
    va_list va;
	FILE *f;

	if(getenv("PVD3D")!=NULL)
	{
		if(strcmp(getenv("PVD3D"),"QUIET")==0)
		{
			return;
		}
	}
		
    va_start( va, fmt );
    wvsprintf( ach, fmt, va );
    va_end( va );
	
	f=fopen("pvd3d.log","a+");
	fprintf(stderr,"%s",ach);
	fprintf(f,"%s",ach);
	OutputDebugString(ach);
	fclose(f);
}

//-----------------------------------------------------------------------------
// Name: D3DUtil_SetProjectionMatrix()
// Desc: Sets the passed in 4x4 matrix to a perpsective projection matrix built
//       from the field-of-view (fov, in y), aspect ratio, near plane (D),
//       and far plane (F). Note that the projection matrix is normalized for
//       element [3][4] to be 1.0. This is performed so that W-based range fog
//       will work correctly.
//-----------------------------------------------------------------------------
HRESULT D3DUtil_SetProjectionMatrix( D3DMATRIX& mat, FLOAT fFOV, FLOAT fAspect,
                                     FLOAT fNearPlane, FLOAT fFarPlane )
{
    if( fabs(fFarPlane-fNearPlane) < 0.01f )
        return E_INVALIDARG;
    if( fabs(sin(fFOV/2)) < 0.01f )
        return E_INVALIDARG;

    FLOAT w = fAspect * (FLOAT)( cos(fFOV/2)/sin(fFOV/2) );
    FLOAT h =   1.0f  * (FLOAT)( cos(fFOV/2)/sin(fFOV/2) );
    FLOAT Q = fFarPlane / ( fFarPlane - fNearPlane );

    ZeroMemory( &mat, sizeof(D3DMATRIX) );
    mat._11 = w;
    mat._22 = h;
    mat._33 = Q;
    mat._34 = 1.0f;
    mat._43 = -Q*fNearPlane;

    return S_OK;
}

//////////////////////////////////////////////////////////////////////////////////////

typedef struct {
    DWORD           bpp;        // we want a texture format of this bpp
    DDPIXELFORMAT   ddpf;       // place the format here
}   FindTextureData;

HRESULT CALLBACK FindTextureCallback (DDSURFACEDESC *DeviceFmt, LPVOID lParam)
{
    FindTextureData * FindData = (FindTextureData *)lParam;
    DDPIXELFORMAT ddpf = DeviceFmt->ddpfPixelFormat;
	
    DebugString("FindTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		ddpf.dwRGBBitCount, 
        (ddpf.dwFlags & (DDPF_ALPHA|DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (ddpf.dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (ddpf.dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		ddpf.dwRBitMask,
		ddpf.dwGBitMask,
		ddpf.dwBBitMask,
		ddpf.dwRGBAlphaBitMask);
	
    // No alpha textures
    if (ddpf.dwFlags & (DDPF_ALPHA|DDPF_ALPHAPIXELS))
        return DDENUMRET_OK;
	
	// No paletized textures
	if(ddpf.dwFlags & (DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) 
		return DDENUMRET_OK;
	
	// No RGBZ Pixel format
    if (ddpf.dwFlags & DDPF_ZPIXELS)
		return DDENUMRET_OK;

	// Only RGB textures
	if (!(ddpf.dwFlags & DDPF_RGB))
        return DDENUMRET_OK;
	
    // Find the nearest surface
    if (FindData->ddpf.dwRGBBitCount == 0 ||
		(ddpf.dwRGBBitCount >= FindData->bpp &&
		(UINT)(ddpf.dwRGBBitCount - FindData->bpp) < (UINT)(FindData->ddpf.dwRGBBitCount - FindData->bpp)))
    {
        FindData->ddpf = ddpf;
    }
	
    return DDENUMRET_OK;
}

static HRESULT CALLBACK FindAlphaTextureCallback (DDSURFACEDESC *DeviceFmt, LPVOID lParam)
{
    FindTextureData * FindData = (FindTextureData *)lParam;
    DDPIXELFORMAT ddpf = DeviceFmt->ddpfPixelFormat;
	
    DebugString("FindTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		ddpf.dwRGBBitCount, 
        (ddpf.dwFlags & (DDPF_ALPHA|DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (ddpf.dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (ddpf.dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		ddpf.dwRBitMask,
		ddpf.dwGBitMask,
		ddpf.dwBBitMask,
		ddpf.dwRGBAlphaBitMask);
	
	// No Alpha Only formats
	// No ZBuffer only formats
	// No YUV formats
	// No RGBZ formats
	// No FourCC formats
	if (ddpf.dwFlags & (DDPF_ZBUFFER |
		DDPF_YUV | DDPF_ZPIXELS | DDPF_FOURCC))
        return DDENUMRET_OK;
	
	// We only want RGB formats for now !!!
    if (! (ddpf.dwFlags & DDPF_RGB))
        return DDENUMRET_OK;
	
	// We only want texture formats with an alpha channel
    if (!(ddpf.dwFlags & DDPF_ALPHAPIXELS))
        return DDENUMRET_OK;
	
	// We don't want palettized textures
    if (ddpf.dwFlags & (DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4 | 
		DDPF_PALETTEINDEXED2 | DDPF_PALETTEINDEXED1))
        return DDENUMRET_OK;
	
    //
    // keep the alpha texture format with the largest
	// alpha channel
    //
    if ((FindData->ddpf.dwRGBAlphaBitMask == 0) ||
		(ddpf.dwRGBAlphaBitMask > FindData->ddpf.dwRGBAlphaBitMask))
    {
        FindData->ddpf = ddpf;
    }
	
    return DDENUMRET_OK;
}

static void ChooseTextureFormat(IDirect3DDevice2 *Device, DWORD bpp, DDPIXELFORMAT *pddpf)
{
    FindTextureData FindData;
    ZeroMemory(&FindData, sizeof(FindData));
    FindData.bpp = bpp;
    Device->EnumTextureFormats(FindTextureCallback, (LPVOID)&FindData);
    *pddpf = FindData.ddpf;
	
    DebugString("ChooseTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		pddpf->dwRGBBitCount, 
        (pddpf->dwFlags & (DDPF_ALPHA|DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (pddpf->dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (pddpf->dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		pddpf->dwRBitMask,
		pddpf->dwGBitMask,
		pddpf->dwBBitMask,
		pddpf->dwRGBAlphaBitMask);
}

static BOOL ChooseAlphaTextureFormat(IDirect3DDevice2 *Device, DDPIXELFORMAT *pddpf)
{
    FindTextureData FindData;
    ZeroMemory(&FindData, sizeof(FindData));
	
    Device->EnumTextureFormats (FindAlphaTextureCallback, (LPVOID)&FindData);
    *pddpf = FindData.ddpf;
	
	if (FindData.ddpf.dwAlphaBitDepth == 0)
		return FALSE;
	
    DebugString("ChooseAlphaTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		pddpf->dwRGBBitCount, 
        (pddpf->dwFlags &   (DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (pddpf->dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (pddpf->dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		pddpf->dwRBitMask,
		pddpf->dwGBitMask,
		pddpf->dwBBitMask,
		pddpf->dwRGBAlphaBitMask);
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////

static HRESULT WINAPI EnumSurfacesCallback(
										   LPDIRECTDRAWSURFACE lpDDSurface,  
										   LPDDSURFACEDESC lpDDSurfaceDesc,  
										   LPVOID lpContext                  
										   )
{
	unsigned h=lpDDSurfaceDesc->ddsCaps.dwCaps&DDSCAPS_PRIMARYSURFACE;
	
	h^=(unsigned)lpContext;
	
	// Look for a 3d surface not directly visible (probably the back buffer)	
	if((lpDDSurfaceDesc->ddsCaps.dwCaps&DDSCAPS_3DDEVICE)&&(h))
	{
		lpDDS=lpDDSurface;
		return DDENUMRET_CANCEL;
	}
	else 
	{
		lpDDSurface->Release();
		return DDENUMRET_OK;	
	}
}

static int GetMaskSize(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
	}
	
	while(x&1)
	{
		x>>=1;
		i++;
	}
	return i;
}

static int GetMaskPos(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
		i++;
	}
	
	return i;
}

static void RestoreLM(void);
static void RestoreAllSurfaces(PVMaterial *m)
{	
	LPDIRECTDRAWSURFACE surf,surf2;
	LPDIRECT3DTEXTURE2 lpTex2,lpTex2b;
	
	// Assumes Primarrysurface state=Other surfaces state	
	if(lpDDSPrimary->IsLost())	lpDDSPrimary->Restore(); else return;	
	if(lpDDS->IsLost())	lpDDS->Restore();	
	if(lpZBuffer!=NULL) 
		if(lpZBuffer->IsLost()) lpZBuffer->Restore();			

		while(m!=NULL)
		{
			if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB)))
			{
				m=m->Next;
				continue;
			}
						
			memcpy(&surf,&m->Tex[0].Texture[4],sizeof(surf));
			memcpy(&surf2,&m->Tex[0].Texture[8],sizeof(surf2));
				
			if((surf->IsLost())||(surf2->IsLost()))
			{
				surf->Restore();
				surf2->Restore();				
				
				surf->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
				surf2->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2b);
				
				// Load it to hardware
				lpTex2b->Load(lpTex2);
				
				lpTex2->Release();
				lpTex2b->Release();							
			}
			m=m->Next;
		}
	RestoreLM();
}

extern PVHardwareCaps D3DCaps;
extern PVHardwareCaps D3DCapsOrg;
static void InitSurfaceCaps(LPDIRECTDRAWSURFACE surf)
{
	DDPIXELFORMAT  ddpf;	
	
	surf->GetPixelFormat(&ddpf);
	D3DCaps.BitsPerPixel=ddpf.dwRGBBitCount;
	D3DCaps.NbrBitsRed=GetMaskSize(ddpf.dwRBitMask);
	D3DCaps.NbrBitsGreen=GetMaskSize(ddpf.dwGBitMask);
	D3DCaps.NbrBitsBlue=GetMaskSize(ddpf.dwBBitMask);
	D3DCaps.NbrBitsAlpha=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	D3DCaps.RedPos=GetMaskPos(ddpf.dwRBitMask);
	D3DCaps.GreenPos=GetMaskPos(ddpf.dwGBitMask);
	D3DCaps.BluePos=GetMaskPos(ddpf.dwBBitMask);
	D3DCaps.AlphaPos=GetMaskSize(ddpf.dwRGBAlphaBitMask);
}

void SetPal(LPDIRECTDRAWSURFACE surf)
{		
	unsigned i;
	PALETTEENTRY Pal[256];
	HRESULT hr;
	
	//
    // build a 332 palette as the default.
    //
	if(lpDDPalette==NULL)
	{
		for (i=0; i<256; i++)
		{
			Pal[i].peRed   = (BYTE)(((i >> 5) & 0x07) * 255 / 7);
			Pal[i].peGreen = (BYTE)(((i >> 2) & 0x07) * 255 / 7);
			Pal[i].peBlue  = (BYTE)(((i >> 0) & 0x03) * 255 / 3);
			Pal[i].peFlags = PC_NOCOLLAPSE;;
		}
		
		hr=lpDD->CreatePalette(DDPCAPS_8BIT|DDPCAPS_ALLOW256,Pal,&lpDDPalette,NULL); 
		if(hr!=DD_OK)
		{
			DebugString("PVDX: CreatePal %x\n",hr);
		}
	}
	hr=surf->SetPalette(lpDDPalette);
	if(hr!=DD_OK)
	{
		//DebugString("PVDX: SetPal %x\n",hr);
	}
	else DebugString("PVDX: Palette handling supplied\n");
}


/////////////////////////////////////////////////////////////////////////////////
static int InitDevice(bool hard)
{
	HRESULT hr;
	DDSURFACEDESC ddsd;

	soft=!hard;

	if(lpZBuffer!=NULL) lpZBuffer->Release();
	if(lpD3DDEV2!=NULL) lpD3DDEV2->Release();
	lpZBuffer=NULL;
	lpD3DDEV2=NULL;

	if(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_ZBUFFERLESSHSR)
	{
		DebugString("This device does not need z-buffer, skipping");
	}
	else
	{
		memset(&ddsd,0,sizeof(ddsd));
		ddsd.dwSize=sizeof(ddsd);
		ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT;
		lpDDS->GetSurfaceDesc(&ddsd);

		ddsd.dwSize=sizeof(ddsd);
		ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT|DDSD_CAPS|DDSD_ZBUFFERBITDEPTH;
		ddsd.ddsCaps.dwCaps=DDSCAPS_ZBUFFER;

		if(!hard) 
			ddsd.ddsCaps.dwCaps|=DDSCAPS_SYSTEMMEMORY;
		else
			ddsd.ddsCaps.dwCaps|=DDSCAPS_VIDEOMEMORY;

		ddsd.dwZBufferBitDepth=16;		

		hr=lpDD2->CreateSurface(&ddsd,&lpZBuffer,NULL);
		if(hr!=DD_OK)
		{
			ddsd.dwZBufferBitDepth=24;

			hr=lpDD2->CreateSurface(&ddsd,&lpZBuffer,NULL);
			if(hr!=DD_OK)
			{
				ddsd.dwZBufferBitDepth=32;

				hr=lpDD2->CreateSurface(&ddsd,&lpZBuffer,NULL);
				if(hr!=DD_OK)
				{
					DebugString("Panard Vision Direct X Driver : WARNING : Unable to create ZBuffer\n");
					DebugString("Error code 0x%x\n",hr);
					return 0;
				}
			}
		}
		
		if(lpZBuffer!=NULL)
		{
			lpDDS->Restore();
			lpZBuffer->Restore();
			hr=lpDDS->AddAttachedSurface(lpZBuffer);
			if(hr!=DD_OK)
			{
				DebugString("Panard Vision Direct X Driver : WARNING : Unable to attach ZBuffer\n");
				DebugString("Error code 0x%x\n",hr);
				
				lpZBuffer->Release();
				lpZBuffer=NULL;
				return 0;
			}
		}
		//else return 0;
	}

	// Gets a Direct3DDevice2
	// Creates a default palette if needed	
	IDirectDrawPalette *pal;
	lpDDS->GetPalette(&pal);
	if(pal==NULL) SetPal(lpDDS);
	else pal->Release();

	lpDDSPrimary->GetPalette(&pal);
	if(pal==NULL) SetPal(lpDDSPrimary);
	else pal->Release();

	// first try HAL then RGB (for debugging)			
	if(hard)
		hr=lpD3D2->CreateDevice(IID_IDirect3DHALDevice,lpDDS,&lpD3DDEV2);
	else 
		hr=lpD3D2->CreateDevice(IID_IDirect3DRGBDevice,lpDDS,&lpD3DDEV2);
	if(hr!=DD_OK) return 0;
	
	return 1;
}

static void PVAPI D3DEndSupport(void);
static void PVAPI D3DHint(char *hint,UPVD32 val);

static int PVAPI D3DDetect(void)
{	
	// Ok, let's try to load d3d6 instead
	HINSTANCE hInst=NULL;
	
	hInst=LoadLibrary("pvd3d6.dll");	
	if(hInst!=NULL)
	{
		PVHardwareDriver *hd=(PVHardwareDriver*)GetProcAddress(hInst,"PVDriver");

		if(hd!=NULL)
		{
			if(hd->Detect())
			{
				memcpy(&PVDriver,hd,sizeof(PVHardwareDriver));
			}
			else
			{
				DebugString("PVDX Driver: Unable to initialize pvd3d6.dll, switching back to pvd3d.dll\n");
			}
		}
	}

	return  1;
}

static void PVAPI SetFogTable(int t)
{
	if((t)&&(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_FOGTABLE))
	{
		PV_SetPipelineControl(PV_GetPipelineControl()&(~PVP_COMPUTEFOGVALUES));
		FogTable=TRUE;
		DebugString("INFO: Using Fog Table functions\n");
	}
	else
	{
		PV_SetPipelineControl(PV_GetPipelineControl()|PVP_COMPUTEFOGVALUES);
		FogTable=FALSE;
		DebugString("INFO: Using Vertex Fog functions\n");
	}
}

// This driver does not take a window handle, but a pointer to a DirectDraw object attached to 
// the rendering window
// This permits the client program to choose cooperative level and rendering device
// assumes Clipper have been already created for windowed rendering
static int PVAPI D3DFillSurface(unsigned surfacenum,float r,float g,float b,float a);
static int PVAPI D3DInitSupport(long _lpDD)
{
	DDSURFACEDESC ddsd;
	HRESULT hr;
	DDCAPS ddcaps;
	
	DebugString("Panard Vision DX Driver : Starting (%s)\n",PVDriver.Desc);
	soft=FALSE;
	
	if(lpDD!=NULL) return ALREADY_ASSIGNED;
	lpDD=(LPDIRECTDRAW)_lpDD;
	if(lpDD==NULL) return ARG_INVALID;

	lpDD->AddRef();

	// reinit caps
	memcpy(&D3DCaps,&D3DCapsOrg,sizeof(D3DCaps));
	
	// gets an IDirectDraw2 Interface and dd3
	if(lpDD->QueryInterface(IID_IDirectDraw2,(LPVOID*)&lpDD2)!=DD_OK)
	{
		DebugString("Panard Vision DirectX driver : failed to get IID_IDirectDraw2\n");
		lpDD=NULL;
		return NO_ACCELSUPPORT;
	}
	
	// Look for client a created surface which could be the frontbuffer
	lpDDS=NULL;
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=0;
	ddsd.ddsCaps.dwCaps=DDSCAPS_3DDEVICE;
	hr=lpDD2->EnumSurfaces(DDENUMSURFACES_DOESEXIST,&ddsd,0,EnumSurfacesCallback);
	if(hr!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : Error during surfaces enumeration\n");
		D3DEndSupport();
		return NO_ACCELSUPPORT;	
	}
	if(lpDDS==NULL)
	{
		DebugString("Panard Vision DirectX driver : No attached surface with 3D caps and front buffer caps\n");		
		D3DEndSupport();
		return NO_ACCELSUPPORT;		
	}
	lpDDSPrimary=lpDDS;
	
	// Look for client a created surface which could be the backbuffer
	lpDDS=NULL;
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=0;
	ddsd.ddsCaps.dwCaps=DDSCAPS_3DDEVICE;
	hr=lpDD2->EnumSurfaces(DDENUMSURFACES_DOESEXIST,&ddsd,(void*)1,EnumSurfacesCallback);
	if(hr!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : Error during 2nd surfaces enumeration\n");
		D3DEndSupport();
		return NO_ACCELSUPPORT;	
	}
	if(lpDDS==NULL)
	{
		DebugString("Panard Vision DirectX driver : WARNING : No attached surface with 3D caps and back buffer caps, running single frame !!\n");
		
		// no backbuffer => backbuf=frontbuffer
		lpDDS=lpDDSPrimary;
		lpDDS->AddRef();
		D3DCaps.NbrSurf=1;
	}
	else D3DCaps.NbrSurf=2;

	// Gets an IDirect3D2 Interface
	if(lpDD2->QueryInterface(IID_IDirect3D2,(LPVOID*)&lpD3D2)!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : failed to get IID_IDirect3D2\n");
		D3DEndSupport();
		return NO_ACCELSUPPORT;
	}
	
	// Init & Gets Caps
	hr=lpD3D2->CreateDevice(IID_IDirect3DHALDevice,lpDDS,&lpD3DDEV2);
	if(hr==COOL)
	{
		HalCaps.dwSize=sizeof(HalCaps);
		HelCaps.dwSize=sizeof(HelCaps);
		lpD3DDEV2->GetCaps(&HalCaps,&HelCaps);
		lpD3DDEV2->Release();
		lpD3DDEV2=NULL;
	}
	
	if(!InitDevice(true))
	{
		hr=lpD3D2->CreateDevice(IID_IDirect3DRGBDevice,lpDDS,&lpD3DDEV2);
		if(hr==COOL)
		{
			HalCaps.dwSize=sizeof(HalCaps);
			HelCaps.dwSize=sizeof(HelCaps);
			lpD3DDEV2->GetCaps(&HalCaps,&HelCaps);
			memcpy(&HalCaps,&HelCaps,sizeof(HalCaps));
			lpD3DDEV2->Release();
			lpD3DDEV2=NULL;
		}
	
		if(!InitDevice(false))
		{
			DebugString("Panard Vision DirectX driver : unable to init 3D device\n");
			return NO_ACCELSUPPORT;
		}
	}
						
	if(soft)
	{		
		DebugString("Panard Vision DirectX driver : WARNING : Running with Direct3D sofware emulation !!!\n");
		DebugString("Panard Vision DirectX driver : The modes/options you selected are not supported by hardware\n");		
	}	
	else DebugString("Panard Vision DirectX driver : Using hardware acceleration\n");
	
	// Creates the Viewport
	hr=lpD3D2->CreateViewport(&lpViewport2,NULL);
	if(hr!=DD_OK)
	{
		DebugString("Panard Vision DirectX driver : failed to get viewport\n");
		DebugString("Error code 0x%x\n",hr);
		D3DEndSupport();
		return NO_ACCELSUPPORT;
	}
	
	lpD3DDEV2->AddViewport(lpViewport2);
	lpD3DDEV2->SetCurrentViewport(lpViewport2);
	memset(&viewport,0,sizeof(D3DVIEWPORT2));	
	viewport.dwSize=sizeof(D3DVIEWPORT2);
	
	// Sets up viewport (full screen)
    memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT;
	lpDDS->GetSurfaceDesc(&ddsd);

	viewport.dwX=0;
	viewport.dwY=0;
	viewport.dwWidth=0;
	viewport.dwHeight=0;
	viewport.dvClipX=0;
	viewport.dvClipY=0;
	viewport.dvClipWidth=ddsd.dwWidth;
	viewport.dvClipHeight=ddsd.dwHeight;
	viewport.dvMinZ = 0.0f;
	viewport.dvMaxZ = 1.0f;	
	lpViewport2->SetViewport2(&viewport);
	
	// Sets the rendering state 
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SUBPIXELX,TRUE);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SUBPIXEL,TRUE);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_DITHERENABLE,TRUE);      // nice with some harware, ugly otherwise
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SPECULARENABLE,FALSE);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_CULLMODE,D3DCULL_NONE);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREPERSPECTIVE,TRUE);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZENABLE,FALSE);
	lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);
	
	// Clear front buffer
	D3DFillSurface(1,0,0,0,0);
	
	// Check to see if we run in full screen or windowed mode
	lpClipper=NULL;	
	lpDDSPrimary->GetClipper(&lpClipper);	

	// Check for render in a window caps
	if(lpClipper!=NULL)
	{
		ddcaps.dwSize=sizeof(ddcaps);
		lpDD->GetCaps(&ddcaps,NULL);
		if(!(ddcaps.dwCaps2&DDCAPS2_CANRENDERWINDOWED))
		{
			DebugString("Panard Vision DirectX driver : No hardware support in a window. Try FullScreen\n",hr);
			MessageBox(NULL,"Your hardware is unable to render accelerated 3D graphics in a window ! If you have multimonitors, then your primary device doesn't support windowed rendering\nSwitch to full screen mode.","WARNING",0); 			
			D3DEndSupport();
			return NO_ACCELSUPPORT;	

		}
	}
	
	// Init PV's Caps
	if(lpZBuffer!=NULL) 
	{
		D3DCaps.GeneralCaps|=PHG_ZBUFFER;
		D3DCaps.FrameCaps|=PHF_DEPTHBUFFER;
	}
	if(HalCaps.dpcTriCaps.dwAlphaCmpCaps!=0) D3DCaps.GeneralCaps|=PHG_ALPHATEST;
	
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_LINEAR) D3DCaps.TextureCaps|=PHT_BILINEAR;
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_MIPNEAREST ) D3DCaps.TextureCaps|=PHT_MIPMAP;
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_LINEARMIPLINEAR) D3DCaps.TextureCaps|=PHT_TRILINEAR;
	
	if(HalCaps.dpcTriCaps.dwSrcBlendCaps!=0) D3DCaps.BlendCaps|=PHB_SRCRGBBLEND;
	if(HalCaps.dpcTriCaps.dwDestBlendCaps!=0) D3DCaps.BlendCaps|=PHB_DSTRGBBLEND;
	
	// if no alpha is present enable stippling just in case of, who said ugly ???	
	if(!(D3DCaps.BlendCaps&(PHB_SRCRGBBLEND|PHB_DSTRGBBLEND))) 
	{	
		DebugString("Panard Vision DirectX Driver : WARNING : Enabling stippling\n");
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_STIPPLEDALPHA,TRUE);
	}
	
	switch(HalCaps.dwDeviceZBufferBitDepth)
	{
	case DDBD_8:D3DCaps.BitsPerDepth=8;break;
	case DDBD_16:D3DCaps.BitsPerDepth=16;break;
	case DDBD_24:D3DCaps.BitsPerDepth=24;break;
	case DDBD_32:D3DCaps.BitsPerDepth=32;break;
	}
	
	InitSurfaceCaps(lpDDS);

	// Pipeline control
	PV_SetPipelineControl(PVP_NO_TRIANGULATE);

	// Some tests
	if(HalCaps.dpcTriCaps.dwTextureCaps&D3DPTEXTURECAPS_SQUAREONLY) DebugString("PVDX: WARNING: Device only supports square textures, problems are coming !!!\n");

	// Fog Testing
	D3DHint("PV_FOG_TABLE",0);
	
	return COOL;
}

static void PVAPI D3DEndSupport(void)
{
	// The magic is done	
	if(lpDDS!=NULL) lpDDS->Release();
	if(lpDDSPrimary!=NULL) lpDDSPrimary->Release();
	if(lpClipper!=NULL) lpClipper->Release();
	if(lpZBuffer!=NULL) lpZBuffer->Release();
	if(lpDDPalette!=NULL) lpDDPalette->Release();
	if(lpViewport2!=NULL) lpViewport2->Release();
	if(lpD3DDEV2!=NULL) lpD3DDEV2->Release();
	if(lpD3D2!=NULL) lpD3D2->Release();
	if(lpDD2!=NULL) lpDD2->Release();
	if(lpDD!=NULL) lpDD->Release();
	lpDD=NULL;
	lpDDS=NULL;
	lpDDSPrimary=NULL;
	lpClipper=NULL;
	lpZBuffer=NULL;
	lpDD2=NULL;
	lpD3D2=NULL;
	
	DebugString("Panard Vision DX Driver : Ending\n");
}

static int PVAPI D3DSetViewPort(unsigned int cmx,unsigned int cMx,unsigned int cmy,unsigned int cMy)
{
	if(lpViewport2==NULL) return COOL;   // Sanity check for out of order function call in the client
	
	// Set up viewport for direct rasterization (no transformation by d3d)
	viewport.dwX=cmx;
	viewport.dwY=cmy;
	viewport.dwWidth=cMx-cmx;
	viewport.dwHeight=cMy-cmy;
	lpViewport2->SetViewport2(&viewport);
	
	return COOL;
}

static int PVAPI D3DLoadTexture(PVMaterial *m)
{
	HRESULT hr;
    static DDSURFACEDESC       ddsd;
	LPDIRECTDRAWSURFACE surf=NULL,FirstSurf=NULL,FirstSurf2=NULL,LastSurf=NULL,surf2;
	UPVD16 *tex16,r,g,b,a;
	UPVD32 c,*tex32;
	UPVD8 *tex8,t;
	unsigned i,j,k,TotMips;
	LPDIRECT3DTEXTURE2 lpTex2,lpTex2b;
	
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return COOL;
	
    DebugString("Downloading %s\n",m->Name);
	
	// Gosh, dx surafce caps is a hell to manage correctly	   
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_MIPNEAREST) TotMips=(m->NbrMipMaps==0?1:m->NbrMipMaps);
	else TotMips=1;
	
	DebugString("Downloading nbrmips %u\n",TotMips);

	// Choose texture type
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	
	if(m->TextureFlags&TEXTURE_RGBA)
	{
		ChooseAlphaTextureFormat(lpD3DDEV2, &ddsd.ddpfPixelFormat);
	}
	else
	{
		if(m->Hint.Quality&PHQ_HIGH) ChooseTextureFormat(lpD3DDEV2, 24, &ddsd.ddpfPixelFormat);
		else
			if(m->Hint.Quality&PHQ_LOW) ChooseTextureFormat(lpD3DDEV2, 8, &ddsd.ddpfPixelFormat);
			else
				ChooseTextureFormat(lpD3DDEV2, 16, &ddsd.ddpfPixelFormat);
	}

	// Try to create a a surface in system memory	
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT |DDSD_MIPMAPCOUNT ;
	ddsd.dwWidth = m->Tex[0].Width;
	ddsd.dwHeight = m->Tex[0].Height;
	ddsd.dwMipMapCount=TotMips;
	ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);
	ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE |DDSCAPS_SYSTEMMEMORY|DDSCAPS_MIPMAP|DDSCAPS_COMPLEX;

	// Check maximum texture size
	if((HalCaps.dwMaxTextureWidth<ddsd.dwWidth)||
	   (HalCaps.dwMaxTextureHeight<ddsd.dwHeight))
	{
		ddsd.dwWidth=HalCaps.dwMaxTextureWidth;
		ddsd.dwHeight=HalCaps.dwMaxTextureHeight;

		PVTexture *newtex;

		for(k=0;k<TotMips;k++)
		{
			DebugString("Resizing incoming %ux%u texture to %ux%u\n",m->Tex[k].Width,m->Tex[k].Height,ddsd.dwWidth>>k,ddsd.dwHeight>>k);
			newtex=PV_MipResample2(m->Tex[k].Texture,m->Tex[k].Width,m->Tex[k].Height, ddsd.dwWidth>>k,ddsd.dwHeight>>k,m->TextureFlags&TEXTURE_RGBDIRECT?TEXTURE_RGB:m->TextureFlags,NULL,0);
			if(newtex==NULL) return NO_MEMORY;

			if(!(m->TextureFlags&TEXTURE_TEX_DONT_FREE)) free(m->Tex[k].Texture);
			m->TextureFlags&=~TEXTURE_TEX_DONT_FREE;

			m->Tex[k].Height=newtex->Width;
			m->Tex[k].Width=newtex->Height;
			m->Tex[k].Texture=newtex->Texture;
		}
	}

	
	hr=lpDD2->CreateSurface(&ddsd,&surf,NULL);
	if(hr!=DD_OK)
	{			
		// failed					
		DebugString("Panard Vision Direct X Driver : Unable to get a proper surface\n");
		DebugString("Error code 0x%x\n",hr);
		return ACCEL_NO_MEMORY;
	}
	
	// Creates the same but for hardware		   		   
	if(!soft) 
	{
		ddsd.ddsCaps.dwCaps&=~DDSCAPS_SYSTEMMEMORY;
		ddsd.ddsCaps.dwCaps|=DDSCAPS_VIDEOMEMORY;
	}
	ddsd.ddsCaps.dwCaps|=DDSCAPS_ALLOCONLOAD;		

	hr=lpDD2->CreateSurface(&ddsd,&surf2,NULL);
	if(hr!=DD_OK)
	{			
		// failed
		DebugString("Panard Vision Direct X Driver : Unable to get a proper surface for hardware\n");
		DebugString("Error code 0x%x\n",hr);
		return ACCEL_NO_MEMORY;
	}
	surf->AddRef();
	FirstSurf2=surf;
	FirstSurf=surf2;

	// Checks that surface is in video mem for hardware
	// Not AGP friendly ?
	if(soft==FALSE)
	{
		FirstSurf->GetSurfaceDesc(&ddsd);
		if(!(ddsd.ddsCaps.dwCaps&DDSCAPS_VIDEOMEMORY))
		{
			DebugString("Panard Vision Direct X driver : not enough memory to download texture\n");
			return ACCEL_NO_MEMORY;
		}
	}
	
	for(k=0;k<TotMips;k++)
	{		   		   		
		ddsd.dwSize=sizeof(ddsd);
				
		// Now fills the surface with the texture				
		hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
		if(hr!=DD_OK) 
		{
			surf->Release();
			
			DebugString("Panard Vision Direct X Driver : Unable to lock surface\n");
			DebugString("Error code 0x%x\n",hr);			
			return ACCEL_NO_MEMORY;
		}
		
		// Init the filling process
		tex8=(UPVD8 *)ddsd.lpSurface;
		tex16=(UPVD16 *)ddsd.lpSurface;
		tex32=(UPVD32 *)ddsd.lpSurface;
		
		unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
		unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
		unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);
		unsigned NbrBitsAlpha=GetMaskSize(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);
		unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
		unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
		unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
		unsigned AlphaPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);

		unsigned Multiplier;

		if(m->TextureFlags&TEXTURE_RGBA) Multiplier=4; else Multiplier=3;
		
		for(i=0;i<m->Tex[k].Height;i++)
		{
			for(j=0;j<m->Tex[k].Width;j++)
			{				
				r=(UPVD8)m->Tex[k].Texture[Multiplier*(i*m->Tex[k].Width+j)];
				g=(UPVD8)m->Tex[k].Texture[Multiplier*(i*m->Tex[k].Width+j)+1];
				b=(UPVD8)m->Tex[k].Texture[Multiplier*(i*m->Tex[k].Width+j)+2];
				if(m->TextureFlags&TEXTURE_RGBA) a=(UPVD8)m->Tex[k].Texture[Multiplier*(i*m->Tex[k].Width+j)+3];

				r=(float)r*((1<<NbrBitsRed)-1)/255.0;
				g=(float)g*((1<<NbrBitsGreen)-1)/255.0;
				b=(float)b*((1<<NbrBitsBlue)-1)/255.0;
				a=(float)a*((1<<NbrBitsAlpha)-1)/255.0;
				
				c=(b<<BluePos);
				c|=(g<<GreenPos);
				c|=(r<<RedPos);
				c|=(a<<AlphaPos);				

				switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
				{
				case 8:
					*tex8=c;
					tex8++;
					break;
				case 16:
					*tex16=c;
					tex16++;
					break;
				case 24:
					*tex8=c;
					*(tex8+1)=(c>>8);
					*(tex8+2)=(c>>16);
					tex8+=3;
					break;
				case 32:
					*tex32=c;
					tex32++;
					break;
				default:
					DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
					D3DEndSupport();
					return BIZAR_ERROR;
				}

			}
			tex8+=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width;
			tex16+=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width/2;
			tex32+=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width/4;
		}
		surf->Unlock(NULL);
			
		// Manages Mipmaps
		DDSCAPS ddsCaps; 

		ddsCaps.dwCaps = DDSCAPS_TEXTURE | DDSCAPS_MIPMAP; 

		hr=surf->GetAttachedSurface(&ddsCaps, &LastSurf); 
		if((hr!=DD_OK)&&(hr!=DDERR_NOTFOUND))
		{
			// not possible
			DebugString("Panard Vision Direct X driver : Unable to step system mipmaps\n");
			return BIZAR_ERROR;
		}

		// Step
		surf->Release(); 
		surf = LastSurf; 	
	}
	   
	// Copy surface to hardware
	// Gets a texture interface for source texture
	hr=FirstSurf2->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
	if(hr!=DD_OK)
	{
		DebugString("Panard Vision Direct X driver : unable to obtain IID_IDIRECT3DTEXTURE2\n");
		DebugString("Error code 0x%x\n",hr);
		return BIZAR_ERROR;
	}
	
	// Gets a texture interface (who said silly ????)
	hr=FirstSurf->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2b);	
	if(hr!=DD_OK)
	{			
		DebugString("Panard Vision Direct X driver : unable to obtain IID_IDIRECT3DTEXTURE2 for hardware\n");
		DebugString("Error code 0x%x\n",hr);
		return BIZAR_ERROR;
	}
	
	// Load it to hardware
	hr=lpTex2b->Load(lpTex2);
	if(hr!=DD_OK)
	{
		DebugString("Panard Vision Direct X driver : unable to load hardware surface\n");
		DebugString("Error code 0x%x\n",hr);
		return BIZAR_ERROR;
	}

	// Hack hack
	if(m->Tex[0].Width*m->Tex[k].Height<4*3) m->Tex[0].Texture=(UPVD8*)malloc(4*3);
													
	// Save the texture handle
	hr=lpTex2b->GetHandle(lpD3DDEV2,(LPD3DTEXTUREHANDLE)&m->Tex[0].Texture[0]);
	if(hr!=DD_OK)
	{
		DebugString("Panard Vision Direct X driver : unable to obtain handle\n");
		DebugString("Error code 0x%x\n",hr);
		return BIZAR_ERROR;
	}

	lpTex2->Release();
	lpTex2b->Release();

	// Saves texture interface to destroy them or reload them			
	memcpy(&m->Tex[0].Texture[4],&FirstSurf2,sizeof(surf));
	memcpy(&m->Tex[0].Texture[8],&FirstSurf,sizeof(surf2));			
	
	// --------------------------------------------------- Now the 'Phong Texture'
	// Hey boys this an horrible D3D Hack. I was unable to figure out a clean and
	// portable way of creating a Luminance map (like in GL or Glide), so I create
	// a 16 bits texturing whith R=G=B=AlphaFromPhongTex
	// Memory consuming
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{			
		// Preprocess lightmap to be darker
		for(i=0;i<m->AuxiliaryTexture.Width;i++)
			for(j=0;j<m->AuxiliaryTexture.Height;j++)
			{
				m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]=max(0,m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]-1.3*(255-m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]));
			}
			
			// Try to create a 16 bits surface in system memory
			memset(&ddsd,0,sizeof(ddsd));
			ddsd.dwSize=sizeof(ddsd);
			ChooseTextureFormat(lpD3DDEV2, 16, &ddsd.ddpfPixelFormat);
			
			ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
			ddsd.dwWidth = m->AuxiliaryTexture.Width;
			ddsd.dwHeight = m->AuxiliaryTexture.Height;	   		   
			ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE |DDSCAPS_SYSTEMMEMORY;
			ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);
			hr=lpDD2->CreateSurface(&ddsd,&surf,NULL);
			if(hr!=DD_OK)
			{			
				// failed					
				DebugString("Panard Vision Direct X Driver : Unable to create a proper phong surface\n");
				DebugString("Error code 0x%x\n",hr);
				return ACCEL_NO_MEMORY;
			}
			
			// Creates the same but for hardware		   		   
			ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE | DDSCAPS_ALLOCONLOAD;
			
			if(!soft) ddsd.ddsCaps.dwCaps|=DDSCAPS_VIDEOMEMORY;
			else ddsd.ddsCaps.dwCaps|=DDSCAPS_SYSTEMMEMORY;

			hr=lpDD2->CreateSurface(&ddsd,&surf2,NULL);
			if(hr!=DD_OK)
			{			
				// failed
				DebugString("Panard Vision Direct X Driver : Unable to get a proper phong surface for hardware\n");
				DebugString("Error code 0x%x\n",hr);
				return ACCEL_NO_MEMORY;
			}
			
			// Now fills the surface with the texture
			ddsd.dwSize=sizeof(ddsd);
			
			hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
			if(hr!=DD_OK) 
			{
				surf->Release();
				
				DebugString("Panard Vision Direct X Driver : Unable to lock phong surface\n");
				DebugString("Error code 0x%x\n",hr);				
				return ACCEL_NO_MEMORY;
			}
			
			// Init the filling process
			tex8=(UPVD8 *)ddsd.lpSurface;
			tex16=(UPVD16 *)ddsd.lpSurface;
			tex32=(UPVD32 *)ddsd.lpSurface;
			
			unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);					
			unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
			
			for(i=0;i<m->AuxiliaryTexture.Height;i++)
			{
				for(j=0;j<m->AuxiliaryTexture.Width;j++)
				{
					t=m->AuxiliaryTexture.Texture[i*m->AuxiliaryTexture.Width+j];
					
					r=(float)t*((1<<NbrBitsRed)-1)/255.0;
					g=(float)t*((1<<NbrBitsGreen)-1)/255.0;
					b=(float)t*((1<<NbrBitsBlue)-1)/255.0;
					
					c=(b<<BluePos);
					c|=(g<<GreenPos);
					c|=(r<<RedPos);
					
					switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
					{
					case 8:
						*tex8=c;
						tex8++;
						break;
					case 16:
						*tex16=c;
						tex16++;
						break;
					case 24:
						*tex8=c;
						*(tex8+1)=(c>>8);
						*(tex8+2)=(c>>16);
						tex8+=3;
						break;
					case 32:
						*tex32=c;
						tex32++;
						break;
					default:
						DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
						D3DEndSupport();
						return BIZAR_ERROR;
					}
				}

				tex8+=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width;
				tex16+=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width/2;
				tex32+=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width/4;
			}
			surf->Unlock(NULL);
			
			// Copy surface to hardware
			// Gets a texture ibnterface for source texture
			hr=surf->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
			if(hr!=DD_OK)
			{
				DebugString("Panard Vision Direct X driver : unable to obtain IID_IDIRECT3DTEXTURE2 for hardware (phong)\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}
			
			// Gets a texture interface (who said silly ????)
			hr=surf2->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2b);	
			if(hr!=DD_OK)
			{
				DebugString("Panard Vision Direct X driver : unable to obtain IID_IDIRECT3DTEXTURE2 (phong)\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}
			
			// Load it to hardware
			hr=lpTex2b->Load(lpTex2);
			if(hr!=DD_OK)
			{
				DebugString("Panard Vision Direct X driver : unable to load hardware surface (phong)\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}
			
			// Save the texture handle
			hr=lpTex2b->GetHandle(lpD3DDEV2,(LPD3DTEXTUREHANDLE)&m->AuxiliaryTexture.Texture[0]);
			if(hr!=DD_OK)
			{
				DebugString("Panard Vision Direct X driver : unable to obtain handle (phong)\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}
			
			// Saves texture interface to destroy them or reload them
			memcpy(&m->AuxiliaryTexture.Texture[4],&surf,sizeof(surf));
			memcpy(&m->AuxiliaryTexture.Texture[8],&surf2,sizeof(surf2));
			lpTex2->Release();
			lpTex2b->Release();
			
			// Checks that surface is in video mem for hardware
			// Not AGP friendly ?
			if(soft==FALSE)
			{
				surf2->GetSurfaceDesc(&ddsd);
				if(!(ddsd.ddsCaps.dwCaps&DDSCAPS_VIDEOMEMORY))
				{
					DebugString("Panard Vision Direct X driver : not enough memory to download texture (phong)\n");
					DebugString("Error code 0x%x\n",hr);
					return ACCEL_NO_MEMORY;
				}
			}
	}
	
	return COOL;
}

static void PVAPI D3DDeleteTexture(PVMaterial *m)
{
	LPDIRECTDRAWSURFACE	surf;
	
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return;
		
	memcpy(&surf,&m->Tex[0].Texture[4],sizeof(surf));
	surf->Release();
	memcpy(&surf,&m->Tex[0].Texture[8],sizeof(surf));
	surf->Release();
	
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{
		memcpy(&surf,&m->AuxiliaryTexture.Texture[4],sizeof(surf));
		surf->Release();
		memcpy(&surf,&m->AuxiliaryTexture.Texture[8],sizeof(surf));
		surf->Release();
	}
}

//////////////////////////////////////////////////////////////////////////// LIGHTMAPS
#define MAXLIGHTMAPS	100000
#define LMAPW			256
#define LMAPH			256

static PVLightMap **LMaps=NULL;
static unsigned nbrlmaps=0,LMapComputed=0;
static LPDIRECTDRAWSURFACE LMSurf[100],LMSurfH[100];
static unsigned nbrsurflm=0;

static void RestoreLM(void)
{
	unsigned i;
	LPDIRECT3DTEXTURE2 lpTex2,lpTex2b;	

	for(i=0;i<nbrsurflm;i++)
	{
		if(LMSurf[i]->IsLost()) LMSurf[i]->Restore();
		if(LMSurfH[i]->IsLost()) LMSurfH[i]->Restore();

		LMSurf[i]->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
		LMSurfH[i]->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2b);
		
		// Load it to hardware
		lpTex2b->Load(lpTex2);
		
		lpTex2->Release();
		lpTex2b->Release();							
	}
}

static int PVAPI D3DLoadLightMap(PVLightMap *m)
{
	if(LMapComputed) return COOL;
	if(m->Flags&LIGHTMAP_PROCESSED) return COOL;
	
	// On alloue le tablo pseudo statique
	if(LMaps==NULL)
	{
		LMaps=(PVLightMap**)calloc(MAXLIGHTMAPS,sizeof(PVLightMap*));
		if(LMaps==NULL) return NO_MEMORY;
		nbrlmaps=0;
	}
	
	LMaps[nbrlmaps++]=m;
	m->Flags|=LIGHTMAP_PROCESSED;
	
    return COOL;
}

static int __cdecl LMCompare( const void *arg1, const void *arg2 )
{
	PVLightMap *m1,*m2;
	
	m1=*(PVLightMap**)arg1;
	m2=*(PVLightMap**)arg2;
	
	if(m1->Height==m2->Height)
	{
		if(m1->Width>m2->Width) return -1;
		else return 1;
	}

	if(m1->Height<m2->Height) return 1;
	else return -1;
}

static int DownloadLightMaps(void)
{
	HRESULT hr;
	LPDIRECTDRAWSURFACE surf=NULL,surf2;    
	static DDSURFACEDESC       ddsd;		
	unsigned CurrentW=0,CurrentH=0,MaxH=0;
	
	UPVD16 *tex16,r,g,b,a;
	UPVD32 c,*tex32;
	UPVD8 *tex8;
	unsigned i,j,k;
	LPDIRECT3DTEXTURE2 lpTex2,lpTex2b;
	PVLightMap *m;
	
	if(nbrlmaps==0) return COOL;
	
	DebugString("Processing %u lightmaps ...\n",nbrlmaps);
	
	// Sort lightmaps
	qsort( (void*)LMaps, nbrlmaps, sizeof( PVLightMap * ), LMCompare );	
	
	ddsd.dwSize=sizeof(ddsd);
	ChooseTextureFormat(lpD3DDEV2, 16, &ddsd.ddpfPixelFormat);
	
	CurrentW=CurrentH=MaxH=0;
	LMapComputed=1;
	
	for(k=0;k<nbrlmaps;k++)
	{
		m=LMaps[k];
		
		for(int z=0;z<m->NbrLightMaps;z++)
		{
			if((CurrentW==0)&&(CurrentH==0))
			{
				// Try to create a a surface in system memory
				ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
				ddsd.dwWidth = LMAPW;
				ddsd.dwHeight = LMAPH;	   		   
				ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE |DDSCAPS_SYSTEMMEMORY;
				ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);

				hr=lpDD2->CreateSurface(&ddsd,&surf,NULL);
				if(hr!=DD_OK)
				{			
					// failed					
					DebugString("Panard Vision Direct X Driver : (Lightmap) Unable to get a proper surface\n");
					DebugString("Error code 0x%x\n",hr);
					return ACCEL_NO_MEMORY;
				}
				LMSurf[nbrsurflm]=surf;
				
				// Creates the same but for hardware		   		   
				ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE | DDSCAPS_ALLOCONLOAD;
				
				if(!soft) ddsd.ddsCaps.dwCaps|=DDSCAPS_VIDEOMEMORY;
				else ddsd.ddsCaps.dwCaps|=DDSCAPS_SYSTEMMEMORY;

				hr=lpDD2->CreateSurface(&ddsd,&surf2,NULL);
				if(hr!=DD_OK)
				{			
					// failed
					DebugString("Panard Vision Direct X Driver : (Lightmap) Unable to get a proper surface for hardware\n");
					DebugString("Error code 0x%x\n",hr);
					return ACCEL_NO_MEMORY;
				}
				LMSurfH[nbrsurflm]=surf2;
				nbrsurflm++;
			}
			
			// Now fills the surface with the texture
			ddsd.dwSize=sizeof(ddsd);
			
			hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
			if(hr!=DD_OK) 
			{
				surf->Release();
				
				DebugString("Panard Vision Direct X Driver : (Lightmap) Unable to lock surface\n");
				DebugString("Error code 0x%x\n",hr);			
				return ACCEL_NO_MEMORY;
			}
			
			// Init the filling process
			tex8=(UPVD8 *)ddsd.lpSurface;
			tex16=(UPVD16 *)ddsd.lpSurface;
			tex32=(UPVD32 *)ddsd.lpSurface;
			
			// Decal
			if((CurrentW+m->Width<LMAPW)&&(CurrentH+m->Height<LMAPH))
			{
				tex8+=CurrentH*LMAPW+CurrentW;
				tex16+=CurrentH*LMAPW+CurrentW;
				tex32+=CurrentH*LMAPW+CurrentW;			
				CurrentW+=m->Width;
				if(m->Height+CurrentH>MaxH) MaxH=m->Height+CurrentH;
			}
			else
			{
				// not enough room, try a lower band
				surf->Unlock(NULL);
				if(MaxH+m->Height<LMAPH)
				{
					CurrentH=MaxH;
					CurrentW=0;
					z--;
					continue;
				}
				else
				{					
					// Copy surface to hardware
					// Gets a texture ibnterface for source texture
					hr=surf->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
					if(hr!=DD_OK)
					{			
						DebugString("Panard Vision Direct X driver : (LightMap) unable to obtain IID_IDIRECT3DTEXTURE2\n");
						return BIZAR_ERROR;
					}

					// Gets a texture interface (who said silly ????)
					hr=surf2->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2b);	
					if(hr!=DD_OK)
					{			
						DebugString("Panard Vision Direct X driver : (LightMap) unable to obtain IID_IDIRECT3DTEXTURE2 for hardware\n");
						DebugString("Error code 0x%x\n",hr);
						return BIZAR_ERROR;
					}

					// Load it to hardware
					hr=lpTex2b->Load(lpTex2);
					if(hr!=DD_OK)
					{
						DebugString("Panard Vision Direct X driver : (LightMap) unable to load hardware surface\n");
						DebugString("Error code 0x%x\n",hr);
						return BIZAR_ERROR;
					}
					lpTex2->Release();
					lpTex2b->Release();
	
					CurrentW=CurrentH=MaxH=0;
					z--;
					continue;
				}
			}		
			
			unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);
			unsigned NbrBitsAlpha=GetMaskSize(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);
			unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
			unsigned AlphaPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);
			
			for(i=0;i<m->Height;i++)
			{
				for(j=0;j<m->Width;j++)
				{				
					if(m->Flags&LIGHTMAP_RGB)
					{
						r=(UPVD8)m->Maps[z][3*(i*m->Width+j)];
						g=(UPVD8)m->Maps[z][3*(i*m->Width+j)+1];
						b=(UPVD8)m->Maps[z][3*(i*m->Width+j)+2];
						a=255;
					}
					else
					{
						r=g=b=(UPVD8)m->Maps[z][(i*m->Width+j)];
						a=255;
					}
					
					
					r=(float)r*(float)((1<<NbrBitsRed)-1)/255.0;
					g=(float)g*(float)((1<<NbrBitsGreen)-1)/255.0;
					b=(float)b*(float)((1<<NbrBitsBlue)-1)/255.0;
					a=(float)a*(float)((1<<NbrBitsAlpha)-1)/255.0;
					
					c=(b<<BluePos);
					c|=(g<<GreenPos);
					c|=(r<<RedPos);
					c|=(a<<AlphaPos);
					
					switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
					{
					case 8:
						*tex8=c;
						tex8++;
						break;
					case 16:
						*tex16=c;
						tex16++;
						break;
					case 24:
						*tex8=c;
						*(tex8+1)=(c>>8);
						*(tex8+2)=(c>>16);
						tex8+=3;
						break;
					case 32:
						*tex32=c;
						tex32++;
						break;
					default:
						DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
						D3DEndSupport();
						return BIZAR_ERROR;
					}
				}
				
				tex8+=LMAPW-m->Width;
				tex16+=LMAPW-m->Width;
				tex32+=LMAPW-m->Width;			

				tex8+=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW;
				tex16+=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW/2;
				tex32+=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW/4;
	
			}
			surf->Unlock(NULL);
						
			// Gets a texture ibnterface for source texture			
			hr=surf2->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2b);	
			if(hr!=DD_OK)
			{			
				DebugString("Panard Vision Direct X driver : (LightMap) unable to obtain IID_IDIRECT3DTEXTURE2 for hardware\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}

			// Hack hack
			UPVD8 *h;
			h=(UPVD8*)malloc(4*4);
			memcpy(&h[12],&m->Maps[z],4);
			m->Maps[z]=h;
			
			// Save the texture handle
			hr=lpTex2b->GetHandle(lpD3DDEV2,(LPD3DTEXTUREHANDLE)&m->Maps[z][0]);
			if(hr!=DD_OK)
			{
				DebugString("Panard Vision Direct X driver : (Lightmap) unable to obtain handle\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}
			
			// Saves texture interface to destroy them or reload them
			memcpy(&m->Maps[z][4],&surf,sizeof(surf));
			memcpy(&m->Maps[z][8],&surf2,sizeof(surf2));			
			lpTex2b->Release();
			
			// Checks that surface is in video mem for hardware	   	   
			if(soft==FALSE)
			{
				surf2->GetSurfaceDesc(&ddsd);
				if(!(ddsd.ddsCaps.dwCaps&DDSCAPS_VIDEOMEMORY))
				{
					DebugString("Panard Vision Direct X driver : not enough memory to download lightmap\n");
					DebugString("Error code 0x%x\n",hr);
					return ACCEL_NO_MEMORY;
				}
			}

			// Fixup ccord		
			m->su[z]*=(float)m->Width/(float)LMAPW;
			m->sv[z]*=(float)m->Height/(float)LMAPH;
			
			m->su[z]+=(float)(CurrentW-m->Width)/(float)LMAPW;
			m->sv[z]+=(float)(CurrentH)/(float)LMAPH;	
		}
				
		// Setup lightmaps scaling
		m->ScaleU*=(float)m->Width/(float)LMAPW;
		m->ScaleV*=(float)m->Height/(float)LMAPH;
		m->ScaleU*=(1.0/(float)(m->MaxU-m->MinU));
		m->ScaleV*=(1.0/(float)(m->MaxV-m->MinV));
	}

	
	// Copy surface to hardware
	// Gets a texture ibnterface for source texture
	hr=surf->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
	if(hr!=DD_OK)
	{			
		DebugString("Panard Vision Direct X driver : (LightMap) unable to obtain IID_IDIRECT3DTEXTURE2\n");
		return BIZAR_ERROR;
	}
	
	// Gets a texture interface (who said silly ????)
	hr=surf2->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2b);	
	if(hr!=DD_OK)
	{			
		DebugString("Panard Vision Direct X driver : (LightMap) unable to obtain IID_IDIRECT3DTEXTURE2 for hardware\n");
		DebugString("Error code 0x%x\n",hr);
		return BIZAR_ERROR;
	}
	
	// Load it to hardware
	hr=lpTex2b->Load(lpTex2);
	if(hr!=DD_OK)
	{
		DebugString("Panard Vision Direct X driver : (LightMap) unable to load hardware surface\n");
		DebugString("Error code 0x%x\n",hr);
		return BIZAR_ERROR;
	}
	lpTex2->Release();
	lpTex2b->Release();
				
	return COOL;
}

static void PVAPI D3DDeleteLightMap(PVLightMap *m)
{
	unsigned k,TotMips;
	
	if(!(m->Flags&LIGHTMAP_PROCESSED)) return;
	if(m==NULL) return;
	
	nbrlmaps--;
	if(nbrlmaps==0)
	{
		DebugString("Freeing lightmaps...\n");
		for(k=0;k<nbrsurflm;k++)
		{
			LMSurf[k]->Release();
			LMSurfH[k]->Release();
		}
		nbrsurflm=0;
	}
	
	TotMips=m->NbrLightMaps;	
	for(k=0;k<TotMips;k++)
	{
	  if(m->Maps[k]==NULL) break;
	  
	  UPVD8 *h;
	  h=m->Maps[k];
	  memcpy(&m->Maps[k],&m->Maps[k][12],4);
      free(h);		
	}
	REMOVEFLAG(m->Flags,LIGHTMAP_PROCESSED);
}

////////////////////////////////////////////////////////////////////////////////////////////

static void *PVAPI D3DGetFiller(PVFLAGS flags)
{
    if(flags&MULTITEXTURE)
	{
		flags&=~MULTITEXTURE;
		flags|=MAPPING;
	}

	flags&=~PERSPECTIVE;

	switch (flags&(RENDER_MASK|SHADE_MASK))
	{
	case FLAT|NOTHING:return TriD3DFlat;break;
	case GOURAUD|NOTHING:return TriD3DGouraud;break;
		
	case U_PHONG|NOTHING:
	case PHONG|NOTHING:
	case NOTHING|AMBIENT_MAPPING:
	case NOTHING|MAPPING:return TriD3DMapping;break;
		
	case FLAT|AMBIENT_MAPPING:
	case FLAT|MAPPING:return TriD3DFlatMapping;break;
		
	case GOURAUD|AMBIENT_MAPPING:
	case GOURAUD|MAPPING:return TriD3DGouraudMapping;break;
		
		// Bump is treated as Phong
	case U_BUMP|AMBIENT_MAPPING:
	case U_BUMP|MAPPING:
	case BUMP|AMBIENT_MAPPING:
	case BUMP|MAPPING:
		
	case U_PHONG|AMBIENT_MAPPING:
	case U_PHONG|MAPPING:				
	case PHONG|AMBIENT_MAPPING:
	case PHONG|MAPPING:return TriD3DBiMapping;break;
		
	case LIGHTMAP|MAPPING:
		return TriD3DLightMap;break;
		
	default:return NULL;
	}
}

static void PVAPI D3DBeginFrame(PVFLAGS PVMode,PVFLAGS PVPipe)
{
	D3DRECT rect;
	
	// Sync hardware
	if(lpClipper!=NULL)
		while(lpDDS->GetBltStatus(DDGBS_ISBLTDONE)==DDERR_WASSTILLDRAWING);
	while(lpDDS->GetFlipStatus(DDGFS_ISFLIPDONE)==DDERR_WASSTILLDRAWING);
	
	// Generates lightmaps
	if(LMapComputed==0)
	{		
		int hr=DownloadLightMaps();
		if(hr!=COOL) return;
	}
	
	// Clear ZBuffer
	if((!(PVPipe&PVP_NO_ZBUFFERCLEAR))&&(PVMode&PVM_ZBUFFER))
	{
		rect.x1=viewport.dwX;
		rect.y1=viewport.dwY;
		rect.x2=viewport.dwX+viewport.dwWidth;
		rect.y2=viewport.dwY+viewport.dwHeight;
		lpViewport2->Clear(1, &rect,D3DCLEAR_ZBUFFER); 
	}

	lpD3DDEV2->BeginScene();

	lastm=NULL;
}

static int PVAPI D3DPreRender(PVWorld *w,unsigned surfacenum,PVFLAGS PVMode,PVFLAGS PVPipe)
{		
	RestoreAllSurfaces(w->Materials);
	AmbientLight=&w->AmbientLight;	
	PVM=PVMode;
	fp=w->Camera->FrontDist;
	bp=w->Camera->BackDist;	
	depthval=(bp/(bp-fp));
	depthval2=(bp*fp)/(bp-fp);

	// Set projection matrix, for WFog, and WBuffer
	D3DMATRIX mat;

	D3DUtil_SetProjectionMatrix(mat,w->Camera->yscreenscale,w->Camera->fieldofview,fp,bp);
	lpD3DDEV2->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&mat);
    
    // Fog support
	if(w->Fog.Type!=PVF_NONE)
	{	
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);
        lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGCOLOR,D3DRGB(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b));
		FogEnabled=true;

		if(FogTable)
		{
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLESTART,*( LONG* ) &w->Fog.Start);
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLEEND,*( LONG* ) &w->Fog.End);
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLEDENSITY,*( LONG* ) &w->Fog.Density);		
				
			switch(w->Fog.Type)
			{
			case PVF_LINEAR:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_LINEAR);break;
			case PVF_EXP:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_EXP);break;
			case PVF_EXP2:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_EXP2);break;
			default:
				PV_Fatal("DX Driver: Unknown fog mode !",w->Fog.Type);
			}
			OverrideLighting=FALSE;
		}
		else
		{
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_NONE);		
			//OverrideLighting=TRUE;
			OverrideLighting=FALSE;		// Bug TNT & pb voodoo
		}
	}
	else
	{
        if(PVMode&PVM_VERTEXFOGGING)
        {
            lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);
            lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_NONE);		
		    lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGCOLOR,D3DRGB(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b));
			//OverrideLighting=TRUE;
			OverrideLighting=FALSE;		// Bug TNT & pb voodoo
			FogEnabled=true;
        }
        else
		{
            lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGENABLE,FALSE);
			OverrideLighting=FALSE;
			FogEnabled=false;
		}
	}
	
	return COOL;
}

static void PVAPI D3DPrepareFace(PVFace *f)
{
	static int Alphaf[]={D3DBLEND_ZERO,D3DBLEND_ONE,D3DBLEND_DESTCOLOR,D3DBLEND_INVDESTCOLOR,D3DBLEND_SRCALPHA,D3DBLEND_INVSRCALPHA,D3DBLEND_DESTALPHA,D3DBLEND_INVDESTALPHA,D3DBLEND_SRCALPHASAT,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR};

	if(oldpvf==PVM)
        if(lastm==f->MaterialInfo) return;	

	// Sets for wireframe
	if(f->MaterialInfo->Type&WIREFRAME)
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FILLMODE,D3DFILL_WIREFRAME);
	else
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FILLMODE,D3DFILL_SOLID);
	
	// Sets for zbuffer
	if((PVM&PVM_ZBUFFER)&&(f->MaterialInfo->Type&ZBUFFER))
	{
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZENABLE,TRUE);
		if(f->MaterialInfo->ZWrite) 
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,TRUE);
		else
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);
		
		switch(f->MaterialInfo->DepthTest)
		{
		case CMP_LESS:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_ALWAYS);break;
		}
	}
	else 
	{
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZENABLE,FALSE);
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);
	}
	
	// Sets for AlphaBlending
	if(PVM&PVM_ALPHABLENDING)
	{
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SRCBLEND,Alphaf[f->MaterialInfo->BlendRgbSrcFactor]);
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_DESTBLEND,Alphaf[f->MaterialInfo->BlendRgbDstFactor]);
	}
	else lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,FALSE);
	
	// Sets for Alpha testing
	if(PVM&PVM_ALPHATESTING)
	{
		switch(f->MaterialInfo->AlphaTest)
		{
		case CMP_LESS:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_ALWAYS);break;
		}
		
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHAREF,(unsigned)(((float)f->MaterialInfo->AlphaReference)/**255.0*/*65535.0)); //16.16 fixed
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHATESTENABLE,TRUE);
	}
	else lpD3DDEV2->SetRenderState(D3DRENDERSTATE_ALPHATESTENABLE,FALSE);
	
	// The following is for textured faces only	
	if(f->MaterialInfo->Type&(MAPPED_MATERIAL))
	{
		// Sets texture blending mode
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMAPBLEND,D3DTBLEND_MODULATEALPHA);
		
		// Sets wrapping modes
		switch(f->MaterialInfo->RepeatU)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSU,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSU,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSU,D3DTADDRESS_WRAP);break;
		}
		
		switch(f->MaterialInfo->RepeatV)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSV,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSV,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSV,D3DTADDRESS_WRAP);break;
		}
		
		// Sets up filtering
		if((f->MaterialInfo->TextureFlags&TEXTURE_BILINEAR)||(f->MaterialInfo->TextureFlags&TEXTURE_TRILINEAR))
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMAG,D3DFILTER_LINEAR);
		else
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMAG,D3DFILTER_NEAREST);
		
		// Sets for mipmap&trilinear
		if(f->MaterialInfo->TextureFlags&TEXTURE_TRILINEAR) lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_LINEARMIPLINEAR);
		else
			if(f->MaterialInfo->TextureFlags&TEXTURE_MIPMAP) 
			{
				if(f->MaterialInfo->TextureFlags&TEXTURE_BILINEAR) lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_MIPLINEAR);
				else lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_MIPNEAREST);
			}
			else
			{
				if(f->MaterialInfo->TextureFlags&TEXTURE_BILINEAR) lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_LINEAR);
				else lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_NEAREST);
			}				
	}
	else 
	{
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREMAPBLEND,D3DTBLEND_DECAL);
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_TEXTUREHANDLE,NULL);
		lastmip=-1;
	}

	// Fog Powah!
	if((!(f->MaterialInfo->Type&FOGABLE))||(!FogEnabled))
	{
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGENABLE,FALSE);
		
		// Shading mode
		if(f->MaterialInfo->Type&GOURAUD)
		{
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_GOURAUD);
		}
		else
		{
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_FLAT);		
		}
	}
	else
	{
		lpD3DDEV2->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);

		// Shading mode
		if((f->MaterialInfo->Type&GOURAUD)||(OverrideLighting))
		{
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_GOURAUD);
		}
		else
		{
			lpD3DDEV2->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_FLAT);		
		}
	}
		
	lastm=f->MaterialInfo;
    oldpvf=PVM;
}

static void PVAPI D3DPostRender(void)
{
}

static void PVAPI D3DEndFrame(void)
{
	if(lpD3DDEV2!=NULL)
		lpD3DDEV2->EndScene();	
}

static int PVAPI D3DFlipSurface(void)
{
	if(lpClipper!=NULL)
	{
		RECT srcr,dstr;
		POINT pt;
		HWND win;
		
		lpClipper->GetHWnd(&win);
		GetClientRect(win,&srcr);
		pt.x=pt.y=0;
		ClientToScreen(win,&pt);
		dstr=srcr;
		dstr.left+=pt.x;
		dstr.right+=pt.x;
		dstr.top+=pt.y;
		dstr.bottom+=pt.y;
		lpDDSPrimary->Blt(&dstr,lpDDS,&srcr,DDBLT_ASYNC,0);
	}
	else lpDDSPrimary->Flip(NULL,0);
	
	return COOL;
}

static int PVAPI D3DFillSurface(unsigned surfacenum,float r,float g,float b,float a)
{
	DDBLTFX ddbltfx;	
	LPDIRECTDRAWSURFACE surf;
	DDPIXELFORMAT  ddpf;
	unsigned rs,gs,bs,rp,gp,bp,as,ap,rf,gf,bf,af;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}	

	if(surf==NULL) return COOL;
	
	// Looking for the correct color mask
	ddpf.dwSize=sizeof(ddpf);
	surf->GetPixelFormat(&ddpf);
	rs=GetMaskSize(ddpf.dwRBitMask);
	gs=GetMaskSize(ddpf.dwGBitMask);
	bs=GetMaskSize(ddpf.dwBBitMask);
	as=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	rp=GetMaskPos(ddpf.dwRBitMask);
	gp=GetMaskPos(ddpf.dwGBitMask);
	bp=GetMaskPos(ddpf.dwBBitMask);
	ap=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	
	// Compute colors
	rf=r*(float)((1<<rs)-1);
	rf<<=rp;
	bf=b*(float)((1<<bs)-1);
	bf<<=bp;
	gf=g*(float)((1<<gs)-1);
	gf<<=gp;
	af=a*(float)((1<<as)-1);
	af<<=ap;
	
	memset(&ddbltfx,0,sizeof(ddbltfx));
	ddbltfx.dwSize=sizeof(ddbltfx);
	ddbltfx.dwFillColor=rf|gf|bf|af;
	
	// Sync hardware
	while(surf->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);

	if(surf->Blt(NULL,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx)!=DD_OK) return BIZAR_ERROR;
	return COOL;
}

static void PVAPI D3DRefreshMaterial(PVMaterial *)
{
	// Direct3D driver don't need this function because the material state is set each time a render is made
	lastm=NULL;
}

extern PVHardwareCaps D3DCaps;
static PVHardwareCaps * PVAPI D3DGetInfo(void)
{
	return &D3DCaps;
}

static void * PVAPI D3DLockFB(unsigned surfacenum,PVFLAGS mode)
{
	LPDIRECTDRAWSURFACE surf;
	DDSURFACEDESC       ddsd;
	unsigned flags;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}
	
	switch(mode)
	{
	case PFB_READONLY:flags=DDLOCK_READONLY;break;
	case PFB_WRITEONLY:flags=DDLOCK_WRITEONLY;break;
	default:return NULL;
	}
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	surf->Lock(NULL,NULL,DDLOCK_SURFACEMEMORYPTR|DDLOCK_WAIT|flags,NULL);
	
	D3DCaps.RowStride=ddsd.lPitch;
	
	return ddsd.lpSurface;
}

static void PVAPI D3DUnLockFB(unsigned surfacenum,PVFLAGS mode)
{
	LPDIRECTDRAWSURFACE surf;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}
	
	surf->Unlock(NULL);
}

static void * PVAPI D3DLockDB(PVFLAGS mode)
{
	unsigned flags;
	DDSURFACEDESC       ddsd;
	
	if(lpZBuffer==NULL) return NULL;
	
	switch(mode)
	{
	case PFB_READONLY:flags=DDLOCK_READONLY;break;
	case PFB_WRITEONLY:flags=DDLOCK_WRITEONLY;break;
	default:return NULL;
	}
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	lpZBuffer->Lock(NULL,NULL,DDLOCK_SURFACEMEMORYPTR|DDLOCK_WAIT|flags,NULL);
	
	D3DCaps.RowStride=ddsd.lPitch;
	
	return ddsd.lpSurface;
}

static void PVAPI D3DUnLockDB(PVFLAGS mode)
{
	if(lpZBuffer==NULL) return;
	
	lpZBuffer->Unlock(NULL);
}

static void PVAPI D3DHint(char *hint,UPVD32 val)
{
	if(strcmp(hint,"PV_FOG_TABLE")==0)
	{
		if(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_FOGTABLE)
		{
			SetFogTable(val);
		}
		else SetFogTable(0);
	}
}

///////////////////////////////////////////////////////////////////////////////
static PVHardwareCaps D3DCapsOrg={
	0,
		PHF_FRAMEBUFFER,
		0,
		0,
		PHD_DEPTHPROP,	
		0,0,0,0,
		0,0,0,0,
		0,
		-1,-1,
		0,
		16,
		0
};

static PVHardwareCaps D3DCaps;

PVEXPORT PVHardwareDriver PVDriver={
	1,
		PV_MN2,
		sizeof(PVHardwareCaps),
		"Panard Vision DirectX5 Generic Driver V1.19a",
		D3DDetect,
		D3DInitSupport,
		D3DEndSupport,
		D3DSetViewPort,
		D3DLoadTexture,
		D3DDeleteTexture,
		D3DGetFiller,
		D3DPreRender,
		D3DPrepareFace,
		D3DPostRender,
		D3DBeginFrame,
		D3DEndFrame,
		D3DFlipSurface,
		D3DFillSurface,
		D3DRefreshMaterial,
		D3DGetInfo,
		D3DLockFB,
		D3DUnLockFB,
		D3DLockDB,
		D3DUnLockDB,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		D3DLoadLightMap,
		D3DDeleteLightMap,
		NULL,
		NULL,
		D3DHint,
};

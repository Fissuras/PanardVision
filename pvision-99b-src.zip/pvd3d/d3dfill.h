/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Direct3D v5 Driver for the Panard Vision 3D Engine
// (C) 1997-98, Olivier Brunet

// Before using this library consult the LICENSE file

#ifndef __D3DFILL_H__
#define __D3DFILL_H__

#include "pvision.h"
#define DIRECT3D_VERSION		0x500
#include <d3d.h>

extern D3DDEVICEDESC	HalCaps;
extern LPDIRECT3DDEVICE2		lpD3DDEV2;
extern PVRGBF *AmbientLight;
extern float fp,bp,depthval,depthval2;
extern unsigned long lastmip;

void PVAPI TriD3DFlat(PVFace *f);
void PVAPI TriD3DGouraud(PVFace *f);
void PVAPI TriD3DMapping(PVFace *f);
void PVAPI TriD3DFlatMapping(PVFace *f);
void PVAPI TriD3DGouraudMapping(PVFace *f);
void PVAPI TriD3DBiMapping(PVFace *f);
void PVAPI TriD3DLightMap(PVFace *f);

#endif

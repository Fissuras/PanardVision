/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "attmgr.h"
#include "pcsys.h"

IMPLEMENT_POMIZED(pcParticlesSystem,"/domains/PanardConfettis/ParticlesSystems");

pcParticlesSystem::pcParticlesSystem()
{
    _Time=0;
    _Lock=0;
    _LastPartSize=0;
    _AttManager=new pcParticleAttributeManager;

    RegisterPFlag(PC_PF_STANDARD,"Standard particle",sizeof(pcsPartStandard));
    RegisterPFlag(PC_PF_NEWTONSYS,"Standard Newton parameters",sizeof(pcsPartNewton));
	RegisterPFlag(PC_PF_ARTISTIC,"Particules beautifuler parameters",sizeof(pcsPartArtistic));
}

pcParticlesSystem::~pcParticlesSystem()
{
    delete _AttManager;
}

void pcParticlesSystem::Flush()
{
    _Particles.clear();
    _ParticlesDead.clear();
}

int pcParticlesSystem::Lock()
{
    if(_Lock) return PC_ERR_PS_ALREADY_LOCKED;
    _Lock++;
    return PC_ERR_NO_ERROR;
}

int pcParticlesSystem::UnLock()
{
    if(!_Lock) return PC_ERR_PS_NOT_LOCKED;
    _Lock--;
    if(_Lock==0)
    {
        // Iterates through all operators to get all used flags
        pctOperatorTable::iterator firsto=_POperators.begin();
        pctOperatorTable::iterator lasto=_POperators.end();
        pctParticleFlags f=0;

        while(firsto!=lasto)
        {
            f|=(*firsto).second->GetUsedFlags();
            firsto++;
        }

        // Iterates through all emittersto get all used flags
        pctEmitterTable::iterator firste=_Emitters.begin();
        pctEmitterTable::iterator laste=_Emitters.end();        

        while(firste!=laste)
        {
            f|=(*firste)->GetUsedFlags();
            firste++;
        }

        // Compute size of a particle
        unsigned totalsize=0;
        unsigned offStart[32];

        for(int i=0;i<32;i++)
        {
            if(f&(1<<i))
            {
                string name;
                unsigned size;
                _AttManager->GetPFlagInfo((1<<i),name,size);
                offStart[i]=totalsize;
                totalsize+=size;
            }
        }
        
        // Sets data for every modules
        firsto=_POperators.begin();
        lasto=_POperators.end();        

        while(firsto!=lasto)
        {
            for(int i=0;i<32;i++) (*firsto).second->SetFlagInfo(1<<i,offStart[i]+sizeof(pcParticle));
            firsto++;
        }

        pctEmitterTable::iterator first=_Emitters.begin();
        pctEmitterTable::iterator last=_Emitters.end();

        while(first!=last)
        {
            for(int i=0;i<32;i++) (*first)->SetFlagInfo(1<<i,offStart[i]+sizeof(pcParticle));
            (*first)->SetParticleSize(totalsize+sizeof(pcParticle));
            first++;
        }
        if(_LastPartSize!=totalsize+sizeof(pcParticle))
        {
            // Flush particles table
            _LastPartSize=totalsize+sizeof(pcParticle);
            Flush();
        }

    }
    return PC_ERR_NO_ERROR;
}

int pcParticlesSystem::RegisterPFlag(pctParticleFlags flag,string name,unsigned size)
{
    return _AttManager->RegisterPFlag(flag,name,size);
}

int pcParticlesSystem::UnRegisterPFlag(pctParticleFlags flag)
{
    return _AttManager->UnRegisterPFlag(flag);
}

unsigned pcParticlesSystem::AddEmitter(pcParticleEmitterInterface *e)
{
    if(!_Lock) return 0;

    _Emitters.push_back(e);
    return _Emitters.size()-1;
}

unsigned pcParticlesSystem::AddOperator(unsigned priority,pcParticleOperatorInterface *o)
{
    if(!_Lock) return 0;

    _POperators.insert(pctOperatorTable::value_type(priority,o));    
    return priority;
}

int pcParticlesSystem::ComputeSystem()
{
    if(_Lock) return PC_ERR_PS_LOCKED;

    // Handle emitters
    pctEmitterTable::iterator first=_Emitters.begin();
    pctEmitterTable::iterator last=_Emitters.end();

    while(first!=last)
    {
        if((*first)->GetState()==pcParticleEmitterInterface::STATE_ON) (*first)->GetNewParticles(_Time,_Particles,_ParticlesDead);
        first++;
    }

    // Handles operators
    pctOperatorTable::iterator firsto=_POperators.begin();
    pctOperatorTable::iterator lasto=_POperators.end();

    while(firsto!=lasto)
    {
        if((*firsto).second->GetState()==pcParticleOperatorInterface::STATE_ON) (*firsto).second->ApplyOn(_Time,_Particles);
        firsto++;
    }

    // Suppress dead particles
    pctParticleTable::iterator firstp=_Particles.begin();
    pctParticleTable::iterator lastp=_Particles.end();
    pctParticleTable::iterator tmp;

    while(firstp!=lastp)
    {
        if((*firstp)->State==pcParticle::STATE_DEAD)
        {
            // Put the dead particles at end
            tmp=firstp;
            tmp++;
           _ParticlesDead.splice(_ParticlesDead.end(),_Particles,firstp);

            firstp=tmp;
        }
        else 
		{
			(*firstp)->Time=_Time;
			firstp++;			
		}
    }

    return PC_ERR_NO_ERROR;
}

pcParticle *pcParticlesSystem::StdGetPart(pctParticleTable &table,pctParticleTable &tabledead,unsigned partsize)
{
    if(tabledead.empty())
    {
        pcParticle *p=(pcParticle*)new char[partsize];

		table.push_back(p);
		return p;
    }
            
    table.splice(table.begin(),tabledead,tabledead.begin());   

	return *table.begin();
}

#define EMITTERS_BEGIN	"EMITTERS_BEGIN"
#define EMITTERS_END	"EMITTERS_END"
#define OPERATORS_BEGIN	"OPERATORS_BEGIN"
#define OPERATORS_END	"OPERATORS_END"
#define BEGIN_DATA		"BEGIN_DATA"
#define END_DATA		"END_DATA"

void pcParticlesSystem::WriteDefs(ostream &o)
{
    pomClassInfo *pc;
	
	// Handle emitters
	o<<EMITTERS_BEGIN<<endl;
    pctEmitterTable::iterator first=_Emitters.begin();
    pctEmitterTable::iterator last=_Emitters.end();

    while(first!=last)
    {
		pc=(*first)->pomGetRuntimeClass();
		o<<pc->ClassName<<endl;
		o<<BEGIN_DATA<<endl;
		(*first)->WriteParams(o);
		o<<END_DATA<<endl<<endl;
        first++;
    }
	o<<EMITTERS_END<<endl<<endl;

    // Handles operators
	o<<OPERATORS_BEGIN<<endl;
    pctOperatorTable::iterator firsto=_POperators.begin();
    pctOperatorTable::iterator lasto=_POperators.end();

    while(firsto!=lasto)
    {        
		pc=(*firsto).second->pomGetRuntimeClass();
		o<<(*firsto).first<<" "<<pc->ClassName<<endl;
		o<<BEGIN_DATA<<endl;
		(*firsto).second->WriteParams(o);
		o<<END_DATA<<endl<<endl;
        firsto++;
    }
	o<<OPERATORS_END<<endl;
}

void pcParticlesSystem::ReadDefs(istream &o)
{
	char a2[4096];
	pomCoreObject *c;
	unsigned t;
	streampos p;

	o.flags(ios::skipws);

	Lock();

	while(!o.eof())
	{	
		o>>a2;
		//i=0;
	    //while(a2[i]!=0) {if((a2[i]>=97)&&(a2[i]<=122)) a2[i]-=32;i++;}
		strupr(a2);

		if(strcmp(a2,EMITTERS_BEGIN)==0)
		{
			// Loads emitters
			while(!o.eof())
			{
				o>>a2;
				c=pomCreateObjectFromClass(a2);
				if(c==NULL) break;
			
				o>>a2;
				((pcParticleEmitterInterface*)c)->ReadParams(o);
				o>>a2;

				AddEmitter((pcParticleEmitterInterface*)c);

				// End ?
				o>>a2;
				//i=0;
				//while(a2[i]!=0) {if((a2[i]>=97)&&(a2[i]<=122)) a2[i]-=32;i++;}
				strupr(a2);
				if(strcmp(a2,EMITTERS_END)==0) break;
			}
		}

		if(strcmp(a2,OPERATORS_BEGIN)==0)
		{
			// Loads emitters
			while(!o.eof())
			{
				o>>t;
				o>>a2;
				c=pomCreateObjectFromClass(a2);
				if(c==NULL) break;

				o>>a2;
				((pcParticleOperatorInterface*)c)->ReadParams(o);
				o>>a2;

				AddOperator(t,(pcParticleOperatorInterface*)c);

				// End ?				
				p=o.tellg();
				o>>a2;
				//i=0;
				//while(a2[i]!=0) {if((a2[i]>=97)&&(a2[i]<=122)) a2[i]-=32;i++;}
				strupr(a2);
				if(strcmp(a2,OPERATORS_END)==0) break;
				o.seekg(p);
			}
		}
	}
	UnLock();
}

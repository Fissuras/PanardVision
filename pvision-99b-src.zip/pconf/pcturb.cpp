/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "pcturb.h"

static pcTurbArray GlobTurbArray; 

pcTurbArray::pcTurbArray()
{
        SizePower=0;
        TurbArray=NULL;
		SetPowerSize(POW_TURB_SIZE);
}


// ////////////////////////////////////////////////////////////////////////////////////////////
pcTurbArray::~pcTurbArray()
{
        free(TurbArray);
        TurbArray=NULL;
        SizePower=0;
}


// ////////////////////////////////////////////////////////////////////////////////////////////
bool pcTurbArray::SetPowerSize(long PowerSize)
{
        pvVector3D *Tmp;
        long N;

        if(PowerSize<=0) return false;

        N=(1<<PowerSize);
        N=N*N*N;

        Tmp=(pvVector3D*)realloc(TurbArray,N*sizeof(pvVector3D));
        if(Tmp)
        {
                TurbArray=Tmp;
                SizePower=PowerSize;
                Mask=(1<<SizePower)-1;
                PlanePower=SizePower*2;

                // Recalcul la grille.
                for(long i=0;i<N;i++)
                {
                        pvVector3D V;
                        V.x=(rand()%30000)/30000.0;
                        V.y=(rand()%30000)/30000.0;
                        V.z=(rand()%30000)/30000.0;
                        TurbArray[i]=V;
                }
                return true;
        }
        else
                return false;
}


// ////////////////////////////////////////////////////////////////////////////////////////////
pvVector3D pcTurbArray::GetTurb(pvVector3D In)
{
        long X,Y,Z,oX1,oX2,oY1,oY2,oZ1,oZ2;
        float fX,fY,fZ;
        pvVector3D Ret;

        In*=(Mask+1);
        X=floor(In.x);fX=In.x-X;
        Y=floor(In.y);fY=In.y-Y;
        Z=floor(In.z);fZ=In.z-Z;
        oX1=X&Mask;oX2=(X+1)&Mask;
        oY1=(Y&Mask)<<SizePower;oY2=((Y+1)&Mask)<<SizePower;
        oZ1=(Z&Mask)<<PlanePower;oZ2=((Z+1)&Mask)<<PlanePower;

        Ret =TurbArray[oX1+oY1+oZ1]*((1-fX)*(1-fY)*(1-fZ));
        Ret+=TurbArray[oX2+oY1+oZ1]*((fX)*(1-fY)*(1-fZ));
        Ret+=TurbArray[oX1+oY2+oZ1]*((1-fX)*(fY)*(1-fZ));
        Ret+=TurbArray[oX2+oY2+oZ1]*((fX)*(fY)*(1-fZ));
        Ret+=TurbArray[oX1+oY1+oZ2]*((1-fX)*(1-fY)*(fZ));
        Ret+=TurbArray[oX2+oY1+oZ2]*((fX)*(1-fY)*(fZ));
        Ret+=TurbArray[oX1+oY2+oZ2]*((1-fX)*(fY)*(fZ));
        Ret+=TurbArray[oX2+oY2+oZ2]*((fX)*(fY)*(fZ));

        return Ret;
}


// ////////////////////////////////////////////////////////////////////////////////////////////
pcTurb::pcTurb(long NbOct)
{
        OOX=OOY=OOZ=1;
        RetFact=pvVector3D(1,1,1);RetAdd=pvVector3D(0,0,0);
        NbOctaves=0;
        Phases=NULL;
        SetNbOctaves(NbOct);
}


// ////////////////////////////////////////////////////////////////////////////////////////////
pcTurb::~pcTurb()
{
        OOX=OOY=OOZ=1;
        RetFact=pvVector3D(1,1,1);RetAdd=pvVector3D(0,0,0);
        NbOctaves=0;
        free(Phases);
        Phases=NULL;
}


// ////////////////////////////////////////////////////////////////////////////////////////////
void pcTurb::SetSize(pvVector3D GridSize)
{
        if(GridSize.x<=0) GridSize.x=0.1;
        if(GridSize.y<=0) GridSize.y=0.1;
        if(GridSize.z<=0) GridSize.z=0.1;
        OOX=1.0/GridSize.x;
        OOY=1.0/GridSize.y;
        OOZ=1.0/GridSize.z;
}

pvVector3D pcTurb::GetSize()
{
	pvVector3D a;

	a.x=1.0/OOX;
	a.y=1.0/OOY;
	a.z=1.0/OOZ;

	return a;
}
// ////////////////////////////////////////////////////////////////////////////////////////////
void pcTurb::SetRetInterval(pvVector3D Min,pvVector3D Max)
{
        if(Max.x<=Min.x) Max.x=Min.x+0.1;
        if(Max.y<=Min.y) Max.y=Min.y+0.1;
        if(Max.z<=Min.z) Max.z=Min.z+0.1;

        RetAdd=Min;
        RetFact.x=Max.x-Min.x;
        RetFact.y=Max.y-Min.y;
        RetFact.z=Max.z-Min.z;
        float f=0,df=0.5;
        for(long i=0;i<NbOctaves;i++)
        {
                f+=df;
                df*=0.5;
        }
        if(NbOctaves<=0) f=1;
        RetFact*=1/f;           // Fo multiplier par ckifo pour vraiment tomber ds 0-1.

}


// ////////////////////////////////////////////////////////////////////////////////////////////
bool pcTurb::SetNbOctaves(long N)
{
        pvVector3D *Tmp;
	long i;

        if(N<=0) return false;

        Tmp=(pvVector3D*)realloc(Phases,N*sizeof(pvVector3D));
        if(Tmp)
        {
                // RECALCUL FIT INTERVALLE
                float f=0,df=0.5;
                for(i=0;i<NbOctaves;i++)
                {
                        f+=df;
                        df*=0.5;
                }
                if(NbOctaves<=0) f=1;
                RetFact*=f;             // Fo remettre normalement.

                f=0;
                df=0.5;
                for(i=0;i<N;i++)
                {
                        f+=df;
                        df*=0.5;
                }
                if(N<=0) f=1;
                RetFact*=1/f;           // Fo mul par ckifo tout ca.

                // RECALC Phases et tout ca.
                NbOctaves=N;
                Phases=Tmp;
                for(i=0;i<N;i++)
                {
                        pvVector3D V;
                        V.x=(rand()%30000)/30000.0;
                        V.y=(rand()%30000)/30000.0;
                        V.z=(rand()%30000)/30000.0;
                        Phases[i]=V;
                }
                return true;
        }
        else
                return false;
}

long pcTurb::GetNbOctaves()
{
	return NbOctaves;
}

// ////////////////////////////////////////////////////////////////////////////////////////////
pvVector3D pcTurb::GetTurb(pvVector3D Pos)
{
        pvVector3D Ret(0,0,0);
        Pos.x*=OOX;
        Pos.y*=OOY;
        Pos.z*=OOZ;

        float f=0.5;
        for(long i=0;i<NbOctaves;i++)
        {
                Pos+=Phases[i];
                Pos.x=fmod(Pos.x,1);
                Pos.y=fmod(Pos.y,1);
                Pos.z=fmod(Pos.z,1);

                Ret+=GlobTurbArray.GetTurb(Pos)*f;

                Pos-=Phases[i];
                Pos*=2;
                f*=0.5;
        }
        Ret.x*=RetFact.x;
        Ret.y*=RetFact.y;
        Ret.z*=RetFact.z;
        return Ret+RetAdd;
}







/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "attmgr.h"

using namespace std;

int pcParticleAttributeManager::RegisterPFlag(pctParticleFlags flag,string name,unsigned size)
{
	_FlagsToName.insert(map<pctParticleFlags,string>::value_type(flag,name));
    _FlagsToSize.insert(map<pctParticleFlags,unsigned>::value_type(flag,size));
    
	return PC_ERR_NO_ERROR;
}

int pcParticleAttributeManager::UnRegisterPFlag(pctParticleFlags flag)
{
	_FlagsToName.erase(flag);
    _FlagsToSize.erase(flag);
    
	return PC_ERR_NO_ERROR;
}

int pcParticleAttributeManager::GetPFlagInfo(pctParticleFlags flag,string &name,unsigned &size)
{
    if(_FlagsToName.find(flag)==_FlagsToName.end()) return PC_ERR_ATTRIB_NOT_FOUND;

    map<pctParticleFlags,string>::iterator i;
    
    i=_FlagsToName.find(flag);
    name=(*i).second;

    map<pctParticleFlags,unsigned>::iterator j;

    j=_FlagsToSize.find(flag);
    size=(*j).second;
    
    return PC_ERR_NO_ERROR;
}

int pcParticleAttributeManager::GetPFlagInfo(string name,pctParticleFlags &flag,unsigned &size)
{
    map<pctParticleFlags,string>::iterator i;
    map<pctParticleFlags,string>::iterator j;
    unsigned f;

    i=_FlagsToName.begin();
    j=_FlagsToName.end();
    while(i!=j)
    {
        if((*i).second==name)
        {
            f=(*i).first;
            break;
        }
        i++;
    }
    if(i==j) return PC_ERR_ATTRIB_NOT_FOUND;

    map<pctParticleFlags,unsigned>::iterator k;

    k=_FlagsToSize.find(f);
    size=(*k).second;
    flag=f;

    return PC_ERR_NO_ERROR;
}

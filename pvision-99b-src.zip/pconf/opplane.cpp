/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "opplane.h"

IMPLEMENT_POMIZED(pcPlaneTrashCanOperator,"/domains/PanardConfettis/Operators");

pcPlaneTrashCanOperator::pcPlaneTrashCanOperator(float a,float b,float c,float d)
{
    _A=a;
	_B=b;
	_C=c;
	_D=d;
}	

int pcPlaneTrashCanOperator::ApplyOn(float time,pctParticleTable &table)
{
    pcParticle *p;

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
            pcsPartStandard *ps=(pcsPartStandard*)PC_GET_PART_FIELD(p,_StdOff);
			if((ps->p.x*_A+ps->p.y*_B+ps->p.z*_C+_D)<0)
            {
                p->State=pcParticle::STATE_DEAD;
                p->BirthTime=time;          // BirthTime becomes DeathTime;
            }
        }
        firstp++;
    }

    return PC_ERR_NO_ERROR;
}

pctParticleFlags pcPlaneTrashCanOperator::GetUsedFlags() const
{
	return (PC_PF_STANDARD);
}

void pcPlaneTrashCanOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_STANDARD:_StdOff=offset;break;
    }
}

void pcPlaneTrashCanOperator::WriteParams(ostream &o)
{	
	pcParticleOperatorInterface::WriteParams(o);
	
	o<<"\tP "<<_A<<" "<<_B<<" "<<_C<<" "<<_D<<endl;	
}

void pcPlaneTrashCanOperator::ReadParams(istream &i)
{	
	char tmp[4096],ok;
	streampos pos;

	pcParticleOperatorInterface::ReadParams(i);
	
	i.flags(ios::skipws);

	ok=1;
	while(ok)
	{
		ok=0;
		
		pos=i.tellg();
		i>>tmp;
		strupr(tmp);

		if(strcmp(tmp,"P")==0)
		{
			ok=1;
			i>>_A;
			i>>_B;
			i>>_C;			
			i>>_D;			
		}	
	}
	i.seekg(pos);
}

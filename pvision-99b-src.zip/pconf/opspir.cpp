/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "opspir.h"
#include "pvmath.h"

IMPLEMENT_POMIZED(pcSpiralOperator,"/domains/PanardConfettis/Operators");

void pcSpiralOperator::DefaultVal()
{
	_Axis.Zero();
	_Axis.y=-1;
	_DTheta=2;
}

pcSpiralOperator::pcSpiralOperator()
{
	DefaultVal();
}

int pcSpiralOperator::ApplyOn(float time,pctParticleTable &table)
{		
	pcParticle *p;
    float dt;	

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
			pcsPartNewton *pn=(pcsPartNewton*)PC_GET_PART_FIELD(p,_NewOff);
			dt=(time-p->Time);

			pvVector3D V;

			V=pn->s;
			V=pvMath::RotateVector(_Axis,V,_DTheta*dt);
			pn->s=V;
        }
        firstp++;
    }

    return PC_ERR_NO_ERROR;
}

pctParticleFlags pcSpiralOperator::GetUsedFlags() const
{
    return (PC_PF_NEWTONSYS);
}

void pcSpiralOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_NEWTONSYS:_NewOff=offset;break;
    }
}

void pcSpiralOperator::WriteParams(ostream &o)
{
	pcParticleOperatorInterface::WriteParams(o);
	
	o<<"\tDTHETA "<<_DTheta<<endl;
	o<<"\tAXIS "<<_Axis.x<<" "<<_Axis.y<<" "<<_Axis.z<<endl;	
}

void pcSpiralOperator::ReadParams(istream &i)
{	
	char tmp[4096],ok;
	streampos pos;

	pcParticleOperatorInterface::ReadParams(i);
	
	i.flags(ios::skipws);

	ok=1;
	while(ok)
	{
		ok=0;
		
		pos=i.tellg();
		i>>tmp;
		strupr(tmp);

		if(strcmp(tmp,"DTHETA")==0)
		{
			ok=1;
			i>>_DTheta;
		}

		if(strcmp(tmp,"AXIS")==0)
		{
			ok=1;
			i>>_Axis.x;
			i>>_Axis.y;
			i>>_Axis.z;			
		}	
	}
	i.seekg(pos);
}

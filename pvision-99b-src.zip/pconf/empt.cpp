/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
// Panard Vision++ : Ponctual emitter implementation
//
// Before using this library consult the LICENSE file

#include "empt.h"
#include "pcsys.h"
#include "base.h"

#ifndef PI
#define PI 3.141592654
#endif

IMPLEMENT_POMIZED(pcPointEmitter,"/domains/PanardConfettis/Emitters");

void pcPointEmitter::DefaultVal()
{
    _Freq=10;
    _LastEmittedTime=0;
    _Angle=45*PI/180.0;
    _Direction.Set(0,-1.0,0);
    _Direction.Normalize();
    _Radius=1;_PercentRadiusRand=10;
    _Weigth=10;_PercentWeigthRand=10;
    _Speed=7;_PercentSpeedRand=10;
	_Acc=pvVector3D(0,9.81,0);
}

pcPointEmitter::pcPointEmitter(pvVector3D pos)
{
    _Position=pos;
    DefaultVal();
}

pcPointEmitter::pcPointEmitter()
{
    _Position.Zero();
    DefaultVal();
}

void pcPointEmitter::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_STANDARD:_StdOff=offset;break;
    case PC_PF_NEWTONSYS:_NewOff=offset;break;
    }
}

pctParticleFlags pcPointEmitter::GetUsedFlags() const
{
    return (PC_PF_STANDARD|PC_PF_NEWTONSYS);
}

int pcPointEmitter::GetNewParticles(float time, pctParticleTable &table, pctParticleTable &tabledead)
{   
    unsigned nbrpart=(time-_LastEmittedTime)*_Freq;
    float t,s;
    float theta,phi;
    pvVector3D pt;
    
    for(unsigned i=0;i<nbrpart;i++)
    {
        pcParticle *p=pcParticlesSystem::StdGetPart(table,tabledead,_PartSize);

        p->State=pcParticle::STATE_ALIVE;
        p->Time=time;
        p->BirthTime=time;    

        pcsPartStandard *ps=(pcsPartStandard*)PC_GET_PART_FIELD(p,_StdOff);
        pcsPartNewton *pn=(pcsPartNewton*)PC_GET_PART_FIELD(p,_NewOff);

        ps->p=_Position;
        
        t=((float)rand()/(float)RAND_MAX);
        ps->radius=_Radius+_Radius*_PercentRadiusRand*t;

        t=((float)rand()/(float)RAND_MAX);
        pn->w=_Weigth+_Weigth*_PercentWeigthRand*t;

        t=((float)rand()/(float)RAND_MAX);
        s=_Speed+_Speed*_PercentSpeedRand*t;
        
        float rTheta=2*PI*((float)rand()/(float)RAND_MAX);
		float rPhi=_Angle*((float)rand()/(float)RAND_MAX)-_Angle/2;
		_Direction.VectorToAngles(theta,phi);

        pvBase3 Base;
        Base.Rotate(rTheta,rPhi,0);
        Base.Rotate(0,-PI/2,0);           // Pour mettre Vj a la place de Vk.
        Base.Rotate(theta,phi,0);
        pt=Base.Vj;
        
        pn->s=pt*s;

        pn->a=_Acc;  
    }
    if(nbrpart>0) _LastEmittedTime=time;

    return PC_ERR_NO_ERROR;
}

void pcPointEmitter::WriteParams(ostream &o)
{	
	pcParticleEmitterInterface::WriteParams(o);

	o<<"\tPOS "<<_Position.x<<" "<<_Position.y<<" "<<_Position.z<<endl;	
	o<<"\tDIR "<<_Direction.x<<" "<<_Direction.y<<" "<<_Direction.z<<endl;	
	o<<"\tANGLE "<<_Angle<<endl;
	o<<"\tFREQ "<<_Freq<<endl;
	o<<"\tACC "<<_Acc.x<<" "<<_Acc.y<<" "<<_Acc.z<<endl;
	o<<"\tRADIUS "<<_Radius<<" " <<_PercentRadiusRand<<endl;
	o<<"\tWEIGTH "<<_Weigth<<" " <<_PercentWeigthRand<<endl;
	o<<"\tSPEED "<<_Speed<<" " <<_PercentSpeedRand<<endl;	
}

void pcPointEmitter::ReadParams(istream &i)
{	
	char tmp[4096],ok;
	streampos pos;

	pcParticleEmitterInterface::ReadParams(i);
	
	i.flags(ios::skipws);

	ok=1;
	while(ok)
	{
		ok=0;
		
		pos=i.tellg();
		i>>tmp;
		strupr(tmp);

		if(strcmp(tmp,"ANGLE")==0)
		{
			ok=1;
			i>>_Angle;
		}
		
		if(strcmp(tmp,"FREQ")==0)
		{
			ok=1;
			i>>_Freq;
		}

		if(strcmp(tmp,"RADIUS")==0)
		{
			ok=1;
			i>>_Radius;
			i>>_PercentRadiusRand;
		}

		if(strcmp(tmp,"WEIGTH")==0)
		{
			ok=1;
			i>>_Weigth;
			i>>_PercentWeigthRand;
		}

		if(strcmp(tmp,"SPEED")==0)
		{
			ok=1;
			i>>_Speed;
			i>>_PercentSpeedRand;
		}

		if(strcmp(tmp,"POS")==0)
		{
			ok=1;
			i>>_Position.x;
			i>>_Position.y;
			i>>_Position.z;			
		}	

		if(strcmp(tmp,"ACC")==0)
		{
			ok=1;
			i>>_Acc.x;
			i>>_Acc.y;
			i>>_Acc.z;			
		}	

		if(strcmp(tmp,"DIR")==0)
		{
			ok=1;
			i>>_Direction.x;
			i>>_Direction.y;
			i>>_Direction.z;			
		}	
	}
	i.seekg(pos);
}

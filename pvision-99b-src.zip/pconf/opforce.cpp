/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "opforce.h"

IMPLEMENT_POMIZED(pcForceOperator,"/domains/PanardConfettis/Operators");

void pcForceOperator::DefaultVal()
{
	_V.Zero();
	_V.x=1;
	_F=100;
}

pcForceOperator::pcForceOperator()
{
	DefaultVal();
}

int pcForceOperator::ApplyOn(float time,pctParticleTable &table)
{
    pcParticle *p;
    float dt;	

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
			pcsPartNewton *pn=(pcsPartNewton*)PC_GET_PART_FIELD(p,_NewOff);
			dt=(time-p->Time);
			pn->s+=_V*(_F*dt/pn->w);
        }
        firstp++;
    }

    return PC_ERR_NO_ERROR;
}

pctParticleFlags pcForceOperator::GetUsedFlags() const
{
    return (PC_PF_NEWTONSYS);
}

void pcForceOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_NEWTONSYS:_NewOff=offset;break;
    }
}

void pcForceOperator::WriteParams(ostream &o)
{
	pcParticleOperatorInterface::WriteParams(o);
	
	o<<"\tFORCE "<<_F<<endl;
	o<<"\tV "<<_V.x<<" "<<_V.y<<" "<<_V.z<<endl;	
}

void pcForceOperator::ReadParams(istream &i)
{	
	char tmp[4096],ok;
	streampos pos;

	pcParticleOperatorInterface::ReadParams(i);
	
	i.flags(ios::skipws);

	ok=1;
	while(ok)
	{
		ok=0;
		
		pos=i.tellg();
		i>>tmp;
		strupr(tmp);

		if(strcmp(tmp,"FORCE")==0)
		{
			ok=1;
			i>>_F;
		}

		if(strcmp(tmp,"V")==0)
		{
			ok=1;
			i>>_V.x;
			i>>_V.y;
			i>>_V.z;			
		}	
	}
	i.seekg(pos);
}

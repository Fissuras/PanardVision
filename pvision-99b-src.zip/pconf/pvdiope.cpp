/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
// Panard Vision++ : PV display operator implementation
//
// Before using this library consult the LICENSE file

#include "pvdiope.h"
#include "base.h"

IMPLEMENT_POMIZED(pcPVDisplayOperator,"/domains/PanardConfettis/Operators");

pcPVDisplayOperator::pcPVDisplayOperator(PVCam *c,PVMaterial *partmat)
{
    _Camera=c;
    _ParticuleMat=partmat;
}

int pcPVDisplayOperator::ApplyOn(float time,pctParticleTable &table)
{    
    PVMat3x3 Id={1,0,0,0,1,0,0,0,1};
    PVPoint Pos={0,0,0};
    PVMat3x3 m;
	pvVector3D b1,b2,b3,b4;
	pvBase3 bas;

    // Panard Primitive Setup
    pvSetMode(PV_3D);								// 3D drawing    
    pvSetCull(PV_CULL_NONE);						// every faces will be displayed
	pvSetLightingMode(PV_NOLIGHTING);		

	pvSetCamera(_Camera);

    m[0][0]=_Camera->Matrix[0][0];
    m[1][0]=_Camera->Matrix[0][1];
    m[2][0]=_Camera->Matrix[0][2];
    m[0][1]=_Camera->Matrix[1][0];
    m[1][1]=_Camera->Matrix[1][1];
    m[2][1]=_Camera->Matrix[1][2];
    m[0][2]=_Camera->Matrix[2][0];
    m[1][2]=_Camera->Matrix[2][1];
    m[2][2]=_Camera->Matrix[2][2];
    
	// BillBoarding stuff
	bas.FromArray(m);
	b1.Set(-1,-1,0);	
	b1=bas.RotateVector(b1);
	b2.Set(1,-1,0);	
	b2=bas.RotateVector(b2);
	b3=b1*-1;
	b4=b2*-1;

	pvSetModelMatrix(m);
    pvSetModelPos(Pos);
    pvSetModelPivot(Pos);

    pvSetMaterial(_ParticuleMat);

    // Let's draw
    pcParticle *p;

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    pvBegin(PV_QUADS,0);
    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
            pcsPartStandard *ps=(pcsPartStandard*)PC_GET_PART_FIELD(p,_StdOff);

            pvMapCoord(0,0);
            pvVertex(ps->p.x+b1.x*ps->radius,ps->p.y+b1.y*ps->radius,ps->p.z+b1.z*ps->radius);
            pvMapCoord(1.0,0);
			pvVertex(ps->p.x+b2.x*ps->radius,ps->p.y+b2.y*ps->radius,ps->p.z+b2.z*ps->radius);
            pvMapCoord(1.0,1.0);
			pvVertex(ps->p.x+b3.x*ps->radius,ps->p.y+b3.y*ps->radius,ps->p.z+b3.z*ps->radius);
            pvMapCoord(0,1.0);
			pvVertex(ps->p.x+b4.x*ps->radius,ps->p.y+b4.y*ps->radius,ps->p.z+b4.z*ps->radius);
        }
        firstp++;
    }
    pvEnd();

    return PC_ERR_NO_ERROR;
}

pctParticleFlags pcPVDisplayOperator::GetUsedFlags() const
{
    return PC_PF_STANDARD;
}

void pcPVDisplayOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_STANDARD:_StdOff=offset;break;
    }
}

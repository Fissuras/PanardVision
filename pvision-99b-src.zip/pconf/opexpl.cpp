/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdlib.h>
#include "opexpl.h"

IMPLEMENT_POMIZED(pcExplodeOperator,"/domains/PanardConfettis/Operators");

void pcExplodeOperator::DefaultVal()
{
	_F=10000;
	_DistTime=1e6;
	_MaxDistMin=0.01;
	_BirthTime=0;
	_P.Zero();
}

pcExplodeOperator::pcExplodeOperator()
{
	DefaultVal();
}

int pcExplodeOperator::ApplyOn(float time,pctParticleTable &table)
{		
	time-=_BirthTime;
	_DistMin=_MaxDistMin*time/_DistTime;
	_DistMin=min(_DistMin,_MaxDistMin);

	pcParticle *p;
    float dt;	

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
			pcsPartStandard *ps=(pcsPartStandard*)PC_GET_PART_FIELD(p,_StdOff);
			pcsPartNewton *pn=(pcsPartNewton*)PC_GET_PART_FIELD(p,_NewOff);
			dt=(time-p->Time);

			pvVector3D V;
			float f,cf;

			V=ps->p-_P;
			f=V.GetNorm();
			cf=max(f,_DistMin);
						
			pn->s+=V*(_F*dt/(f*cf*max(pn->w,0.000001f)));
        }
        firstp++;
    }

    return PC_ERR_NO_ERROR;
}

pctParticleFlags pcExplodeOperator::GetUsedFlags() const
{
    return (PC_PF_STANDARD|PC_PF_NEWTONSYS);
}

void pcExplodeOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_STANDARD:_StdOff=offset;break;
    case PC_PF_NEWTONSYS:_NewOff=offset;break;
    }
}

void pcExplodeOperator::WriteParams(ostream &o)
{
	pcParticleOperatorInterface::WriteParams(o);

	o<<"\tFORCE "<<_F<<endl;
	o<<"\tMAXDISTMIN "<<_MaxDistMin<<endl;
	o<<"\tDISTTIME "<<_DistTime<<endl;
	o<<"\tBIRTHTIME "<<_BirthTime<<endl;
	o<<"\tP "<<_P.x<<" "<<_P.y<<" "<<_P.z<<endl;	
}

void pcExplodeOperator::ReadParams(istream &i)
{	
	char tmp[4096],ok;
	streampos pos;

	pcParticleOperatorInterface::ReadParams(i);
	
	i.flags(ios::skipws);

	ok=1;
	while(ok)
	{
		ok=0;
		
		pos=i.tellg();
		i>>tmp;
		strupr(tmp);

		if(strcmp(tmp,"FORCE")==0)
		{
			ok=1;
			i>>_F;
		}

		if(strcmp(tmp,"MAXDISTMIN")==0)
		{
			ok=1;
			i>>_MaxDistMin;
		}

		if(strcmp(tmp,"DISTTIME")==0)
		{
			ok=1;
			i>>_DistTime;
		}
		
		if(strcmp(tmp,"BIRTHTIME")==0)
		{
			ok=1;
			i>>_BirthTime;
		}


		if(strcmp(tmp,"P")==0)
		{
			ok=1;
			i>>_P.x;
			i>>_P.y;
			i>>_P.z;			
		}	
	}
	i.seekg(pos);
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "opaturb.h"

IMPLEMENT_POMIZED(pcATurbOperator,"/domains/PanardConfettis/Operators");

pctParticleFlags pcATurbOperator::GetUsedFlags() const
{
    return (PC_PF_NEWTONSYS|PC_PF_STANDARD);
}

void pcATurbOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_NEWTONSYS:_NewOff=offset;break;
    case PC_PF_STANDARD:_StdOff=offset;break;
    }
}

int pcATurbOperator::ApplyOn(float time,pctParticleTable &table)
{		
	pcParticle *p;
    float dt;	

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
			pcsPartNewton *pn=(pcsPartNewton*)PC_GET_PART_FIELD(p,_NewOff);
			pcsPartStandard *ps=(pcsPartStandard*)PC_GET_PART_FIELD(p,_StdOff);
			dt=(time-p->Time);

			pvVector3D V;

			V=_Turb.GetTurb(ps->p)*(_Force*ps->radius*dt/max(pn->w,0.000001f));
			V.Mul(_MulAxe);
			pn->s=V;
        }
        firstp++;
    }

    return PC_ERR_NO_ERROR;
}

void pcATurbOperator::WriteParams(ostream &o)
{
	pcParticleOperatorInterface::WriteParams(o);

	o<<"\tNB_OCTAVE "<<_Turb.GetNbOctaves()<<endl;
	o<<"\tGRIDSIZE "<<_Turb.GetSize().x<<" "<<_Turb.GetSize().y<<" "<<_Turb.GetSize().z<<endl;
	o<<"\tFORCE "<<_Force<<endl;
	o<<"\tMULAXE "<<_MulAxe.x<<" "<<_MulAxe.y<<" "<<_MulAxe.z<<endl;	
}

void pcATurbOperator::ReadParams(istream &i)
{	
	char tmp[4096],ok;
	unsigned t;
	float x,y,z;
	streampos pos;

	pcParticleOperatorInterface::ReadParams(i);
	
	i.flags(ios::skipws);

	ok=1;
	while(ok)
	{
		ok=0;
		
		pos=i.tellg();
		i>>tmp;
		strupr(tmp);

		if(strcmp(tmp,"NB_OCTAVE")==0)
		{
			ok=1;
			i>>t;
			_Turb.SetNbOctaves(t);
		}

		if(strcmp(tmp,"GRIDSIZE")==0)
		{
			ok=1;
			i>>x;
			i>>y;
			i>>z;
			_Turb.SetSize(pvVector3D(x,y,z));
		}

		if(strcmp(tmp,"FORCE")==0)
		{
			ok=1;
			i>>_Force;
		}

		if(strcmp(tmp,"MULAXE")==0)
		{
			ok=1;
			i>>_MulAxe.x;
			i>>_MulAxe.y;
			i>>_MulAxe.z;			
		}	
	}
	i.seekg(pos);
}

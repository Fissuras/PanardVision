/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
// Panard Vision++ : Newton operator implementation
//
// Before using this library consult the LICENSE file

#include "opnewt.h"

IMPLEMENT_POMIZED(pcNewtonOperator,"/domains/PanardConfettis/Operators");

int pcNewtonOperator::ApplyOn(float time,pctParticleTable &table)
{    
    pcParticle *p;
    float dt;
	pvVector3D OldSpeed,NewSpeed;

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
            // Standard cinematic move
            pcsPartStandard *ps=(pcsPartStandard*)PC_GET_PART_FIELD(p,_StdOff);
            pcsPartNewton *pn=(pcsPartNewton*)PC_GET_PART_FIELD(p,_NewOff);
            dt=(time-p->Time);
            
            // Cinematic update
			// Euler Rulez
			OldSpeed=pn->s;
            
            // Speed+=dt*Accel
            pn->s+=pn->a*dt;
			NewSpeed=pn->s;
			
			// Position+= dt*(OldSpeed+NewSpeed)/2
			ps->p+=(OldSpeed+NewSpeed)*dt/2;
        }
        firstp++;
    }

    return PC_ERR_NO_ERROR;
}

pctParticleFlags pcNewtonOperator::GetUsedFlags() const
{
    return (PC_PF_STANDARD|PC_PF_NEWTONSYS);
}

void pcNewtonOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_STANDARD:_StdOff=offset;break;
    case PC_PF_NEWTONSYS:_NewOff=offset;break;
    }
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "opvortex.h"
#include "base.h"
#include "pvmath.h"

IMPLEMENT_POMIZED(pcVortexOperator,"/domains/PanardConfettis/Operators");

void pcVortexOperator::DefaultVal()
{
	_AxisV.Zero();
	_AxisV.y=-1.0;
	_AxisV.Normalize();
	
	_Center.Zero();

	_Magn=50;
	_Tigh=1.0;
	_Trans=0;
	_Force=10;
}

pcVortexOperator::pcVortexOperator()
{
	DefaultVal();
}

int pcVortexOperator::ApplyOn(float time,pctParticleTable &table)
{    
    pcParticle *p;
    float dt;	

    pctParticleTable::iterator firstp=table.begin();
    pctParticleTable::iterator lastp=table.end();

    while(firstp!=lastp)
    {
        p=(*firstp);
        if(p->State==pcParticle::STATE_ALIVE)
        {
			pvVector3D V;
			float R;

			pcsPartStandard *ps=(pcsPartStandard*)PC_GET_PART_FIELD(p,_StdOff);
            pcsPartNewton *pn=(pcsPartNewton*)PC_GET_PART_FIELD(p,_NewOff);
			dt=(time-p->Time);			

			R=(ps->p-_Center).GetNorm();
			if(R<1.0) R=1;
			R=pow(R,_Tigh);

			//V=ps->p-_AxisP;
			//V=RotateVector(_AxisV,V,dt*_Magn/R);
			/*ps->p=_AxisP+V;*/
			V=ps->p-_Center;
			V=pvMath::RotateVector(_AxisV,V,dt*_Magn/R);
			V+=_Center;		
			
			ps->p=V;
			ps->p+=_AxisV*_Trans;	// Translation Axis
			
			// Effet Vortex.
			/*R=(ps->p-_Center).GetNorm();			
			R=R-_Thick;
			R=R*R;*/
			
			/*V=ps->p-_AxisP;
			pvVector3D I=_AxisV;
			
			I.Normalize();
			V=V-(I*(I*V));	// V=Axe-HPos.
			V.Normalize();
			pn->s-=V*R*_Force*dt;*/



        }
        firstp++;
    }

    return PC_ERR_NO_ERROR;
}

pctParticleFlags pcVortexOperator::GetUsedFlags() const
{
    return (PC_PF_STANDARD|PC_PF_NEWTONSYS);
}

void pcVortexOperator::SetFlagInfo(pctParticleFlags f,unsigned offset)
{
    switch(f)
    {
    case PC_PF_STANDARD:_StdOff=offset;break;
    case PC_PF_NEWTONSYS:_NewOff=offset;break;
    }
}


void pcVortexOperator::WriteParams(ostream &o)
{
	pcParticleOperatorInterface::WriteParams(o);
	
	o<<"\tAXISV "<<_AxisV.x<<" "<<_AxisV.y<<" "<<_AxisV.z<<endl;	
	o<<"\tCENTER "<<_Center.x<<" "<<_Center.y<<" "<<_Center.z<<endl;	
	o<<"\tMAGN "<<_Magn<<endl;
	o<<"\tTIGH "<<_Tigh<<endl;
	o<<"\tTRANS "<<_Trans<<endl;
	o<<"\tFORCE "<<_Force<<endl;
}

void pcVortexOperator::ReadParams(istream &i)
{	
	char tmp[4096],ok;
	streampos pos;

	pcParticleOperatorInterface::ReadParams(i);
	
	i.flags(ios::skipws);

	ok=1;
	while(ok)
	{
		ok=0;
		
		pos=i.tellg();
		i>>tmp;
		strupr(tmp);

		if(strcmp(tmp,"FORCE")==0)
		{
			ok=1;
			i>>_Force;
		}

		if(strcmp(tmp,"MAGN")==0)
		{
			ok=1;
			i>>_Magn;
		}

		if(strcmp(tmp,"TIGH")==0)
		{
			ok=1;
			i>>_Tigh;
		}

		if(strcmp(tmp,"TRANS")==0)
		{
			ok=1;
			i>>_Trans;
		}

		if(strcmp(tmp,"AXISV")==0)
		{
			ok=1;
			i>>_AxisV.x;
			i>>_AxisV.y;
			i>>_AxisV.z;			
		}	

		if(strcmp(tmp,"CENTER")==0)
		{
			ok=1;
			i>>_Center.x;
			i>>_Center.y;
			i>>_Center.z;			
		}	

	}
	i.seekg(pos);
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __PC_ATTMGR__
#define __PC_ATTMGR__

#include "pctypes.h"
#include "pomcore.h"

#include <string>
#include <map>
using std::map;
using std::string;

class PVDLL pcParticleAttributeManager
{
	private:
		map<pctParticleFlags,unsigned> _FlagsToSize;
		map<pctParticleFlags,string> _FlagsToName;
		
	public:		
		int RegisterPFlag(pctParticleFlags flag,string name,unsigned size);
		int UnRegisterPFlag(pctParticleFlags flag);
		int GetPFlagInfo(pctParticleFlags flag,string &name,unsigned &size);
		int GetPFlagInfo(string name,pctParticleFlags &flag,unsigned &size);
};

#endif


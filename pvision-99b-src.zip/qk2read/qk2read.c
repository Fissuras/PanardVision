/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
// Quake II bsp driver
//
// Before using this library consult the LICENSE file

#include "cmdlib.h"					// cmdlib.h must be included first because of a bug in the original q2 .h files
#include "mathlib.h"				// idem
#include "bspfile.h"
#include "pvision.h"
#include "pakfile.h"
#include "inifile.h"
#include "qk2read.h"

#ifdef __UNIX__
#define __fastcall

static char *strlwr(char *t)
{
   // convert to lower case
   unsigned i=0;
   while(t[i]!=0) {if((t[i]>=97-32)&&(t[i]<=122-32)) t[i]+=32;i++;}
}

#endif

#define NBR_CLIP_VERTEX     4000			// maybe *a little* overestimated :)

////////////////////////////////////////////////////////////////// INI 

static int HiQual=1;
static int MipTex=1;
static int LightMapping=1;

////////////////////////////////////////////////////////////////////////////

static char vis_cluster[MAX_MAP_LEAFS/8+1];
static char vis_node[MAX_MAP_NODES];

static PVMesh *CurrentMesh;

static int CurrentLeaf,OldLeaf=0;

static PVTexBasis *BasIndex[MAX_MAP_TEXINFO];
static PVMaterial *MatIndex[MAX_MAP_TEXINFO];

static char skyname[256];
static PVMaterial *SkyMats[6];

/////////////////////////////////////////////////////// Some useful routines
// This is not the coolest way sky should be handled (I think)
// but it's simple
static PVMesh *CreateSkyBox(float mins[],float maxs[],PVMaterial *sky[])
{
	PVMesh* Mesh1;
	unsigned V[4];

	Mesh1=PV_SimpleCreateMesh(6,8*3,50,50);    // Clip Values a lot overestimated
	if(Mesh1==NULL) return NULL;
    Mesh1->Flags|=MESH_NOSORT;				 // no sorting needed for a cube, since it's a convec polyhedron

	Mesh1->Vertex[0].xf=mins[0];
    Mesh1->Vertex[0].yf=-mins[2];
    Mesh1->Vertex[0].zf=-mins[1];
	Mesh1->Mapping[0].u=1.0-0.0/256.0;
	Mesh1->Mapping[0].v=1.0-0.0/256.0;

	Mesh1->Vertex[1].xf=maxs[0];
    Mesh1->Vertex[1].yf=-mins[2];
    Mesh1->Vertex[1].zf=-mins[1];
	Mesh1->Mapping[1].u=0.0+0.0/256.0;
	Mesh1->Mapping[1].v=1.0-0.0/256.0;

	Mesh1->Vertex[2].xf=maxs[0];
    Mesh1->Vertex[2].yf=-maxs[2];
    Mesh1->Vertex[2].zf=-mins[1];
	Mesh1->Mapping[2].u=0.0+0.0/256.0;
	Mesh1->Mapping[2].v=0.0+0.0/256.0;

	Mesh1->Vertex[3].xf=mins[0];
    Mesh1->Vertex[3].yf=-maxs[2];
    Mesh1->Vertex[3].zf=-mins[1];
	Mesh1->Mapping[3].u=1.0-0.0/256.0;
	Mesh1->Mapping[3].v=0.0+0.0/256.0;

	Mesh1->Vertex[4].xf=mins[0];
    Mesh1->Vertex[4].yf=-mins[2];
    Mesh1->Vertex[4].zf=-maxs[1];
	Mesh1->Mapping[4].u=0.0+0.0/256.0;
	Mesh1->Mapping[4].v=1.0-0.0/256.0;

	Mesh1->Vertex[5].xf=maxs[0];
    Mesh1->Vertex[5].yf=-mins[2];
    Mesh1->Vertex[5].zf=-maxs[1];
	Mesh1->Mapping[5].u=1.0-0.0/256.0;
	Mesh1->Mapping[5].v=1.0-0.0/256.0;

	Mesh1->Vertex[6].xf=maxs[0];
    Mesh1->Vertex[6].yf=-maxs[2];
    Mesh1->Vertex[6].zf=-maxs[1];
	Mesh1->Mapping[6].u=1.0-0.0/256.0;
	Mesh1->Mapping[6].v=0.0+0.0/256.0;

	Mesh1->Vertex[7].xf=mins[0];
    Mesh1->Vertex[7].yf=-maxs[2];
    Mesh1->Vertex[7].zf=-maxs[1];
	Mesh1->Mapping[7].u=0.0+0.0/256.0;
	Mesh1->Mapping[7].v=0.0+0.0/256.0;

	Mesh1->Vertex[0+8].xf=mins[0];
    Mesh1->Vertex[0+8].yf=-mins[2];
    Mesh1->Vertex[0+8].zf=-mins[1];
	Mesh1->Mapping[0+8].u=0.0+0.0/256.0;
	Mesh1->Mapping[0+8].v=1.0-0.0/256.0;

	Mesh1->Vertex[1+8].xf=maxs[0];
    Mesh1->Vertex[1+8].yf=-mins[2];
    Mesh1->Vertex[1+8].zf=-mins[1];
	Mesh1->Mapping[1+8].u=1.0-0.0/256.0;
	Mesh1->Mapping[1+8].v=1.0-0.0/256.0;

	Mesh1->Vertex[2+8].xf=maxs[0];
    Mesh1->Vertex[2+8].yf=-maxs[2];
    Mesh1->Vertex[2+8].zf=-mins[1];
	Mesh1->Mapping[2+8].u=1.0-0.0/256.0;
	Mesh1->Mapping[2+8].v=0.0+0.0/256.0;

	Mesh1->Vertex[3+8].xf=mins[0];
    Mesh1->Vertex[3+8].yf=-maxs[2];
    Mesh1->Vertex[3+8].zf=-mins[1];
	Mesh1->Mapping[3+8].u=0.0+0.0/256.0;
	Mesh1->Mapping[3+8].v=0.0+0.0/256.0;

	Mesh1->Vertex[4+8].xf=mins[0];
    Mesh1->Vertex[4+8].yf=-mins[2];
    Mesh1->Vertex[4+8].zf=-maxs[1];
	Mesh1->Mapping[4+8].u=1.0-0.0/256.0;
	Mesh1->Mapping[4+8].v=1.0-0.0/256.0;

	Mesh1->Vertex[5+8].xf=maxs[0];
    Mesh1->Vertex[5+8].yf=-mins[2];
    Mesh1->Vertex[5+8].zf=-maxs[1];
	Mesh1->Mapping[5+8].u=0.0+0.0/256.0;
	Mesh1->Mapping[5+8].v=1.0-0.0/256.0;

	Mesh1->Vertex[6+8].xf=maxs[0];
    Mesh1->Vertex[6+8].yf=-maxs[2];
    Mesh1->Vertex[6+8].zf=-maxs[1];
	Mesh1->Mapping[6+8].u=0.0+0.0/256.0;
	Mesh1->Mapping[6+8].v=0.0+0.0/256.0;

	Mesh1->Vertex[7+8].xf=mins[0];
    Mesh1->Vertex[7+8].yf=-maxs[2];
    Mesh1->Vertex[7+8].zf=-maxs[1];
	Mesh1->Mapping[7+8].u=1.0-0.0/256.0;
	Mesh1->Mapping[7+8].v=0.0+0.0/256.0;

	Mesh1->Vertex[0+16].xf=mins[0];
    Mesh1->Vertex[0+16].yf=-mins[2];
    Mesh1->Vertex[0+16].zf=-mins[1];
	Mesh1->Mapping[0+16].u=1.0-0.0/256.0;
	Mesh1->Mapping[0+16].v=1.0-0.0/256.0;

	Mesh1->Vertex[1+16].xf=maxs[0];
    Mesh1->Vertex[1+16].yf=-mins[2];
    Mesh1->Vertex[1+16].zf=-mins[1];
	Mesh1->Mapping[1+16].u=1.0-0.0/256.0;
	Mesh1->Mapping[1+16].v=0.0+0.0/256.0;

	Mesh1->Vertex[2+16].xf=maxs[0];
    Mesh1->Vertex[2+16].yf=-maxs[2];
    Mesh1->Vertex[2+16].zf=-mins[1];
	Mesh1->Mapping[2+16].u=1.0-0.0/256.0;
	Mesh1->Mapping[2+16].v=1.0-0.0/256.0;

	Mesh1->Vertex[3+16].xf=mins[0];
    Mesh1->Vertex[3+16].yf=-maxs[2];
    Mesh1->Vertex[3+16].zf=-mins[1];
	Mesh1->Mapping[3+16].u=1.0-0.0/256.0;
	Mesh1->Mapping[3+16].v=0.0+0.0/256.0;

	Mesh1->Vertex[4+16].xf=mins[0];
    Mesh1->Vertex[4+16].yf=-mins[2];
    Mesh1->Vertex[4+16].zf=-maxs[1];
	Mesh1->Mapping[4+16].u=0.0+0.0/256.0;
	Mesh1->Mapping[4+16].v=1.0-0.0/256.0;

	Mesh1->Vertex[5+16].xf=maxs[0];
    Mesh1->Vertex[5+16].yf=-mins[2];
    Mesh1->Vertex[5+16].zf=-maxs[1];
	Mesh1->Mapping[5+16].u=0.0+0.0/256.0;
	Mesh1->Mapping[5+16].v=0.0+0.0/256.0;

	Mesh1->Vertex[6+16].xf=maxs[0];
    Mesh1->Vertex[6+16].yf=-maxs[2];
    Mesh1->Vertex[6+16].zf=-maxs[1];
	Mesh1->Mapping[6+16].u=0.0+0.0/256.0;
	Mesh1->Mapping[6+16].v=1.0-0.0/256.0;

	Mesh1->Vertex[7+16].xf=mins[0];
    Mesh1->Vertex[7+16].yf=-maxs[2];
    Mesh1->Vertex[7+16].zf=-maxs[1];
	Mesh1->Mapping[7+16].u=0.0+0.0/256.0;
	Mesh1->Mapping[7+16].v=0.0+0.0/256.0;

	
	Mesh1->Face[0].NbrVertices=4;        
    Mesh1->Face[0].MaterialInfo=sky[0];		

	V[0]=3;
	V[1]=2;
	V[2]=1;
	V[3]=0;
	PV_SetVerticesToFace(&Mesh1->Face[0],V,4);

	Mesh1->Face[1].NbrVertices=4;        
    Mesh1->Face[1].MaterialInfo=sky[1];

	V[0]=4;
	V[1]=5;
	V[2]=6;
	V[3]=7;
	PV_SetVerticesToFace(&Mesh1->Face[1],V,4);

	Mesh1->Face[2].NbrVertices=4;        
    Mesh1->Face[2].MaterialInfo=sky[2];

	V[0]=6+8;
	V[1]=5+8;
	V[2]=1+8;
	V[3]=2+8;
	PV_SetVerticesToFace(&Mesh1->Face[2],V,4);

	Mesh1->Face[3].NbrVertices=4;        
    Mesh1->Face[3].MaterialInfo=sky[3];

	V[0]=3+8;
	V[1]=0+8;
	V[2]=4+8;
	V[3]=7+8;
	PV_SetVerticesToFace(&Mesh1->Face[3],V,4);

	Mesh1->Face[4].NbrVertices=4;        
    Mesh1->Face[4].MaterialInfo=sky[5];

	V[0]=5+16;
	V[1]=4+16;
	V[2]=0+16;
	V[3]=1+16;
	PV_SetVerticesToFace(&Mesh1->Face[4],V,4);

	Mesh1->Face[5].NbrVertices=4;        
    Mesh1->Face[5].MaterialInfo=sky[4];

	V[0]=2+16;
	V[1]=3+16;
	V[2]=7+16;
	V[3]=6+16;
	PV_SetVerticesToFace(&Mesh1->Face[5],V,4);
	
	PV_SetMeshName(Mesh1,Q2SKY_MESHNAME);

	PV_MeshNormCalc(Mesh1);    
    PV_MeshBuildBoxes(Mesh1,10);

	PV_MeshSetupMatrix(Mesh1,0,PI,0);

	return Mesh1;
}

static int point_plane_test(PVPoint *loc, dplane_t *plane)
{
   return plane->normal[0] * loc->xf + -plane->normal[2] * loc->yf
        + -plane->normal[1]*loc->zf < plane->dist;
}

static int find_leaf( PVPoint *v )
{
	int n = dmodels[0].headnode;
	while (n >= 0) {
		dnode_t *node = &dnodes[n];
		
		n = node->children[point_plane_test(v,&dplanes[node->planenum])];
	}
	return ~n;
}

static int bbox_inside_frustum(short *mins, short *maxs)
{
   unsigned i=0xFFFFFFFF;
   PVPoint a;

   a.xf=mins[0];
   a.yf=-mins[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-mins[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-maxs[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=mins[0];
   a.yf=-maxs[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=mins[0];
   a.yf=-mins[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-mins[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-maxs[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=mins[0];
   a.yf=-maxs[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);

   if(i) return 0; else return 1;
}


static int bboxf_inside_frustum(float *mins, float *maxs)
{
   unsigned i=0xFFFFFFFF;
   PVPoint a;

   a.xf=mins[0];
   a.yf=-mins[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-mins[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-maxs[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=mins[0];
   a.yf=-maxs[2];
   a.zf=-mins[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=mins[0];
   a.yf=-mins[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-mins[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=maxs[0];
   a.yf=-maxs[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);
   if(!i) return 1;

   a.xf=mins[0];
   a.yf=-maxs[2];
   a.zf=-maxs[1];
   i&=PV_GetFrustumFlags(&a);   

   if(i) return 0; else return 1;
}

static int leaf_in_frustrum(dleaf_t *node)
{
   return bbox_inside_frustum(node->mins, node->maxs);
}

static int node_in_frustrum(dnode_t *node)
{
	return bbox_inside_frustum(node->mins, node->maxs);
}

/////////////////////////////////////////////////////// BSP Pipeline is here

static int __fastcall CheckPortals(int src,int dest)
{	
   int i;

   for(i=dareas[src].firstareaportal;i<dareas[src].firstareaportal+dareas[src].numareaportals;i++)
   {	
	   if(dareaportals[i].otherarea==dest) return 1;	
   }
   return 0;
}

// recursively determine which nodes need exploring (so we
// don't look for polygons on _every_ node in the level)
static int __fastcall bsp_find_visible_nodes(int node)
{
   if (node >= 0) {      
	  vis_node[node] = !!(bsp_find_visible_nodes(dnodes[node].children[0])
                       | bsp_find_visible_nodes(dnodes[node].children[1]));
      return vis_node[node];
   }
   else {
      int c;

	  node = ~node;

	  if(dleafs[node].contents&CONTENTS_SOLID) return 0;

	  c = dleafs[node].cluster;

	  // Check that the leaf is not linked to us through a portal
	  if(CheckPortals(dleafs[CurrentLeaf].area,dleafs[node].area)) 
      {
          vis_cluster[c>>3] &= ~(1 << (c & 7));
          return 0;
      }
	  
	  return (vis_cluster[c >> 3] & (1 << (c & 7)));
   }
}

static int visit_visible_leaves(PVPoint *cam_loc)
{
	int n, v, i,j;
	byte *visdata;	
	 
   n = find_leaf( cam_loc );
   CurrentLeaf=n;   
	 
   if (n == 0 || dleafs[n].cluster < 0)
		 return 0;

   if((dleafs[CurrentLeaf].cluster==dleafs[OldLeaf].cluster)&&(OldLeaf!=0)) return 1;

   memset( vis_cluster,0,(numleafs+7)>>3 );
	 
   visdata = (byte*)dvis + dvis->bitofs[ dleafs[n].cluster ][DVIS_PVS];
   v = 0;
   for (i = 0; i < dvis->numclusters; ) {
		 if (visdata[v] == 0) {
			 i += 8 * visdata[v+1];    // skip some leaves
			 v += 2;
		 } else {
			 for (j = 0; j <8; j++,i++)	{
				 if (visdata[v] & (1<<j) )
					 vis_cluster[i>>3] |= (1 << (i & 7));
			 }
			 v++;
		 }
   }
   
   return 1;
}

static void render_node_faces(int node, int side)
{
   int i,n,f;
   n = dnodes[node].numfaces;
   f = dnodes[node].firstface;
   
   for (i=0; i < n; ++i) 
   {
		 if (dfaces[f].side == side)
         {
             // Emitting face to Panard Vision
			 if(!(texinfo[dfaces[f].texinfo].flags&(SURF_SKY|SURF_SKIP)))			 
             if(PV_ClipFaceToFrustum(&CurrentMesh->Face[f]))
             {                				
				 CurrentMesh->Visible[CurrentMesh->NbrVisibles++]=&CurrentMesh->Face[f];
             }
         }
      ++f;
   }
}

static void __fastcall bsp_render_node(int node,PVPoint *loc)
{
	if (vis_node[node]) {
        if (node_in_frustrum(&dnodes[node]))
		if (point_plane_test(loc, &dplanes[dnodes[node].planenum])) {
          if(dnodes[node].children[0]>=0) bsp_render_node(dnodes[node].children[0],loc);
          render_node_faces(node, 1);
	      if(dnodes[node].children[1]>=0) bsp_render_node(dnodes[node].children[1],loc);
       } else {
          if(dnodes[node].children[1]>=0) bsp_render_node(dnodes[node].children[1],loc);
          render_node_faces(node, 0);
          if(dnodes[node].children[0]>=0) bsp_render_node(dnodes[node].children[0],loc);
       }	
   }
}

static int PVAPI BSPPipe(PVMesh *m)
{
   PVWorld *w=m->Owner;
   unsigned i,j;
   int n,c;
	
   CurrentMesh=m;
   
   if (!visit_visible_leaves(&w->Camera->pos)) {
      memset(vis_cluster, 255, sizeof(vis_cluster));
   }
   
   if((dleafs[CurrentLeaf].cluster!=dleafs[OldLeaf].cluster)||(OldLeaf==0)) bsp_find_visible_nodes((int)dmodels[0].headnode);
   OldLeaf=CurrentLeaf;

   bsp_render_node( (int)dmodels[0].headnode,&w->Camera->pos);   

   // Render sub models
   for(i=1;i<nummodels;i++)
   {
	   if(bboxf_inside_frustum(dmodels[i].mins,dmodels[i].maxs))
	   {
		   // No bsp walk ?
		   // render as-is if bbox inside visible leaf
		   PVPoint p;		              

           p.xf=dmodels[i].mins[0];
		   p.yf=-dmodels[i].mins[2];
		   p.zf=-dmodels[i].mins[1];
		   n=find_leaf(&p);
		   c=dleafs[n].cluster;                   
		   if(!(vis_cluster[c >> 3] & (1 << (c & 7))))
		   {
				p.xf=dmodels[i].maxs[0];
				p.yf=-dmodels[i].maxs[2];
				p.zf=-dmodels[i].maxs[1];	
				n=find_leaf(&p);
				c=dleafs[n].cluster;                        
                if(!(vis_cluster[c >> 3] & (1 << (c & 7)))) continue;
		   }
		   
		   for(j=dmodels[i].firstface;j<dmodels[i].firstface+dmodels[i].numfaces;j++)
		   {
			   if(!(texinfo[dfaces[j].texinfo].flags&(SURF_SKIP|SURF_SLICK)))			 
			   if(PV_ClipFaceToFrustum(&CurrentMesh->Face[j]))
				{                
						CurrentMesh->Visible[CurrentMesh->NbrVisibles++]=&CurrentMesh->Face[j];
				}
		   }
	   }

   }

   return MESH_FRUSTUM_CLIPPED;								// Tells PV to finsih clipping
}

////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////  Here is the driver code
////////////////////////////////////////////////////////////////////////////

static int CreateBigMeshWithPolys(PVWorld *w)
{
    unsigned i,j,cf,k;
    int edge;
    PVMesh *m;
    unsigned Poly[32],V[MAX_VERTICES_PER_POLY]; // up to 32 vertices per poly

	m=PV_SimpleCreateMesh(numfaces,numvertexes,2000,NBR_CLIP_VERTEX);
    if(m==NULL) return NO_MEMORY;
    
	PV_SetMeshName(m,"Quake2 world");

    // Init Vertex Array
    for(i=0;i<numvertexes;i++)
    {
        m->Vertex[i].xf=dvertexes[i].point[0];
        m->Vertex[i].yf=-dvertexes[i].point[2];
        m->Vertex[i].zf=-dvertexes[i].point[1];
        m->Vertex[i].Flags=0;
		m->Pivot.xf+=dvertexes[i].point[0];
        m->Pivot.yf+=-dvertexes[i].point[2];
        m->Pivot.zf+=-dvertexes[i].point[1];
    }
	m->Pivot.xf/=numvertexes;
	m->Pivot.yf/=numvertexes;
	m->Pivot.zf/=numvertexes;

    // Fill Face array
    for(i=0;i<numfaces;i++)
    {
        cf=0;
        for(j=dfaces[i].firstedge;j<dfaces[i].firstedge+dfaces[i].numedges;j++)
        {
            edge=dsurfedges[j];
            if (edge<0)
            {
                Poly[cf++]=dedges[-edge].v[1];
		    }
            else
            {
                Poly[cf++]=dedges[edge].v[0];
			}
            if(cf==MAX_VERTICES_PER_POLY) break;

        }

        // Invert normal
        for(j=0;j<cf;j++) V[cf-j-1]=Poly[j];

		PV_SetVerticesToFace(&m->Face[i],V,cf);

		m->Face[i].NbrVertices=dfaces[i].numedges;        
        m->Face[i].Material=NULL;

        m->Face[i].MaterialInfo=MatIndex[dfaces[i].texinfo];
        m->Face[i].Father=m;
		
		// TRICK: setup a texture basis, but tell PV to use it ONLY when it's not a sky
		PV_AttachTextureBasis(&m->Face[i],BasIndex[dfaces[i].texinfo]);

		if(!(texinfo[dfaces[i].texinfo].flags&(SURF_SKY)))
		{			
			m->Face[i].Flags|=TEXTURE_BASIS;
		}        
		// m->Face[i].Flags|=POLYGON_PLANAR;

		// Resize texture basis if needed
/*		if(m->Face[i].MaterialInfo!=NULL)
		if(m->Face[i].MaterialInfo->UserData)
		{
			float f;
			miptex_t *mip;
			dmiptexlump_t *mtl = (dmiptexlump_t *) dtexdata;
			unsigned h;

			mip = (miptex_t *) (dtexdata + mtl->dataofs[texinfo[dfaces[i].texinfo].miptex]);
			f=(float)m->Face[i].MaterialInfo->Tex[0].Width/(float)mip->width;
			for(h=0;h<4;h++) m->Face[i].TexBasis->SBasis[h]*=f;

			f=(float)m->Face[i].MaterialInfo->Tex[0].Height/(float)mip->height;
			for(h=0;h<4;h++) m->Face[i].TexBasis->TBasis[h]*=f;
		}*/

        // Here we got a face that as two many edges
		// We should split it into two or more faces
		// But that's pretty rare, and I'm lazzy :)
        if(m->Face[i].NbrVertices>MAX_VERTICES_PER_POLY)
        {
            printf("WARNING: Too many edges, %u for face %u, forgetting some...\n",m->Face[i].NbrVertices,i);
        	m->Face[i].NbrVertices=MAX_VERTICES_PER_POLY;		// Keep number of edges acceptable
        }

		// Lightmaps stuff
        if(LightMapping)
        {
            PV_AttachLightMap(&m->Face[i],PV_CreateLightMapInfo());
            if((m->Face[i].LightMap!=NULL)&&(m->Face[i].MaterialInfo!=NULL))
            {
                unsigned size;

                PV_SetLightMapExtent(&m->Face[i],0,m->Face[i].LightMap);
                size=m->Face[i].LightMap->Width*m->Face[i].LightMap->Height*3;

                m->Face[i].LightMap->NbrLightMaps=0;
                m->Face[i].LightMap->Flags|=LIGHTMAP_RGB;
                m->Face[i].LightMap->CurrentLightMap=0;
                m->Face[i].LightMap->Sampling=4;        // Quake's lightmaps are 16 times undersampled
            
                for(k=0;k<1/*MAXLIGHTMAPS && dfaces[i].styles[k]!=255*/;k++)            
                {            
                    m->Face[i].LightMap->NbrLightMaps++;            
                    m->Face[i].LightMap->Maps[k]=&dlightdata[dfaces[i].lightofs+size*k];            
                }
            }
        }
    }

    m->UserPipeline=BSPPipe;				// Disable default PV's render pipe, hence there is no need to compute normals or bounding boxes
    m->Flags|=MESH_NOSORT|MESH_NOLIGHTING;  // Forget the lighting and sorting stage

	PV_AddMesh(w,m); 

	//PV_MeshBuildBoxes(m,700);
    
	return COOL;
}

static PVRGB *ZePal=NULL;
static UPVD8 ColorMap[256*256];
static void LoadPalette(char *name)
{
    FILE *f;
    unsigned i;

    if(ZePal!=NULL) pvfree(ZePal);
	ZePal=(PVRGB*)pvmalloc(256*sizeof(PVRGB));
	if(ZePal==NULL) 
	{
		printf("Out of memory to load palette\n");
		exit(1);
	}
	
	if((f=fopen(name,"rb"))==NULL) return;

    fread(ZePal,1,768,f);
    fclose(f);

    for(i=0;i<256;i++)
    {
        ZePal[i].r>>=2;
        ZePal[i].g>>=2;
        ZePal[i].b>>=2;
    }
}

static void MakeColorMap(void)
{
    unsigned i,j;
    PVRGB col;
    float ratio;

    if (PV_Mode&PVM_RGB) return;
    printf("Generating colormap (for 256 colors rendering)...\n");
    for(j=0;j<256;j++)
    {
        ratio=(float)j*2.0/255.0;
        for(i=0;i<256;i++)
        {
            col.r=(float)ZePal[i].r*ratio;
            col.g=(float)ZePal[i].g*ratio;
            col.b=(float)ZePal[i].b*ratio;

            if(col.r>63) col.r=63;
            if(col.g>63) col.g=63;
            if(col.b>63) col.b=63;

            ColorMap[i*256+j]=PV_LookClosestColor(ZePal,col,0);
        }
    }
}

static void LoadPCX (byte *raw, byte **pic, byte **palette, int *width, int *height,int len)
{
	pcx_t	*pcx;
	int		x, y,i;
	//int		len;
	int		dataByte, runLength;
	byte	*out, *pix;

	//
	// load the file
	//
	//len = LoadFile (filename, (void **)&raw);

	//
	// parse the PCX file
	//
	pcx = (pcx_t *)raw;
	raw = &pcx->data;

	pcx->xmin = LittleShort(pcx->xmin);
	pcx->ymin = LittleShort(pcx->ymin);
	pcx->xmax = LittleShort(pcx->xmax);
	pcx->ymax = LittleShort(pcx->ymax);
	pcx->hres = LittleShort(pcx->hres);
	pcx->vres = LittleShort(pcx->vres);
	pcx->bytes_per_line = LittleShort(pcx->bytes_per_line);
	pcx->palette_type = LittleShort(pcx->palette_type);

	if (pcx->manufacturer != 0x0a
		|| pcx->version != 5
		|| pcx->encoding != 1
		|| pcx->bits_per_pixel != 8
		|| pcx->xmax >= 640
		|| pcx->ymax >= 480)
		Error ("Bad pcx file");
	
	if (palette)
	{
		*palette = malloc(768);
		memcpy (*palette, (byte *)pcx + len - 768, 768);
		for(i=0;i<768;i++) (*palette)[i]>>=2;
	}

	if (width)
		*width = pcx->xmax+1;
	if (height)
		*height = pcx->ymax+1;

	if (!pic)
		return;

	out = malloc ( (pcx->ymax+1) * (pcx->xmax+1) );
	if (!out)
		Error ("Skin_Cache: couldn't allocate");

	*pic = out;

	pix = out;

	for (y=0 ; y<=pcx->ymax ; y++, pix += pcx->xmax+1)
	{
		for (x=0 ; x<=pcx->xmax ; )
		{
			dataByte = *raw++;

			if((dataByte & 0xC0) == 0xC0)
			{
				runLength = dataByte & 0x3F;
				dataByte = *raw++;
			}
			else
				runLength = 1;

			while(runLength-- > 0)
				pix[x++] = dataByte;
		}

	}

	if ( raw - (byte *)pcx > len)
		Error ("PCX file was malformed");

	//free (pcx);
}

static void InitMatIndex(PVWorld *w)
{
    unsigned i;
    float bass[4],bast[4],t;
	
	char name[256];
	pcx_t *pcxfile;
	int pcxh,pcxw;
	char *pcxpal;
	char *pcxdata;

    memset(BasIndex,0,sizeof(BasIndex));
	
	for(i=0;i<numtexinfo;i++)
    {        
		memcpy(bass,texinfo[i].vecs[0],sizeof(bass));
        memcpy(bast,texinfo[i].vecs[1],sizeof(bast));

        t=bass[2];
        bass[2]=-bass[1];
        bass[1]=-t;
        t=bast[2];
        bast[2]=-bast[1];
        bast[1]=-t;

        BasIndex[i]=PV_CreateTextureBasis(bass,bast);
    }

	// Sky materials
	if(skyname[0]=='\0') return;

	strcpy(name,"env/");
	strcat(name,skyname);
	strcat(name,"ft.pcx");	
	strlwr(name);

	pcxfile=(pcx_t*)OpenPakFile(name);
	if(pcxfile==NULL) return;
	LoadPCX((byte*)pcxfile,&pcxdata,&pcxpal,&pcxw,&pcxh,GetPakFileSize(name));	

	SkyMats[0]=PV_CreateMaterial(Q2SKY_MATNAME,NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
	PV_SetMaterialTexture(SkyMats[0],pcxw,pcxh,pcxdata,(PVRGB*)pcxpal);
	SkyMats[0]->RepeatU=TEXTURE_CLAMP;
	SkyMats[0]->RepeatV=TEXTURE_CLAMP;
	SkyMats[0]->ZWrite=0;
	ClosePakFile((char*)pcxfile);

	strcpy(name,"env/");
	strcat(name,skyname);
	strcat(name,"bk.pcx");	
	strlwr(name);

	pcxfile=(pcx_t*)OpenPakFile(name);
	if(pcxfile==NULL) return;
	LoadPCX((byte*)pcxfile,&pcxdata,&pcxpal,&pcxw,&pcxh,GetPakFileSize(name));	

	SkyMats[1]=PV_CreateMaterial(Q2SKY_MATNAME,NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
	PV_SetMaterialTexture(SkyMats[1],pcxw,pcxh,pcxdata,(PVRGB*)pcxpal);
	SkyMats[1]->RepeatU=TEXTURE_CLAMP;
	SkyMats[1]->RepeatV=TEXTURE_CLAMP;
	SkyMats[1]->ZWrite=0;
	ClosePakFile((char*)pcxfile);

	strcpy(name,"env/");
	strcat(name,skyname);
	strcat(name,"lf.pcx");	
	strlwr(name);

	pcxfile=(pcx_t*)OpenPakFile(name);
	if(pcxfile==NULL) return;
	LoadPCX((byte*)pcxfile,&pcxdata,&pcxpal,&pcxw,&pcxh,GetPakFileSize(name));	

	SkyMats[3]=PV_CreateMaterial(Q2SKY_MATNAME,NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
	PV_SetMaterialTexture(SkyMats[3],pcxw,pcxh,pcxdata,(PVRGB*)pcxpal);
	SkyMats[3]->RepeatU=TEXTURE_CLAMP;
	SkyMats[3]->RepeatV=TEXTURE_CLAMP;
	SkyMats[3]->ZWrite=0;
	ClosePakFile((char*)pcxfile);

	strcpy(name,"env/");
	strcat(name,skyname);
	strcat(name,"rt.pcx");	
	strlwr(name);

	pcxfile=(pcx_t*)OpenPakFile(name);
	if(pcxfile==NULL) return;
	LoadPCX((byte*)pcxfile,&pcxdata,&pcxpal,&pcxw,&pcxh,GetPakFileSize(name));	

	SkyMats[2]=PV_CreateMaterial(Q2SKY_MATNAME,NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
	PV_SetMaterialTexture(SkyMats[2],pcxw,pcxh,pcxdata,(PVRGB*)pcxpal);
	SkyMats[2]->RepeatU=TEXTURE_CLAMP;
	SkyMats[2]->RepeatV=TEXTURE_CLAMP;
	SkyMats[2]->ZWrite=0;
	ClosePakFile((char*)pcxfile);

	strcpy(name,"env/");
	strcat(name,skyname);
	strcat(name,"up.pcx");	
	strlwr(name);

	pcxfile=(pcx_t*)OpenPakFile(name);
	if(pcxfile==NULL) return;
	LoadPCX((byte*)pcxfile,&pcxdata,&pcxpal,&pcxw,&pcxh,GetPakFileSize(name));	

	SkyMats[4]=PV_CreateMaterial(Q2SKY_MATNAME,NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
	PV_SetMaterialTexture(SkyMats[4],pcxw,pcxh,pcxdata,(PVRGB*)pcxpal);
	SkyMats[4]->RepeatU=TEXTURE_CLAMP;
	SkyMats[4]->RepeatV=TEXTURE_CLAMP;
	SkyMats[4]->ZWrite=0;
	ClosePakFile((char*)pcxfile);

	strcpy(name,"env/");
	strcat(name,skyname);
	strcat(name,"dn.pcx");	
	strlwr(name);

	pcxfile=(pcx_t*)OpenPakFile(name);
	if(pcxfile==NULL) return;
	LoadPCX((byte*)pcxfile,&pcxdata,&pcxpal,&pcxw,&pcxh,GetPakFileSize(name));	

	SkyMats[5]=PV_CreateMaterial(Q2SKY_MATNAME,NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
	PV_SetMaterialTexture(SkyMats[5],pcxw,pcxh,pcxdata,(PVRGB*)pcxpal);
	SkyMats[5]->RepeatU=TEXTURE_CLAMP;
	SkyMats[5]->RepeatV=TEXTURE_CLAMP;
	SkyMats[5]->ZWrite=0;
	ClosePakFile((char*)pcxfile);

	PV_AddMaterial(w,SkyMats[0]);
	PV_AddMaterial(w,SkyMats[1]);
	PV_AddMaterial(w,SkyMats[2]);
	PV_AddMaterial(w,SkyMats[3]);
	PV_AddMaterial(w,SkyMats[4]);
	PV_AddMaterial(w,SkyMats[5]);
}

static int CreateMaterials(PVWorld *w)
{
    unsigned i,j;
    PVMaterial *m;
    texinfo_t *mip;
	PVTexture *nmip;
	char walname[4096];
	miptex_t *tex;
	int MaxMip;
    char Lighted;
	
	printf("Setting up textures ...\n");
	
	for(i=0;i<numtexinfo;i++)
	{
		mip=&texinfo[i];

		if(mip->flags&SURF_SKY) continue;
		if(mip->flags&SURF_NODRAW) continue;
		if(mip->flags&SURF_SKY) continue;
		if(mip->flags&SURF_SKIP) continue;

		// Lighted ?
		Lighted=1; 
		if(mip->flags&SURF_SKY) Lighted=0;
		if(mip->flags&SURF_WARP) Lighted=0;
		if(mip->flags&SURF_TRANS33) Lighted=0;
		if(mip->flags&SURF_TRANS66) Lighted=0;
		if(mip->flags&SURF_FLOWING) Lighted=0;
		if(LightMapping==0) Lighted=0;
		
		// normal textures
		strcpy(walname,"textures/");
		strcat(walname,mip->texture);
		strcat(walname,".wal");
		strlwr(walname);
		tex=(miptex_t*)OpenPakFile(walname);		
		if(tex==NULL) return FILE_IOERROR;

		// Some materials should not have lightmaps
		if(MipTex)
		{
			if(!Lighted)
				m=PV_CreateMaterial("",NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR|ZBUFFER,TEXTURE_PALETIZED8|TEXTURE_MIPMAP|TEXTURE_BILINEAR|TEXTURE_MANUALMIPMAPS,4);
			else
				m=PV_CreateMaterial("",LIGHTMAP|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR|ZBUFFER,TEXTURE_PALETIZED8|TEXTURE_MIPMAP|TEXTURE_BILINEAR|TEXTURE_MANUALMIPMAPS,4);
		}
		else
		{				
			if(!Lighted)
				m=PV_CreateMaterial("",NOTHING|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR|ZBUFFER,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
			else
				m=PV_CreateMaterial("",LIGHTMAP|MAPPING|PERSPECTIVE|AUTOMATIC_BILINEAR|ZBUFFER,TEXTURE_PALETIZED8|TEXTURE_BILINEAR,1);
		}
		if(m==NULL) return NO_MEMORY;				

		// Special fx
		if(mip->flags&(SURF_TRANS33|SURF_WARP)) 
		{
			m->BlendRgbSrcFactor=BLEND_SRC_ALPHA;
			m->BlendRgbDstFactor=BLEND_ONE_MINUS_SRC_ALPHA;
			m->AlphaConstant=0.33;
			m->Type|=BLENDING;
		}
		if(mip->flags&(SURF_TRANS66)) 
		{
			m->BlendRgbSrcFactor=BLEND_SRC_ALPHA;
			m->BlendRgbDstFactor=BLEND_ONE_MINUS_SRC_ALPHA;
			m->AlphaConstant=0.66;
			m->Type|=BLENDING;
		}

		// Setup memory managment
		m->TextureFlags|=TEXTURE_TEX_DONT_FREE;

		if(MipTex) MaxMip=4; else MaxMip=1;

		for(j=0;j<MaxMip;j++)
		{
			// Make all textures with size power of 2 (by reducing them if needed)
			nmip=PV_MipResample((UPVD8*)tex+tex->offsets[j],tex->width>>j,tex->height>>j, 0,TEXTURE_PALETIZED8,ZePal,0);
			if(nmip==NULL) return NO_MEMORY;

			// Set some form of resize flag for resizing texture basis vectors	
			if((tex->width!=nmip->Width)||(tex->height!=nmip->Height)) 
			{
				m->UserData=1;
			}

			if(j==0)
				PV_SetMaterialTexture(m,nmip->Width,nmip->Height,nmip->Texture,ZePal);
			else
				PV_SetMaterialMipMap(m,j,nmip->Texture);		
		}


		MatIndex[i]=m;

        // Setup the colormap table in case of paletized rendering or RGB16 rendering
		m->Type|=COLORTABLE_DONT_FREE;
		m->PaletteTranscodeTable=ColorMap;			

		// Hint for hardware
		if(!HiQual)	m->Hint.Quality=PHQ_LOW;     
               
        PV_AddMaterial(w,m);
	}

    return COOL;
}

/////////////////////////////////////////////////////////////////////// Driver API

static int	LoadBSPFileFromMemory (dheader_t *header);
int PVAPI LoadMeshesFromQuake2(char *name,PVWorld *Wor)
{
    int hr;
	char *l,*l2,*l3,*stopstring;
	double ang;
	char tmp[4096];
	unsigned i;
	
	//////////////////////// Setup driver 
	for(i=0;i<MAX_PAK_FILES;i++)
	{
		sprintf(tmp,"pakfile%u",i);
		l=iniReadStringKey("qk2read.ini","GENERAL",tmp);
		
		if((i==0)&&(l==NULL))
			PV_Fatal("You must specify a .PAK file in qk2read.ini",0);

		if(l!=NULL)
		{
			if(InitPakFS(l))
			{
				printf("Pak: %s not found !!!\n",l);
			}
			else printf("Added pak %s\n",l);
		}
	}

	HiQual=iniReadIntKey("qk2read.ini","GENERAL","hiquality");
	MipTex=iniReadIntKey("qk2read.ini","GENERAL","mipmap");
	LightMapping=iniReadIntKey("qk2read.ini","GENERAL","lightmaps");

	/////////////////////// Try to load the bsp from the pak first
	strcpy(tmp,"maps/");
	strcat(tmp,name);
	l=OpenPakFile(tmp);
	if(l!=NULL)
	{				
		printf("Loaded %s from pak file\n",tmp);
		if(LoadBSPFileFromMemory((dheader_t*)l)) return ARG_INVALID;
	}
	else if(LoadBSPFile(name)) return ARG_INVALID;
	
	PrintBSPFileSizes();

    // Stats
    if(lightdatasize==0) LightMapping=0;

	if(HiQual) printf("Using high quality textures\n");
	else printf("Using low quality textures\n");
	
	if(MipTex) printf("Using mipmapped textures\n");
	else printf("Using no mipmaps\n");

	if(LightMapping) printf("Using lightmaps\n");
	else printf("No lightmaps\n");


	/////////////////////// Palette stuff
	LoadPalette("q2pal.lmp");    
    PV_GammaCorrectPal(ZePal,1.9);
    for(i=0;i<lightdatasize/3;i++)
        PV_GammaCorrectCol(&dlightdata[i*3],1.9);
    MakeColorMap();    

    PV_SetPerspectiveMipBias(2.0); // Agressive MipMapping !

    Wor->Global256Palette=ZePal;

	////////////////////// Retrieves sky name
	l=dentdata;
	l=strstr(l,"sky");
	if(l!=NULL)
	{
		l=l+6;
		i=0;
		while((*l)!='\"') {skyname[i++]=(*l); l++;}
		skyname[i]='\0';
	}

	/////////////////////// Material Stuff    
	InitMatIndex(Wor);
    if((hr=CreateMaterials(Wor))!=COOL) return hr;

    PV_SetPerspectiveMipBias(2.0); // Agressive MipMapping !
	PV_SetMode(PV_Mode|PVM_ALPHABLENDING|PVM_ZBUFFER);

	////////////////////// Setup camera at player starting point
	l=dentdata;
	while((l=strstr(l,"{"))!=NULL)
	{		
		l3=l;
		l2=strstr(l,"}");

		l=strstr(l3,"info_player_start");
		if(l!=NULL)
		{
			if(l>l2) 
			{
				l=l2;
				continue;
			}
		}
		
		l=strstr(l3,"target");
		if(l!=NULL)
		{
			// Skip starting point with target
			if(l<l2) 
			{
				l=l2;
				continue;
			}
		}
		l=strstr(l3,"origin");

		l+=9;
		Wor->Camera->pos.xf=strtod(l,&stopstring);
		
		l=++stopstring;
		Wor->Camera->pos.zf=strtod(l,&stopstring);
		l=++stopstring;
		Wor->Camera->pos.yf=strtod(l,&stopstring);
		Wor->Camera->pos.zf=-Wor->Camera->pos.zf;
		Wor->Camera->pos.yf=-Wor->Camera->pos.yf;

		l=strstr(l3,"angle");
		l+=8;

		ang=strtod(l,&stopstring);

		PV_SetCamAngles(Wor->Camera,ang*PI/180,0,0);		
		break;
	}
	
    ///////////////////////// Setup world
	hr=CreateBigMeshWithPolys(Wor);	
	PV_AddMesh(Wor,CreateSkyBox(dmodels[0].mins,dmodels[0].maxs,SkyMats));	// Add the sky after, so it will be rendered BEFORE the world
	
	ClosePakFS();

	return hr;
}

void PVAPI UpdateQuake2World(PVWorld *w)
{
	PVMesh *m;

	if(w==NULL) return;
	if(w->Camera==NULL) return;

	// Make the sky box follow the player
	m=PV_GetMeshPtr(w,Q2SKY_MESHNAME);
	if(m!=NULL)
	{
		m->Position=w->Camera->pos;
	}

	// Add additional triggering code here
/*    m=PV_GetMeshPtr(w,"Quake2 world");
	if(m!=NULL)
	{
		unsigned i;

        for(i=0;i<m->NbrFaces;i++)
        {
            m->Face[i].LightMap->CurrentLightMap++;
            if(m->Face[i].LightMap->CurrentLightMap>=m->Face[i].LightMap->NbrLightMaps)
                m->Face[i].LightMap->CurrentLightMap=0;
        }
	}*/
}

///////////////////////////////////////////////////////////////////////////////////

int CopyLump (int lump, void *dest, int size);
void SwapBSPFile (qboolean todisk);
extern dheader_t	*header;
static int	LoadBSPFileFromMemory (dheader_t *head)
{
	int			i;
	
// swap the header
	header=head;
	for (i=0 ; i< sizeof(dheader_t)/4 ; i++)
		((int *)header)[i] = LittleLong ( ((int *)header)[i]);

	if (header->ident != IDBSPHEADER) return 1;
		//Error ("the memory image is not a IBSP file");
	if (header->version != BSPVERSION) return 1;
		//Error ("Memory image is version %i, not %i", header->version, BSPVERSION);

	nummodels = CopyLump (LUMP_MODELS, dmodels, sizeof(dmodel_t));
	numvertexes = CopyLump (LUMP_VERTEXES, dvertexes, sizeof(dvertex_t));
	numplanes = CopyLump (LUMP_PLANES, dplanes, sizeof(dplane_t));
	numleafs = CopyLump (LUMP_LEAFS, dleafs, sizeof(dleaf_t));
	numnodes = CopyLump (LUMP_NODES, dnodes, sizeof(dnode_t));
	numtexinfo = CopyLump (LUMP_TEXINFO, texinfo, sizeof(texinfo_t));
	numfaces = CopyLump (LUMP_FACES, dfaces, sizeof(dface_t));
	numleaffaces = CopyLump (LUMP_LEAFFACES, dleaffaces, sizeof(dleaffaces[0]));
	numleafbrushes = CopyLump (LUMP_LEAFBRUSHES, dleafbrushes, sizeof(dleafbrushes[0]));
	numsurfedges = CopyLump (LUMP_SURFEDGES, dsurfedges, sizeof(dsurfedges[0]));
	numedges = CopyLump (LUMP_EDGES, dedges, sizeof(dedge_t));
	numbrushes = CopyLump (LUMP_BRUSHES, dbrushes, sizeof(dbrush_t));
	numbrushsides = CopyLump (LUMP_BRUSHSIDES, dbrushsides, sizeof(dbrushside_t));
	numareas = CopyLump (LUMP_AREAS, dareas, sizeof(darea_t));
	numareaportals = CopyLump (LUMP_AREAPORTALS, dareaportals, sizeof(dareaportal_t));

	visdatasize = CopyLump (LUMP_VISIBILITY, dvisdata, 1);
	lightdatasize = CopyLump (LUMP_LIGHTING, dlightdata, 1);
	entdatasize = CopyLump (LUMP_ENTITIES, dentdata, 1);

	CopyLump (LUMP_POP, dpop, 1);

	free (header);		// everything has been copied out
		
//
// swap everything
//	
	SwapBSPFile (false);

	return 0;
}

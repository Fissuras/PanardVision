/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdio.h>
#include <string.h>
#include "cmdlib.h"					// cmdlib.h must be included first because of a bug in the original q2 .h files
#include "qfiles.h"
#include "pakfile.h"
#include "pvision.h"

#ifdef __UNIX__
static char *strlwr(char *t)
{
   // convert to lower case
   unsigned i=0;
   while(t[i]!=0) {if((t[i]>=97-32)&&(t[i]<=122-32)) t[i]+=32;i++;}
}

#endif

static dpackfile_t PakDirectory[MAX_PAK_FILES][MAX_FILES_IN_PACK];
static unsigned NumPackFiles=0,NumDPEntries[MAX_PAK_FILES];
static FILE *pak[MAX_PAK_FILES];
static char PakName[MAX_PAK_FILES][4096];

int InitPakFS(char *pakfile)
{	
	dpackheader_t header;
	unsigned i;
	char *y;

	if(pakfile==NULL) return 0;
	if(NumPackFiles==MAX_PAK_FILES) return -1;

	pak[NumPackFiles]=fopen(pakfile,"rb");
	if(pak[NumPackFiles]==NULL) return -1;
	
	strcpy(PakName[NumPackFiles],pakfile);
	y=strrchr(PakName[NumPackFiles],'\\');
	if(y==NULL) y=strrchr(PakName[NumPackFiles],'/');
	*(y+1)='\0';

	fread(&header,sizeof(header),1,pak[NumPackFiles]);

	header.ident=LittleLong(header.ident);
	header.dirofs=LittleLong(header.dirofs);
	header.dirlen=LittleLong(header.dirlen);

	if(header.ident!=IDPAKHEADER)
	{		
		printf("FATAL: PAK file format not recognized !");
		exit(1);
	}

	fseek(pak[NumPackFiles],header.dirofs,SEEK_SET);

	NumDPEntries[NumPackFiles]=header.dirlen/sizeof(dpackfile_t);

	printf("PAKStats: %u lumps in %s\n",NumDPEntries[NumPackFiles],pakfile);

	fread(&PakDirectory[NumPackFiles],sizeof(dpackfile_t),NumDPEntries[NumPackFiles],pak[NumPackFiles]);
	for(i=0;i<NumDPEntries[NumPackFiles];i++)
	{
		PakDirectory[NumPackFiles][i].filepos=LittleLong(PakDirectory[NumPackFiles][i].filepos);
		PakDirectory[NumPackFiles][i].filelen=LittleLong(PakDirectory[NumPackFiles][i].filelen);
		strlwr(PakDirectory[NumPackFiles][i].name);
	}
	
	NumPackFiles++;
	return 0;
}

void ClosePakFS(void)
{
	unsigned i;

	for(i=0;i<NumPackFiles;i++) fclose(pak[i]);
	NumPackFiles=0;
}

char *OpenPakFile(char *name)
{
	unsigned i,end,j;
	char tmp[4096];
	FILE *ak;
	char *block;
			
	for(j=0;j<NumPackFiles;j++)
	{
		for(i=0;i<NumDPEntries[j];i++)
		{		
			if(strcmp(name,PakDirectory[j][i].name)==0)
			{
				block=(char*)malloc(PakDirectory[j][i].filelen);
				if(block==NULL) return NULL;

				fseek(pak[j],PakDirectory[j][i].filepos,SEEK_SET);

				fread(block,PakDirectory[j][i].filelen,1,pak[j]);

				return block;
			}
		}
	}

	for(j=0;j<NumPackFiles;j++)
	{
		strcpy(tmp,PakName[j]);
		strcat(tmp,name);
		
		ak=fopen(tmp,"rb");
		if(ak==NULL)
		{
			if(j==NumPackFiles-1)
			{
				PV_Log("qk2read.log","Unable to open %s\n",tmp);
				return NULL;
			}
			else
			{
				continue;
			}
		}
		
		fseek (ak, 0, SEEK_END);
		end = ftell (ak);
		fseek (ak, 0, SEEK_SET);

		block=(char*)malloc(end);
		if(block==NULL) return NULL;

		fread(block,end,1,ak);
		
		fclose(ak);
	}

	return block;
}

int GetPakFileSize(char *name)
{
	unsigned i,j;

	for(j=0;j<NumPackFiles;j++)
	{
		for(i=0;i<NumDPEntries[j];i++)
		{		
			if(strcmp(name,PakDirectory[j][i].name)==0) return PakDirectory[j][i].filelen;
		}
	}
	return -1;
}


void ClosePakFile(char *handle)
{
	free(handle);
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdio.h>
#include <string.h>

static FILE *OpenIniFile(char *name)
{
	return fopen(name,"r");
}

static void CloseIniFile(FILE *f)
{
	fclose(f);
}

int iniReadIntKey(char *inifile,char *section,char *keyname)
{
	FILE *f=OpenIniFile(inifile);
	int r=0;

	if(f==NULL) return 0;

	while(!feof(f))
	{
		char tmp[4096],tmp2[4096];

		fscanf(f,"[%s",tmp);
		tmp[strlen(tmp)-1]=0;

		if(strcmp(section,tmp)==0)
		{
			while(!feof(f))
			{
				fscanf(f,"%s",tmp);

				strcpy(tmp2,"[");
				strcat(tmp2,keyname);
				strcpy(tmp2,"]");
				if(strcmp(tmp2,tmp)==0) 
				{
					CloseIniFile(f);
					return r;
				}

				if(strstr(tmp,keyname)==tmp)
				{
					sscanf(&tmp[strlen(keyname)],"=%u",&r);
					CloseIniFile(f);
					return r;
				}
			}
		}
	}
	
	CloseIniFile(f);
	return r;
}


char *iniReadStringKey(char *inifile,char *section,char *keyname)
{
	FILE *f=OpenIniFile(inifile);

	if(f==NULL) return NULL;

	while(!feof(f))
	{
		char tmp[4096],tmp2[4096];

		fscanf(f,"[%s\n",tmp);
		tmp[strlen(tmp)-1]=0;

		if(strcmp(section,tmp)==0)
		{
			while(!feof(f))
			{
				fgets(tmp,4096,f);
				tmp[strlen(tmp)-1]=0;

				strcpy(tmp2,"[");
				strcat(tmp2,keyname);
				strcpy(tmp2,"]");
				if(strcmp(tmp2,tmp)==0) 
				{
					CloseIniFile(f);
					return NULL;
				}

				if(strstr(tmp,keyname)==tmp)
				{					
					CloseIniFile(f);
					return &tmp[strlen(keyname)+1];
				}
			}
		}
	}

	CloseIniFile(f);
	return NULL;
}

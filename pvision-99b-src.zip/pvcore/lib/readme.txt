
 The libjpeg.lib is the JPEG library from the Independent JPEG Group

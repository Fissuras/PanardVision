/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "pvmath.h"
#include "base.h"

pvVector3D pvMath::RotateVector(pvVector3D AxisV,pvVector3D V,float Theta)
{
	pvBase3 M;
	pvVector3D Ret;

	float sa=sin(Theta);
	float ca=cos(Theta);
	float ux2=AxisV.x*AxisV.x;
	float uy2=AxisV.y*AxisV.y;
	float uz2=AxisV.z*AxisV.z;

	M.Vi.x=ux2+ca*(1-ux2);
	M.Vi.y=AxisV.x*AxisV.y*(1-ca)+AxisV.z*sa;
	M.Vi.z=AxisV.x*AxisV.z*(1-ca)-AxisV.y*sa;

	M.Vj.x=AxisV.x*AxisV.y*(1-ca)-AxisV.z*sa;
	M.Vj.y=uy2+ca*(1-uy2);
	M.Vj.z=AxisV.y*AxisV.z*(1-ca)+AxisV.x*sa;

	M.Vk.x=AxisV.x*AxisV.z*(1-ca)+AxisV.y*sa;
	M.Vk.y=AxisV.y*AxisV.z*(1-ca)-AxisV.x*sa;
	M.Vk.z=uz2+ca*(1-uz2);

	Ret=M.RotateVector(V);

	return Ret;
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <memory.h>
#include "pvzip.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////

pvzfilebuf::pvzfilebuf() :
  zipfile(NULL),
  mode(0),
  own_file_descriptor(0),
  pos(0)
{ }

pvzfilebuf::~pvzfilebuf() {

  sync();
  if ( own_file_descriptor )
    close();

}

pvzfilebuf *pvzfilebuf::open( const char *name,
			    int io_mode ) {

  if ( is_open() )
    return NULL;

  char char_mode[10];
  char *p;
  memset(char_mode,'\0',10);
  p = char_mode;

  if ( io_mode & ios::in ) {
    mode = ios::in;
    *p++ = 'r';
  } else if ( io_mode & ios::app ) {
    mode = ios::app;
    *p++ = 'a';
  } else {
    mode = ios::out;
    *p++ = 'w';
  }

  if ( io_mode & ios::binary ) {
    mode |= ios::binary;
    *p++ = 'b';
  }

  // Hard code the compression level
  if ( io_mode & (ios::out|ios::app )) {
    *p++ = '9';
  }

  zipfile=unzOpen(name);
  if(zipfile==NULL) return NULL;

  
  /*if ( (file = gzopen(name, char_mode)) == NULL )
    return NULL;*/

  own_file_descriptor = 1;

  return this;

}

/*pvzfilebuf *pvzfilebuf::attach( int file_descriptor,
			      int io_mode ) {

  if ( is_open() )
    return NULL;

  char char_mode[10];
  char *p;
  memset(char_mode,'\0',10);
  p = char_mode;

  if ( io_mode & ios::in ) {
    mode = ios::in;
    *p++ = 'r';
  } else if ( io_mode & ios::app ) {
    mode = ios::app;
    *p++ = 'a';
  } else {
    mode = ios::out;
    *p++ = 'w';
  }

  if ( io_mode & ios::binary ) {
    mode |= ios::binary;
    *p++ = 'b';
  }

  // Hard code the compression level
  if ( io_mode & (ios::out|ios::app )) {
    *p++ = '9';
  }

  if ( (zipfile = gzdopen(file_descriptor, char_mode)) == NULL )   
    return NULL;

  own_file_descriptor = 0;

  return this;

}*/

pvzfilebuf *pvzfilebuf::close() {

  if ( is_open() ) {

    sync();
	unzClose(zipfile);
	zipfile=NULL;
  }

  return this;

}

int pvzfilebuf::setcurrentfile(const char *name) {

   unzCloseCurrentFile(zipfile);
   if (unzLocateFile(zipfile, name, 2) != UNZ_OK) return 1;
   if (unzOpenCurrentFile(zipfile) != UNZ_OK) return 1;

   unz_file_info fi;
   unzGetCurrentFileInfo(zipfile,&fi,NULL,0,NULL,0,NULL,0);
   filesize=fi.uncompressed_size;

   return 0; 
}

streampos pvzfilebuf::seekoff( streamoff off, ios::seek_dir dir, int which ) 
{
	if((dir==ios::beg)&&(which==ios::in))
	{
		pos=off;
		return pos;
	}

	if((dir==ios::end)&&(which==ios::in))
	{		
		pos=filesize+pos;
		return pos;
	}


	if((dir==ios::cur)&&(which==ios::in))
	{	
		pos+=off;
		return pos;
	}
  	
	return streampos(EOF);
}

int pvzfilebuf::underflow() {

  // If the file hasn't been opened for reading, error.
  if ( !is_open() || !(mode & ios::in) )
    return EOF;

  // if a buffer doesn't exists, allocate one.
  if ( !base() ) {

    if ( (allocate()) == EOF )
      return EOF;
    setp(0,0);

  } else {

    if ( in_avail() )
      return (unsigned char) *gptr();

    if ( out_waiting() ) {
      if ( flushbuf() == EOF )
	return EOF;
    }

  }

  // Attempt to fill the buffer.

  int result = fillbuf();
  if ( result == EOF ) {
    // disable get area
    setg(0,0,0);
    return EOF;
  }

  return (unsigned char) *gptr();

}

int pvzfilebuf::overflow( int c ) {

  if ( !is_open() || !(mode & ios::out) )
    return EOF;

  if ( !base() ) {
    if ( allocate() == EOF )
      return EOF;
    setg(0,0,0);
  } else {
    if (in_avail()) {
	return EOF;
    }
    if (out_waiting()) {
      if (flushbuf() == EOF)
	return EOF;
    }
  }

  int bl = blen();
  setp( base(), base() + bl);

  if ( c != EOF ) {

    *pptr() = c;
    pbump(1);

  }

  return 0;

}

int pvzfilebuf::sync() {

  if ( !is_open() )
    return EOF;

  if ( out_waiting() )
    return flushbuf();

  return 0;

}

int pvzfilebuf::flushbuf() {

  int n;
  char *q;

  q = pbase();
  n = pptr() - q;

  /*if ( gzwrite( zipfile, q, n) < n )
    return EOF; */

  setp(0,0);

  return 0;

}

int pvzfilebuf::fillbuf() {

  int required;
  char *p;

  p = base();

  required = blen();

  int t=unzReadCurrentFile(zipfile,p,required);

  if ( t <= 0) return EOF;

  setg( base(), base(), base()+t);
  

  return t;

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////

pvzfilestream_common::pvzfilestream_common() :
  ios( pvzfilestream_common::rdbuf() )
{ }

pvzfilestream_common::~pvzfilestream_common()
{ }

/*void pvzfilestream_common::attach( int fd, int io_mode ) {

  if ( !buffer.attach( fd, io_mode) )
    clear( ios::failbit | ios::badbit );
  else
    clear();

}*/

void pvzfilestream_common::open( const char *zipname, int io_mode ) {

  if ( !buffer.open( zipname, io_mode ) )
    clear( ios::failbit | ios::badbit );
  else
    clear();

}

void pvzfilestream_common::close() {

  if ( !buffer.close() )
    clear( ios::failbit | ios::badbit );

}

pvzfilebuf *pvzfilestream_common::rdbuf() {

  return &buffer;

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
     
pvzifstream::pvzifstream() :
  ios( pvzfilestream_common::rdbuf() )
{
  clear( ios::badbit );
}

pvzifstream::pvzifstream( const char *zipname, int io_mode ) :
  ios( pvzfilestream_common::rdbuf() )
{
  pvzfilestream_common::open( zipname, io_mode );

}

/*pvzifstream::pvzifstream( int fd, int io_mode ) :
  ios( pvzfilestream_common::rdbuf() )
{
  pvzfilestream_common::attach( fd, io_mode );
}*/

pvzifstream::~pvzifstream() { }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

gzfilebuf::gzfilebuf() :
  file(NULL),
  mode(0),
  own_file_descriptor(0)
{ }

gzfilebuf::~gzfilebuf() {

  sync();
  if ( own_file_descriptor )
    close();

}

gzfilebuf *gzfilebuf::open( const char *name,
			    int io_mode ) {

  if ( is_open() )
    return NULL;

  char char_mode[10];
  char *p;
  memset(char_mode,'\0',10);
  p = char_mode;

  if ( io_mode & ios::in ) {
    mode = ios::in;
    *p++ = 'r';
  } else if ( io_mode & ios::app ) {
    mode = ios::app;
    *p++ = 'a';
  } else {
    mode = ios::out;
    *p++ = 'w';
  }

  if ( io_mode & ios::binary ) {
    mode |= ios::binary;
    *p++ = 'b';
  }

  // Hard code the compression level
  if ( io_mode & (ios::out|ios::app )) {
    *p++ = '9';
  }

  if ( (file = gzopen(name, char_mode)) == NULL )
    return NULL;

  own_file_descriptor = 1;

  return this;

}

gzfilebuf *gzfilebuf::attach( int file_descriptor,
			      int io_mode ) {

  if ( is_open() )
    return NULL;

  char char_mode[10];
  char *p;
  memset(char_mode,'\0',10);
  p = char_mode;

  if ( io_mode & ios::in ) {
    mode = ios::in;
    *p++ = 'r';
  } else if ( io_mode & ios::app ) {
    mode = ios::app;
    *p++ = 'a';
  } else {
    mode = ios::out;
    *p++ = 'w';
  }

  if ( io_mode & ios::binary ) {
    mode |= ios::binary;
    *p++ = 'b';
  }

  // Hard code the compression level
  if ( io_mode & (ios::out|ios::app )) {
    *p++ = '9';
  }

  if ( (file = gzdopen(file_descriptor, char_mode)) == NULL )
    return NULL;

  own_file_descriptor = 0;

  return this;

}

gzfilebuf *gzfilebuf::close() {

  if ( is_open() ) {

    sync();
    gzclose( file );
    file = NULL;

  }

  return this;

}

int gzfilebuf::setcompressionlevel( short comp_level ) {

  return gzsetparams(file, comp_level, -2);

}

int gzfilebuf::setcompressionstrategy( short comp_strategy ) {

  return gzsetparams(file, -2, comp_strategy);

}


streampos gzfilebuf::seekoff( streamoff off, ios::seek_dir dir, int which ) {

  return streampos(EOF);

}

int gzfilebuf::underflow() {

  // If the file hasn't been opened for reading, error.
  if ( !is_open() || !(mode & ios::in) )
    return EOF;

  // if a buffer doesn't exists, allocate one.
  if ( !base() ) {

    if ( (allocate()) == EOF )
      return EOF;
    setp(0,0);

  } else {

    if ( in_avail() )
      return (unsigned char) *gptr();

    if ( out_waiting() ) {
      if ( flushbuf() == EOF )
	return EOF;
    }

  }

  // Attempt to fill the buffer.

  int result = fillbuf();
  if ( result == EOF ) {
    // disable get area
    setg(0,0,0);
    return EOF;
  }

  return (unsigned char) *gptr();

}

int gzfilebuf::overflow( int c ) {

  if ( !is_open() || !(mode & ios::out) )
    return EOF;

  if ( !base() ) {
    if ( allocate() == EOF )
      return EOF;
    setg(0,0,0);
  } else {
    if (in_avail()) {
	return EOF;
    }
    if (out_waiting()) {
      if (flushbuf() == EOF)
	return EOF;
    }
  }

  int bl = blen();
  setp( base(), base() + bl);

  if ( c != EOF ) {

    *pptr() = c;
    pbump(1);

  }

  return 0;

}

int gzfilebuf::sync() {

  if ( !is_open() )
    return EOF;

  if ( out_waiting() )
    return flushbuf();

  return 0;

}

int gzfilebuf::flushbuf() {

  int n;
  char *q;

  q = pbase();
  n = pptr() - q;

  if ( gzwrite( file, q, n) < n )
    return EOF;

  setp(0,0);

  return 0;

}

int gzfilebuf::fillbuf() {

  int required;
  char *p;

  p = base();

  required = blen();

  int t = gzread( file, p, required );

  if ( t <= 0) return EOF;

  setg( base(), base(), base()+t);

  return t;

}

gzfilestream_common::gzfilestream_common() :
  ios( gzfilestream_common::rdbuf() )
{ }

gzfilestream_common::~gzfilestream_common()
{ }

void gzfilestream_common::attach( int fd, int io_mode ) {

  if ( !buffer.attach( fd, io_mode) )
    clear( ios::failbit | ios::badbit );
  else
    clear();

}

void gzfilestream_common::open( const char *name, int io_mode ) {

  if ( !buffer.open( name, io_mode ) )
    clear( ios::failbit | ios::badbit );
  else
    clear();

}

void gzfilestream_common::close() {

  if ( !buffer.close() )
    clear( ios::failbit | ios::badbit );

}

gzfilebuf *gzfilestream_common::rdbuf() {

  return &buffer;

}
     
gzifstream::gzifstream() :
  ios( gzfilestream_common::rdbuf() )
{
  clear( ios::badbit );
}

gzifstream::gzifstream( const char *name, int io_mode ) :
  ios( gzfilestream_common::rdbuf() )
{
  gzfilestream_common::open( name, io_mode );
}

gzifstream::gzifstream( int fd, int io_mode ) :
  ios( gzfilestream_common::rdbuf() )
{
  gzfilestream_common::attach( fd, io_mode );
}

gzifstream::~gzifstream() { }

gzofstream::gzofstream() :
  ios( gzfilestream_common::rdbuf() )
{
  clear( ios::badbit );
}

gzofstream::gzofstream( const char *name, int io_mode ) :
  ios( gzfilestream_common::rdbuf() )
{
  gzfilestream_common::open( name, io_mode );
}

gzofstream::gzofstream( int fd, int io_mode ) :
  ios( gzfilestream_common::rdbuf() )
{
  gzfilestream_common::attach( fd, io_mode );
}

gzofstream::~gzofstream() { }

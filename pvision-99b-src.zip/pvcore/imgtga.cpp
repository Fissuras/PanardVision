/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "imgtga.h"

IMPLEMENT_POMIZED(pvLoadImageTGA,IMAGE_LOADERS_DOMAIN);

///////////////////////////////////////////////////////////////////////////////////////////////////////////

const char *pvLoadImageTGA::GetExtension(unsigned i)
{
	switch(i)
	{
	case 0: return "tga";
    case 1: return "targa";
	}
	return NULL;
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

/* rd_tga.c - read a TrueVision Targa file
**
** Partially based on tgatoppm.c from pbmplus (just a big hack :)
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
*/

#define getbyte() (_In->get())

typedef char ImageIDField[256];

/* Definitions for image types. */
#define TGA_Null 0
#define TGA_Map 1
#define TGA_RGB 2
#define TGA_Mono 3
#define TGA_RLEMap 9
#define TGA_RLERGB 10
#define TGA_RLEMono 11
#define TGA_CompMap 32
#define TGA_CompMap4 33

/* Definitions for interleave flag. */
#define TGA_IL_None 0
#define TGA_IL_Two 1
#define TGA_IL_Four 2

pvImageLoader::pvImageData *pvLoadImageTGA::Load(istream &in)
{
  pvLoadImageTGA::ImageHeader tga_head;
  int i;
  unsigned int temp1, temp2;
  int rows, cols, row, col, realrow, truerow, baserow;
  int maxval;
  RGBA *pixels;

  _In=&in;

  /* Read the Targa file header. */
  ReadTga (&tga_head);

  rows = ( (int) tga_head.Height_lo ) + ( (int) tga_head.Height_hi ) * 256;
  cols = ( (int) tga_head.Width_lo ) + ( (int) tga_head.Width_hi ) * 256;

  switch ( tga_head.ImgType )
  {
    case TGA_Map:
    case TGA_RGB:
    case TGA_Mono:
    case TGA_RLEMap:
    case TGA_RLERGB:
    case TGA_RLEMono:
    break;

    default:
		return NULL;
  }

  if ( tga_head.ImgType == TGA_Map ||
       tga_head.ImgType == TGA_RLEMap ||
       tga_head.ImgType == TGA_CompMap ||
       tga_head.ImgType == TGA_CompMap4 )
  { /* Color-mapped image */
    if ( tga_head.CoMapType != 1 )
    {
      return NULL;
    }
    mapped = 1;
    /* Figure maxval from CoSize. */
    switch ( tga_head.CoSize )
    {
      case 8:
      case 24:
      case 32:
        maxval = 255;
        break;

      case 15:
      case 16:
        maxval = 31;
        break;

      default:
		return NULL;
    }
  }
  else
  { /* Not colormap, so figure maxval from PixelSize. */
    mapped = 0;
    switch ( tga_head.PixelSize )
    {
      case 8:
      case 24:
      case 32:
        maxval = 255;
        break;

      case 15:
      case 16:
        maxval = 31;
        break;

      default:
		return NULL;
    }
  }

  /* If required, read the color map information. */
  if ( tga_head.CoMapType != 0 )
  {
	temp1 = tga_head.Index_lo + tga_head.Index_hi * 256;
	temp2 = tga_head.Length_lo + tga_head.Length_hi * 256;
	if ( ( temp1 + temp2 + 1 ) >= MAXCOLORS )
	{
	  return NULL;
	}
	for ( i = temp1; i < (int)( temp1 + temp2 ); ++i )
	    get_map_entry(&ColorMap[i], (int) tga_head.CoSize );
	}

    /* Check run-length encoding. */
    if ( tga_head.ImgType == TGA_RLEMap ||
	 tga_head.ImgType == TGA_RLERGB ||
	 tga_head.ImgType == TGA_RLEMono )
	rlencoded = 1;
    else
	rlencoded = 0;

    /* Read the Targa file body and convert to portable format. */
	pixels=new RGBA[cols*rows];

    truerow = 0;
    baserow = 0;
    for ( row = 0; row < rows; ++row )
    {
	realrow = truerow;
	if ( tga_head.OrgBit == 0 )
	    realrow = rows - realrow - 1;

	for ( col = 0; col < cols; ++col )
	    get_pixel( &(pixels[realrow*cols+col]), (int) tga_head.PixelSize );
	if ( tga_head.IntrLve == TGA_IL_Four )
	    truerow += 4;
	else if ( tga_head.IntrLve == TGA_IL_Two )
	    truerow += 2;
	else
	    ++truerow;
	if ( truerow >= rows )
	    truerow = ++baserow;
    }

	//// Pixels is the image
	pvImageLoader::pvImageData *p;
	p=new pvImageLoader::pvImageData;

	p->Height=rows;
	p->Width=cols;
	if(tga_head.PixelSize>24)
	{
		p->Pixels=(unsigned char*)pixels;
		p->Flags=pvImageLoader::pvidRGBA;
	}
	else
	{
		p->Pixels=new UPVD8[rows*cols*3];

		for(unsigned i=0;i<rows*cols;i++)
		{
			p->Pixels[i*3]=pixels[i].red;
			p->Pixels[i*3+1]=pixels[i].green;
			p->Pixels[i*3+2]=pixels[i].blue;
		}

		delete[] pixels;
	}
	return p;

}

void pvLoadImageTGA::ReadTga(pvLoadImageTGA::ImageHeader* tgaP)
{
    unsigned char flags;

    tgaP->IDLength = getbyte();
    tgaP->CoMapType = getbyte();
    tgaP->ImgType = getbyte();
    tgaP->Index_lo = getbyte();
    tgaP->Index_hi = getbyte();
    tgaP->Length_lo = getbyte();
    tgaP->Length_hi = getbyte();
    tgaP->CoSize = getbyte();
    tgaP->X_org_lo = getbyte();
    tgaP->X_org_hi = getbyte();
    tgaP->Y_org_lo = getbyte();
    tgaP->Y_org_hi = getbyte();
    tgaP->Width_lo = getbyte();
    tgaP->Width_hi = getbyte();
    tgaP->Height_lo = getbyte();
    tgaP->Height_hi = getbyte();
    tgaP->PixelSize = getbyte();
    flags = getbyte();
    tgaP->AttBits = flags & 0xf;
    tgaP->Rsrvd = ( flags & 0x10 ) >> 4;
    tgaP->OrgBit = ( flags & 0x20 ) >> 5;
    tgaP->IntrLve = ( flags & 0xc0 ) >> 6;

    if ( tgaP->IDLength != 0 )
	{
		_In->seekg(tgaP->IDLength,ios::cur);
	}
}

void pvLoadImageTGA::get_map_entry (RGBA* Value, int Size)
{
    unsigned char j, k, r, g, b;
    r=g=b=0; /* get rid of stupid 'might be used uninited' warning */

    /* Read appropriate number of bytes, break into rgb & put in map. */
    switch ( Size )
	{
	case 8:				/* Grey scale, read and triplicate. */
	r = g = b = getbyte();
	break;

	case 16:			/* 5 bits each of red green and blue. */
	case 15:			/* Watch for byte order. */
	j = getbyte();
	k = getbyte();
	r = ( k & 0x7C ) >> 2;
	g = ( ( k & 0x03 ) << 3 ) + ( ( j & 0xE0 ) >> 5 );
	b = j & 0x1F;
	r<<=3;
	g<<=3;
	b<<=3;
	break;

	case 32:
	case 24:			/* 8 bits each of blue green and red. */
	b = getbyte();
	g = getbyte();
	r = getbyte();
	if ( Size == 32 )
	    (void) getbyte();	/* Read alpha byte & throw away. */
	break;

	default:
	  return;
	}
    Value->red=r; Value->green=g; Value->blue=b;
}

void pvLoadImageTGA::get_pixel (RGBA* dest, int Size)
{
    static int Red, Grn, Blu;
    unsigned char j, k;
    static unsigned int l;

    /* Check if run length encoded. */
    if ( rlencoded )
	{
	if ( RLE_count == 0 )
	    { /* Have to restart run. */
	    unsigned char i;
	    i = getbyte();
	    RLE_flag = ( i & 0x80 );
	    if ( RLE_flag == 0 )
		/* Stream of unencoded pixels. */
		RLE_count = i + 1;
	    else
		/* Single pixel replicated. */
		RLE_count = i - 127;
	    /* Decrement count & get pixel. */
	    --RLE_count;
	    }
	else
	    { /* Have already read count & (at least) first pixel. */
	    --RLE_count;
	    if ( RLE_flag != 0 )
		/* Replicated pixels. */
		goto PixEncode;
	    }
	}
    /* Read appropriate number of bytes, break into RGB. */
    switch ( Size )
	{
	case 8:				/* Grey scale, read and triplicate. */
	Red = Grn = Blu = l = getbyte();
	break;

	case 16:			/* 5 bits each of red green and blue. */
	case 15:			/* Watch byte order. */
	j = getbyte();
	k = getbyte();
	l = ( (unsigned int) k << 8 ) + j;
	Red = ( k & 0x7C ) >> 2;
	Grn = ( ( k & 0x03 ) << 3 ) + ( ( j & 0xE0 ) >> 5 );
	Blu = j & 0x1F;
	Red<<=3;
	Grn<<=3;
	Blu<<=3;
	break;

	case 32:
	case 24:			/* 8 bits each of blue green and red. */
	Blu = getbyte();
	Grn = getbyte();
	Red = getbyte();
	if ( Size == 32 )
	    (void) getbyte();	/* Read alpha byte & throw away. */
	l = 0;
	break;

	default:
	  //set_error (IFE_BadFormat, "Unknown pixel size");
	  return;
	}

PixEncode:
    if ( mapped )
	*dest = ColorMap[l];
    else
	{dest->red=Red;dest->green=Grn;dest->blue=Blu;}
}


/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifdef WIN32
#include <windows.h>
#include <process.h>
#else
#include <pthread.h>
#include <unistd.h>
#endif
#include "pvsys.h"

#ifdef WIN32
static void __cdecl ObjectThreadRoutine(void *fpObj)
#else
static void *ObjectThreadRoutine(void *fpObj)
#endif
{ 
 ((pvThreadable *)fpObj)->RunThread();
} 

//////////////////////////////////////////////////////////////////////////////////
#ifdef WIN32
int PVAPI pvSystem::StartThread(pvThreadable *f)
{
	_beginthread(ObjectThreadRoutine,0,f);
	return 0;
}

int PVAPI pvSystem::CreateMutex(char *name)
{
	HANDLE hMutex; 

	hMutex = ::CreateMutex(NULL,FALSE,name);

	return (int)hMutex;
}

int PVAPI pvSystem::CaptureMutex(int handle,bool timeout)
{
	DWORD dwWaitResult; 

 
    dwWaitResult = WaitForSingleObject((HANDLE)handle,(timeout)?0:INFINITE);

	  switch (dwWaitResult) 
      {
         case WAIT_OBJECT_0: 
			 return 1;
                        // Cannot get mutex ownership due to time-out.
        case WAIT_TIMEOUT: 
            return 0; 

                        // Got ownership of the abandoned mutex object.
        case WAIT_ABANDONED: 
            return 1; 
      }      
}

void PVAPI pvSystem::ReleaseMutex(int handle)
{
	::ReleaseMutex((HANDLE)handle);
}

void PVAPI pvSystem::DeleteMutex(int handle)
{
	::CloseHandle((HANDLE)handle);
}

void PVAPI pvSystem::Sleep(unsigned millisecond)
{
	::Sleep(millisecond);
}
#else
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int PVAPI pvSystem::StartThread(pvThreadable *f)
{
	pthread_t t;
	pthread_create(&t,NULL,ObjectThreadRoutine,f);
	return 0;
}

int PVAPI pvSystem::CreateMutex(char *name)
{
	return 0;
}

int PVAPI pvSystem::CaptureMutex(int handle,bool timeout)
{
        return 0; 
}

void PVAPI pvSystem::ReleaseMutex(int handle)
{
}

void PVAPI pvSystem::DeleteMutex(int handle)
{
}

void PVAPI pvSystem::Sleep(unsigned millisecond)
{
	sleep(millisecond/1000);
}
#endif

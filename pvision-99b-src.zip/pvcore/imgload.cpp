/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <fstream.h>
#include "imgload.h"

#ifdef __UNIX__
#define stricmp strcasecmp
#endif

IMPLEMENT_POMIZED(pvImageLoader,"/domains/PanardVision/");

pvImageLoader::pvImageData *pvImageLoader::LoadFromFile(const char *name)
{
	char *t;

	if(name==NULL) return 0;

	t=strrchr(name,'.');
	if(t==NULL) return 0;
	t++;
	if(*t=='\0') return 0;

	pomNameServer *ns;
	pomClassInfo ci;
	
	pomGetNameServer(&ns);
	
	// Loop terrain loader domain for registered classes
	unsigned ret=POMERR_COOL;
	for(unsigned i=0;ret==POMERR_COOL;i++)
	{
		ret=ns->IterateClassesDirectory(i,ci);
		if(ret==POMERR_COOL)
		{
			if(strcmp(ci.DomainName,IMAGE_LOADERS_DOMAIN)==0)
			{
				// Loop registered extension for this loader
				psLoadImageInterface *loader=(psLoadImageInterface *)pomCreateObjectFromClass(ci.ClassName);

				if(loader!=NULL)
				{
					const char *ext;
					unsigned k=0;
					
					while((ext=loader->GetExtension(k))!=NULL)
					{						
						if(stricmp(ext,t)==0)
						{
							// openfile
							ifstream ifs(name,ios::in|ios::binary|ios::nocreate);

							if(ifs.is_open())
							{								
								pvImageLoader::pvImageData* h=loader->Load(ifs);
								delete loader;
								return h;
							}
						}
						k++;
					}
					delete loader;
				}
			}
		}
	}
	
	return NULL;
}



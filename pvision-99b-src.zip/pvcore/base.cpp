/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "base.h"

#ifndef PI
#define PI 3.141592654
#endif

pvBase3::pvBase3()
{
	Id();
}

pvBase3::pvBase3(float m[3][3])
{
	FromArray(m);
}

void pvBase3::FromArray(float m[3][3])
{
	Vi.x=m[0][0];Vi.y=m[0][1];Vi.z=m[0][2];
	Vj.x=m[1][0];Vj.y=m[1][1];Vj.z=m[1][2];
	Vk.x=m[2][0];Vk.y=m[2][1];Vk.z=m[2][2];
}

void pvBase3::Id(void)
{
	Vi.x=1;Vi.y=0;Vi.z=0;
	Vj.x=0;Vj.y=1;Vj.z=0;
	Vk.x=0;Vk.y=0;Vk.z=1;
}

void pvBase3::Rotate(float theta,float phi,float alpha)
{
	float ct,st,ca,sa,cp,sp;

	if(!((theta)||(phi)||(alpha))) return;

	ca=cos(alpha);sa=sin(alpha);
	ct=cos(theta);st=sin(theta);
	cp=cos(phi);sp=sin(phi);

	RotateVectorP(&Vi,ct,st,cp,sp,ca,sa);
	RotateVectorP(&Vj,ct,st,cp,sp,ca,sa);
	RotateVectorP(&Vk,ct,st,cp,sp,ca,sa);
}

pvVector3D pvBase3::RotateVector(const pvVector3D &P) const
{
	return Vi*P.x+Vj*P.y+Vk*P.z;
}

pvBase3 pvBase3::RotateBase(const pvBase3 &BaseInFather) const
{
	pvBase3 Ret;

	Ret.Vi=RotateVector(BaseInFather.Vi);
	Ret.Vj=RotateVector(BaseInFather.Vj);
	Ret.Vk=RotateVector(BaseInFather.Vk);

	return Ret;
}

void pvBase3::Inverse()
{
	// INVERSION D'UNE BASE!!! et non une matrice quelconque.
	float MatA[9];

	MatA[0]=Vi.x;MatA[1]=Vj.x;MatA[2]=Vk.x;
	MatA[3]=Vi.y;MatA[4]=Vj.y;MatA[5]=Vk.y;
	MatA[6]=Vi.z;MatA[7]=Vj.z;MatA[8]=Vk.z;
	// Calcul Direct de la transposee de MatA.
	Vi.x=MatA[0];Vi.y=MatA[1];Vi.z=MatA[2];
	Vj.x=MatA[3];Vj.y=MatA[4];Vj.z=MatA[5];
	Vk.x=MatA[6];Vk.y=MatA[7];Vk.z=MatA[8];
}

void pvBase3::InverseOfBase(const pvBase3 &Base)
{
	// INVERSION D'UNE BASE!!! et non une matrice quelconque.
	// Calcul Direct de la transposee de Base.
	Vi.x=Base.Vi.x;Vi.y=Base.Vj.x;Vi.z=Base.Vk.x;
	Vj.x=Base.Vi.y;Vj.y=Base.Vj.y;Vj.z=Base.Vk.y;
	Vk.x=Base.Vi.z;Vk.y=Base.Vj.z;Vk.z=Base.Vk.z;
}


void pvBase3::RotateVectorP(pvVector3D *v,float ct,float st,float cp,float sp,
	float ca,float sa)
{
	float x2,y2,z2;


	x2=ca*v->x-sa*v->y;
	y2=ca*v->y+sa*v->x;
	z2=v->z;
	v->x=x2;
	v->y=cp*y2+sp*z2;
	v->z=cp*z2-sp*y2;
	x2=ct*v->x-st*v->z;
	y2=v->y;
	z2=ct*v->z+st*v->x;
	v->x=x2;
	v->y=y2;
	v->z=z2;
	// Version optimis�e:
	/*x2=ca*v->x-sa*v->y;
	y2=ca*v->y+sa*v->x;
	v->y=cp*y2+sp*v->z;
	z=cp*v->z-sp*y2;
	v->x=ct*x2-st*z;
	v->z=ct*z+st*x2;*/
}

void pvBase3::BaseToAngles(float *theta,float *phi,float *alpha) const
{
	float T,P,A,T1,P2;
	pvBase3 Temp;

	Temp=*this;
	Temp.Vk.VectorToAngles(T,P);
	Temp.Rotate(-T,0,0);
	Temp.Rotate(0,-P,0);
	Temp.Vi.VectorToAngles(T1,P2);
	A=P2;
	if((T1>0.0)||(T1<-PI))
	{
		A=PI-P2;
	}
	// Angles en RADIANS.
	*theta=T;
	*phi=P;
	*alpha=A;
}

char pvBase3::Normalize()
{
	pvBase3 Temp;

	// Renormalisons la base.
	Temp=*this;
	Temp.Vk.Normalize();
	Temp.Vi=Temp.Vj^Temp.Vk;
	Temp.Vi.Normalize();
	Temp.Vj=Temp.Vk^Temp.Vi;
	if((Temp.Vi.IsNull())||(Temp.Vj.IsNull())||(Temp.Vk.IsNull()))
		return 0;
	*this=Temp;

	return 1;
}

void pvBase3::FromAngles(float x,float y,float z)
{
	Id();
	Rotate(x,y,z);
}

pvBase3 pvBase3::operator*(const pvBase3 &M) const
{
    pvBase3 t;

	t.Vi.x=Vi.x*M.Vi.x+Vj.x*M.Vi.y+Vk.x*M.Vi.z;
	t.Vi.y=Vi.y*M.Vi.x+Vj.y*M.Vi.y+Vk.y*M.Vi.z;
	t.Vi.z=Vi.z*M.Vi.x+Vj.z*M.Vi.y+Vk.z*M.Vi.z;

	t.Vj.x=Vi.x*M.Vj.x+Vj.x*M.Vj.y+Vk.x*M.Vj.z;
	t.Vj.y=Vi.y*M.Vj.x+Vj.y*M.Vj.y+Vk.y*M.Vj.z;
	t.Vj.z=Vi.z*M.Vj.x+Vj.z*M.Vj.y+Vk.z*M.Vj.z;

	t.Vk.x=Vi.x*M.Vk.x+Vj.x*M.Vk.y+Vk.x*M.Vk.z;
	t.Vk.y=Vi.y*M.Vk.x+Vj.y*M.Vk.y+Vk.y*M.Vk.z;
	t.Vk.z=Vi.z*M.Vk.x+Vj.z*M.Vk.y+Vk.z*M.Vk.z;

	return t;
}
 
/////////////////////////////////////////////////////////////////////////////////////////// Base4

pvBase4::pvBase4()
{
	Id();
}

void pvBase4::Id(void)
{
	pvBase3::Id();
	Vp.x=Vp.y=Vp.z=0;
}

void pvBase4::SetPosition(const pvVector3D &P)
{
	Vp.x=P.x;
	Vp.y=P.y;
	Vp.z=P.z;
}

void pvBase4::Move(const pvVector3D &P)
{
	Vp.x+=P.x;
	Vp.y+=P.y;
	Vp.z+=P.z;
}

pvVector3D pvBase4::RotatePoint(const pvVector3D &P) const
{
	return Vi*P.x+Vj*P.y+Vk*P.z+Vp;
}

pvBase4 pvBase4::RotateBase(const pvBase4 &BaseInFather) const
{
	pvBase4 Ret;

	Ret.Vi=RotateVector(BaseInFather.Vi);
	Ret.Vj=RotateVector(BaseInFather.Vj);
	Ret.Vk=RotateVector(BaseInFather.Vk);
	Ret.Vp=RotatePoint(BaseInFather.Vp);

	return Ret;
}

void pvBase4::Inverse()
{
	// INVERSION D'UNE BASE!!! et non une matrice quelconque.

	pvBase3::Inverse();

	// Calcul de la nouvelle position.
	Vp=Vi*(-Vp.x)+Vj*(-Vp.y)+Vk*(-Vp.z);
}

void pvBase4::InverseOfBase(const pvBase4 &Base)
{
	// INVERSION D'UNE BASE!!! et non une matrice quelconque.
	// Calcul Direct de la transposee de Base.
	Vi.x=Base.Vi.x;Vi.y=Base.Vj.x;Vi.z=Base.Vk.x;
	Vj.x=Base.Vi.y;Vj.y=Base.Vj.y;Vj.z=Base.Vk.y;
	Vk.x=Base.Vi.z;Vk.y=Base.Vj.z;Vk.z=Base.Vk.z;

	// Calcul de la nouvelle position.
	Vp=Vi*(-Base.Vp.x)+Vj*(-Base.Vp.y)+Vk*(-Base.Vp.z);
}

pvBase4 pvBase4::operator*(const pvBase4 &M) const
{
    pvBase4 t;

	t.Vi.x=Vi.x*M.Vi.x+Vj.x*M.Vi.y+Vk.x*M.Vi.z;
	t.Vi.y=Vi.y*M.Vi.x+Vj.y*M.Vi.y+Vk.y*M.Vi.z;
	t.Vi.z=Vi.z*M.Vi.x+Vj.z*M.Vi.y+Vk.z*M.Vi.z;

	t.Vj.x=Vi.x*M.Vj.x+Vj.x*M.Vj.y+Vk.x*M.Vj.z;
	t.Vj.y=Vi.y*M.Vj.x+Vj.y*M.Vj.y+Vk.y*M.Vj.z;
	t.Vj.z=Vi.z*M.Vj.x+Vj.z*M.Vj.y+Vk.z*M.Vj.z;

	t.Vk.x=Vi.x*M.Vk.x+Vj.x*M.Vk.y+Vk.x*M.Vk.z;
	t.Vk.y=Vi.y*M.Vk.x+Vj.y*M.Vk.y+Vk.y*M.Vk.z;
	t.Vk.z=Vi.z*M.Vk.x+Vj.z*M.Vk.y+Vk.z*M.Vk.z;

	t.Vp.Zero();

	return t;
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __LOAD_TGA_H__
#define __LOAD_TGA_H__

#include "imgload.h"

#define MAXCOLORS 16384

class PVDLL pvLoadImageTGA : public psLoadImageInterface
{
	DECLARE_POMIZED(pvLoadImageTGA);
protected:
	istream *_In;

	struct ImageHeader {
    unsigned char IDLength;		/* length of Identifier String */
    unsigned char CoMapType;		/* 0 = no map */
    unsigned char ImgType;		/* image type (see below for values) */
    unsigned char Index_lo, Index_hi;	/* index of first color map entry */
    unsigned char Length_lo, Length_hi;	/* number of entries in color map */
    unsigned char CoSize;		/* size of color map entry (15,16,24,32) */
    unsigned char X_org_lo, X_org_hi;	/* x origin of image */
    unsigned char Y_org_lo, Y_org_hi;	/* y origin of image */
    unsigned char Width_lo, Width_hi;	/* width of image */
    unsigned char Height_lo, Height_hi;	/* height of image */
    unsigned char PixelSize;		/* pixel size (8,16,24,32) */
    unsigned char AttBits;		/* 4 bits, number of attribute bits per pixel */
    unsigned char Rsrvd;		/* 1 bit, reserved */
    unsigned char OrgBit;		/* 1 bit, origin: 0=lower left, 1=upper left */
    unsigned char IntrLve;		/* 2 bits, interleaving flag */
    };

	struct RGBA
	{
		UPVD8 red,green,blue,alpha;
	};

	int mapped, rlencoded;

	RGBA ColorMap[MAXCOLORS];
	int RLE_count, RLE_flag;


	void Ld();
	void ReadTga(pvLoadImageTGA::ImageHeader* tgaP);
	void get_map_entry (RGBA* Value, int Size);
	void get_pixel (RGBA* dest, int Size);

public:
	pvLoadImageTGA() {RLE_count=RLE_flag=0;};
	pvImageLoader::pvImageData *Load(istream &in);
	const char *GetExtension(unsigned i);
	const char *GetName() {return "TARGA Loader";};
};

#endif
/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	This file contains the ZCB Format exporter plug-in for Flexporter.
 *	\file		IceZCBExporter.h
 *	\author		Pierre Terdiman
 *	\date		April, 4, 2000
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Include Guard
#ifndef __PVBEXPORTER_H__
#define __PVBEXPORTER_H__

	class PVBFormat : public ExportFormat
	{
	public:
	// Constructor/Destructor
										PVBFormat();
		virtual							~PVBFormat();

	// Exporter init
		virtual	bool					Init(bool motion);

	// Main scene info
		virtual bool					SetSceneInfo(const MainDescriptor& maininfo);

	// Export loop
				bool					ExportBasicInfo		(const ObjectDescriptor* obj, CustomArray* array);

		virtual bool					ExportCamera		(const CameraDescriptor& camera);
		virtual bool					ExportController	(const ControllerDescriptor& controller);
		virtual bool					ExportHelper		(const HelperDescriptor& helper);
		virtual bool					ExportLight			(const LightDescriptor& light);
		virtual bool					ExportMaterial		(const MaterialDescriptor& material);
		virtual bool					ExportMesh			(const MeshDescriptor& mesh);
		virtual bool					ExportMotion		(const MotionDescriptor& motion);
		virtual bool					ExportShape			(const ShapeDescriptor& shape);
		virtual bool					ExportTexture		(const TextureDescriptor& texture);

	// End of export notification
		virtual bool					EndExport(const StatsDescriptor& stats);

	private:
	// Time info local copy
				MAXTimeInfo				mTimeInfo;
	// Export arrays
				CustomArray				mGeneral;
				CustomArray				mGeomObjects;
				CustomArray				mCameras;
				CustomArray				mLights;
				CustomArray				mShapes;
				CustomArray				mHelpers;
				CustomArray				mTexmaps;
				CustomArray				mMaterials;
				CustomArray				mControllers;
				CustomArray				mMotion;
	// Flags
				bool					mIsMotionFile;

	// Export a list of points
				bool					ExportFloats(MAXPoint* points, udword nbpoints, CustomArray& array, udword nbbits, bool keeplast);
	};

#endif // __ICEZCBEXPORTER_H__

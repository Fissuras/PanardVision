/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __PVBFORMAT_H__
#define __PVBFORMAT_H__

	// Chunk versions
	#define	CHUNK_MAIN_VER			1
	#define	CHUNK_MESH_VER			1
	#define	CHUNK_LITE_VER			1
	#define	CHUNK_TEXM_VER			1
	#define	CHUNK_MATL_VER			1

	// Mesh flags.
	#define	PVB_VFACE				(1<<0)				//!< Mesh has vertex-faces.
	#define	PVB_TFACE				(1<<1)				//!< Mesh has texture-faces.
	#define	PVB_CFACE				(1<<2)				//!< Mesh has color-faces.
	#define PVB_UVW					(1<<3)				//!< UVW's are exported
	#define PVB_WDISCARDED			(1<<4)				//!< W is discarded
	#define PVB_VERTEXCOLORS		(1<<5)				//!< Vertex colors are exported
	#define	PVB_ONEBONEPERVERTEX	(1<<6)				//!< Simple skin with one driving bone/vertex
	#define	PVB_CONVEXHULL			(1<<7)				//!< The convex hull has been exported
	#define	PVB_BOUNDINGSPHERE		(1<<8)				//!< The bounding sphere has been exported
	#define	PVB_INERTIATENSOR		(1<<9)				//!< The inertia tensor has been exported
	#define	PVB_QUANTIZEDVERTICES	(1<<10)				//!< Vertices have been quantized
	#define	PVB_WORDFACES			(1<<11)				//!< Vertex references within faces are stored as words instead of dwords
	#define	PVB_COMPRESSED			(1<<12)				//!< Mesh has been saved in a compression-friendly way
	#define	PVB_EDGEVIS				(1<<13)				//!< Edge visibility has been exported

	#define	PVB_CONSOLIDATION		(1<<16)				//!< Mesh has been consolidated
	#define	PVB_FACENORMALS			(1<<17)				//!< Export normals to faces
	#define	PVB_VERTEXNORMALS		(1<<18)				//!< Export normals to vertices
	#define	PVB_NORMALINFO			(1<<19)				//!< Export NormalInfo

	// Scene flags
	#define	PVB_FILE_SCENE			0x00001000			//!< Complete 3D scene
	#define	PVB_FILE_MOTION			0x00001100			//!< Motion file

	// Controllers flags
	#define	PVB_CTRL_NONE			0					//!< No controller
	#define	PVB_CTRL_FLOAT			1					//!< Float controller
	#define	PVB_CTRL_VECTOR			2					//!< Vector controller
	#define	PVB_CTRL_QUAT			3					//!< Quaternion controller
	#define	PVB_CTRL_PR				4					//!< PR controller
	#define	PVB_CTRL_PRS			5					//!< PRS controller
	#define	PVB_CTRL_VERTEXCLOUD	6					//!< Morph controller

	#define	PVB_CTRL_SAMPLES		1					//!< Samples
	#define	PVB_CTRL_KEYFRAMES		2					//!< Keyframes

	#define	PVB_COMPRESSION_NONE	0
	#define	PVB_COMPRESSION_ZLIB	1
	#define	PVB_COMPRESSION_BZIP2	2

#endif

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	This file contains the PVB Format exporter plug-in for Flexporter.
 *	\file		PVBExport.cpp
 *	\author		Olivier Brunet
 *	\date		February, 4, 2001
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Precompiled Header
#include "Stdafx.h"
#include "pvbexport.h"
#include "pvbformat.h"

static PVBFormat		gPVBExporter;		// Gloabl exporter instance
static ExportSettings	gSettings;			// Global export settings

// FLEXPORTER Identification Callbacks

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Flexporter callback.
 *	Gives a brief exporter description. That string is displayed inside MAX, in the Options Panel.
 *	\relates	PVBFormat
 *	\fn			ExporterDescription()
 *	\return		a description string
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DLLEXPORT const char* ExporterDescription()
{ 
	return "Panard Vision Binary Exporter";
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Flexporter callback.
 *	Returns the format's extension. That string is displayed inside MAX, in the Options Panel.
 *	\relates	PVBFormat
 *	\fn			FormatExtension()
 *	\return		an extension string
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DLLEXPORT const char* FormatExtension()
{
	return "pvb";
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Flexporter callback.
 *	Returns the one and only exporter instance.
 *	\relates	PVBFormat
 *	\fn			GetExporter()
 *	\return		pointer to the global exporter instance.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DLLEXPORT ExportFormat* GetExporter()
{
	return &gPVBExporter;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Flexporter callback.
 *	Returns the default exportation settings for this format. This is the right place to initialize the default settings for your format.
 *	\relates	PVBFormat
 *	\fn			GetDefaultSettings()
 *	\return		pointer to the global ExportSettings instance.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DLLEXPORT ExportSettings* GetDefaultSettings()
{
	// General settings
	gSettings.mCompression					= COMPRESSION_ZLIB;
	gSettings.mNbBits						= 8;
	gSettings.mExportWholeScene				= true;
	gSettings.mExportVisTrack				= false;
	gSettings.mExportHiddenNodes				= false;
	// Mesh settings
	gSettings.mExpUVW						= true;
	gSettings.mDiscardW						= true;
	gSettings.mExpVTXColor					= false;
	gSettings.mUseSmgrp						= true;
	gSettings.mRemoveScaling					= true;
	gSettings.mConvertToD3D					= true;
	gSettings.mAbsolutePRS					= false;
	gSettings.mConvexHull					= false;
	gSettings.mBoundingSphere				= false;
	gSettings.mInertiaTensor					= false;
	gSettings.mEdgeVis						= false;
	// Consolidation settings
	gSettings.mConsolidateMesh				= false;
	gSettings.mComputeFaceNormals			= false;
	gSettings.mComputeVertexNormals			= false;
	gSettings.mExportNormalInfo				= false;
	gSettings.mMakeManifold					= false;
	// Material settings
	gSettings.mForceAmbient					= false;
	gSettings.mForceDiffuse					= false;
	// Texture settings
	gSettings.mOpacityInAlpha				= true;
	gSettings.mTexnameOnly					= false;
	gSettings.mKeepAmbientTexture			= false;
	gSettings.mKeepDiffuseTexture			= true;
	gSettings.mKeepSpecularTexture			= false;
	gSettings.mKeepShininessTexture			= false;
	gSettings.mKeepShiningStrengthTexture	= false;
	gSettings.mKeepSelfIllumTexture			= false;
	gSettings.mKeepOpacityTexture			= true;
	gSettings.mKeepFilterTexture				= false;
	gSettings.mKeepBumpTexture				= false;
	gSettings.mKeepReflexionTexture			= false;
	gSettings.mKeepRefractionTexture			= false;
	gSettings.mKeepDisplacementTexture		= false;
	gSettings.mTexMaxSize					= 512;
	// Camera settings
	gSettings.mExpCameras					= false;
	gSettings.mExpTargetNodes				= false;
	// Light settings
	gSettings.mExpLights						= true;
	gSettings.mComputeVtxColors				= false;
	gSettings.mComputeShadows				= false;
	gSettings.mColorSmoothing				= false;
	// Animation settings
	gSettings.mSingleFrame					= true;
	gSettings.mSampling						= true;
	gSettings.mSamplingRate					= 1;

	return &gSettings;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Flexporter callback.
 *	Returns the enabled/disabled status for all settings. This is the right place to disable options your own format doesn't support.
 *	\relates	ZCBFormat
 *	\fn			GetEnabled()
 *	\return		pointer to a global Enabled instance.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DLLEXPORT Enabled* GetEnabled()
{
	static Enabled Settings;
	return &Settings;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Flexporter callback.
 *	Returns the FLEXPORTER SDK Version.
 *	\relates	PVBFormat
 *	\fn			Version()
 *	\return		FLEXPORTER_VERSION
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DLLEXPORT int Version()
{
	return FLEXPORTER_VERSION;
}









///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	A PVB exporter plug-in for Flexporter..
 *	\class		PVBFormat
 *	\author		Olivier Brunet
 *	\version	1.0
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Constructor.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
PVBFormat::PVBFormat()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Destructor.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
PVBFormat::~PVBFormat()
{
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Plug-in initialization method.
 *	This method is called once before each export. When this method is called, the mSettings and mFilename members of the base format are valid.
 *	\param		true for pure motion files.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::Init(bool motion)
{
	motion=false;
	
	// Header
	mGeneral.Store((char)'P').Store((char)'V').Store((char)'B').Store((char)'!').Store((udword)motion ? PVB_FILE_MOTION : PVB_FILE_SCENE);

	// Chunk & version
	if(!motion)
	{
		mGeneral		.Store("MAIN").Store((udword)CHUNK_MAIN_VER);
		mGeomObjects	.Store("MESH").Store((udword)CHUNK_MESH_VER);
		//mCameras		.Store("CAMS").Store((udword)CHUNK_CAMS_VER);
		mLights			.Store("LITE").Store((udword)CHUNK_LITE_VER);
		//mShapes			.Store("SHAP").Store((udword)CHUNK_SHAP_VER);
		//mHelpers		.Store("HELP").Store((udword)CHUNK_HELP_VER);
		mTexmaps		.Store("TEXM").Store((udword)CHUNK_TEXM_VER);
		mMaterials		.Store("MATL").Store((udword)CHUNK_MATL_VER);
		//mControllers	.Store("CTRL").Store((udword)CHUNK_CTRL_VER);
		//mMotion			.Store("MOVE").Store((udword)CHUNK_MOVE_VER);
	}
	else
	{
//		mMotion			.Store("MOVE").Store((udword)CHUNK_MOVE_VER);
	}

	mIsMotionFile	= motion;

	return true;
}

bool PVBFormat::SetSceneInfo(const MainDescriptor& maininfo)
{
	// Save time info for later
	CopyMemory(&mTimeInfo, &maininfo.mTime, sizeof(TimeInfo));

	// Export time info
	mGeneral
		.Store((long)(mTimeInfo.mStartTime / mTimeInfo.mDeltaTime))
		.Store((long)(mTimeInfo.mEndTime / mTimeInfo.mDeltaTime))
		.Store(mTimeInfo.mFrameRate).Store((long)mTimeInfo.mDeltaTime);

	// Export background color
	mGeneral.Store(maininfo.mBackColor.r).Store(maininfo.mBackColor.g).Store(maininfo.mBackColor.b);

	// Export ambient color
	mGeneral.Store(maininfo.mAmbColor.r).Store(maininfo.mAmbColor.g).Store(maininfo.mAmbColor.b);

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Common method used to export basic information for a mesh, a camera, a light, etc.
 *	\param		obj			current object
 *	\param		array		destination export array
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportBasicInfo(const ObjectDescriptor* obj, CustomArray* array)
{
	if(!array || !obj) return false;

	// Export name
	array	->Store((const char*)obj->mName).Store((ubyte)0);

	// Export database management information
	array	->Store(obj->mObjectID)
			.Store(obj->mParentID)
			.Store(obj->mLinkID)
			.Store(obj->mIsGroupMember);

	// Export common properties
	array	->Store(obj->mPrs.Position.x)
			.Store(obj->mPrs.Position.y)
			.Store(obj->mPrs.Position.z)

			.Store(obj->mPrs.Rotation.x)
			.Store(obj->mPrs.Rotation.y)
			.Store(obj->mPrs.Rotation.z)
			.Store(obj->mPrs.Rotation.w)

			.Store(obj->mPrs.Scale.x)
			.Store(obj->mPrs.Scale.y)
			.Store(obj->mPrs.Scale.z)

			.Store(obj->mWireColor)

			.Store(obj->mLocalPRS)
			.Store(obj->mD3DCompliant);

	// Export user-defined properties
	if(obj->mUserProps)	array->Store((const char*)obj->mUserProps);
	array->Store((ubyte)0);

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Camera export method.
 *	This method is called once for each exported camera.
 *	\param		camera		a structure filled with current camera information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportCamera(const CameraDescriptor& camera)
{
	// Export common information
/*	ExportBasicInfo(&camera, &mCameras);

	// Save parameters
	mCameras
		.Store(camera.mOrthoCam)
		.Store(camera.mFOV)
		.Store(camera.mNearClip)
		.Store(camera.mFarClip)
		.Store(camera.mTDist)
		.Store(camera.mHLineDisplay)
		.Store(camera.mEnvNearRange)
		.Store(camera.mEnvFarRange)
		.Store(camera.mEnvDisplay)
		.Store(camera.mManualClip);
*/
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Controller export method.
 *	This method is called once for each exported controller.
 *	\param		controller		a structure filled with current controller information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportController(const ControllerDescriptor& controller)
{
/*	mControllers
		.Store((const char*)controller.mField).Store((ubyte)0)		// Controlled field
		.Store(controller.mObjectID)								// Controller ID
		.Store(controller.mOwnerID);								// Owner ID

	// Controller data
	ControllerData* cdata = controller.mData;

	udword NbValues = 0;

	// Save controller type
			if(cdata->mType==CTRL_FLOAT)		{	mControllers.Store((udword)ZCB_CTRL_FLOAT);		NbValues = 1;	}
	else	if(cdata->mType==CTRL_VECTOR)		{	mControllers.Store((udword)ZCB_CTRL_VECTOR);	NbValues = 3;	}
	else	if(cdata->mType==CTRL_QUAT)			{	mControllers.Store((udword)ZCB_CTRL_QUAT);		NbValues = 4;	}
	else	if(cdata->mType==CTRL_PR)			{	mControllers.Store((udword)ZCB_CTRL_PR);		NbValues = 7;	}
	else	if(cdata->mType==CTRL_PRS)			{	mControllers.Store((udword)ZCB_CTRL_PRS);		NbValues = 10;	}
	else	if(cdata->mType==CTRL_VERTEXCLOUD)	{	mControllers.Store((udword)ZCB_CTRL_VERTEXCLOUD);				}
	else										{	mControllers.Store((udword)ZCB_CTRL_NONE);						}

	// Save controller mode
			if(cdata->mMode==CTRL_SAMPLES)			mControllers.Store((udword)ZCB_CTRL_SAMPLES);
	else	if(cdata->mMode==CTRL_KEYFRAMES)		mControllers.Store((udword)ZCB_CTRL_KEYFRAMES);
	else											mControllers.Store((udword)ZCB_CTRL_NONE);

	// Dump the samples
	if(cdata->mMode==CTRL_SAMPLES)
	{
		if(cdata->mType==CTRL_VERTEXCLOUD)
		{
			// A morph controller
			MorphData* mdata = (MorphData*)cdata;
			mControllers.Store(mdata->mNbVertices).Store(mdata->mNbSamples).Store(mdata->mSamplingRate);

			// Dump morphed vertices as a list of floats
			float* Values = (float*)mdata->mSamples;
			for(udword i=0;i<3*mdata->mNbSamples*mdata->mNbVertices;i++)	mControllers.Store(*Values++);
		}
		else
		{
			// A standard controller
			SampleData* sdata = (SampleData*)cdata;
			mControllers.Store(sdata->mNbSamples).Store(sdata->mSamplingRate);

			// Dump samples as a list of floats
			float* Values = (float*)sdata->mSamples;
			for(udword i=0;i<NbValues*sdata->mNbSamples;i++)				mControllers.Store(*Values++);
		}
	}
*/
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Helper export method.
 *	This method is called once for each exported helper.
 *	\param		helper		a structure filled with current helper information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportHelper(const HelperDescriptor& helper)
{
/*	// Export common information
	ExportBasicInfo(&helper, &mHelpers);

	// Save parameters
	mHelpers.Store(helper.mIsGroupHead);
*/
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Light export method.
 *	This method is called once for each exported light.
 *	\param		light		a structure filled with current light information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportLight(const LightDescriptor& light)
{
	// Export common information
	ExportBasicInfo(&light, &mLights);

	// Save parameters
	mLights
		.Store(light.mLightType)
		.Store(light.mIsSpot)
		.Store(light.mIsDir)
		.Store(light.mColor.x)
		.Store(light.mColor.y)
		.Store(light.mColor.z)
		.Store(light.mIntensity)
		.Store(light.mContrast)
		.Store(light.mDiffuseSoft)
		.Store(light.mLightUsed)
		.Store(light.mAffectDiffuse)
		.Store(light.mAffectSpecular)
		.Store(light.mUseAttenNear)
		.Store(light.mAttenNearDisplay)
		.Store(light.mUseAtten)
		.Store(light.mShowAtten)
		.Store(light.mNearAttenStart)
		.Store(light.mNearAttenEnd)
		.Store(light.mAttenStart)
		.Store(light.mAttenEnd)
		.Store(light.mDecayType)
		.Store(light.mHotSpot)
		.Store(light.mFallsize)
		.Store(light.mAspect)
		.Store(light.mSpotShape)
		.Store(light.mOvershoot)
		.Store(light.mConeDisplay)
		.Store(light.mTDist)
		.Store(light.mShadowType)
		.Store(light.mAbsMapBias)
		.Store(light.mRayBias)
		.Store(light.mMapBias)
		.Store(light.mMapRange)
		.Store(light.mMapSize);

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Material export method.
 *	This method is called once for each exported material.
 *	\param		material		a structure filled with current material information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportMaterial(const MaterialDescriptor& material)
{
	// Export name
	mMaterials.Store((const char*)material.mName).Store((ubyte)0);

	// Export material ID
	mMaterials.Store(material.mObjectID);

	// Export material parameters
	mMaterials
		.Store(material.mAmbientMapID)
		.Store(material.mDiffuseMapID)
		.Store(material.mSpecularMapID)
		.Store(material.mShininessMapID)
		.Store(material.mShiningStrengthMapID)
		.Store(material.mSelfIllumMapID)
		.Store(material.mOpacityMapID)
		.Store(material.mFilterMapID)
		.Store(material.mBumpMapID)
		.Store(material.mReflexionMapID)
		.Store(material.mRefractionMapID)
		.Store(material.mDisplacementMapID)

		.Store(material.mAmbientCoeff)
		.Store(material.mDiffuseCoeff)
		.Store(material.mSpecularCoeff)
		.Store(material.mShininessCoeff)
		.Store(material.mShiningStrengthCoeff)
		.Store(material.mSelfIllumCoeff)
		.Store(material.mOpacityCoeff)
		.Store(material.mFilterCoeff)
		.Store(material.mBumpCoeff)
		.Store(material.mReflexionCoeff)
		.Store(material.mRefractionCoeff)
		.Store(material.mDisplacementCoeff)

		.Store(material.mMtlAmbientColor.r)		.Store(material.mMtlAmbientColor.g)		.Store(material.mMtlAmbientColor.b)
		.Store(material.mMtlDiffuseColor.r)		.Store(material.mMtlDiffuseColor.g)		.Store(material.mMtlDiffuseColor.b)
		.Store(material.mMtlSpecularColor.r)	.Store(material.mMtlSpecularColor.g)	.Store(material.mMtlSpecularColor.b)
		.Store(material.mMtlFilterColor.r)		.Store(material.mMtlFilterColor.g)		.Store(material.mMtlFilterColor.b)

		.Store(material.mShading)
		.Store(material.mSoften)
		.Store(material.mFaceMap)
		.Store(material.mTwoSided)
		.Store(material.mWire)
		.Store(material.mWireUnits)
		.Store(material.mFalloffOut)
		.Store(material.mTransparencyType)

		.Store(material.mShininess)
		.Store(material.mShiningStrength)
		.Store(material.mSelfIllum)
		.Store(material.mOpacity)
		.Store(material.mOpaFalloff)
		.Store(material.mWireSize)
		.Store(material.mIOR)

		.Store(material.mBounce)
		.Store(material.mStaticFriction)
		.Store(material.mSlidingFriction);

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Mesh export method.
 *	This method is called once for each exported mesh.
 *	\param		mesh		a structure filled with current mesh information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportMesh(const MeshDescriptor& mesh)
{
	// Export common information
	ExportBasicInfo(&mesh, &mGeomObjects);

	// Export mesh parameters
	mGeomObjects
		.Store(mesh.mIsCollapsed)
		.Store(mesh.mIsSkeleton)
		.Store(mesh.mIsInstance)
		.Store(mesh.mIsTarget)
		.Store(mesh.mIsConvertible)
		.Store(mesh.mIsSkin);

	// For BIPED parts, export the related character's ID, as well as the bone's CSID.
	//if(mesh.mIsSkeleton)	mGeomObjects.Store(mesh.mCharID).Store(mesh.mCSID);

	if(!mesh.mIsInstance)	// If that's an instance, use mLinkID
	{
		// Export MAX native mesh
		MAXNativeMesh* Mesh = (MAXNativeMesh*)&mesh.mOriginalMesh;

		// Adjust flags
		if(mSettings.mCompression!=COMPRESSION_NONE)
		{
			// If compression is on, two things happen:
			// 1) Vertices are quantized. A "vertex" here is a geometric point, a UVW triplet or a vertex-color.
			// 2) Faces are delta-encoded to please further compressors (e.g. ZLib)
			// NB: the MAX native mesh only is modified by the compression settings, not the consolidated mesh!
			// ..simply because if you really want to save space, don't export the consolidation results, do it at runtime...
			Mesh->mFlags|=MESH_QUANTIZEDVERTICES;
			Mesh->mFlags|=MESH_COMPRESSED;
		}

		Mesh->mFlags|=MESH_WDISCARDED;	// Force WDiscard
		Mesh->mFlags|=MESH_QUANTIZEDVERTICES;   // Force Quantization
		Mesh->mFlags|=MESH_COMPRESSED;

		// Now, faces can still be saved as words or dwords, regardless of the compression setting.
		if(Mesh->mNbVerts < 65536 && Mesh->mNbTVerts < 65536 && Mesh->mNbCVerts < 65536)	Mesh->mFlags|=MESH_WORDFACES;

		// Save useful figures
		mGeomObjects.Store(Mesh->mNbFaces).Store(Mesh->mNbVerts).Store(Mesh->mNbTVerts).Store(Mesh->mNbCVerts).Store(Mesh->mFlags).Store(Mesh->mParity);

		// Save vertices (null for skins)
		if(Mesh->mVerts)
		{
			// Save plain floats or quantized vertices
			if(Mesh->mFlags&MESH_QUANTIZEDVERTICES)	ExportFloats(Mesh->mVerts, Mesh->mNbVerts, mGeomObjects, mSettings.mNbBits, true);
			else									ExportFloats(Mesh->mVerts, Mesh->mNbVerts, mGeomObjects, 0, true);
		}

		// Save skin-related data
/*		if(mesh.mIsSkin)
		{
			// Export links to the driving skeleton
			if(!Mesh->mBonesNb)
			{
				// A simple skin with one bone/vertex.

				// Save offset vectors
				MAXPoint* v = Mesh->mOffsetVectors;
				for(udword i=0;i<Mesh->mNbVerts;i++)	mGeomObjects.Store(v[i].x).Store(v[i].y).Store(v[i].z);

				// Save bones ID
				for(i=0;i<Mesh->mNbVerts;i++)			mGeomObjects.Store(Mesh->mBonesID[i]);
			}
			else
			{
				// A skin with multiple bones/vertex.

				// Save bones Nb
				udword Sum = 0;
				for(udword i=0;i<Mesh->mNbVerts;i++)
				{
					mGeomObjects.Store(Mesh->mBonesNb[i]);
					Sum+=Mesh->mBonesNb[i];
				}

				// Save bones ID
				for(i=0;i<Sum;i++)						mGeomObjects.Store(Mesh->mBonesID[i]);

				// Save weights
				for(i=0;i<Sum;i++)						mGeomObjects.Store(Mesh->mWeights[i]);

				// Save offset vectors
				MAXPoint* v = Mesh->mOffsetVectors;
				for(i=0;i<Sum;i++)						mGeomObjects.Store(v[i].x).Store(v[i].y).Store(v[i].z);
			}

			// Export compatible skeletal information
			Skeleton* Skel = Mesh->mSkeleton;
			mGeomObjects.Store(Skel->mNbBones);
			udword* ID = Skel->mID;
			for(udword i=0;i<Skel->mNbBones;i++)
			{
				udword CSID = *ID++;
				udword pCSID = *ID++;
				mGeomObjects.Store(CSID).Store(pCSID);
			}
		}*/

		// Save mapping coordinates
		if(Mesh->mTVerts)
		{
			// Save plain floats or quantized vertices
			if(Mesh->mFlags&MESH_QUANTIZEDVERTICES)	ExportFloats(Mesh->mTVerts, Mesh->mNbTVerts, mGeomObjects, mSettings.mNbBits, !(Mesh->mFlags&MESH_WDISCARDED));
			else									ExportFloats(Mesh->mTVerts, Mesh->mNbTVerts, mGeomObjects, 0, !(Mesh->mFlags&MESH_WDISCARDED));
		}

		// Save vertex-colors
/*		if(Mesh->mCVerts)
		{
			// Save plain floats or quantized vertices
			if(mSettings.Compression!=COMPRESSION_NONE)	ExportFloats(Mesh->mCVerts, Mesh->mNbCVerts, mGeomObjects, mSettings.NbBits, true);
			else										ExportFloats(Mesh->mCVerts, Mesh->mNbCVerts, mGeomObjects, 0, true);
		}*/

		// Save faces
		// The way faces are stored within the ZCB file has changed! Use the version number to detect old ZCB files.
		// CHUNK_MESH_VER = 2   => old format
		// CHUNK_MESH_VER > 2	=> new format, as below
		MAXFace* f = Mesh->mFaces;

		udword i;
		if(Mesh->mFlags&MESH_WORDFACES)
		{
			sword* Buffer = new sword[Mesh->mNbFaces*3];	CHECKALLOC(Buffer);

			// Save faces
			if(Mesh->mFlags&MESH_VFACE)
			{
				for(i=0;i<Mesh->mNbFaces;i++)
				{
					Buffer[i*3+0] = uword(f[i].VRef[0]);
					Buffer[i*3+1] = uword(f[i].VRef[1]);
					Buffer[i*3+2] = uword(f[i].VRef[2]);
				}
				if(Mesh->mFlags&MESH_COMPRESSED)	Delta(Buffer, Mesh->mNbFaces*3, 2);
				for(i=0;i<Mesh->mNbFaces*3;i++)	mGeomObjects.Store(Buffer[i]);
			}

			// Save texture faces
		/*	if((Mesh->mFlags&MESH_TFACE)&&(Mesh->mFlags&MESH_UVW))
			{
				for(i=0;i<Mesh->mNbFaces;i++)
				{
					Buffer[i*3+0] = uword(f[i].TRef[0]);
					Buffer[i*3+1] = uword(f[i].TRef[1]);
					Buffer[i*3+2] = uword(f[i].TRef[2]);
				}
				if(Mesh->mFlags&MESH_COMPRESSED)	Delta(Buffer, Mesh->mNbFaces*3, 2);
				for(i=0;i<Mesh->mNbFaces*3;i++)	mGeomObjects.Store(Buffer[i]);
			}*/

			// Save color faces
			/*if((Mesh->mFlags&MESH_CFACE)&&(Mesh->mFlags&MESH_VERTEXCOLORS))
			{
				for(i=0;i<Mesh->mNbFaces;i++)
				{
					Buffer[i*3+0] = uword(f[i].CRef[0]);
					Buffer[i*3+1] = uword(f[i].CRef[1]);
					Buffer[i*3+2] = uword(f[i].CRef[2]);
				}
				if(Mesh->mFlags&MESH_COMPRESSED)	Delta(Buffer, Mesh->mNbFaces*3, 2);
				for(i=0;i<Mesh->mNbFaces*3;i++)	mGeomObjects.Store(Buffer[i]);
			}*/

			DELETEARRAY(Buffer);
		}
		else
		{
			sdword* Buffer = new sdword[Mesh->mNbFaces*3];	CHECKALLOC(Buffer);

			// Save faces
			if(Mesh->mFlags&MESH_VFACE)
			{
				for(i=0;i<Mesh->mNbFaces;i++)
				{
					Buffer[i*3+0] = udword(f[i].VRef[0]);
					Buffer[i*3+1] = udword(f[i].VRef[1]);
					Buffer[i*3+2] = udword(f[i].VRef[2]);
				}
				if(Mesh->mFlags&MESH_COMPRESSED)	Delta(Buffer, Mesh->mNbFaces*3, 4);
				for(i=0;i<Mesh->mNbFaces*3;i++)	mGeomObjects.Store(Buffer[i]);
			}

			// Save texture faces
			/*if((Mesh->mFlags&MESH_TFACE)&&(Mesh->mFlags&MESH_UVW))
			{
				for(i=0;i<Mesh->mNbFaces;i++)
				{
					Buffer[i*3+0] = udword(f[i].TRef[0]);
					Buffer[i*3+1] = udword(f[i].TRef[1]);
					Buffer[i*3+2] = udword(f[i].TRef[2]);
				}
				if(Mesh->mFlags&MESH_COMPRESSED)	Delta(Buffer, Mesh->mNbFaces*3, 4);
				for(i=0;i<Mesh->mNbFaces*3;i++)	mGeomObjects.Store(Buffer[i]);
			}*/

			// Save color faces
			/*if((Mesh->mFlags&MESH_CFACE)&&(Mesh->mFlags&MESH_VERTEXCOLORS))
			{
				for(i=0;i<Mesh->mNbFaces;i++)
				{
					Buffer[i*3+0] = udword(f[i].CRef[0]);
					Buffer[i*3+1] = udword(f[i].CRef[1]);
					Buffer[i*3+2] = udword(f[i].CRef[2]);
				}
				if(Mesh->mFlags&MESH_COMPRESSED)	Delta(Buffer, Mesh->mNbFaces*3, 4);
				for(i=0;i<Mesh->mNbFaces*3;i++)	mGeomObjects.Store(Buffer[i]);
			}*/

			DELETEARRAY(Buffer);
		}

		// Save face parameters
		for(i=0;i<Mesh->mNbFaces;i++)	mGeomObjects.Store(f[i].MatID);
		//for(i=0;i<Mesh->mNbFaces;i++)	mGeomObjects.Store(f[i].Smg);

		/*if(mSettings.EdgeVis)
		{
			for(i=0;i<Mesh->mNbFaces;i++)	mGeomObjects.Store(f[i].EdgeVis);
		}*/

		// Export the possible convex hull
		/*if(Mesh->mFlags&MESH_CONVEXHULL)
		{
			mGeomObjects.Store(Mesh->mConvexHull->mNbVerts).Store(Mesh->mConvexHull->mNbFaces);
			if(Mesh->mConvexHull->mVerts)
			{
				MAXPoint* v = Mesh->mConvexHull->mVerts;
				for(udword i=0;i<Mesh->mConvexHull->mNbVerts;i++)	mGeomObjects.Store(v[i].x).Store(v[i].y).Store(v[i].z);
			}

			if(Mesh->mConvexHull->mFaces)
			{
				udword* f = Mesh->mConvexHull->mFaces;
				for(udword i=0;i<Mesh->mConvexHull->mNbFaces;i++)	mGeomObjects.Store(f[i*3+0]).Store(f[i*3+1]).Store(f[i*3+2]);
			}
		}*/

		// Export the possible bounding sphere
		/*if(Mesh->mFlags&MESH_BOUNDINGSPHERE)
		{
			mGeomObjects.Store(Mesh->mBSCenter.x).Store(Mesh->mBSCenter.y).Store(Mesh->mBSCenter.z).Store(Mesh->mBSRadius);
		}*/

		// Export the inertia tensor
		/*if(Mesh->mFlags&MESH_INERTIATENSOR)
		{
			ITensor* T = Mesh->mTensor;
			mGeomObjects
				.Store(T->COM.x).Store(T->COM.y).Store(T->COM.z)
				.Store(T->Mass)
				.Store(T->InertiaTensor[0][0]).Store(T->InertiaTensor[0][1]).Store(T->InertiaTensor[0][2])
				.Store(T->InertiaTensor[1][0]).Store(T->InertiaTensor[1][1]).Store(T->InertiaTensor[1][2])
				.Store(T->InertiaTensor[2][0]).Store(T->InertiaTensor[2][1]).Store(T->InertiaTensor[2][2])
				.Store(T->COMInertiaTensor[0][0]).Store(T->COMInertiaTensor[0][1]).Store(T->COMInertiaTensor[0][2])
				.Store(T->COMInertiaTensor[1][0]).Store(T->COMInertiaTensor[1][1]).Store(T->COMInertiaTensor[1][2])
				.Store(T->COMInertiaTensor[2][0]).Store(T->COMInertiaTensor[2][1]).Store(T->COMInertiaTensor[2][2]);
		}*/

		// Export consolidated mesh
		if(Mesh->mFlags&MESH_CONSOLIDATION)
		{
			// Topology
			{
				MBTopology& Topo = mesh.mCleanMesh->Topology;

				mGeomObjects.Store(Topo.NbFaces).Store(Topo.NbSubmeshes);

				// Submeshes				
				for(udword i=0;i<Topo.NbSubmeshes;i++)
				{
					MBSubmesh* CurSM = &Topo.SubmeshProperties[i];
					//mGeomObjects.Store(CurSM->MatID).Store(CurSM->SmGrp).Store(CurSM->NbFaces).Store(CurSM->NbVerts).Store(CurSM->NbSubstrips);
					mGeomObjects.Store(CurSM->NbVerts);
				}

				// Connectivity
				uword* VRefs = Topo.VRefs;
				for(i=0;i<Topo.NbSubmeshes;i++)
				{
					MBSubmesh* CurSM = &Topo.SubmeshProperties[i];
					mGeomObjects.Store(CurSM->MatID);
					
					uword NbFaces = Topo.FacesInSubmesh[i];

					mGeomObjects.Store(NbFaces);

					// Save faces (Ref0, Ref1, Ref2)
					for(uword j=0;j<NbFaces;j++)
					{
						uword Ref0 = *VRefs++;
						uword Ref1 = *VRefs++;
						uword Ref2 = *VRefs++;
						mGeomObjects.Store(Ref0).Store(Ref1).Store(Ref2);
					}
				}

				// Face normals
/* 				if(Mesh->mFlags&MESH_FACENORMALS)
				{
					float* Normals = Topo.Normals;
					for(i=0;i<Topo.NbFaces;i++)
					{
						float nx = Normals ? Normals[i*3+0] : 0.0f;
						float ny = Normals ? Normals[i*3+1] : 0.0f;
						float nz = Normals ? Normals[i*3+2] : 0.0f;
						mGeomObjects.Store(nx).Store(ny).Store(nz);
					}
				}*/
			}

			// Geometry
			{
				MBGeometry& Geo = mesh.mCleanMesh->Geometry;

				mGeomObjects.Store(Geo.NbGeomPts).Store(Geo.NbVerts).Store(Geo.NbTVerts);

				// Indexed geometry
				udword MaxRef=0;
				if(Geo.VertsRefs)
				{
					for(udword i=0;i<Geo.NbVerts;i++)
					{
						udword Ref = Geo.VertsRefs[i];
						if(Ref>MaxRef)	MaxRef=Ref;
						mGeomObjects.Store(Ref);
					}
				}

				// Vertices
				udword NbVerts = Geo.VertsRefs ? (MaxRef+1) : Geo.NbVerts;
				mGeomObjects.Store(NbVerts);
				for(udword i=0;i<NbVerts;i++)
				{
					float x = Geo.Verts[i*3+0];
					float y = Geo.Verts[i*3+1];
					float z = Geo.Verts[i*3+2];
					mGeomObjects.Store(x).Store(y).Store(z);
				}

				// Indexed UVWs
				MaxRef = 0;
				if((Mesh->mFlags&MESH_UVW) && Geo.TVertsRefs)
				{
					for(udword i=0;i<Geo.NbVerts;i++)
					{
						udword Ref = Geo.TVertsRefs[i];
						if(Ref>MaxRef)	MaxRef=Ref;
						mGeomObjects.Store(Ref);
					}
				}

				// Texture-vertices
				if((Mesh->mFlags&MESH_UVW) && Geo.TVerts)
				{
					udword NbTVerts = Geo.TVertsRefs ? (MaxRef+1) : Geo.NbVerts;
					mGeomObjects.Store(NbTVerts);
					float* p = Geo.TVerts;
					for(udword i=0;i<NbTVerts;i++)
					{
						float u = *p++;	mGeomObjects.Store(u);
						float v = *p++;	mGeomObjects.Store(v);
						if(!(Mesh->mFlags&MESH_WDISCARDED))	
						{
							float w = *p++;	mGeomObjects.Store(w);
						}
					}
				}

				// Normals
				if(Mesh->mFlags&MESH_VERTEXNORMALS)
				{
					udword NbNormals = Geo.NbVerts;
					mGeomObjects.Store(NbNormals);
					for(udword i=0;i<NbNormals;i++)
					{
						float x = Geo.Normals[i*3+0];
						float y = Geo.Normals[i*3+1];
						float z = Geo.Normals[i*3+2];
						mGeomObjects.Store(x).Store(y).Store(z);
					}
				}

				// Vertex colors
				/*if((Mesh->mFlags&MESH_VERTEXCOLORS) && Geo.CVerts)
				{
					udword NbVtxColors = Geo.NbVerts;
					mGeomObjects.Store(NbVtxColors);
					for(udword i=0;i<NbVtxColors;i++)
					{
						float r = Geo.CVerts[i*3+0];
						float g = Geo.CVerts[i*3+1];
						float b = Geo.CVerts[i*3+2];
						mGeomObjects.Store(r).Store(g).Store(b);
					}
				}*/

				// Normal info
				/*if((Mesh->mFlags&MESH_NORMALINFO) && Geo.NormalInfo)
				{
					udword NormalInfoSize = Geo.NormalInfoSize;
					mGeomObjects.Store(NormalInfoSize);
					for(udword i=0;i<NormalInfoSize;i++)
					{
						udword d = Geo.NormalInfo[i];
						mGeomObjects.Store(d);
					}
				}*/
			}

			// Materials
			/*{
				MESHBUILDERMATERIALS& Mtl = mesh.mCleanMesh->Materials;

				mGeomObjects.Store(Mtl.NbMtls);

				for(udword i=0;i<Mtl.NbMtls;i++)
				{
					MESHBUILDERMATINFO* CurMtl = &Mtl.MaterialInfo[i];

					mGeomObjects.Store(CurMtl->MatID).Store(CurMtl->NbFaces).Store(CurMtl->NbVerts).Store(CurMtl->NbSubmeshes);
				}
			}*/
		}
	}

	// Lightmapper's vertex colors. Since the lighting depends on the world space position, instances have their own lighting data.
	// That's why those colors are not directly included in MAX's vertex colors channel !
	//mesh.mNbColors=0;
	mGeomObjects.Store((unsigned)0/*mesh.mNbColors*/);	// Can be 0 => use that as a flag
	/*if(mesh.mColors)
	{
		for(udword i=0;i<mesh.mNbColors;i++)	mGeomObjects.Store(mesh.mColors[i].x).Store(mesh.mColors[i].y).Store(mesh.mColors[i].z);
	}*/

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Motion export method.
 *	This method is called once for each exported motion.
 *	\param		motion		a structure filled with current motion information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportMotion(const MotionDescriptor& motion)
{
/*	mMotion.Store(motion.mLinkID).Store(motion.mNbBones).Store(motion.mNbVirtualBones);

	udword* Data = (udword*)motion.mData;
	for(udword i=0;i<motion.mNbBones;i++)
	{
		udword CSID = *Data++;
		udword NbFrames = *Data++;
		mMotion.Store(CSID).Store(NbFrames);
		float* p = (float*)Data;
		for(udword j=0;j<NbFrames;j++)
		{
			float tx = *p++;
			float ty = *p++;
			float tz = *p++;
			float qx = *p++;
			float qy = *p++;
			float qz = *p++;
			float qw = *p++;
			mMotion
				.Store(tx).Store(ty).Store(tz)
				.Store(qx).Store(qy).Store(qz).Store(qw);
		}
		Data = (udword*)p;
	}
*/
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Shape export method.
 *	This method is called once for each exported shape.
 *	\param		shape		a structure filled with current shape information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportShape(const ShapeDescriptor& shape)
{
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	Texture export method.
 *	This method is called once for each exported texture.
 *	\param		texture		a structure filled with current texture information.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportTexture(const TextureDescriptor& texture)
{
	// 1) Export name
	mTexmaps.Store((const char*)texture.mName).Store((ubyte)0);

	// 2) Export texture ID
	mTexmaps.Store(texture.mObjectID);

	// 3) Export texture data if needed
	ubyte* Pixels = texture.mPixels;
	if(Pixels)
	{
		// Pixels exist => the user didn't select "Export filenames only", so let's export the whole texture bitmap.
		// A byte to tell the bitmap follows
		mTexmaps.Store(ubyte(1));
		// Then export the bitmap info...
		mTexmaps.Store(texture.mWidth).Store(texture.mHeight).Store(texture.mHasAlpha);
		// Then export the bitmap data...
		for(udword i=0;i<texture.mWidth*texture.mHeight;i++)
		{
			ubyte R = *Pixels++;
			ubyte G = *Pixels++;
			ubyte B = *Pixels++;
			ubyte A = *Pixels++;
			mTexmaps.Store(R).Store(G).Store(B);
			if(texture.mHasAlpha)	mTexmaps.Store(A);
		}
	}
	else
	{
		// A byte to tell the bitmap is not included
		mTexmaps.Store(ubyte(0));
	}

	// 4) Export cropping values
	mTexmaps
		.Store(texture.mCValues.OffsetU).Store(texture.mCValues.OffsetV).Store(texture.mCValues.ScaleU).Store(texture.mCValues.ScaleV);

	// 5) Export texture matrix
	mTexmaps
		.Store(texture.mTMtx.m[0][0]).Store(texture.mTMtx.m[0][1]).Store(texture.mTMtx.m[0][2])
		.Store(texture.mTMtx.m[1][0]).Store(texture.mTMtx.m[1][1]).Store(texture.mTMtx.m[1][2])
		.Store(texture.mTMtx.m[2][0]).Store(texture.mTMtx.m[2][1]).Store(texture.mTMtx.m[2][2])
		.Store(texture.mTMtx.m[3][0]).Store(texture.mTMtx.m[3][1]).Store(texture.mTMtx.m[3][2]);

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	End of export notification.
 *	This method is called once all nodes have been exported. This is a convenient place to free all used ram, etc.
 *	\param		stats		a structure filled with some export statistics.
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::EndExport(const StatsDescriptor& stats)
{
	// Complete general chunk
	if(!mIsMotionFile)
		mGeneral
			.Store(stats.mNbGeomObjects)
			.Store(stats.mNbDerivedObjects)
			.Store(stats.mNbCameras)
			.Store(stats.mNbLights)
			.Store(stats.mNbShapes)
			.Store(stats.mNbHelpers)
			.Store(stats.mNbControllers)
			.Store(stats.mNbMaterials)
			.Store(stats.mNbTexmaps)
			.Store(stats.mNbUnknowns)
			.Store(stats.mNbInvalidNodes);

	// Export to disk
	{
		// Open output file
		udword fp = CreateFile(mFilename, FILE_WRITE, FILE_CREATE_ALWAYS);
		if(fp!=-1)
		{
			// Write data to disk
			void* Data;
				// The "General" array must be exported first, since it may include the format's signature.
											{ Data = mGeneral			.Collapse();	if(Data)	WriteFile(fp, Data, mGeneral		.GetOffset());}
			if(!mIsMotionFile)
			{
				if(stats.mNbGeomObjects)	{ Data = mGeomObjects		.Collapse();	if(Data)	WriteFile(fp, Data, mGeomObjects	.GetOffset());}
				if(stats.mNbCameras)		{ Data = mCameras			.Collapse();	if(Data)	WriteFile(fp, Data, mCameras		.GetOffset());}
				if(stats.mNbLights)			{ Data = mLights			.Collapse();	if(Data)	WriteFile(fp, Data, mLights			.GetOffset());}
				if(stats.mNbShapes)			{ Data = mShapes			.Collapse();	if(Data)	WriteFile(fp, Data, mShapes			.GetOffset());}
				if(stats.mNbHelpers)		{ Data = mHelpers			.Collapse();	if(Data)	WriteFile(fp, Data, mHelpers		.GetOffset());}
				if(stats.mNbTexmaps)		{ Data = mTexmaps			.Collapse();	if(Data)	WriteFile(fp, Data, mTexmaps		.GetOffset());}
				if(stats.mNbMaterials)		{ Data = mMaterials			.Collapse();	if(Data)	WriteFile(fp, Data, mMaterials		.GetOffset());}
				if(stats.mNbControllers)	{ Data = mControllers		.Collapse();	if(Data)	WriteFile(fp, Data, mControllers	.GetOffset());}
				if(stats.mNbDerivedObjects)	{ Data = mMotion			.Collapse();	if(Data)	WriteFile(fp, Data, mMotion			.GetOffset());}
			}
			else							{ Data = mMotion			.Collapse();	if(Data)	WriteFile(fp, Data, mMotion			.GetOffset());}

			// Close output file
			CloseFile(fp);

			// ...and while we're at it.....
			if(mSettings.mCompression!=COMPRESSION_NONE)
			{
				// Compress file
				// - Load the file from disk
				udword Size = GetFileSize(mFilename);
				CustomArray Importer(mFilename);
				void* SrcBuffer = Importer.GetAddress();

				// - Create a destination (packed) buffer
				ubyte* DstBuffer = new ubyte[Size*2];
				CHECKALLOC(DstBuffer);

				// - Compress the buffer
				udword DestLen=Size*2;
				int ErrorCode;
				if(mSettings.mCompression==COMPRESSION_ZLIB)
				{
					ErrorCode = compress2((Bytef*)DstBuffer, (uLongf*)&DestLen, (Bytef*)SrcBuffer, Size, Z_BEST_COMPRESSION);
					ASSERT(ErrorCode==Z_OK);
				}
				else if(mSettings.mCompression==COMPRESSION_BZIP2)
				{
					ErrorCode = BZ2_bzBuffToBuffCompress((char*)DstBuffer, &DestLen, (char*)SrcBuffer, Size, 9, 0, 0);
					ASSERT(ErrorCode==BZ_OK);
				}
				// - Create a new ZCB packed file in memory
				CustomArray PackedBuffer;
				PackedBuffer.Store((char)'P').Store((char)'V').Store((char)'B').Store((char)'Z');
				PackedBuffer.Store(mSettings.mCompression);
				PackedBuffer.Store(Size).Store(DestLen);
				for(udword i=0;i<DestLen;i++)
				{
					PackedBuffer.Store(DstBuffer[i]);
				}

				// - Save the new ZCB file to disk
				PackedBuffer.ExportToDisk(mFilename);
			}
		}

		// Free everything for next call
		mGeneral		.Clean();
		mGeomObjects	.Clean();
		mCameras		.Clean();
		mLights			.Clean();
		mShapes			.Clean();
		mHelpers		.Clean();
		mTexmaps		.Clean();
		mMaterials		.Clean();
		mControllers	.Clean();
		mMotion			.Clean();
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 *	A method to dump a list of points in a CustomArray.
 *	\param		points			the list of points
 *	\param		nbpoints		the number of points in the list
 *	\param		array			the destination array
 *	\param		nbbits			the number of bits for quantization (0 to export plain floats)
 *	\param		keeplast		true to keep the last component, false to discard it (used to discard W for example)
 *	\return		true if success.
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool PVBFormat::ExportFloats(MAXPoint* points, udword nbpoints, CustomArray& array, udword nbbits, bool keeplast)
{
	if(!nbbits)
	{
		// Here we export plain floating-point values, in the same way as Flexporter did before version 1.05
		for(udword i=0;i<nbpoints;i++)
		{
			array.Store(points[i].x).Store(points[i].y);
			if(keeplast)	array.Store(points[i].z);
		}
	}
	else
	{
		// Here we quantize the vertex cloud before exporting it. The purpose is to reduce the size of the file without using advanced
		// mesh compression (which would be painful to read back for most users)

		// 1) Compute the quantization coeffs
		float MaxX = MIN_FLOAT, MaxY = MIN_FLOAT, MaxZ = MIN_FLOAT;
		for(udword i=0;i<nbpoints;i++)
		{
			if(fabsf(points[i].x)>MaxX)	MaxX = fabsf(points[i].x);
			if(fabsf(points[i].y)>MaxY)	MaxY = fabsf(points[i].y);
			if(fabsf(points[i].z)>MaxZ)	MaxZ = fabsf(points[i].z);
		}
		float QuantCoeffX = float((1<<nbbits)-1)/MaxX;
		float QuantCoeffY = float((1<<nbbits)-1)/MaxY;
		float QuantCoeffZ = float((1<<nbbits)-1)/MaxZ;

		float DequantCoeffX = MaxX / float((1<<nbbits)-1);
		float DequantCoeffY = MaxY / float((1<<nbbits)-1);
		float DequantCoeffZ = MaxZ / float((1<<nbbits)-1);

		// 2) Export quantization coeffs
		array.Store(DequantCoeffX).Store(DequantCoeffY);
		if(keeplast)	array.Store(DequantCoeffZ);

		// 3) Quantize vertex cloud and export
		for(i=0;i<nbpoints;i++)
		{
			sword x = sword(points[i].x * QuantCoeffX);
			sword y = sword(points[i].y * QuantCoeffY);
			array.Store(x).Store(y);
			if(keeplast)
			{
				sword z = sword(points[i].z * QuantCoeffZ);
				array.Store(z);
			}
		}

		// To dequantize, perform the following operations:
		//float x = float(QuantizedX) * DequantCoeffX;
		//float y = float(QuantizedY) * DequantCoeffY;
		//float z = float(QuantizedZ) * DequantCoeffZ;
	}
	return true;
}





/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Generic DirectX6 driver for the Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//

// If there is no hardware found, defaults to software D3D rendering 
// (mainly for debugging purposes), and it's damn slow !

//---------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#define INITGUID
#define DIRECTDRAW_VERSION		0x600
#include <ddraw.h>
#include <math.h>
#include "d3d6fill.h"
#include "pvd3d6.h"

/////////////////////////////////////////////////////////////////////////////////
static LPDIRECTDRAW		lpDD=NULL;
static LPDIRECTDRAW4	lpDD4;
static LPDIRECT3D3		lpD3D3;
LPDIRECT3DDEVICE3		lpD3DDEV3;
static LPDIRECT3DVIEWPORT3		lpViewport3=NULL;

static LPDIRECTDRAWSURFACE4 lpDDS,lpDDSPrimary,lpZBuffer=NULL;

static LPDIRECTDRAWPALETTE lpDDPalette=NULL;

static LPDIRECTDRAWCLIPPER lpClipper=NULL;
static D3DVIEWPORT2 viewport;
static LPDIRECT3DMATERIAL3 g_pMatBack=NULL;

static D3DDEVICEDESC	HalCaps;
static D3DDEVICEDESC	HelCaps;

static PVFLAGS PVM;

static PVMaterial *lastm=NULL;
static PVFLAGS oldpvf=0;

static bool soft=FALSE,FogTable,OverrideLighting,FogEnabled;
static unsigned StencilSupported;
static D3DZBUFFERTYPE zbuftype;

/////////////////////////////////////////////////////////////////////////////////

static void __cdecl DebugString(char *fmt, ...)
{
    char ach[128];
    va_list va;
	FILE *f;

	if(getenv("PVD3D6")!=NULL)
	{
		if(strcmp(getenv("PVD3D6"),"QUIET")==0)
		{
			return;
		}
	}

    va_start( va, fmt );
    wvsprintf( ach, fmt, va );
    va_end( va );
	
	f=fopen("pvd3d6.log","a+");
	fprintf(stderr,"%s",ach);
	fprintf(f,"%s",ach);
	OutputDebugString(ach);
	fclose(f);
}

//-----------------------------------------------------------------------------
// Name: D3DUtil_SetProjectionMatrix()
// Desc: Sets the passed in 4x4 matrix to a perpsective projection matrix built
//       from the field-of-view (fov, in y), aspect ratio, near plane (D),
//       and far plane (F). Note that the projection matrix is normalized for
//       element [3][4] to be 1.0. This is performed so that W-based range fog
//       will work correctly.
//-----------------------------------------------------------------------------
HRESULT D3DUtil_SetProjectionMatrix( D3DMATRIX& mat, FLOAT fFOV, FLOAT fAspect,
                                     FLOAT fNearPlane, FLOAT fFarPlane )
{
    if( fabs(fFarPlane-fNearPlane) < 0.01f )
        return E_INVALIDARG;
    if( fabs(sin(fFOV/2)) < 0.01f )
        return E_INVALIDARG;

    FLOAT w = fAspect * (FLOAT)( cos(fFOV/2)/sin(fFOV/2) );
    FLOAT h =   1.0f  * (FLOAT)( cos(fFOV/2)/sin(fFOV/2) );
    FLOAT Q = fFarPlane / ( fFarPlane - fNearPlane );

    ZeroMemory( &mat, sizeof(D3DMATRIX) );
    mat._11 = w;
    mat._22 = h;
    mat._33 = Q;
    mat._34 = 1.0f;
    mat._43 = -Q*fNearPlane;

    return S_OK;
}

//////////////////////////////////////////////////////////////////////////////////////

typedef struct {
    DWORD           bpp;        // we want a texture format of this bpp
    DDPIXELFORMAT   ddpf;       // place the format here
}   FindTextureData;

HRESULT CALLBACK FindTextureCallback (DDPIXELFORMAT *pixelfmt, LPVOID lParam)
{

	if( NULL==pixelfmt || NULL==lParam )
        return DDENUMRET_OK;

    FindTextureData * FindData = (FindTextureData *)lParam;
    DDPIXELFORMAT ddpf;

	memcpy(&ddpf,pixelfmt,sizeof(ddpf));
		
    // No alpha textures
    if (ddpf.dwFlags & (DDPF_ALPHA|DDPF_ALPHAPIXELS))
        return DDENUMRET_OK;
	
	// No paletized textures
	if(ddpf.dwFlags & (DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) 
		return DDENUMRET_OK;

	// No RGBZ Pixel format
    if (ddpf.dwFlags & DDPF_ZPIXELS)
		return DDENUMRET_OK;
	
    // Only RGB textures
	if (!(ddpf.dwFlags & DDPF_RGB))
        return DDENUMRET_OK;
	
    // FInd the nearest surface
    if (FindData->ddpf.dwRGBBitCount == 0 ||
		(ddpf.dwRGBBitCount >= FindData->bpp &&
		(UINT)(ddpf.dwRGBBitCount - FindData->bpp) < (UINT)(FindData->ddpf.dwRGBBitCount - FindData->bpp)))
    {
        FindData->ddpf = ddpf;
    }
	
    return DDENUMRET_OK;
}

static HRESULT CALLBACK FindAlphaTextureCallback (DDPIXELFORMAT *pixelfmt, LPVOID lParam)
{
	if( NULL==pixelfmt || NULL==lParam )
        return DDENUMRET_OK;

    FindTextureData * FindData = (FindTextureData *)lParam;
    DDPIXELFORMAT ddpf;

	memcpy(&ddpf,pixelfmt,sizeof(ddpf));
	
    DebugString("FindTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		ddpf.dwRGBBitCount, 
        (ddpf.dwFlags & (DDPF_ALPHA|DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (ddpf.dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (ddpf.dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		ddpf.dwRBitMask,
		ddpf.dwGBitMask,
		ddpf.dwBBitMask,
		ddpf.dwRGBAlphaBitMask);
	
	// No Alpha Only formats
	// No ZBuffer only formats
	// No YUV formats
	// No RGBZ formats
	// No FourCC formats
	if (ddpf.dwFlags & ( DDPF_ZBUFFER |
		DDPF_YUV | DDPF_ZPIXELS | DDPF_FOURCC))
        return DDENUMRET_OK;
	
	// We only want RGB formats for now !!!
    if (! (ddpf.dwFlags & DDPF_RGB))
        return DDENUMRET_OK;
	
	// We only want texture formats with an alpha channel
    if (!(ddpf.dwFlags & DDPF_ALPHAPIXELS))
        return DDENUMRET_OK;
	
	// We don't want palettized textures
    if (ddpf.dwFlags & (DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4 | 
		DDPF_PALETTEINDEXED2 | DDPF_PALETTEINDEXED1))
        return DDENUMRET_OK;
	
	//
    // keep the alpha texture format with the largest
	// alpha channel
    //
    if ((FindData->ddpf.dwRGBAlphaBitMask == 0) ||
		(ddpf.dwRGBAlphaBitMask > FindData->ddpf.dwRGBAlphaBitMask))
    {
        FindData->ddpf = ddpf;
    }
    return DDENUMRET_OK;
}

static HRESULT WINAPI EnumZBufferFormatsCallback( DDPIXELFORMAT* pddpf,
                                                  VOID* pddpfDesired )
{
    if( NULL==pddpf || NULL==pddpfDesired )
        return D3DENUMRET_CANCEL;

	DDPIXELFORMAT* pddpf2=(DDPIXELFORMAT*)pddpfDesired;

    // If the current pixel format's match the desired ones (DDPF_ZBUFFER and
    // possibly DDPF_STENCILBUFFER), lets copy it and return. This function is
    // not choosy...it accepts the first valid format that comes along.

    if( pddpf->dwFlags == pddpf2->dwFlags )
    {        		
		// We're happy with a 16-bit z-buffer. Otherwise, keep looking.
		if( pddpf->dwZBufferBitDepth == pddpf2->dwZBufferBitDepth )		
		{			
			memcpy( pddpfDesired, pddpf, sizeof(DDPIXELFORMAT) );
			return D3DENUMRET_OK;
		}
    }

    return D3DENUMRET_OK;
}

static void ChooseTextureFormat(IDirect3DDevice3 *Device, DWORD bpp, DDPIXELFORMAT *pddpf)
{
    FindTextureData FindData;
    ZeroMemory(&FindData, sizeof(FindData));
    FindData.bpp = bpp;
    Device->EnumTextureFormats(FindTextureCallback, (LPVOID)&FindData);
    *pddpf = FindData.ddpf;
}

static BOOL ChooseAlphaTextureFormat(IDirect3DDevice3 *Device, DDPIXELFORMAT *pddpf)
{
    FindTextureData FindData;
    ZeroMemory(&FindData, sizeof(FindData));
	
    Device->EnumTextureFormats (FindAlphaTextureCallback, (LPVOID)&FindData);
    *pddpf = FindData.ddpf;
	
	if (FindData.ddpf.dwAlphaBitDepth == 0)
		return FALSE;
	
    DebugString("ChooseAlphaTexture: %d %s%s%s %08X %08X %08X %08X\n", 
		pddpf->dwRGBBitCount, 
        (pddpf->dwFlags &   (DDPF_ALPHAPIXELS)) ? "ALPHA " : "", 
        (pddpf->dwFlags &	(DDPF_RGB)) ? "RGB " : "", 
        (pddpf->dwFlags &	(DDPF_PALETTEINDEXED8 | DDPF_PALETTEINDEXED4)) ? "PAL " : "", 
		pddpf->dwRBitMask,
		pddpf->dwGBitMask,
		pddpf->dwBBitMask,
		pddpf->dwRGBAlphaBitMask);
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////

static HRESULT WINAPI EnumSurfacesCallback(
										   LPDIRECTDRAWSURFACE4 lpDDSurface,  
										   LPDDSURFACEDESC2 lpDDSurfaceDesc,  
										   LPVOID lpContext                  
										   )
{
	// 0 = Front buffer
	// 1 = Back buffer
	unsigned h;
		
	if((unsigned)lpContext==0)
		h=lpDDSurfaceDesc->ddsCaps.dwCaps&(DDSCAPS_FRONTBUFFER|DDSCAPS_PRIMARYSURFACE|DDSCAPS_VISIBLE);
	else
	{
		h=lpDDSurfaceDesc->ddsCaps.dwCaps&(DDSCAPS_BACKBUFFER|DDSCAPS_OFFSCREENPLAIN);
		if(!(lpDDSurfaceDesc->ddsCaps.dwCaps&DDSCAPS_3DDEVICE)) h=0;
	}

	// Look for a 3d surface not directly visible (probably the back buffer)	
	if(h)
	{
		lpDDS=lpDDSurface;
		return DDENUMRET_CANCEL;
	}
	else 
	{
		lpDDSurface->Release();
		return DDENUMRET_OK;	
	}
}

static int GetMaskSize(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
	}
	
	while(x&1)
	{
		x>>=1;
		i++;
	}
	return i;
}

static int GetMaskPos(unsigned x)
{ 
	int i=0;
	while((!(x&1))&&(x!=0))
	{
		x>>=1;		
		i++;
	}
	
	return i;
}

static void RestoreAllSurfaces(void)
{		
	// Assumes Primarrysurface state=Other surfaces state	
	if(lpDDSPrimary->IsLost())	lpDDSPrimary->Restore(); else return;	
	if(lpDDS->IsLost())	lpDDS->Restore();	
	if(lpZBuffer!=NULL) 
		if(lpZBuffer->IsLost()) lpZBuffer->Restore();	

	lpDD4->RestoreAllSurfaces();
}

extern PVHardwareCaps D3DCaps;
extern PVHardwareCaps D3DCapsOrg;
static void InitSurfaceCaps(LPDIRECTDRAWSURFACE4 surf)
{
	DDPIXELFORMAT  ddpf;	
	
	surf->GetPixelFormat(&ddpf);
	D3DCaps.BitsPerPixel=ddpf.dwRGBBitCount;
	D3DCaps.NbrBitsRed=GetMaskSize(ddpf.dwRBitMask);
	D3DCaps.NbrBitsGreen=GetMaskSize(ddpf.dwGBitMask);
	D3DCaps.NbrBitsBlue=GetMaskSize(ddpf.dwBBitMask);
	D3DCaps.NbrBitsAlpha=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	D3DCaps.RedPos=GetMaskPos(ddpf.dwRBitMask);
	D3DCaps.GreenPos=GetMaskPos(ddpf.dwGBitMask);
	D3DCaps.BluePos=GetMaskPos(ddpf.dwBBitMask);
	D3DCaps.AlphaPos=GetMaskSize(ddpf.dwRGBAlphaBitMask);
}

void SetPal(LPDIRECTDRAWSURFACE4 surf)
{		
	unsigned i;
	PALETTEENTRY Pal[256];
	HRESULT hr;
	
	//
    // build a 332 palette as the default.
    //
	if(lpDDPalette==NULL)
	{
		for (i=0; i<256; i++)
		{
			Pal[i].peRed   = (BYTE)(((i >> 5) & 0x07) * 255 / 7);
			Pal[i].peGreen = (BYTE)(((i >> 2) & 0x07) * 255 / 7);
			Pal[i].peBlue  = (BYTE)(((i >> 0) & 0x03) * 255 / 3);
			Pal[i].peFlags = PC_NOCOLLAPSE;;
		}
		
		hr=lpDD->CreatePalette(DDPCAPS_8BIT|DDPCAPS_ALLOW256,Pal,&lpDDPalette,NULL); 
		if(hr!=DD_OK)
		{
			DebugString("PVDX: CreatePal %x\n",hr);
		}
	}
	hr=surf->SetPalette(lpDDPalette);	
}

static void SetBackground(void)
{
	D3DMATERIAL MatBack;
	D3DMATERIALHANDLE hMatBack;

	if(lpD3D3==NULL) return;

	//Create the material interface
	lpD3D3->CreateMaterial (&g_pMatBack, NULL);
	if(g_pMatBack==NULL) return;

	//Fill out a material description; we'll make it red
	memset (&MatBack, 0, sizeof(D3DMATERIAL));
	MatBack.dwSize = sizeof(D3DMATERIAL);
   	MatBack.diffuse.r = D3DVAL (0);
	MatBack.diffuse.g = D3DVAL (0);
	MatBack.diffuse.b = D3DVAL (0);
	MatBack.dwRampSize = 1;
	
	//Set up the background material using the description
	g_pMatBack->SetMaterial (&MatBack);

	//Get a material handle for it from the device
    g_pMatBack->GetHandle (lpD3DDEV3, &hMatBack);	  

	//Associate this background material with our viewport
    lpViewport3->SetBackground (hMatBack);
}

/////////////////////////////////////////////////////////////////////////////////
static int InitDevice(bool hard)
{
	HRESULT hr;
	DDSURFACEDESC2 ddsd;
	bool FirstTry=true;

	//hard=false;
	soft=!hard;

	if(lpZBuffer!=NULL) lpZBuffer->Release();
	if(lpD3DDEV3!=NULL) lpD3DDEV3->Release();
	lpZBuffer=NULL;
	lpD3DDEV3=NULL;

	if(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_ZBUFFERLESSHSR)
	{
		DebugString("This device does not need z-buffer, skipping");
	}
	else
	{
retry:
		memset(&ddsd,0,sizeof(ddsd));
		ddsd.dwSize=sizeof(ddsd);
		ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT;
		lpDDS->GetSurfaceDesc(&ddsd);

		ddsd.dwSize=sizeof(ddsd);
		ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT|DDSD_CAPS|DDSD_PIXELFORMAT;
		ddsd.ddsCaps.dwCaps=DDSCAPS_ZBUFFER;

		if(!hard) 
			ddsd.ddsCaps.dwCaps|=DDSCAPS_SYSTEMMEMORY;
		else
			ddsd.ddsCaps.dwCaps|=DDSCAPS_VIDEOMEMORY;		

		ddsd.ddpfPixelFormat.dwSize=sizeof(DDPIXELFORMAT);
		
		if(FirstTry)
		{
			ddsd.ddpfPixelFormat.dwFlags=DDPF_ZBUFFER|DDPF_STENCILBUFFER;
			ddsd.ddpfPixelFormat.dwZBufferBitDepth=32;
			ddsd.ddpfPixelFormat.dwStencilBitDepth=8;
		}
		else
		{
			ddsd.ddpfPixelFormat.dwFlags=DDPF_ZBUFFER;
			ddsd.ddpfPixelFormat.dwZBufferBitDepth=16;
			ddsd.ddpfPixelFormat.dwStencilBitDepth=0;
		}

		if(hard)
			lpD3D3->EnumZBufferFormats(IID_IDirect3DHALDevice, EnumZBufferFormatsCallback,(VOID*)&ddsd.ddpfPixelFormat);
		else
			lpD3D3->EnumZBufferFormats(IID_IDirect3DRGBDevice, EnumZBufferFormatsCallback,(VOID*)&ddsd.ddpfPixelFormat);

		hr=lpDD4->CreateSurface(&ddsd,&lpZBuffer,NULL);
		if(hr!=DD_OK)
		{
			if(FirstTry)			// this case for devices that don't support ZTENCILBUFFER and fal the first time
			{
				FirstTry=false;
				goto retry;
			}
			DebugString("WARNING : Unable to create ZBuffer\n");
			DebugString("Error code 0x%x\n",hr);
			return 0;
		}
		
		if(lpZBuffer!=NULL)
		{			
			lpDDS->Restore();
			lpZBuffer->Restore();
			hr=lpDDS->AddAttachedSurface(lpZBuffer);
			if(hr!=DD_OK)
			{
				lpZBuffer->Release();
				lpZBuffer=NULL;

				DebugString("WARNING : Unable to attach ZBuffer\n");
				DebugString("Error code 0x%x\n",hr);
				return 0;
			}
		}
		//else return 0;
	}

	// Gets a Direct3DDevice2
	// Creates a default palette if needed	
	IDirectDrawPalette *pal;
	lpDDS->GetPalette(&pal);
	if(pal==NULL) SetPal(lpDDS);
	else pal->Release();

	lpDDSPrimary->GetPalette(&pal);
	if(pal==NULL) SetPal(lpDDSPrimary);
	else pal->Release();

	// first try HAL then RGB (for debugging)		
	if(hard)
		hr=lpD3D3->CreateDevice(IID_IDirect3DHALDevice,lpDDS,&lpD3DDEV3,NULL);
		//hr=lpD3D3->CreateDevice(IID_IDirect3DRefDevice,lpDDS,&lpD3DDEV3,NULL);
	else 
		hr=lpD3D3->CreateDevice(IID_IDirect3DRGBDevice,lpDDS,&lpD3DDEV3,NULL);
	if(hr!=DD_OK) 
	{
		if(FirstTry) // This case for TNT like devices, where ZBuffer+Stencil==Depth fram
		{
			lpDDS->DeleteAttachedSurface(0,lpZBuffer);
			lpZBuffer->Release();
			lpZBuffer=NULL;

			FirstTry=false;
			goto retry;
		}
		return 0;
	}

	// Infos
	DDSURFACEDESC2 ddsdz;

	ddsdz.dwSize=sizeof(ddsdz);
	lpZBuffer->GetSurfaceDesc(&ddsdz);

	DebugString("INFO: ZBuffer is %u bits\n",ddsdz.ddpfPixelFormat.dwZBufferBitDepth);
	DebugString("INFO: StencilBuffer is %u bits\n",ddsdz.ddpfPixelFormat.dwStencilBitDepth);
	
	StencilSupported=ddsdz.ddpfPixelFormat.dwStencilBitDepth;

	return 1;
}

static void PVAPI D3DEndSupport(void);
static void PVAPI D3DHint(char *hint,UPVD32 val);

static int PVAPI D3DDetect(void)
{	
	IDirectDraw *lpDD;
	IDirectDraw4 *lpDD4;

	if( DirectDrawCreate( NULL, &lpDD, NULL ) == DD_OK )
	{
		if(lpDD->QueryInterface(IID_IDirectDraw4,(LPVOID*)&lpDD4)!=DD_OK)
		{
			lpDD->Release();
			DebugString("PVDX6 : DirectX6 not detected\n");
			return  0;
		}
		lpDD4->Release();
		lpDD->Release();
	}

	// Ok, let's try to load d3d7 instead
	HINSTANCE hInst=NULL;
	
	hInst=LoadLibrary("pvd3d7.dll");	
	if(hInst!=NULL)
	{
		PVHardwareDriver *hd=(PVHardwareDriver*)GetProcAddress(hInst,"PVDriver");

		if(hd!=NULL)
		{
			if(hd->Detect())
			{
				memcpy(&PVDriver,hd,sizeof(PVHardwareDriver));
			}
			else
			{
				DebugString("PVDX Driver: Unable to initialize pvd3d7.dll, switching back to pvd3d6.dll\n");
			}
		}
	}

	return  1;
}

static void PVAPI SetFogTable(int t)
{
	if((t)&&(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_FOGTABLE))
	{
		PV_SetPipelineControl(PV_GetPipelineControl()&(~PVP_COMPUTEFOGVALUES));
		FogTable=TRUE;
		DebugString("INFO: Using Fog Table functions\n");
	}
	else
	{
		PV_SetPipelineControl(PV_GetPipelineControl()|PVP_COMPUTEFOGVALUES);
		FogTable=FALSE;
		DebugString("INFO: Using Vertex Fog functions\n");		
	}
}

// This driver does not take a window handle, but a pointer to a DirectDraw object attached to 
// the rendering window
// This permits the client program to choose cooperative level and rendering device
// assumes Clipper have been already created for windowed rendering
static int PVAPI D3DFillSurface(unsigned surfacenum,float r,float g,float b,float a);
static int PVAPI D3DInitSupport(long _lpDD)
{
	DDSURFACEDESC2 ddsd;
	HRESULT hr;
	DDCAPS ddcaps;
		
	DebugString("Panard Vision DX6 Driver : Starting (%s)\n",PVDriver.Desc);
	soft=FALSE;
	
	if(lpDD!=NULL) return ALREADY_ASSIGNED;
	lpDD=(LPDIRECTDRAW)_lpDD;
	if(lpDD==NULL) return ARG_INVALID;

	lpDD->AddRef();

	// reinit caps
	memcpy(&D3DCaps,&D3DCapsOrg,sizeof(D3DCaps));
	ddsd.dwSize=sizeof(ddsd);
	
	// gets an IDirectDraw4 Interface and dd3
	if(lpDD->QueryInterface(IID_IDirectDraw4,(LPVOID*)&lpDD4)!=DD_OK)
	{
		DebugString("Panard Vision DirectX driver : failed to get IID_IDirectDraw4\n");
		lpDD=NULL;
		return NO_ACCELSUPPORT;
	}
	
	// Look for client a created surface which could be the frontbuffer
	lpDDS=NULL;	
	hr=lpDD4->EnumSurfaces(DDENUMSURFACES_DOESEXIST|DDENUMSURFACES_ALL,NULL,0,EnumSurfacesCallback);
	if(hr!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : Error during surfaces enumeration (0x%x)\n",hr);
		D3DEndSupport();
		return NO_ACCELSUPPORT;	
	}
	if(lpDDS==NULL)
	{
		DebugString("Panard Vision DirectX driver : No attached surface with 3D caps and front buffer caps\n");		
		D3DEndSupport();
		return NO_ACCELSUPPORT;		
	}
	lpDDSPrimary=lpDDS;
	
	// Look for client a created surface which could be the backbuffer
	lpDDS=NULL;
	hr=lpDD4->EnumSurfaces(DDENUMSURFACES_DOESEXIST|DDENUMSURFACES_ALL,NULL,(void*)1,EnumSurfacesCallback);
	if(hr!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : Error during 2nd surfaces enumeration\n");
		D3DEndSupport();
		return NO_ACCELSUPPORT;	
	}
	if(lpDDS==NULL)
	{
		DebugString("WARNING : No attached surface with 3D caps and back buffer caps, running single frame !!\n");
		
		// no backbuffer => backbuf=frontbuffer
		lpDDS=lpDDSPrimary;
		lpDDS->AddRef();
		D3DCaps.NbrSurf=1;
	}
	else D3DCaps.NbrSurf=2;

	// Gets an IDirect3D3 Interface
	if(lpDD4->QueryInterface(IID_IDirect3D3,(LPVOID*)&lpD3D3)!=DD_OK) 
	{
		DebugString("Panard Vision DirectX driver : failed to get IID_IDirect3D3\n");
		D3DEndSupport();
		return NO_ACCELSUPPORT;
	}

	// Init & Gets Caps
	hr=lpD3D3->CreateDevice(IID_IDirect3DHALDevice,lpDDS,&lpD3DDEV3,NULL);
	if(hr==COOL)
	{
		HalCaps.dwSize=sizeof(HalCaps);
		HelCaps.dwSize=sizeof(HelCaps);
		lpD3DDEV3->GetCaps(&HalCaps,&HelCaps);
		lpD3DDEV3->Release();
		lpD3DDEV3=NULL;
	}
	
	if(!InitDevice(true))
	{
		hr=lpD3D3->CreateDevice(IID_IDirect3DRGBDevice,lpDDS,&lpD3DDEV3,NULL);
		if(hr==COOL)
		{
			HalCaps.dwSize=sizeof(HalCaps);
			HelCaps.dwSize=sizeof(HelCaps);
			lpD3DDEV3->GetCaps(&HalCaps,&HelCaps);
			memcpy(&HalCaps,&HelCaps,sizeof(HalCaps));
			lpD3DDEV3->Release();
			lpD3DDEV3=NULL;
		}
		
		if(!InitDevice(false))
		{
			DebugString("Panard Vision DirectX driver : unable to init 3D device\n");
			return NO_ACCELSUPPORT;
		}
	}
						
	if(soft)
	{		
		DebugString("WARNING : Running with Direct3D sofware emulation !!!\n");
		DebugString("          The modes/options you selected are not supported by hardware\n");		
	}	
	else DebugString("INFO: Using hardware acceleration\n");
	
	// Creates the Viewport
	hr=lpD3D3->CreateViewport(&lpViewport3,NULL);
	if(hr!=DD_OK)
	{
		DebugString("Panard Vision DirectX driver : failed to get viewport\n");
		DebugString("Error code 0x%x\n",hr);
		D3DEndSupport();
		return NO_ACCELSUPPORT;
	}
	
	lpD3DDEV3->AddViewport(lpViewport3);
	lpD3DDEV3->SetCurrentViewport(lpViewport3);
	memset(&viewport,0,sizeof(viewport));	
	viewport.dwSize=sizeof(viewport);
	
	// Sets up viewport (full screen)
    memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_WIDTH|DDSD_HEIGHT;
	lpDDS->GetSurfaceDesc(&ddsd);

	viewport.dwX=0;
	viewport.dwY=0;
	viewport.dwWidth=0;
	viewport.dwHeight=0;
	viewport.dvClipX=0;
	viewport.dvClipY=0;
	viewport.dvClipWidth=ddsd.dwWidth;
	viewport.dvClipHeight=ddsd.dwHeight;
	viewport.dvMinZ = 0.0f;
	viewport.dvMaxZ = 1.0f;	
	lpViewport3->SetViewport2(&viewport);
	
	// Sets the rendering state 
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SUBPIXELX,TRUE);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SUBPIXEL,TRUE);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DITHERENABLE,TRUE);      // nice with some harware, ugly otherwise
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SPECULARENABLE,FALSE);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_CULLMODE,D3DCULL_NONE);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREPERSPECTIVE,TRUE);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZENABLE,FALSE);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);    

	lpD3DDEV3->SetTextureStageState( 1, D3DTSS_MINFILTER, D3DTFN_LINEAR );
    lpD3DDEV3->SetTextureStageState( 1, D3DTSS_MAGFILTER, D3DTFG_LINEAR );
	lpD3DDEV3->SetTextureStageState( 1, D3DTSS_MIPFILTER, D3DTFP_POINT);

	lpD3DDEV3->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX, 0 );
    lpD3DDEV3->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    lpD3DDEV3->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
    
	lpD3DDEV3->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 1 );
    lpD3DDEV3->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    lpD3DDEV3->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT ); 
	
	// Clear front buffer
	D3DFillSurface(1,0,0,0,0);
	
	// Check to see if we run in full screen or windowed mode
	lpClipper=NULL;	
	lpDDSPrimary->GetClipper(&lpClipper);	

	// Check for render in a window caps
	if(lpClipper!=NULL)
	{	
		ddcaps.dwSize=sizeof(ddcaps);
		lpDD4->GetCaps(&ddcaps,NULL);
		if(!(ddcaps.dwCaps2&DDCAPS2_CANRENDERWINDOWED))
		{
			DebugString("Panard Vision DirectX driver : No hardware support in a window. Try FullScreen\n",hr);
			MessageBox(NULL,"Your hardware is unable to render accelerated 3D graphics in a window ! If you have multimonitors, then your primary device doesn't support windowed rendering\nSwitch to full screen mode.","WARNING",0); 			
			D3DEndSupport();
			return NO_ACCELSUPPORT;	

		}
	}
		
	// Init PV's Caps
	if(lpZBuffer!=NULL) 
	{
		D3DCaps.GeneralCaps|=PHG_ZBUFFER;
		D3DCaps.FrameCaps|=PHF_DEPTHBUFFER;
	}
	if(HalCaps.dpcTriCaps.dwAlphaCmpCaps!=0) D3DCaps.GeneralCaps|=PHG_ALPHATEST;
	if(StencilSupported) 
	{
		D3DCaps.GeneralCaps|=PHG_STENCILBUFFER;
		D3DCaps.BitsPerStencil=StencilSupported;
	}
	
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_LINEAR) D3DCaps.TextureCaps|=PHT_BILINEAR;
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_MIPNEAREST ) D3DCaps.TextureCaps|=PHT_MIPMAP;
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_LINEARMIPLINEAR) D3DCaps.TextureCaps|=PHT_TRILINEAR;
	
	if(HalCaps.dpcTriCaps.dwSrcBlendCaps!=0) D3DCaps.BlendCaps|=PHB_SRCRGBBLEND;
	if(HalCaps.dpcTriCaps.dwDestBlendCaps!=0) D3DCaps.BlendCaps|=PHB_DSTRGBBLEND;
	
	// if no alpha is present enable stippling just in case of, who said ugly ???	
	if(!(D3DCaps.BlendCaps&(PHB_SRCRGBBLEND|PHB_DSTRGBBLEND))) 
	{	
		DebugString("WARNING : Enabling stippling\n");
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STIPPLEDALPHA,TRUE);
	}
	
	switch(HalCaps.dwDeviceZBufferBitDepth)
	{
	case DDBD_8:D3DCaps.BitsPerDepth=8;break;
	case DDBD_16:D3DCaps.BitsPerDepth=16;break;
	case DDBD_24:D3DCaps.BitsPerDepth=24;break;
	case DDBD_32:D3DCaps.BitsPerDepth=32;break;
	}
	
	InitSurfaceCaps(lpDDS);

	SetBackground();

	// Init some runtime decision variables
	if(HalCaps.wMaxSimultaneousTextures>1) 
	{
		MultiTexture=HalCaps.wMaxSimultaneousTextures; 
		DebugString("INFO: Multitexture enabled (%u)\n",HalCaps.wMaxSimultaneousTextures);
	}
	else 
	{
		MultiTexture=0;
		DebugString("INFO: Multitexture not supported, LeelooMultipass enabled\n");
	}

	// Pipeline
	PV_SetPipelineControl(PVP_NO_TRIANGULATE);

	// Some tests
	if(HalCaps.dpcTriCaps.dwTextureCaps&D3DPTEXTURECAPS_SQUAREONLY) DebugString("WARNING : Device only supports square textures, problems are coming !!!\n");

	// Fog Testing
	D3DHint("PV_FOG_TABLE",0);

	// W-Buffer
	D3DHint("PV_WBUFFER",1);

	return COOL;
}

static void PVAPI D3DEndSupport(void)
{
	// The magic is done	
	if(lpDDS!=NULL) lpDDS->Release();
	if(lpDDSPrimary!=NULL) lpDDSPrimary->Release();
	if(lpClipper!=NULL) lpClipper->Release();
	if(lpZBuffer!=NULL) lpZBuffer->Release();
	if(lpDDPalette!=NULL) lpDDPalette->Release();
	if(g_pMatBack!=NULL) g_pMatBack->Release();
	if(lpViewport3!=NULL) lpViewport3->Release();
	if(lpD3DDEV3!=NULL) lpD3DDEV3->Release();
	if(lpD3D3!=NULL) lpD3D3->Release();
	if(lpDD4!=NULL) lpDD4->Release();
	if(lpDD!=NULL) lpDD->Release();
	lpDD=NULL;
	lpDDS=NULL;
	lpDDSPrimary=NULL;
	lpClipper=NULL;
	lpZBuffer=NULL;
	lpDD4=NULL;
	lpD3D3=NULL;
	
	DebugString("Panard Vision DX Driver : Ending\n");
}

static int PVAPI D3DSetViewPort(unsigned int cmx,unsigned int cMx,unsigned int cmy,unsigned int cMy)
{
	if(lpViewport3==NULL) return COOL;   // Sanity check for out of order function call in the client
	
	// Set up viewport for direct rasterization (no transformation by d3d)
	viewport.dwX=cmx;
	viewport.dwY=cmy;
	viewport.dwWidth=cMx-cmx;
	viewport.dwHeight=cMy-cmy;
	lpViewport3->SetViewport2(&viewport);
	
	return COOL;
}

static int PVAPI D3DLoadTexture(PVMaterial *m)
{
	HRESULT hr;
    static DDSURFACEDESC2       ddsd;
	LPDIRECTDRAWSURFACE4 surf=NULL,FirstSurf2=NULL,LastSurf=NULL;
	UPVD16 *tex16,r,g,b,a;
	UPVD32 c,*tex32;
	UPVD8 *tex8,t;
	unsigned i,j,k,TotMips;
	LPDIRECT3DTEXTURE2 lpTex2;
	
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return COOL;
	
//DebugString("Downloading %s\n",m->Name);
	
	// Gosh, dx surafce caps is a hell to manage correctly	   
	if(HalCaps.dpcTriCaps.dwTextureFilterCaps&D3DPTFILTERCAPS_MIPNEAREST) TotMips=(m->NbrMipMaps==0?1:m->NbrMipMaps);
	else TotMips=1;

	if(m->Type&PROCEDURAL) TotMips=1;
	
//DebugString("Downloading nbrmips %u\n",TotMips);

	// Choose texture type
	ddsd.dwSize=sizeof(ddsd);		
	if(m->TextureFlags&TEXTURE_RGBA)
	{
			ChooseAlphaTextureFormat(lpD3DDEV3, &ddsd.ddpfPixelFormat);
	}
	else
	{		
			if(m->Hint.Quality&PHQ_HIGH) ChooseTextureFormat(lpD3DDEV3, 24, &ddsd.ddpfPixelFormat);
			else
				if(m->Hint.Quality&PHQ_LOW) ChooseTextureFormat(lpD3DDEV3, 8, &ddsd.ddpfPixelFormat);
				else
					ChooseTextureFormat(lpD3DDEV3, 16, &ddsd.ddpfPixelFormat);
	}

	// Try to create a a surface in system memory	
	ddsd.dwFlags = DDSD_TEXTURESTAGE|DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT | DDSD_MIPMAPCOUNT ;
	ddsd.dwWidth = m->Tex[0].Width;
	ddsd.dwHeight = m->Tex[0].Height;
	ddsd.dwMipMapCount=TotMips;
	ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE |DDSCAPS_MIPMAP|DDSCAPS_COMPLEX;		
	ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE|DDSCAPS2_OPAQUE; 
	ddsd.dwTextureStage=0;
	ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);

	// Check maximum texture size
	if((HalCaps.dwMaxTextureWidth<ddsd.dwWidth)||
	   (HalCaps.dwMaxTextureHeight<ddsd.dwHeight))
	{
		ddsd.dwWidth=HalCaps.dwMaxTextureWidth;
		ddsd.dwHeight=HalCaps.dwMaxTextureHeight;

		PVTexture *newtex;

		for(k=0;k<TotMips;k++)
		{
			DebugString("Resizing incoming %ux%u texture to %ux%u\n",m->Tex[k].Width,m->Tex[k].Height,ddsd.dwWidth>>k,ddsd.dwHeight>>k);
			newtex=PV_MipResample2(m->Tex[k].Texture,m->Tex[k].Width,m->Tex[k].Height, ddsd.dwWidth>>k,ddsd.dwHeight>>k,m->TextureFlags&TEXTURE_RGBDIRECT?TEXTURE_RGB:m->TextureFlags,NULL,0);
			if(newtex==NULL) return NO_MEMORY;

			if(!(m->TextureFlags&TEXTURE_TEX_DONT_FREE)) free(m->Tex[k].Texture);
			m->TextureFlags&=~TEXTURE_TEX_DONT_FREE;

			m->Tex[k].Height=newtex->Width;
			m->Tex[k].Width=newtex->Height;
			m->Tex[k].Texture=newtex->Texture;
		}
	}

	// Handles procedural textures
	if(m->Type&PROCEDURAL)
	{
		ddsd.ddsCaps.dwCaps2&=~DDSCAPS2_OPAQUE;
		ddsd.ddsCaps.dwCaps2|=DDSCAPS2_HINTDYNAMIC;
	}

	hr=lpDD4->CreateSurface(&ddsd,&surf,NULL);
	if(hr!=DD_OK)
	{			
		// failed					
		DebugString("Panard Vision Direct X Driver : Unable to get a proper surface\n");
		DebugString("Error code 0x%x\n",hr);
		return ACCEL_NO_MEMORY;
	}
	surf->AddRef();
	FirstSurf2=surf;

	// Setup constants
	unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned NbrBitsAlpha=GetMaskSize(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);
	unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned AlphaPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);

	unsigned Multiplier;

	if(m->TextureFlags&TEXTURE_RGBA) Multiplier=4; else Multiplier=3;
		
	for(k=0;k<TotMips;k++)
	{		   		   
		ddsd.dwSize=sizeof(ddsd);
				
		// Now fills the surface with the texture				
		hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
		if(hr!=DD_OK) 
		{
			surf->Release();
			
			DebugString("Panard Vision Direct X Driver : Unable to lock surface\n");
			DebugString("Error code 0x%x\n",hr);			
			return ACCEL_NO_MEMORY;
		}
		
		// Init the filling process
		tex8=(UPVD8 *)ddsd.lpSurface;
		tex16=(UPVD16 *)ddsd.lpSurface;
		tex32=(UPVD32 *)ddsd.lpSurface;
		UPVD8 *rov=(UPVD8*)m->Tex[k].Texture;
		float c1,c2,c3,c4;
		unsigned c5,c6,c7;

		c1=((1<<NbrBitsRed)-1)/255.0;
		c2=((1<<NbrBitsGreen)-1)/255.0;
		c3=((1<<NbrBitsBlue)-1)/255.0;
		c4=((1<<NbrBitsAlpha)-1)/255.0;

		c5=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width;
		c6=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width/2;
		c7=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->Tex[k].Width/4;

		for(i=0;i<m->Tex[k].Height;i++)
		{
			for(j=0;j<m->Tex[k].Width;j++,rov+=Multiplier)
			{				
				r=*rov;
				g=*(rov+1);
				b=*(rov+2);
				if(m->TextureFlags&TEXTURE_RGBA) a=*(rov+3);

				r=(float)r*c1;
				g=(float)g*c2;
				b=(float)b*c3;
				a=(float)a*c4;
				
				c=(b<<BluePos);
				c|=(g<<GreenPos);
				c|=(r<<RedPos);
				c|=(a<<AlphaPos);				

				switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
				{
				case 8:
					*tex8=c;
					tex8++;
					break;
				case 16:
					*tex16=c;
					tex16++;
					break;
				case 24:
					*tex8=c;
					*(tex8+1)=(c>>8);
					*(tex8+2)=(c>>16);
					tex8+=3;
					break;
				case 32:
					*tex32=c;
					tex32++;
					break;
				default:
					DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
					D3DEndSupport();
					return BIZAR_ERROR;
				}
			}
			tex8+=c5;
			tex16+=c6;
			tex32+=c7;
		}
				
		surf->Unlock(NULL);		

		// Manages Mipmaps
		DDSCAPS2 ddsCaps; 

		ddsCaps.dwCaps = DDSCAPS_TEXTURE | DDSCAPS_MIPMAP; 

		hr=surf->GetAttachedSurface(&ddsCaps, &LastSurf); 
		if((hr!=DD_OK)&&(hr!=DDERR_NOTFOUND))
		{
			// not possible
			DebugString("Panard Vision Direct X driver : Unable to step system mipmaps\n");
			return BIZAR_ERROR;
		}
		surf->Release(); 
		surf = LastSurf; 
	}
	   
	// Copy surface to hardware
	// Gets a texture interface for source texture
	hr=FirstSurf2->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
	if(hr!=DD_OK)
	{
		DebugString("Panard Vision Direct X driver : unable to obtain IID_IDIRECT3DTEXTURE2\n");
		DebugString("Error code 0x%x\n",hr);
		return BIZAR_ERROR;
	}
		
	// Saves texture interface to destroy them or reload them
	PVSurfCtrl *sc;
	sc=(PVSurfCtrl*)calloc(sizeof(PVSurfCtrl),1);
	if(sc==NULL) return NO_MEMORY;
	sc->d3dsurf[0]=FirstSurf2;
	sc->d3dtex[0]=lpTex2;
	sc->d3dddpf=ddsd.ddpfPixelFormat;
	m->HardwarePrivate=sc;		
	
	// --------------------------------------------------- Now the 'Phong Texture'
	// Hey boys this an horrible D3D Hack. I was unable to figure out a clean and
	// portable way of creating a Luminance map (like in GL or Glide), so I create
	// a 16 bits texturing whith R=G=B=AlphaFromPhongTex
	// Memory consuming
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{			
		// Preprocess lightmap to be darker
		for(i=0;i<m->AuxiliaryTexture.Width;i++)
			for(j=0;j<m->AuxiliaryTexture.Height;j++)
			{
				m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]=max(0,m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]-1.3*(255-m->AuxiliaryTexture.Texture[j*m->AuxiliaryTexture.Width+i]));
			}
			
			// Try to create a 16 bits surface in system memory
			memset(&ddsd,0,sizeof(ddsd));
			ddsd.dwSize=sizeof(ddsd);
			ChooseTextureFormat(lpD3DDEV3, 16, &ddsd.ddpfPixelFormat);
			
			ddsd.dwFlags = DDSD_TEXTURESTAGE|DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
			ddsd.dwWidth = m->AuxiliaryTexture.Width;
			ddsd.dwHeight = m->AuxiliaryTexture.Height;	   		   
			ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE;
			ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE|DDSCAPS2_OPAQUE;			
			if(MultiTexture)
				ddsd.dwTextureStage=1;
			else
				ddsd.dwTextureStage=0;
			ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);

			hr=lpDD4->CreateSurface(&ddsd,&surf,NULL);
			if(hr!=DD_OK)
			{			
				// failed					
				DebugString("Panard Vision Direct X Driver : Unable to create a proper phong surface\n");
				DebugString("Error code 0x%x\n",hr);
				return ACCEL_NO_MEMORY;
			}
									
			// Now fills the surface with the texture
			ddsd.dwSize=sizeof(ddsd);
			
			hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
			if(hr!=DD_OK) 
			{
				surf->Release();
				
				DebugString("Panard Vision Direct X Driver : Unable to lock phong surface\n");
				DebugString("Error code 0x%x\n",hr);				
				return ACCEL_NO_MEMORY;
			}
			
			// Init the filling process
			tex8=(UPVD8 *)ddsd.lpSurface;
			tex16=(UPVD16 *)ddsd.lpSurface;
			tex32=(UPVD32 *)ddsd.lpSurface;
			
			unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);					
			unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
			unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
			unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
			
			for(i=0;i<m->AuxiliaryTexture.Height;i++)
			{
				for(j=0;j<m->AuxiliaryTexture.Width;j++)
				{
					t=m->AuxiliaryTexture.Texture[i*m->AuxiliaryTexture.Width+j];
				
					r=(float)t*((1<<NbrBitsRed)-1)/255.0;
					g=(float)t*((1<<NbrBitsGreen)-1)/255.0;
					b=(float)t*((1<<NbrBitsBlue)-1)/255.0;
					
					c=(b<<BluePos);
					c|=(g<<GreenPos);
					c|=(r<<RedPos);
					
					switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
					{
					case 8:
						*tex8=c;
						tex8++;
						break;
					case 16:
						*tex16=c;
						tex16++;
						break;
					case 24:
						*tex8=c;
						*(tex8+1)=(c>>8);
						*(tex8+2)=(c>>16);
						tex8+=3;
						break;
					case 32:
						*tex32=c;
						tex32++;
						break;
					default:
						DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
						D3DEndSupport();
						return BIZAR_ERROR;
					}
				}
				tex8+=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width;
				tex16+=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width/2;
				tex32+=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*m->AuxiliaryTexture.Width/4;

			}
			surf->Unlock(NULL);
			
			// Copy surface to hardware
			// Gets a texture ibnterface for source texture
			hr=surf->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
			if(hr!=DD_OK)
			{
				DebugString("Panard Vision Direct X driver : unable to obtain IID_IDIRECT3DTEXTURE2 for hardware (phong)\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}
						
			// Saves texture interface to destroy them or reload them
			sc->d3dsurf[1]=surf;
			sc->d3dtex[1]=lpTex2;
	}
//	DebugString("Material done.\n");	
	return COOL;
}

static void PVAPI D3DDeleteTexture(PVMaterial *m)
{
	PVSurfCtrl *sc;
	
	if(!((m->TextureFlags&TEXTURE_RGBDIRECT)||(m->TextureFlags&TEXTURE_RGBA)||(m->TextureFlags&TEXTURE_RGB))) return;
		
	sc=(PVSurfCtrl*)m->HardwarePrivate;
	sc->d3dsurf[0]->Release();
	sc->d3dtex[0]->Release();
	
	if((m->Type&(PHONG|U_PHONG))&&(m->AuxiliaryTexture.Texture!=NULL))
	{
		sc->d3dsurf[1]->Release();
		sc->d3dtex[1]->Release();
	}
	free(sc);
	m->HardwarePrivate=NULL;
}

//////////////////////////////////////////////////////////////////////////// LIGHTMAPS
#define MAXLIGHTMAPS	100000
#define LMAPW			256
#define LMAPH			256

static PVLightMap **LMaps=NULL;
static unsigned nbrlmaps=0,LMapComputed=0;
static LPDIRECTDRAWSURFACE4 LMSurf[100];
static unsigned nbrsurflm=0;

static int PVAPI D3DLoadLightMap(PVLightMap *m)
{
	if(LMapComputed) return COOL;
	if(m->Flags&LIGHTMAP_PROCESSED) return COOL;
	
	// On alloue le tablo pseudo statique
	if(LMaps==NULL)
	{
		LMaps=(PVLightMap**)calloc(MAXLIGHTMAPS,sizeof(PVLightMap*));
		if(LMaps==NULL) return NO_MEMORY;
		nbrlmaps=0;
	}
	
	LMaps[nbrlmaps++]=m;
	m->Flags|=LIGHTMAP_PROCESSED;
	
    return COOL;
}

static int __cdecl LMCompare( const void *arg1, const void *arg2 )
{
	PVLightMap *m1,*m2;
	
	m1=*(PVLightMap**)arg1;
	m2=*(PVLightMap**)arg2;
	
	if(m1->Height==m2->Height)
	{
		if(m1->Width>m2->Width) return -1;
		else return 1;
	}

	if(m1->Height<m2->Height) return 1;
	else return -1;
}

static int DownloadLightMaps(void)
{
	HRESULT hr;
	LPDIRECTDRAWSURFACE4 surf=NULL;    
	static DDSURFACEDESC2       ddsd;		
	unsigned CurrentW=0,CurrentH=0,MaxH=0;
	
	UPVD16 *tex16,r,g,b,a;
	UPVD32 c,*tex32;
	UPVD8 *tex8;
	unsigned i,j,k;
	LPDIRECT3DTEXTURE2 lpTex2;
	PVLightMap *m;
	PVSurfCtrl *sc;
	
	if(nbrlmaps==0) return COOL;
	
	DebugString("Processing %u lightmaps ...\n",nbrlmaps);
	
	// Sort lightmaps
	qsort( (void*)LMaps, nbrlmaps, sizeof( PVLightMap * ), LMCompare );	
	
	ddsd.dwSize=sizeof(ddsd);
	ChooseTextureFormat(lpD3DDEV3, 16, &ddsd.ddpfPixelFormat);

	unsigned NbrBitsRed=GetMaskSize(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned NbrBitsGreen=GetMaskSize(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned NbrBitsBlue=GetMaskSize(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned NbrBitsAlpha=GetMaskSize(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);
	unsigned RedPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRBitMask);
	unsigned GreenPos=GetMaskPos(ddsd.ddpfPixelFormat.dwGBitMask);
	unsigned BluePos=GetMaskPos(ddsd.ddpfPixelFormat.dwBBitMask);
	unsigned AlphaPos=GetMaskPos(ddsd.ddpfPixelFormat.dwRGBAlphaBitMask);

	float c1,c2,c3,c4;

	c1=(float)((1<<NbrBitsRed)-1)/255.0;
	c2=(float)((1<<NbrBitsGreen)-1)/255.0;
	c3=(float)((1<<NbrBitsBlue)-1)/255.0;
	c4=(float)((1<<NbrBitsAlpha)-1)/255.0;
	
	CurrentW=CurrentH=MaxH=0;
	LMapComputed=1;
	nbrsurflm=0;
	
	for(k=0;k<nbrlmaps;k++)
	{
		m=LMaps[k];
		sc=(PVSurfCtrl*)calloc(sizeof(PVSurfCtrl),1);
		if(sc==NULL) return NO_MEMORY;
		m->HardwarePrivate=sc;
		
		for(int z=0;z<m->NbrLightMaps;z++)
		{
			if((CurrentW==0)&&(CurrentH==0))
			{
				// Try to create a a surface in system memory
				ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT|DDSD_TEXTURESTAGE;;
				ddsd.dwWidth = LMAPW;
				ddsd.dwHeight = LMAPH;	   		   
				ddsd.ddsCaps.dwCaps=DDSCAPS_TEXTURE;
				ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE|DDSCAPS2_OPAQUE;			
				ddsd.dwTextureStage=1;
				ddsd.ddpfPixelFormat.dwSize=sizeof(ddsd.ddpfPixelFormat);
				
				hr=lpDD4->CreateSurface(&ddsd,&surf,NULL);
				if(hr!=DD_OK)
				{			
					// failed					
					DebugString("Panard Vision Direct X Driver : (Lightmap) Unable to get a proper surface\n");
					DebugString("Error code 0x%x\n",hr);
					return ACCEL_NO_MEMORY;
				}
				LMSurf[nbrsurflm]=surf;				
				nbrsurflm++;
			}
			
			// Now fills the surface with the texture
			ddsd.dwSize=sizeof(ddsd);
			
			hr=surf->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR,NULL);
			if(hr!=DD_OK) 
			{
				surf->Release();
				
				DebugString("Panard Vision Direct X Driver : (Lightmap) Unable to lock surface\n");
				DebugString("Error code 0x%x\n",hr);			
				return ACCEL_NO_MEMORY;
			}
			
			// Init the filling process
			tex8=(UPVD8 *)ddsd.lpSurface;
			tex16=(UPVD16 *)ddsd.lpSurface;
			tex32=(UPVD32 *)ddsd.lpSurface;
			
			// Decal
			if((CurrentW+m->Width<LMAPW)&&(CurrentH+m->Height<LMAPH))
			{
				tex8+=CurrentH*LMAPW+CurrentW;
				tex16+=CurrentH*LMAPW+CurrentW;
				tex32+=CurrentH*LMAPW+CurrentW;			
				CurrentW+=m->Width;
				if(m->Height+CurrentH>MaxH) MaxH=m->Height+CurrentH;
			}
			else
			{
				// not enough room, try a lower band
				surf->Unlock(NULL);
				if(MaxH+m->Height<LMAPH)
				{
					CurrentH=MaxH;
					CurrentW=0;
					z--;
					continue;
				}
				else
				{					
					// New surface
					CurrentW=CurrentH=MaxH=0;
					z--;
					continue;
				}
			}					

			unsigned c5=ddsd.lPitch-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW;
			unsigned c6=ddsd.lPitch/2-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW/2;
			unsigned c7=ddsd.lPitch/4-(ddsd.ddpfPixelFormat.dwRGBBitCount/8)*LMAPW/4;

			UPVD8 *rov=&m->Maps[z][0];

			for(i=0;i<m->Height;i++)
			{
				for(j=0;j<m->Width;j++)
				{				
					if(m->Flags&LIGHTMAP_RGB)
					{
						r=*rov;
						g=*(rov+1);
						b=*(rov+2);
						a=255;
						rov+=3;
					}
					else
					{
						r=g=b=*rov;
						a=255;
						rov++;
					}
										
					r=(float)r*c1;
					g=(float)g*c2;
					b=(float)b*c3;
					a=(float)a*c4;
					
					c=(b<<BluePos);
					c|=(g<<GreenPos);
					c|=(r<<RedPos);
					c|=(a<<AlphaPos);
					
					switch(ddsd.ddpfPixelFormat.dwRGBBitCount)
					{
					case 8:
						*tex8=c;
						tex8++;
						break;
					case 16:
						*tex16=c;
						tex16++;
						break;
					case 24:
						*tex8=c;
						*(tex8+1)=(c>>8);
						*(tex8+2)=(c>>16);
						tex8+=3;
						break;
					case 32:
						*tex32=c;
						tex32++;
						break;
					default:
						DebugString("Unknown pixel format (%u)\n",ddsd.ddpfPixelFormat.dwRGBBitCount);
						D3DEndSupport();
						return BIZAR_ERROR;
					}
				}
				
				tex8+=LMAPW-m->Width;
				tex16+=LMAPW-m->Width;
				tex32+=LMAPW-m->Width;
				
				tex8+=c5;
				tex16+=c6;
				tex32+=c7;
			}
			surf->Unlock(NULL);
						
			// Gets a texture interface for source texture			
			hr=surf->QueryInterface(IID_IDirect3DTexture2,(LPVOID*)&lpTex2);	
			if(hr!=DD_OK)
			{			
				DebugString("Panard Vision Direct X driver : (LightMap) unable to obtain IID_IDIRECT3DTEXTURE2 for hardware\n");
				DebugString("Error code 0x%x\n",hr);
				return BIZAR_ERROR;
			}

			// Saves texture interface to destroy them or reload them									
			sc->d3dsurf[z]=surf;
			sc->d3dtex[z]=lpTex2;			
			
			// Fixup ccord		
			m->su[z]*=(float)m->Width/(float)LMAPW;
			m->sv[z]*=(float)m->Height/(float)LMAPH;
			
			m->su[z]+=(float)(CurrentW-m->Width)/(float)LMAPW;
			m->sv[z]+=(float)(CurrentH)/(float)LMAPH;	
		}
		// Setup lightmaps scaling
		m->ScaleU*=(float)m->Width/(float)LMAPW;
		m->ScaleV*=(float)m->Height/(float)LMAPH;
		m->ScaleU*=(1.0/(float)(m->MaxU-m->MinU));
		m->ScaleV*=(1.0/(float)(m->MaxV-m->MinV));
	}
	DebugString("Lightmap done\n");
						
	return COOL;
}

static void PVAPI D3DDeleteLightMap(PVLightMap *m)
{
	unsigned k,TotMips;
	PVSurfCtrl *sc;
	
	if(!(m->Flags&LIGHTMAP_PROCESSED)) return;
	if(m==NULL) return;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	
	nbrlmaps--;
	if(nbrlmaps==0)
	{
		DebugString("Freeing lightmaps...\n");
		for(k=0;k<nbrsurflm;k++)
		{
			LMSurf[k]->Release();	
		}		
		LMapComputed=0;
	}
	
	TotMips=m->NbrLightMaps;	
	for(k=0;k<TotMips;k++)
	{
	  if(m->Maps[k]==NULL) break;	  	  
	  sc->d3dtex[k]->Release();
	}
	free(sc);
	m->HardwarePrivate=NULL;
	REMOVEFLAG(m->Flags,LIGHTMAP_PROCESSED);
}

////////////////////////////////////////////////////////////////////////////////////////////

static void *PVAPI D3DGetFiller(PVFLAGS flags)
{
	flags&=~PERSPECTIVE;
	switch (flags&(RENDER_MASK|SHADE_MASK))
	{
	case FLAT|NOTHING:return TriD3DFlat;break;
	case GOURAUD|NOTHING:return TriD3DGouraud;break;
		
	case U_PHONG|NOTHING:
	case PHONG|NOTHING:
	case NOTHING|AMBIENT_MAPPING:
	case NOTHING|MAPPING:return TriD3DMapping;break;
		
	case FLAT|AMBIENT_MAPPING:
	case FLAT|MAPPING:return TriD3DFlatMapping;break;
		
	case GOURAUD|AMBIENT_MAPPING:
	case GOURAUD|MAPPING:return TriD3DGouraudMapping;break;
		
		// Bump is treated as Phong
	case U_BUMP|AMBIENT_MAPPING:
	case U_BUMP|MAPPING:
	case BUMP|AMBIENT_MAPPING:
	case BUMP|MAPPING:
			
	case U_PHONG|AMBIENT_MAPPING:
	case U_PHONG|MAPPING:				
	case PHONG|AMBIENT_MAPPING:
	case PHONG|MAPPING:if(MultiTexture) return TriD3DBiMappingMT; else return TriD3DBiMapping;break;

	case MULTITEXTURE|GOURAUD:
	case MULTITEXTURE|FLAT:
	case MULTITEXTURE|LIGHTMAP:
	case MULTITEXTURE: if(MultiTexture) return TriD3DMTMT; else return TriD3DMT; break;
		
	case LIGHTMAP|MAPPING:
		if(MultiTexture) return TriD3DLightMapMT; else return TriD3DLightMap;break;
		
	default:return NULL;
	}
}

static void PVAPI D3DBeginFrame(PVFLAGS PVMode,PVFLAGS PVPipe)
{
	D3DRECT rect;

	RestoreAllSurfaces();

	// Sync hardware
	if(lpClipper!=NULL)
		while(lpDDS->GetBltStatus(DDGBS_ISBLTDONE)==DDERR_WASSTILLDRAWING);
	while(lpDDS->GetFlipStatus(DDGFS_ISFLIPDONE)==DDERR_WASSTILLDRAWING);
	
	// Generates lightmaps
	if(LMapComputed==0)
	{		
		int hr=DownloadLightMaps();
		if(hr!=COOL) return;
	}
			
	// Clear ZBuffer+Stencil
	DWORD flags=0;
	
	if((!(PVPipe&PVP_NO_ZBUFFERCLEAR))&&(PVMode&PVM_ZBUFFER)&&(lpZBuffer!=NULL)) flags|=D3DCLEAR_ZBUFFER;
	if((!(PVPipe&PVP_NO_STENCILCLEAR))&&(PVMode&PVM_STENCILBUFFER)&&(StencilSupported)) flags|=D3DCLEAR_STENCIL;

	if(flags!=0)
	{
		rect.x1=viewport.dwX;
		rect.y1=viewport.dwY;
		rect.x2=viewport.dwX+viewport.dwWidth;
		rect.y2=viewport.dwY+viewport.dwHeight;

		lpViewport3->Clear2(1, &rect,flags,0,1.0,(1<<(StencilSupported-1))|(1<<(StencilSupported-2)));
	}

	lpD3DDEV3->BeginScene();

	lastm=NULL;
}

static int PVAPI D3DPreRender(PVWorld *w,unsigned surfacenum,PVFLAGS PVMode,PVFLAGS PVPipe)
{		
	AmbientLight=&w->AmbientLight;	
	PVM=PVMode;
	fp=w->Camera->FrontDist;
	bp=w->Camera->BackDist;	
	depthval=(bp/(bp-fp));
	depthval2=(bp*fp)/(bp-fp);

	// Set projection matrix, for WFog, and WBuffer
	D3DMATRIX mat;

	D3DUtil_SetProjectionMatrix(mat,w->Camera->yscreenscale,w->Camera->fieldofview,fp,bp);
	lpD3DDEV3->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&mat);
	
	// Fog support
	if(w->Fog.Type!=PVF_NONE)
	{	
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);
        lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGCOLOR,D3DRGB(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b));
		FogEnabled=true;

		if(FogTable)
		{
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLESTART,*( LONG* ) &w->Fog.Start);
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLEEND,*( LONG* ) &w->Fog.End);
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLEDENSITY,*( LONG* ) &w->Fog.Density);		
			
			switch(w->Fog.Type)
			{
			case PVF_LINEAR:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_LINEAR);break;
			case PVF_EXP:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_EXP);break;
			case PVF_EXP2:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_EXP2);break;
			default:
				PV_Fatal("DX Driver: Unknown fog mode !",w->Fog.Type);
			}
			OverrideLighting=FALSE;
		}
		else
		{
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_NONE);		
			//OverrideLighting=TRUE;
			OverrideLighting=FALSE;		// Bug TNT & pb voodoo
		}
	}
	else 
	{		
        if(PVMode&PVM_VERTEXFOGGING)
        {
            lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);
            lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE,D3DFOG_NONE);		
		    lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGCOLOR,D3DRGB(w->Fog.Color.r,w->Fog.Color.g,w->Fog.Color.b));
			//OverrideLighting=TRUE;
			OverrideLighting=FALSE;		// Bug TNT & pb voodoo
			FogEnabled=true;
        }
        else
		{
            lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGENABLE,FALSE);
			OverrideLighting=FALSE;
			FogEnabled=false;
		}
	}
	
	return COOL;
}

static void PVAPI D3DPrepareFace(PVFace *f)
{	
	static int Alphaf[]={D3DBLEND_ZERO,D3DBLEND_ONE,D3DBLEND_DESTCOLOR,D3DBLEND_INVDESTCOLOR,D3DBLEND_SRCALPHA,D3DBLEND_INVSRCALPHA,D3DBLEND_DESTALPHA,D3DBLEND_INVDESTALPHA,D3DBLEND_SRCALPHASAT,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR};    

    if(oldpvf==PVM)
        if(lastm==f->MaterialInfo) return;

	// Sets for wireframe
	if(f->MaterialInfo->Type&WIREFRAME)
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FILLMODE,D3DFILL_WIREFRAME);
	else
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FILLMODE,D3DFILL_SOLID);

	// Sets for zbuffer
	if((PVM&PVM_ZBUFFER)&&(f->MaterialInfo->Type&ZBUFFER))
	{
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZENABLE,zbuftype);
		if(f->MaterialInfo->ZWrite) 
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,TRUE);
		else
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);

		switch(f->MaterialInfo->DepthTest)
		{
		case CMP_LESS:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_ALWAYS);break;
		}
	}
	else 
	{
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZENABLE,FALSE);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,FALSE);
	}

	// Stencil Buffer
	if((PVM&PVM_STENCILBUFFER)&&(f->MaterialInfo->Type&STENCILBUFFER))
	{
		static D3DSTENCILOP sop[]={D3DSTENCILOP_KEEP,D3DSTENCILOP_ZERO,D3DSTENCILOP_REPLACE, D3DSTENCILOP_INCRSAT,
								   D3DSTENCILOP_DECRSAT, D3DSTENCILOP_INVERT,D3DSTENCILOP_INCR, D3DSTENCILOP_DECR};				

		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILENABLE,TRUE);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILREF,f->MaterialInfo->StencilRef);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILMASK,f->MaterialInfo->StencilMask);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILWRITEMASK,f->MaterialInfo->StencilWriteMask);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFAIL,sop[f->MaterialInfo->StencilFail]);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILZFAIL,sop[f->MaterialInfo->StencilZFail]);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILPASS,sop[f->MaterialInfo->StencilPass]);
		
		switch(f->MaterialInfo->StencilFunc)
		{
		case CMP_LESS:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILFUNC,D3DCMP_ALWAYS);break;
		}
	}
	else 
	{
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_STENCILENABLE,FALSE);
	}
	
	// Sets for AlphaBlending
	if(PVM&PVM_ALPHABLENDING)
	{
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,Alphaf[f->MaterialInfo->BlendRgbSrcFactor]);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,Alphaf[f->MaterialInfo->BlendRgbDstFactor]);
	}
	else lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,FALSE);
	
	// Sets for Alpha testing
	if(PVM&PVM_ALPHATESTING)
	{
		switch(f->MaterialInfo->AlphaTest)
		{
		case CMP_LESS:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_LESS);break;
		case CMP_NEVER:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_NEVER);break;
		case CMP_EQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_EQUAL);break;
		case CMP_LEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_LESSEQUAL);break;
		case CMP_GREATER:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_GREATER);break;
		case CMP_NOTEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_NOTEQUAL);break;
		case CMP_GEQUAL:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_GREATEREQUAL);break;
		case CMP_ALWAYS:
		default:lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAFUNC,D3DCMP_ALWAYS);break;
		}
		
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHAREF,(unsigned)((float)f->MaterialInfo->AlphaReference*255.0)); //16.16 fixed, bah non en fait avec dx6
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHATESTENABLE,TRUE);
	}
	else lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHATESTENABLE,FALSE);
	
	// The following is for textured faces only	
	if(f->MaterialInfo->Type&(MAPPED_MATERIAL))
	{
		// Sets texture blending mode
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMAPBLEND,D3DTBLEND_MODULATEALPHA);
		
		// Sets wrapping modes
		switch(f->MaterialInfo->RepeatU)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSU,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSU,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSU,D3DTADDRESS_WRAP);break;
		}
		
		switch(f->MaterialInfo->RepeatV)
		{
		case TEXTURE_MIRROR:			 
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSV,D3DTADDRESS_MIRROR);break;
		case TEXTURE_CLAMP:
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSV,D3DTADDRESS_CLAMP);break;
		default:
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREADDRESSV,D3DTADDRESS_WRAP);break;
		}
		
		// Sets up filtering
		if((f->MaterialInfo->TextureFlags&TEXTURE_BILINEAR)||(f->MaterialInfo->TextureFlags&TEXTURE_TRILINEAR))
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMAG,D3DFILTER_LINEAR);
		else
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMAG,D3DFILTER_NEAREST);
		
		// Sets for mipmap&trilinear
		if(f->MaterialInfo->TextureFlags&TEXTURE_TRILINEAR) lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_LINEARMIPLINEAR);
		else
			if(f->MaterialInfo->TextureFlags&TEXTURE_MIPMAP) 
			{
				if(f->MaterialInfo->TextureFlags&TEXTURE_BILINEAR) lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_MIPLINEAR);
				else lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_MIPNEAREST);
			}
			else
			{
				if(f->MaterialInfo->TextureFlags&TEXTURE_BILINEAR) lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_LINEAR);
				else lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREMIN,D3DFILTER_NEAREST);
			}				
	}
	else 
	{
		lpD3DDEV3->SetTexture(0,NULL);
		lastmip[0]=NULL;
	}

	// Fog Powah!
	if((!(f->MaterialInfo->Type&FOGABLE))||(!FogEnabled))
	{
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGENABLE,FALSE);		
		
		// Shading mode
		if(f->MaterialInfo->Type&GOURAUD)
		{
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_GOURAUD);
		}
		else
		{
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_FLAT);		
		}
	}
	else
	{
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_FOGENABLE,TRUE);

		// Shading mode
		if((f->MaterialInfo->Type&GOURAUD)||(OverrideLighting))
		{
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_GOURAUD);
		}
		else
		{
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SHADEMODE,D3DSHADE_FLAT);		
		}
	}
		
	lastm=f->MaterialInfo;
    oldpvf=PVM;
}

static void PVAPI D3DPostRender(void)
{
}

static void PVAPI D3DEndFrame(void)
{
	if(lpD3DDEV3!=NULL)
		lpD3DDEV3->EndScene();	
}

static int PVAPI D3DFlipSurface(void)
{
	if(lpClipper!=NULL)
	{
		RECT srcr,dstr;
		POINT pt;
		HWND win;
		
		lpClipper->GetHWnd(&win);
		GetClientRect(win,&srcr);
		pt.x=pt.y=0;
		ClientToScreen(win,&pt);
		dstr=srcr;
		dstr.left+=pt.x;
		dstr.right+=pt.x;
		dstr.top+=pt.y;
		dstr.bottom+=pt.y;
		lpDDSPrimary->Blt(&dstr,lpDDS,&srcr,DDBLT_ASYNC,0);
	}
	else lpDDSPrimary->Flip(NULL,0);

	return COOL;
}

static int PVAPI D3DFillSurface(unsigned surfacenum,float r,float g,float b,float a)
{
	DDBLTFX ddbltfx;	
	LPDIRECTDRAWSURFACE4 surf;
	DDPIXELFORMAT  ddpf;
	unsigned rs,gs,bs,rp,gp,bp,as,ap,rf,gf,bf,af;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}	
	if(surf==NULL) return COOL;

	// Looking for the correct color mask
	ddpf.dwSize=sizeof(ddpf);
	surf->GetPixelFormat(&ddpf);
	rs=GetMaskSize(ddpf.dwRBitMask);
	gs=GetMaskSize(ddpf.dwGBitMask);
	bs=GetMaskSize(ddpf.dwBBitMask);
	as=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	rp=GetMaskPos(ddpf.dwRBitMask);
	gp=GetMaskPos(ddpf.dwGBitMask);
	bp=GetMaskPos(ddpf.dwBBitMask);
	ap=GetMaskSize(ddpf.dwRGBAlphaBitMask);
	
	// Compute colors
	rf=r*(float)((1<<rs)-1);
	rf<<=rp;
	bf=b*(float)((1<<bs)-1);
	bf<<=bp;
	gf=g*(float)((1<<gs)-1);
	gf<<=gp;
	af=a*(float)((1<<as)-1);
	af<<=ap;
	
	memset(&ddbltfx,0,sizeof(ddbltfx));
	ddbltfx.dwSize=sizeof(ddbltfx);
	ddbltfx.dwFillColor=rf|gf|bf|af;

	// Sync hardware
	while(surf->GetBltStatus(DDGBS_CANBLT)==DDERR_WASSTILLDRAWING);
	
	if(surf->Blt(NULL,NULL,NULL,DDBLT_COLORFILL|DDBLT_ASYNC,&ddbltfx)!=DD_OK) return BIZAR_ERROR;
	return COOL;
}

static void PVAPI D3DRefreshMaterial(PVMaterial *)
{
	// Direct3D driver don't need this function because the material state is set each time a render is made
	lastm=NULL;
}

extern PVHardwareCaps D3DCaps;
static PVHardwareCaps * PVAPI D3DGetInfo(void)
{
	return &D3DCaps;
}

static void * PVAPI D3DLockFB(unsigned surfacenum,PVFLAGS mode)
{
	LPDIRECTDRAWSURFACE4 surf;
	DDSURFACEDESC       ddsd;
	unsigned flags;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}
	
	switch(mode)
	{
	case PFB_READONLY:flags=DDLOCK_READONLY;break;
	case PFB_WRITEONLY:flags=DDLOCK_WRITEONLY;break;
	default:return NULL;
	}
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	surf->Lock(NULL,NULL,DDLOCK_SURFACEMEMORYPTR|DDLOCK_WAIT|flags,NULL);
	
	D3DCaps.RowStride=ddsd.lPitch;
	
	return ddsd.lpSurface;
}

static void PVAPI D3DUnLockFB(unsigned surfacenum,PVFLAGS mode)
{
	LPDIRECTDRAWSURFACE4 surf;
	
	switch(surfacenum)
	{
	case 1:surf=lpDDSPrimary;break;
	default:surf=lpDDS;break;
	}
	
	surf->Unlock(NULL);
}

static void * PVAPI D3DLockDB(PVFLAGS mode)
{
	unsigned flags;
	DDSURFACEDESC       ddsd;
	
	if(lpZBuffer==NULL) return NULL;
	
	switch(mode)
	{
	case PFB_READONLY:flags=DDLOCK_READONLY;break;
	case PFB_WRITEONLY:flags=DDLOCK_WRITEONLY;break;
	default:return NULL;
	}
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	lpZBuffer->Lock(NULL,NULL,DDLOCK_SURFACEMEMORYPTR|DDLOCK_WAIT|flags,NULL);
	
	D3DCaps.RowStride=ddsd.lPitch;
	
	return ddsd.lpSurface;
}

static void PVAPI D3DUnLockDB(PVFLAGS mode)
{
	if(lpZBuffer==NULL) return;
	
	lpZBuffer->Unlock(NULL);
}

static UPVD8* PVAPI D3DLockProcedural(PVMaterial *m,PVRGBFormat *rgb,PVFLAGS access)
{
	PVSurfCtrl *sc;
	DDSURFACEDESC2       ddsd;	
	HRESULT hr;
	DWORD flags;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL) return NULL;

	rgb->RedSize=GetMaskSize(sc->d3dddpf.dwRBitMask);
	rgb->GreenSize=GetMaskSize(sc->d3dddpf.dwGBitMask);
	rgb->BlueSize=GetMaskSize(sc->d3dddpf.dwBBitMask);
	rgb->AlphaSize=GetMaskSize(sc->d3dddpf.dwRGBAlphaBitMask);
	rgb->RedPos=GetMaskPos(sc->d3dddpf.dwRBitMask);
	rgb->GreenPos=GetMaskPos(sc->d3dddpf.dwGBitMask);
	rgb->BluePos=GetMaskPos(sc->d3dddpf.dwBBitMask);
	rgb->AlphaPos=GetMaskPos(sc->d3dddpf.dwRGBAlphaBitMask);
	rgb->NbrBitsPerPixel=sc->d3dddpf.dwRGBBitCount;

	ddsd.dwSize=sizeof(ddsd);

	flags=0;
	if(access==PV_READ_ONLY) flags|=DDLOCK_READONLY;
	else
	if(access==PV_WRITE_ONLY) flags|=DDLOCK_WRITEONLY;
			
	hr=sc->d3dsurf[0]->Lock(NULL,&ddsd,DDLOCK_WAIT|DDLOCK_SURFACEMEMORYPTR|flags,NULL);
	if(hr!=DD_OK) return NULL;

	rgb->Pitch=ddsd.lPitch;
		
	return (UPVD8 *)ddsd.lpSurface;
}

static void PVAPI D3DUnLockProcedural(PVMaterial *m)
{
	PVSurfCtrl *sc;

	sc=(PVSurfCtrl*)m->HardwarePrivate;
	if(sc==NULL) return;

	sc->d3dsurf[0]->Unlock(NULL);
}

static void PVAPI D3DHint(char *hint,UPVD32 val)
{
	if(strcmp(hint,"PV_FOG_TABLE")==0)
	{
		if(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_FOGTABLE)
		{
			SetFogTable(val);
		}
		else SetFogTable(0);
	}

	if(strcmp(hint,"PV_WBUFFER")==0)
	{
		if((val)&&(HalCaps.dpcTriCaps.dwRasterCaps&D3DPRASTERCAPS_WBUFFER))
		{
			DebugString("INFO: Using W-Buffer\n");
			zbuftype=D3DZB_USEW;		
		}
		else
		{
			DebugString("INFO: Using Z-Buffer\n");
			zbuftype=D3DZB_TRUE;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
static PVHardwareCaps D3DCapsOrg={
	0,
		PHF_FRAMEBUFFER,
		0,
		0,
		PHD_DEPTHPROP,	
		0,0,0,0,
		0,0,0,0,
		0,
		-1,-1,
		0,
		16,
		0,
		0
};

static PVHardwareCaps D3DCaps;

PVEXPORT PVHardwareDriver PVDriver={
	1,
		PV_MN2,
		sizeof(PVHardwareCaps),
		"Panard Vision DirectX6 Generic Driver V1.15",
		D3DDetect,
		D3DInitSupport,
		D3DEndSupport,
		D3DSetViewPort,
		D3DLoadTexture,
		D3DDeleteTexture,
		D3DGetFiller,
		D3DPreRender,
		D3DPrepareFace,
		D3DPostRender,
		D3DBeginFrame,
		D3DEndFrame,
		D3DFlipSurface,
		D3DFillSurface,
		D3DRefreshMaterial,
		D3DGetInfo,
		D3DLockFB,
		D3DUnLockFB,
		D3DLockDB,
		D3DUnLockDB,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		D3DLoadLightMap,
		D3DDeleteLightMap,
		D3DLockProcedural,
		D3DUnLockProcedural,
		D3DHint,
};

PVEXPORT PVHardwareDriver PVDriverOrg=PVDriver;

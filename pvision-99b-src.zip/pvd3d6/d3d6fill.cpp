/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Direct3D v6 Driver for the Panard Vision 3D Engine
// (C) 1997-2000, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//

#define D3D_OVERLOADS
#include "d3d6fill.h"
#include <string.h>

PVRGBF *AmbientLight;
float bp,fp,depthval,depthval2;
unsigned MultiTexture;

//--------------------------------------------------------------------------------

static D3DTLVERTEX v[MAX_VERTICES_PER_POLY*2];
static unsigned nbrv;

#define Color(p) \
	D3DRGBA( \
	min(1,(o->Shading[p].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r), \
	min(1,(o->Shading[p].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g), \
	min(1,(o->Shading[p].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b), \
	o->Shading[p].Color.a*f->MaterialInfo->AlphaConstant)

#define Color2(p,a) \
	D3DRGBA( \
	min(1,(o->Shading[p].Color.r+AmbientLight->r)*f->MaterialInfo->Diffuse.r+f->MaterialInfo->Emissive.r), \
	min(1,(o->Shading[p].Color.g+AmbientLight->g)*f->MaterialInfo->Diffuse.g+f->MaterialInfo->Emissive.g), \
	min(1,(o->Shading[p].Color.b+AmbientLight->b)*f->MaterialInfo->Diffuse.b+f->MaterialInfo->Emissive.b), \
	a)

IDirect3DTexture2 *lastmip[MAX_TEXTURE_STAGE];

#define LoadTextureStage(x,m) \
	if(lastmip[x]!=m) \
		lpD3DDEV3->SetTexture(x,lastmip[x]=m);

#define LoadZ(a) \
	(depthval+o->Projected[a].InvertZ*depthval2)

#define DrawPoly(w) \
{ \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			v[i] = w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			v[i] = w; \
} \
} \
lpD3DDEV3->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_TLVERTEX,(LPVOID)v,nbrv,D3DDP_DONOTUPDATEEXTENTS|D3DDP_DONOTCLIP); \
}

#define DrawPoly2(w) \
{ \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			w; \
} \
} \
lpD3DDEV3->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_TLVERTEX,(LPVOID)v,nbrv,D3DDP_DONOTUPDATEEXTENTS|D3DDP_DONOTCLIP); \
}

#define DrawLine(w) \
{ \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertice[i]; \
			v[i] = w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertexes; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			v[i] = w; \
} \
} \
lpD3DDEV3->DrawPrimitive(D3DPT_LINESTRIP,D3DFVF_TLVERTEX,(LPVOID)v,nbrv,D3DDP_DONOTUPDATEEXTENTS|D3DDP_DONOTCLIP); \
}

	
//------------------------------------------------------------------------------------------
void PVAPI TriD3DGouraud(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;	

    DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,Color(a),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),0,0))
}

void PVAPI TriD3DFlat(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;
		
	D3DCOLOR col=Color(f->V[0]);

	DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,col,D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),0,0))
}

void PVAPI TriD3DMapping(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;		
	
    LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
	if(f->Flags&(PHONG|U_PHONG))
	{		
		if(o->Shading!=NULL)
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].AmbientU,o->Mapping[a].AmbientV))
        else
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].AmbientU,o->Mapping[a].AmbientV))
	}
	else
	{
		if(o->Shading!=NULL)
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
        else
            DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].u,o->Mapping[a].v))
	}
	
	/*lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);			
	lpD3DDEV3->SetTexture(0,NULL);
	lastmip[0]=NULL;
	DrawLine(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),0,0))*/
}

void PVAPI TriD3DFlatMapping(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;

	D3DCOLOR col=Color(f->V[0]);
	D3DCOLOR spe=D3DRGBA(0,0,0,1-o->Shading[f->V[0]].Specular.a);

	LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
	DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,col,spe,o->Mapping[a].u,o->Mapping[a].v))
}

void PVAPI TriD3DGouraudMapping(PVFace *f)
{
	PVMesh *o=f->Father;
	unsigned a,i;	

    LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
	DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,Color(a),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
}

void PVAPI TriD3DBiMapping(PVFace *f)
{
	unsigned a,i;
	DWORD as,a1,a2,zws;
	PVMesh *o=f->Father;		
	
	// 2 Pas fill
	// 1st pass, mapping			
    LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
	if(o->Shading!=NULL)
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
    else
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].u,o->Mapping[a].v))
	
	//2nd Pass : luminance by blending a light map over the 1st triangle	
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_DESTBLEND,&a1);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_ZERO);
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_SRCBLEND,&a2);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,D3DBLEND_DESTCOLOR);
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,&as);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ZFUNC,&zws);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);			

    LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[1]);
	DrawPoly2(
		v[i].tu=o->Mapping[a].AmbientU;
	    v[i].tv=o->Mapping[a].AmbientV
			)

	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,as);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,a1);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,a2);	
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,zws);			
}

void PVAPI TriD3DLightMap(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;		
	DWORD as,a1,a2,zws;
	
	// 2 Pas fill
	// 1st pass, mapping			
    LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
	if(o->Shading!=NULL)
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
    else
        DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].u,o->Mapping[a].v))

	//2nd Pass : luminance by blending a light map over the 1st triangle	
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_DESTBLEND,&a1);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_ZERO);
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_SRCBLEND,&a2);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,D3DBLEND_DESTCOLOR);
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,&as);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);			
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ZFUNC,&zws);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);			
			
	LoadTextureStage(0,((PVSurfCtrl*)f->LightMap->HardwarePrivate)->d3dtex[f->LightMap->CurrentLightMap]);
	DrawPoly2(
		    v[i].tu=f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU;
		    v[i].tv=f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV;
			)

	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,as);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,a1);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,a2);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,zws);			
}

//////////////////////////////////////////////////////////////////////////////////////////////

struct MTVERTEX
{
    FLOAT x, y, z,rhw;
	D3DCOLOR specular;
    FLOAT tuBase, tvBase;
    FLOAT tuLightMap, tvLightMap;
};

#define FILL_MTVERTEX(v,ax, ay, az,Rhw,atu1, atv1, atu2, atv2,spe )  \
    v.x = ax; v.y = ay; v.z = az; v.rhw=Rhw; \
	v.specular=spe; \
    v.tuBase     = atu1; v.tvBase     = atv1; \
    v.tuLightMap = atu2; v.tvLightMap = atv2; 

#define DrawPoly3(w) \
{ \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			w; \
} \
} \
lpD3DDEV3->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_XYZRHW|D3DFVF_SPECULAR|D3DFVF_TEX2,(LPVOID)vm,nbrv,D3DDP_DONOTUPDATEEXTENTS|D3DDP_DONOTCLIP); \
}

void PVAPI TriD3DBiMappingMT(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;		
	MTVERTEX vm[MAX_VERTICES_PER_POLY*2];
	
    lpD3DDEV3->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_MODULATE );

    LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
    LoadTextureStage(1,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[1]);

    if(o->Shading!=NULL)
		DrawPoly3(
			FILL_MTVERTEX(vm[i],o->Projected[a].xf,o->Projected[a].yf,LoadZ(a),-o->Projected[a].InvertZ,
						  o->Mapping[a].u,
						  o->Mapping[a].v,
						  o->Mapping[a].AmbientU,
						  o->Mapping[a].AmbientV,
						  D3DRGBA(0,0,0,1-o->Shading[a].Specular.a))
		)
	else
		DrawPoly3(
			FILL_MTVERTEX(vm[i],o->Projected[a].xf,o->Projected[a].yf,LoadZ(a),-o->Projected[a].InvertZ,
						  o->Mapping[a].u,
						  o->Mapping[a].v,
						  o->Mapping[a].AmbientU,
						  o->Mapping[a].AmbientV,
						  D3DRGB(0,0,0))
		)

	lpD3DDEV3->SetTextureStageState( 1, D3DTSS_COLOROP,  D3DTOP_DISABLE );
}

void PVAPI TriD3DLightMapMT(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;		
	MTVERTEX vm[MAX_VERTICES_PER_POLY*2];
	
    lpD3DDEV3->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_MODULATE );

    LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
	LoadTextureStage(1,((PVSurfCtrl*)f->LightMap->HardwarePrivate)->d3dtex[f->LightMap->CurrentLightMap]);

	if(o->Shading!=NULL)
		DrawPoly3(
		FILL_MTVERTEX(vm[i],o->Projected[a].xf,o->Projected[a].yf,LoadZ(a),-o->Projected[a].InvertZ,
					  o->Mapping[a].u,
					  o->Mapping[a].v,
					  f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU,
					  f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV,
					  D3DRGBA(0,0,0,1-o->Shading[a].Specular.a))
		)
	else
		DrawPoly3(
		FILL_MTVERTEX(vm[i],o->Projected[a].xf,o->Projected[a].yf,LoadZ(a),-o->Projected[a].InvertZ,
					  o->Mapping[a].u,
					  o->Mapping[a].v,
					  f->LightMap->su[f->LightMap->CurrentLightMap]+(o->Mapping[a].u-f->LightMap->MinU)*f->LightMap->ScaleU,
					  f->LightMap->sv[f->LightMap->CurrentLightMap]+(o->Mapping[a].v-f->LightMap->MinV)*f->LightMap->ScaleV,
					  D3DRGB(0,0,0))
		)

		
	lpD3DDEV3->SetTextureStageState( 1, D3DTSS_COLOROP,  D3DTOP_DISABLE );
}

//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////// PV Multitexture Pipe

struct MTUV
{
	FLOAT u,v;
};

struct MTVERTEXPVMT
{ 
	FLOAT x,y,z,rhw; 
	D3DCOLOR diff,specular;
    MTUV  uv[8]; 
};

#define SetupPoly(w) \
{ \
	if(f->Poly!=NULL)	\
{ \
		nbrv=f->Poly->NbrVertices;	\
		for(i=0;i<nbrv;i++) \
{ \
			a=f->Poly->Vertices[i]; \
			w; \
} \
} \
	else \
{ \
		nbrv=f->NbrVertices; \
		for(i=0;i<nbrv;i++)  \
{ \
			a=f->V[i]; \
			w; \
} \
} \
}

void PVAPI TriD3DMTMT(PVFace *f)
{
	unsigned a,i,decal;
	PVMesh *o=f->Father;			
	MTVERTEXPVMT vm[MAX_VERTICES_PER_POLY*2];
	DWORD as,a1,a2,zws;

	// Cas des lightmaps
	decal=0;
	if(f->Flags&LIGHTMAP)
	{
		TriD3DLightMapMT(f);

		lpD3DDEV3->GetRenderState(D3DRENDERSTATE_DESTBLEND,&a1);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_INVSRCALPHA);
		lpD3DDEV3->GetRenderState(D3DRENDERSTATE_SRCBLEND,&a2);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,D3DBLEND_SRCALPHA);
		lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,&as);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);			
		lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ZFUNC,&zws);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);				

		decal=1;

		if(o->Shading!=NULL)
		{
			SetupPoly(
			vm[i].x=o->Projected[a].xf;
			vm[i].y=o->Projected[a].yf;
			vm[i].diff=D3DRGBA(1,1,1,0.3);
			vm[i].specular=D3DRGBA(0,0,0,1-o->Shading[a].Specular.a);
			vm[i].z=LoadZ(a);
			vm[i].rhw=-o->Projected[a].InvertZ;
			)
		}
		else
		{
			SetupPoly(
			vm[i].x=o->Projected[a].xf;
			vm[i].y=o->Projected[a].yf;
			vm[i].diff=D3DRGBA(1,1,1,0.3);
			vm[i].specular=D3DRGB(0,0,0);
			vm[i].z=LoadZ(a);
			vm[i].rhw=-o->Projected[a].InvertZ;
			)
		}
	}
	else
	{    
		LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);

		if((o->Shading!=NULL)&&(f->Flags&(FLAT|GOURAUD)))
		{
			SetupPoly(
			vm[i].x=o->Projected[a].xf;
			vm[i].y=o->Projected[a].yf;
			vm[i].diff=Color2(a,0.3);
			vm[i].specular=D3DRGBA(0,0,0,1-o->Shading[a].Specular.a);
			vm[i].z=LoadZ(a);
			vm[i].rhw=-o->Projected[a].InvertZ;
			vm[i].uv[0].u=o->Mapping[a].u;
			vm[i].uv[0].v=o->Mapping[a].v;
			)
		}
		else
		{
			if(o->Shading!=NULL)
			{
				SetupPoly(
				vm[i].x=o->Projected[a].xf;
				vm[i].y=o->Projected[a].yf;
				vm[i].diff=D3DRGBA(1,1,1,0.3);
				vm[i].specular=D3DRGBA(0,0,0,1-o->Shading[a].Specular.a);
				vm[i].z=LoadZ(a);
				vm[i].rhw=-o->Projected[a].InvertZ;
				vm[i].uv[0].u=o->Mapping[a].u;
				vm[i].uv[0].v=o->Mapping[a].v;
				)
			}
			else
			{
				SetupPoly(
				vm[i].x=o->Projected[a].xf;
				vm[i].y=o->Projected[a].yf;
				vm[i].diff=D3DRGBA(1,1,1,0.3);
				vm[i].specular=D3DRGB(0,0,0);
				vm[i].z=LoadZ(a);
				vm[i].rhw=-o->Projected[a].InvertZ;
				vm[i].uv[0].u=o->Mapping[a].u;
				vm[i].uv[0].v=o->Mapping[a].v;
				)
			}
		}
	}

	for(unsigned s=1;s<MAX_TEXTURE_STAGE;s++)
	{
		switch(f->MaterialInfo->TexStage[s-1].ColorOp)
		{
		case PVTSO_DISABLE:
			lpD3DDEV3->SetTextureStageState(s-decal,D3DTSS_COLOROP,D3DTOP_DISABLE);
			s=MAX_TEXTURE_STAGE;
			continue;
			break;
		case PVTSO_DETAILTEXTURE:			
			D3DCOLOR fact=D3DRGBA(1,1,1,0.3);
			LoadTextureStage(s-decal,((PVSurfCtrl*)f->MaterialInfo->TexStage[s-1].Mat->HardwarePrivate)->d3dtex[0]);
			lpD3DDEV3->SetRenderState(D3DRENDERSTATE_TEXTUREFACTOR,*( LONG* )(&fact));			
			if(decal)
				lpD3DDEV3->SetTextureStageState(s-decal,D3DTSS_COLOROP,D3DTOP_SELECTARG1);
			else
				lpD3DDEV3->SetTextureStageState(s,D3DTSS_COLOROP,D3DTOP_BLENDFACTORALPHA);
			lpD3DDEV3->SetTextureStageState(s-decal,D3DTSS_COLORARG2,D3DTA_CURRENT);
			lpD3DDEV3->SetTextureStageState(s-decal,D3DTSS_COLORARG1,D3DTA_TEXTURE);

			SetupPoly(
				vm[i].uv[s-decal].u=o->Mapping[a].u*f->MaterialInfo->TexStage[s-1].Data1;
				vm[i].uv[s-decal].v=o->Mapping[a].v*f->MaterialInfo->TexStage[s-1].Data2;
			)

			break;
		}
	}

	lpD3DDEV3->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_SPECULAR|D3DFVF_TEX8,(LPVOID)vm,nbrv,D3DDP_DONOTUPDATEEXTENTS|D3DDP_DONOTCLIP);
	
	lpD3DDEV3->SetTextureStageState( 1, D3DTSS_COLOROP,  D3DTOP_DISABLE ); 
	lpD3DDEV3->SetTextureStageState( 0, D3DTSS_COLOROP,  D3DTOP_MODULATE );

	if(f->Flags&LIGHTMAP)
	{
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,as);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,a1);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,a2);
		lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,zws);		
	}	
}

void PVAPI TriD3DMT(PVFace *f)
{
	unsigned a,i;
	PVMesh *o=f->Father;		
	DWORD as,a1,a2,zws;
	
	if(f->MaterialInfo->TexStage[0].ColorOp!=PVTSO_DETAILTEXTURE) return;

	if(f->Flags&LIGHTMAP)
	{
		TriD3DLightMap(f);
	}
	else
	{	
		// 2 Pas fill
		// 1st pass, mapping			
		LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->HardwarePrivate)->d3dtex[0]);
		if((o->Shading!=NULL)&&(f->Flags&(FLAT|GOURAUD)))
		{
			DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,Color(a),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
		}
		else
		{
			if(o->Shading==NULL)
			{
				DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGBA(1,1,1,f->MaterialInfo->AlphaConstant),D3DRGB(0,0,0),o->Mapping[a].u,o->Mapping[a].v))
			}
			else
			{
				DrawPoly(D3DTLVERTEX(D3DVECTOR(o->Projected[a].xf,o->Projected[a].yf,LoadZ(a)),-o->Projected[a].InvertZ,D3DRGB(1,1,1),D3DRGBA(0,0,0,1-o->Shading[a].Specular.a),o->Mapping[a].u,o->Mapping[a].v))
			}

		}
	}

	//2nd Pass : luminance by blending a light map over the 1st triangle	
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_DESTBLEND,&a1);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_INVSRCALPHA);
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_SRCBLEND,&a2);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,D3DBLEND_SRCALPHA);
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,&as);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,TRUE);			
	lpD3DDEV3->GetRenderState(D3DRENDERSTATE_ZFUNC,&zws);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_LESSEQUAL);			
			
	LoadTextureStage(0,((PVSurfCtrl*)f->MaterialInfo->TexStage[0].Mat->HardwarePrivate)->d3dtex[0]);

    DrawPoly2(
	v[i].color=D3DRGBA(1,1,1,0.3);
	v[i].tu*=f->MaterialInfo->TexStage[0].Data1;
	v[i].tv*=f->MaterialInfo->TexStage[0].Data2;
	)

	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,as);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_DESTBLEND,a1);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_SRCBLEND,a2);
	lpD3DDEV3->SetRenderState(D3DRENDERSTATE_ZFUNC,zws);			
}

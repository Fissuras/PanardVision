/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "pomcore.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////////// pomCoreObject

unsigned pomCoreObject::_CurrentId=0;

static multimap<string,pomCoreObject*> PomObjects;

IMPLEMENT_POMIZED_ABSTRACT(pomCoreObject);

pomCoreObject::pomCoreObject()
{
	_Id=_CurrentId;
    _CurrentId++;
    _RefCnt=0;
}

void pomCoreObject::SetShortName(char *name)
{
    pomClassInfo *p;
	multimap<string,pomCoreObject*>::iterator	p1,p2;

	p=pomGetRuntimeClass();	
	_CurrentClassInfo=p;

	p1=PomObjects.find(p->DomainName);
	p2=PomObjects.end();

	while(p1!=p2)
	{
		if(strcmp((*p1).second->GetShortName(),_ShortName.data())==0)
		{
			PomObjects.erase(p1);
			break;
		}
		p1++;
	}
		
	_ShortName=name;

	if(strlen(name)==0) return;
	
	PomObjects.insert(multimap<string,pomCoreObject*>::value_type(p->DomainName,this));
}

const char *pomCoreObject::GetShortName()
{
	return _ShortName.data();
}

pomCoreObject::~pomCoreObject()
{
	multimap<string,pomCoreObject*>::iterator	p1,p2;
	
	if(_ShortName=="") return;

	p1=PomObjects.find(_CurrentClassInfo->DomainName);
	p2=PomObjects.end();

	while(p1!=p2)
	{
		if(strcmp((*p1).second->GetShortName(),_ShortName.data())==0)
		{
			PomObjects.erase(p1);
			break;
		}
		p1++;
	}
}

////////////////////////////////////////////////////////////////////////////////////// pomNameServer

void pomNameServer::AddName(const char *name,pomClassInfo &ci)
{
	_NameSpaces.insert(multimap<string,pomClassInfo>::value_type(name,ci));
}

POMERR pomNameServer::GetClassInfoFromName(const char *name,pomClassInfo &ci)
{
	multimap<string,pomClassInfo>::iterator	p;

	p=_NameSpaces.find(name);

	if(p==_NameSpaces.end()) 
	{
		return POMERR_NO_SUCH_NAME;
	}
	else
	{
		ci=(*p).second;
		return POMERR_COOL;
	}	
}

POMERR pomNameServer::GetObjectFromFQN(const char *name,pomCoreObject **c)
{
	char tmp[4096],*t2;

	multimap<string,pomCoreObject*>::iterator	p1,p2;

	strncpy(tmp,name,4096);
	t2=strrchr(tmp,'/');
	*t2=0;
	t2++;

	p1=PomObjects.find(tmp);
	p2=PomObjects.end();

	while(p1!=p2)
	{
		if(strcmp((*p1).second->GetShortName(),t2)==0)
		{
			*c=(*p1).second;
			return POMERR_COOL;
		}
		p1++;
	}
	*c=NULL;
	return POMERR_NO_SUCH_NAME;
}

POMERR pomNameServer::IterateClassesDirectory(unsigned index,pomClassInfo &ci)
{
	multimap<string,pomClassInfo>::iterator	p1,p2;

	p1=_NameSpaces.begin();
	p2=_NameSpaces.end();

	for(unsigned i=0;(i<index)&&(p1!=p2);i++) p1++;
	if(p1!=p2)
	{
		ci=(*p1).second;
		return POMERR_COOL;
	}

	return POMERR_NO_SUCH_NAME;
}

POMERR pomNameServer::IterateObjectsDirectory(unsigned index,const char *directory,pomCoreObject **c)
{
	multimap<string,pomCoreObject*>::iterator p1,p2;

	p1=PomObjects.find(directory);
	p2=PomObjects.end();

	for(unsigned i=0;(i<index)&&(p1!=p2);i++) p1++;
	if(p1!=p2)
	{
		*c=(*p1).second;
		return POMERR_COOL;
	}

	return POMERR_NO_SUCH_NAME;
}

void pomNameServer::DumpNameSpace(::ostream &out)
{
		multimap<string,pomClassInfo>::iterator	p1,p2;

		// Dumps static mapping
		p1=_NameSpaces.begin();
		p2=_NameSpaces.end();

		while(p1!=p2)
		{
			out<<(*p1).first.data()<<::endl;
			p1++;
		}

		// Dumps dynamics things
		multimap<string,pomCoreObject*>::iterator	q1,q2;
		
		q1=PomObjects.begin();
		q2=PomObjects.end();

		while(q1!=q2)
		{
			out<<(*q1).first.data()<<"/"<<(*q1).second->GetShortName()<<::endl;
			q1++;
		}
}

////////////////////////////////////////////////////////////////////////////////////// pomConstrainedNameServer

pomConstrainedNameServer::pomConstrainedNameServer(const char *Domainroot)
{
	char tmp[4096],*t;

	strcpy(tmp,Domainroot);
	
	// Suppress trailing /
	t=strrchr(tmp,'/');
	if(t!=NULL)
	{
		if(t[1]==0) *t=0;
	}
	
	_DomainRoot=tmp;
}

POMERR pomConstrainedNameServer::GetClassInfoFromName(const char *name,pomClassInfo &ci)
{
	string t;

	t=_DomainRoot+"/"+name;
	return pomNameServer::GetClassInfoFromName(t.data(),ci);
}

POMERR pomConstrainedNameServer::GetObjectFromFQN(const char *name,pomCoreObject **c)
{
	string t;

	t=_DomainRoot+"/"+name;
	
	return pomNameServer::GetObjectFromFQN(t.data(),c);
}

//////////////////////////////////////////////////////////////////

__pomAutoRegister::__pomAutoRegister(pomClassInfo *ci)
{
	char name[4096];
	pomNameServer *ns;
	
	pomGetNameServer(&ns);
	strcpy(name,"/classes/");
	strcat(name,ci->ClassName);
	ns->AddName(name,*ci);
}

///////////////////////////////////////////////////////////////////////////////////// General API
static pomNameServer *NameServer=NULL;

#define INITNS	\
	if(NameServer==NULL) \
{ \
		NameServer=new pomNameServer; \
	}

POMERR POMAPI pomGetNameServer(pomNameServer **ns)
{
	INITNS;
	
	*ns=NameServer;
	
	return POMERR_COOL;
}

pomCoreObject *POMAPI pomCreateObjectFromClass(char *name)
{
	pomClassInfo p;
	char tmp[4096];

	INITNS;

	strcpy(tmp,"/classes/");
	strncat(tmp,name,4096);

	if(NameServer->GetClassInfoFromName(tmp,p)!=POMERR_COOL) return NULL;

	if(p.CreateObject!=NULL)
		return p.CreateObject();
	else
		return NULL;
}

POM_DLL pomCoreObject *POMAPI pomGetObjectFromName(char *name)
{
	pomCoreObject *p;
	
	INITNS;

	if(NameServer->GetObjectFromFQN(name,&p)!=POMERR_COOL) 
		return NULL;
	else 
		return p;
}
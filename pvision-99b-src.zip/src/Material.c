/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <string.h>
#include "pvision.h"
#include "oct1.h"
#include "sqrt.h"

#define debug(x) //x

#ifdef __WATCOMC__
#pragma intrinsic(PV_LookClosestColor)
#pragma intrinsic(StandardLightTable)
#endif

#define EuclideDistance(a,b,c) (fsqrt((a)*(a)+(b)*(b)+(c)*(c)))
#define EuclideDistanceFast(a,b,c) ((a)*(a)+(b)*(b)+(c)*(c))

#define DEFAULT_MIPMAPS 9

//////////////////////////////////////////// Gestion PVRGB
UPVD8 RMaskSize=8,GMaskSize=8,BMaskSize=8;
UPVD8 PixelSize=3;                           // Taille en octets d'un pixel
UPVD32 RedMask=0x0F00,GreenMask=0xF0,BlueMask=0xF;
unsigned RedFact=(1<<16),GreenFact=(1<<8),BlueFact=1;
UPVD8 RFieldPos=16,GFieldPos=8,BFieldPos=0;

///////////////////////////////////////////////////////////////////////////

static PVRGB *PV_CreatePalette(void)
{
    return (PVRGB*)calloc(256,sizeof(PVRGB));
}

#ifdef __cplusplus
extern "C" {
#endif
void __cdecl HLRGBSetMasks(void);     // Defined in hline86.asm
#ifdef __cplusplus
}
#endif
int PVAPI PV_SetRGBIndexingMode(UPVD8 RMaskS,UPVD8 GMaskS,UPVD8 BMaskS,
                            UPVD8 RFieldP,UPVD8 GFieldP, UPVD8 BFieldP,UPVD8 AMaskS)
{
    if(PV_Mode&PVM_USEHARDWARE) return COOL;

	if(!((RMaskS+GMaskS+BMaskS==16)||(RMaskS+GMaskS+BMaskS==15)||(RMaskS+GMaskS+BMaskS==24))) return ARG_INVALID;

    PixelSize=(RMaskS+GMaskS+BMaskS+AMaskS+1)/8;
    RMaskSize=RMaskS;
    GMaskSize=GMaskS;
    BMaskSize=BMaskS;

    RFieldPos=RFieldP;
    GFieldPos=GFieldP;
    BFieldPos=BFieldP;

    RedMask=((1<<RMaskSize)-1)<<RFieldPos;
    GreenMask=((1<<GMaskSize)-1)<<GFieldPos;
    BlueMask=((1<<BMaskSize)-1)<<BFieldPos;

    RedFact=1<<RFieldPos;
    GreenFact=1<<GFieldPos;
    BlueFact=1<<BFieldPos;

#ifdef __386__
    HLRGBSetMasks();
#endif
    return COOL;
}

static UPVD8 *PV_GetPhongTexture(void)
{
    UPVD8 *t;
    float d;
    int i,j;

    t=(UPVD8*)malloc(256*256*sizeof(UPVD8));
    if(t!=NULL)
    {
        for(i=0;i<256;i++)
            for(j=0;j<256;j++)
            {
                d=EuclideDistance(i-128,j-128,0);
                t[256*i+j]=(UPVD8)((d<=128)?255-sin(d*PI/(128*2))*d:0);
            }
    }
    return t;
}

PVMaterial * PVAPI PV_CreateMaterial(char *n,PVFLAGS type,PVFLAGS flags,UPVD8 nbrmipmaps)
{
    PVMaterial *m;
    unsigned i;

    if(nbrmipmaps>MAX_MIPMAP_NUM ) return NULL;
	m=(PVMaterial *)calloc(sizeof(PVMaterial),1);
    if(m==NULL) return NULL;

    m->NbrMipMaps=(nbrmipmaps==0)?DEFAULT_MIPMAPS:nbrmipmaps;
    m->Type=type;
    m->TextureFlags=flags;

    if((m->Name=strdup(n))==NULL)
    {
            PV_KillMaterial(m);
            return NULL;
    }
    if((m->Tex=(PVTexture*)malloc(m->NbrMipMaps*sizeof(PVTexture)))==NULL)
    {
            PV_KillMaterial(m);
            return NULL;
    }

    for(i=0;i<m->NbrMipMaps;i++)
    {
        m->Tex[i].Texture=NULL;
        m->Tex[i].Width=m->Tex[i].Height=0;
        m->Tex[i].ShiftWidth=m->Tex[i].ShiftHeight=0;
    }

    m->PaletteTranscodeTable=NULL;
    m->RGB16TranscodeTable=NULL;
    m->BumpMap.Map=NULL;
    m->BumpMap.Width=0;
    m->BumpMap.Height=0;
    m->AuxiliaryTexture.Texture=NULL;
    m->AuxiliaryTexture.Width=0;
    m->AuxiliaryTexture.Height=0;
    m->AuxiliaryTexture.ShiftWidth=0;
    m->AuxiliaryTexture.ShiftHeight=0;
    m->Pal=NULL;
    m->UserData=0;
	m->RepeatU=m->RepeatV=TEXTURE_WRAP;
	m->DepthTest=CMP_LESS;
	m->AlphaTest=CMP_ALWAYS;
	m->AlphaReference=0;
	m->BlendRgbSrcFactor=BLEND_ONE;
	m->BlendRgbDstFactor=BLEND_ZERO;
	m->BlendAlphaSrcFactor=BLEND_ONE;
	m->BlendAlphaDstFactor=BLEND_ZERO;
	m->AlphaConstant=1.0;
	m->Diffuse.r=m->Diffuse.g=m->Diffuse.b=1.0;

    if((m->Type&(PHONG|BUMP))&&(!(m->Type&RENDER_MASK)))
    {
        m->TextureFlags|=TEXTURE_PALETIZED8;
        m->Tex[0].Texture=PV_GetPhongTexture();
        if(m->Tex[0].Texture==NULL)
        {
            PV_KillMaterial(m);
            return NULL;
        }

        m->Tex[0].Width=256;
        m->Tex[0].Height=256;
        m->Tex[0].ShiftWidth=m->Tex[0].ShiftHeight=8;
    }

    if((m->Type&(PHONG|BUMP))&&(m->Type&RENDER_MASK))
    {
        if((m->AuxiliaryTexture.Texture=PV_GetPhongTexture())==NULL)
        {
            PV_KillMaterial(m);
            return NULL;
        }
        m->AuxiliaryTexture.Width=256;
        m->AuxiliaryTexture.Height=256;
        m->AuxiliaryTexture.ShiftWidth=m->AuxiliaryTexture.ShiftHeight=8;
    }

	m->ZWrite=1;
	m->HardwarePrivate=NULL;

	m->StencilFunc=CMP_ALWAYS;
	m->StencilRef=0;
	m->StencilMask=m->StencilWriteMask=~0;
	m->StencilFail=STENCIL_KEEP;
	m->StencilZFail=STENCIL_KEEP;
	m->StencilPass=STENCIL_KEEP;

	m->RefCnt=0;

	m->Id1=0xDEAD;
	m->Id2=0xBEEF;

	memset(&m->TexStage[0],0,sizeof(PVTexStage)*(MAX_TEXTURE_STAGE-1));

    return m;
}

void PVAPI PV_KillMaterial(PVMaterial *m)
{
    unsigned i;

    if(m==NULL) return;

	if(m->RefCnt>0) m->RefCnt--;

	if(m->RefCnt==0)
	{
		// Si sur hardware, delete de la memoire
		if(PV_Mode&PVM_USEHARDWARE)
		{			
                if(PV_GetHardwareDriver()!=NULL) PV_GetHardwareDriver()->DeleteTexture(m);
		}

		free(m->Name);
		if(!(m->TextureFlags&TEXTURE_TEX_DONT_FREE))		
			for(i=0;i<m->NbrMipMaps;i++)
			{
	 				free(m->Tex[i].Texture);			
													
			}
		free(m->Tex);
		if(!(m->TextureFlags&TEXTURE_TEX_DONT_FREE)) free(m->Pal);		
		if(!(m->Type&COLORTABLE_DONT_FREE)) free(m->PaletteTranscodeTable);			
		if(!(m->Type&COLORTABLE_DONT_FREE)) free(m->RGB16TranscodeTable);
		if(!(m->TextureFlags&TEXTURE_ATEX_DONT_FREE)) free(m->AuxiliaryTexture.Texture);
		free(m->BumpMap.Map);
		free(m);
	}
}

///////////////////////////////////////////////////////////////////////////

PVTexBasis *PVAPI PV_CreateTextureBasis(float s[4],float t[4])
{
    PVTexBasis *m;

    if((m=(PVTexBasis*)calloc(sizeof(PVTexBasis),1))==NULL) return NULL;

    memcpy(m->SBasis,s,sizeof(float)*4);
    memcpy(m->TBasis,t,sizeof(float)*4);

    m->RefCnt=0;

    return m;
}

void PVAPI PV_KillTextureBasis(PVTexBasis *b)
{
    if(b==NULL) return;
    if(b->RefCnt>0) b->RefCnt--;
    if(b->RefCnt==0) free(b);
}

void PVAPI PV_AttachTextureBasis(PVFace *f,PVTexBasis *b)
{
	if(f==NULL) return;
	if(f->MapInfos.TexBasis!=NULL)
    {
            PV_KillTextureBasis(f->MapInfos.TexBasis);
        	f->MapInfos.TexBasis=NULL;
    }

	if(b!=NULL)
	{
		f->MapInfos.TexBasis=b;
		b->RefCnt++;
	}
}

/////////////////////////////////////////////////////////////// LIGHTMAPS

PVLightMap *PVAPI PV_CreateLightMapInfo(void)
{
    PVLightMap *t;

    t=(PVLightMap *)calloc(sizeof(PVLightMap),1);	

    return t;
}

void PVAPI PV_KillLightMapInfo(PVLightMap *l)
{
    if(l==NULL) return;

    if(l->RefCnt>0) l->RefCnt--;
	if(l->RefCnt==0)
	{
		if(PV_Mode&PVM_USEHARDWARE)
		{
			if(PV_GetHardwareDriver()!=NULL)
			if(PV_GetHardwareDriver()->DeleteLightMap!=NULL)
				PV_GetHardwareDriver()->DeleteLightMap(l);
		}
		free(l);
	}
}

void PVAPI PV_AttachLightMap(PVFace *f,PVLightMap *b)
{
	if(f==NULL) return;
    if(f->LightMap!=NULL)
    {
            PV_KillLightMapInfo(f->LightMap);
            f->LightMap=NULL;
    }

	if(b!=NULL)
	{
        b->RefCnt++;
		f->LightMap=b;
	}
}

void PVAPI PV_SetMaterialName(PVMaterial *m,char *name)
{
	if(m==NULL) return;

	if(m->Name!=NULL) free(m->Name);

	m->Name=strdup(name);
}

///////////////////////////////////////////////////////////////////////////

void PVAPI PV_SwapMaterials(PVMaterial *m1,PVMaterial *m2)
{
	PVMaterial t,*p;
	unsigned t2;

	if((m1==NULL)||(m2==NULL)) return;

	memcpy(&t,m1,sizeof(PVMaterial));
	memcpy(m1,m2,sizeof(PVMaterial));
	memcpy(m2,&t,sizeof(PVMaterial));

	// R�tabli l'ordre de la chaine
	p=m1->Next;
	m1->Next=m2->Next;
	m2->Next=p;

	// Et le compteur de reference
	t2=m2->RefCnt;
	m2->RefCnt=m1->RefCnt;
	m1->RefCnt=t2;
}

void PVAPI PV_SetMaterialTextureFlags(PVMaterial *m,PVFLAGS f)
{
    if(m==NULL) return;
    m->TextureFlags=f;
}

void PVAPI PV_SetMaterialType(PVMaterial *m,PVFLAGS f)
{
    if(m==NULL) return;
    m->Type=f;
}

static int PV_SpecularMaterial(PVMaterial *m)
{
    if((m->Specular.r!=0)||(m->Specular.g!=0)||(m->Specular.b!=0)) return 1;
    return 0;
}

static unsigned GetPowerOf2(unsigned x)
{
    unsigned i;

    for(i=0;(1<<i)!=x;i++);

    return i;
}

int PVAPI PV_SetMaterialTexture(PVMaterial *m,unsigned width,unsigned height,UPVD8 *texture,PVRGB *pal)
{
    if(m==NULL) return COOL;

    // puissance de 2
    if((width&(-width))!=width) return ARG_INVALID;
    if((height&(-height))!=height) return ARG_INVALID;
    if(m->Tex[0].Texture!=NULL) return ALREADY_ASSIGNED;
    m->Tex[0].ShiftHeight=GetPowerOf2(height);
    m->Tex[0].ShiftWidth=GetPowerOf2(width);

    m->Tex[0].Width=width;
    m->Tex[0].Height=height;
    m->Tex[0].Texture=texture;
    m->Pal=pal;

    return COOL;
}

// MipNbr commence a 1 !
int PVAPI PV_SetMaterialMipMap(PVMaterial *m,unsigned mipnbr,UPVD8 *texture)
{
    if(m==NULL) return ARG_INVALID;
    if(mipnbr<1) return ARG_INVALID;
    if(mipnbr>=m->NbrMipMaps) return ARG_INVALID;

    // puissance de 2
    m->Tex[mipnbr].ShiftHeight=GetPowerOf2(m->Tex[0].Height>>mipnbr);
    m->Tex[mipnbr].ShiftWidth=GetPowerOf2(m->Tex[0].Width>>mipnbr);

    m->Tex[mipnbr].Width=m->Tex[0].Width>>mipnbr;
    m->Tex[mipnbr].Height=m->Tex[0].Height>>mipnbr;
    m->Tex[mipnbr].Texture=texture;

    return COOL;
}

int PVAPI PV_SetMaterialAuxiliaryTexture(PVMaterial *m,unsigned width,unsigned height,UPVD8 *texture)
{
    if(m==NULL) return COOL;

    // puissance de 2
    if((width&(-width))!=width) return ARG_INVALID;
    if((height&(-height))!=height) return ARG_INVALID;
    if(m->AuxiliaryTexture.Texture!=NULL) return ALREADY_ASSIGNED;
    m->AuxiliaryTexture.ShiftHeight=GetPowerOf2(height);
    m->AuxiliaryTexture.ShiftWidth=GetPowerOf2(width);

    m->AuxiliaryTexture.Width=width;
    m->AuxiliaryTexture.Height=height;
    m->AuxiliaryTexture.Texture=texture;

    return COOL;
}

void PVAPI PV_SetMaterialPureColorsIndex(PVMaterial *m,UPVD8 start,UPVD8 end)
{
    m->StartingColorIndex=start;
    m->EndingColorIndex=end;
}

int PVAPI PV_SetMaterialLightInfo(PVMaterial *m,PVRGBF Emissive,PVRGBF Diffuse,PVRGBF Specular,unsigned specularpower)
{
    if(m==NULL) return COOL;

    if ((Emissive.r<0)|| (Emissive.r>1)) return ARG_INVALID;
    if ((Emissive.g<0)|| (Emissive.g>1)) return ARG_INVALID;
    if ((Emissive.b<0)|| (Emissive.b>1)) return ARG_INVALID;
    if ((Diffuse.r<0)|| (Diffuse.r>1)) return ARG_INVALID;
    if ((Diffuse.g<0)|| (Diffuse.g>1)) return ARG_INVALID;
    if ((Diffuse.b<0)|| (Diffuse.b>1)) return ARG_INVALID;
    if ((Specular.r<0)|| (Specular.r>1)) return ARG_INVALID;
    if ((Specular.g<0)|| (Specular.g>1)) return ARG_INVALID;
    if ((Specular.b<0)|| (Specular.b>1)) return ARG_INVALID;
    m->Emissive=Emissive;
    m->Specular=Specular;
    m->Diffuse=Diffuse;
    m->SpecularPower=specularpower;
    return COOL;
}

static PVRGB LightColor(PVMaterial *m,PVRGB c,unsigned intensity,PVRGBF ambient)
{
    float j,i,ifi;

    if(intensity<128) intensity=0; else intensity=intensity-128;
    ifi=(float)intensity/128.0;

    i=ifi+ambient.r;
    if(i>1) i=1;

    // Traitement Rouge
    j=m->Emissive.r*255;
    if(PV_SpecularMaterial(m))
    {
        // Specular material
        if(i<0.75)
            j+=m->Diffuse.r*(i/0.75)*c.r;

        else
            j+=m->Diffuse.r*c.r+(255-m->Diffuse.r*c.r)*m->Specular.r*pow(sin((i-0.75)*PI/(2*0.25)),m->SpecularPower);
    }
    else
    {
        // Diffuse material
        j+=c.r*m->Diffuse.r*i;
    }
    if(j>255) c.r=255;  else c.r=j;

    i=ifi+ambient.g;
    if(i>1) i=1;

    // Traitement Vert
    j=m->Emissive.g*255;
    if(PV_SpecularMaterial(m))
    {
        // Specular material
        if(i<0.75)
            j+=m->Diffuse.g*(i/0.75)*c.g;

        else
            j+=m->Diffuse.g*c.g+(255-m->Diffuse.g*c.g)*m->Specular.g*pow(sin((i-0.75)*PI/(2*0.25)),m->SpecularPower);
    }
    else
    {
        // Diffuse material
        j+=c.g*m->Diffuse.g*i;
    }
    if(j>255) c.g=255;  else c.g=j;

    i=ifi+ambient.b;
    if(i>1) i=1;

    // Traitement Bleu
    j=m->Emissive.b*255;
    if(PV_SpecularMaterial(m))
    {
        // Specular material
        if(i<0.75)
            j+=m->Diffuse.b*(i/0.75)*c.b;

        else
            j+=m->Diffuse.b*c.b+(255-m->Diffuse.b*c.b)*m->Specular.b*pow(sin((i-0.75)*PI/(2*0.25)),m->SpecularPower);
    }
    else
    {
        // Diffuse material
        j+=c.b*m->Diffuse.b*i;
    }
    if(j>255) c.b=255;  else c.b=j;


    return c;
}


int PVAPI PV_SetMaterialPhongPalette(PVMaterial *t,PVRGBF ambient)
{
    int i;
    PVRGB c;

    if(t->Pal==NULL) t->Pal=PV_CreatePalette();
    if(t->Pal==NULL) return NO_MEMORY;

    for(i=0;i<256;i++)
    {
            c.r=t->Diffuse.r*255;
            c.g=t->Diffuse.g*255;
            c.b=t->Diffuse.b*255;
            c=LightColor(t,c,i,ambient);
            c.r/=4;
            c.g/=4;
            c.b/=4;

            t->Pal[i]=c;
    }
    return COOL;
}

UPVD8 PVAPI PV_LookClosestColor(PVRGB *pal,PVRGB c,unsigned reserved)
{
    unsigned i;
    float h,minval;
    UPVD8 min;

    // Recherche la couleur la plus proche
    minval=MAXFLOAT;
    min=0;
    for (i=reserved;i<256;i++)
    {
        h=EuclideDistanceFast((c.r-pal[i].r)*0.3,(c.g-pal[i].g)*0.59,(c.b-pal[i].b)*0.11);
        if(h<minval)
        {
            minval=h;
            min=i;
			if(h==0) break;
        }
    }

    return min;
}

static UPVD8 StandardLightTable(PVRGB *pal,PVMaterial *m,unsigned col,unsigned intensity,PVRGBF ambient,unsigned reserved)
{
    PVRGB c;

    // r�cupere couleur originale
    c=pal[col];
    c.r*=4;
    c.g*=4;
    c.b*=4;

    c=LightColor(m,c,intensity,ambient);

    c.r/=4;
    c.g/=4;
    c.b/=4;

    return PV_LookClosestColor(pal,c,reserved);
}


int PVAPI PV_CreateMaterialLightTranscodeTable(PVMaterial *mat,unsigned TexNumber,PVRGB *pal,UPVD8 (*CalcFunc)(PVRGB *pal,PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient,unsigned reserved),PVRGBF ambient,unsigned reserved)
{
    unsigned j,col;
    unsigned x,y;
    int index[256];
    UPVD8 (*CF)(PVRGB *pal,PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient,unsigned reserved);

    // Sauf si y'en a deja une
    if(mat->PaletteTranscodeTable!=NULL) return COOL;

    if(CalcFunc==NULL) CF=StandardLightTable; else CF=CalcFunc;

    memset(index,0,sizeof(index));

    if (mat->PaletteTranscodeTable==NULL) if((mat->PaletteTranscodeTable=(UPVD8*)malloc(256*256))==NULL) return NO_MEMORY;

    for(x=0;x<mat->Tex[TexNumber].Width;x++)
    {
        debug(printf("  Material Light Map : %u%%\r",x*100/mat->Tex[0].Width););
        for(y=0;y<mat->Tex[TexNumber].Height;y++)
        {
            if (index[col=mat->Tex[TexNumber].Texture[y*mat->Tex[TexNumber].Width+x]]==0)
            {
                for(j=0;j<256;j++)
                {
                    mat->PaletteTranscodeTable[j*256+col]= CF(pal,mat,col,j,ambient,reserved);
                }
                index[col]=1;
            }
        }
    }
    return COOL;
}

PVD32 PVAPI PV_MakeNormalizedColorRGB(PVRGB c)
{
    PVD32 d=0;
    UPVD8 r=(1<<(RMaskSize))-1,g=(1<<(GMaskSize))-1,b=(1<<(BMaskSize))-1;

    c.r=((c.r*r)/255.0);
    c.g=((c.g*g)/255.0);
    c.b=((c.b*b)/255.0);

    d|=(c.r<<RFieldPos);
    d|=(c.g<<GFieldPos);
    d|=(c.b<<BFieldPos);

    return d;
}

PVRGB PVAPI PV_DecomposeNormalizedColor(UPVD32 c)
{
    PVRGB h;

    h.r=(c&RedMask)>>RFieldPos;
    h.g=(c&GreenMask)>>GFieldPos;
    h.b=(c&BlueMask)>>BFieldPos;
    h.r*=255/((1<<RMaskSize)-1);
    h.g*=255/((1<<GMaskSize)-1);
    h.b*=255/((1<<BMaskSize)-1);

    return h;}

static UPVD16 StandardLightTable16(PVMaterial *m,unsigned col,unsigned intensity,PVRGBF ambient)
{
    PVRGB c;

    // Couleur originale en 6 6 6
    c=m->Pal[col];
    c.r*=4;
    c.g*=4;
    c.b*=4;

    c=LightColor(m,c,intensity,ambient);

    return (UPVD16)PV_MakeNormalizedColorRGB(c);
}

int PVAPI PV_CreateMaterialLightTranscodeTable16(PVMaterial *mat,unsigned TexNumber,UPVD16 (*CalcFunc)(PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient),PVRGBF ambient)
{
    unsigned j,col;
    unsigned x,y;
    unsigned index[256];
    UPVD16 (*CF)(PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient);

    // Sauf si y'en a deja une
    if(mat->RGB16TranscodeTable!=NULL) return COOL;

    if(CalcFunc==NULL) CF=StandardLightTable16; else CF=CalcFunc;

    memset(index,0,sizeof(index));

    if (mat->RGB16TranscodeTable==NULL) if((mat->RGB16TranscodeTable=(UPVD16*)malloc(256*256*sizeof(UPVD16)))==NULL) return NO_MEMORY;

    for(x=0;x<mat->Tex[TexNumber].Width;x++)
    {
        debug(printf("  Material Light Map16 : %u%%\r",x*100/mat->Tex[0].Width););
        for(y=0;y<mat->Tex[TexNumber].Height;y++)
        {
            if (index[col=mat->Tex[TexNumber].Texture[y*mat->Tex[TexNumber].Width+x]]==0)
            {
                for(j=0;j<256;j++)
                {
                    mat->RGB16TranscodeTable[j*256+col]=CF(mat,col,j,ambient);
                }
                index[col]=1;
            }
        }
    }
    return COOL;
}

static int PV_CreateMipMapTexturesRGB(PVMaterial *m)
{
    unsigned int i,j,w,h,k,r,g,b;
    UPVD8 *SrcTex,*DstTex;

    if(m->Tex[0].Texture==NULL) return INVALID_TEXTURE;
    if(!(m->TextureFlags&TEXTURE_RGB)) return INVALID_TEXTURE;

    debug(printf("  Creating MipMapsRGB...          \n"););

    h=m->Tex[0].Height;
    w=m->Tex[0].Width;
    SrcTex=&m->Tex[0].Texture[0];

    for(k=0;k<(m->NbrMipMaps-1);k++)
    {

        debug(printf("  Dimension %d        \n",k););

        if(m->Tex[k+1].Texture==NULL)
            if((m->Tex[k+1].Texture=(UPVD8*)malloc(sizeof(UPVD8)*3*(h/2)*(w/2)))==NULL) return NO_MEMORY;

        DstTex=&m->Tex[k+1].Texture[0];
        for(i=0;i<(h-1);i+=2)
        {
            debug(printf("\r   %d",i););
            for(j=0;j<(w-1);j+=2)
            {
                r=SrcTex[3*(i*w+j)];
                g=SrcTex[3*(i*w+j)+1];
                b=SrcTex[3*(i*w+j)+2];

                r+=SrcTex[3*(i*w+j+1)];
                g+=SrcTex[3*(i*w+j+1)+1];
                b+=SrcTex[3*(i*w+j+1)+2];

                r+=SrcTex[3*((i+1)*w+j+1)];
                g+=SrcTex[3*((i+1)*w+j+1)+1];
                b+=SrcTex[3*((i+1)*w+j+1)+2];

                r+=SrcTex[3*((i+1)*w+j)];
                g+=SrcTex[3*((i+1)*w+j)+1];
                b+=SrcTex[3*((i+1)*w+j)+2];

                r/=4;
                g/=4;
                b/=4;

                DstTex[3*((i/2)*(w/2)+j/2)]=r;
                DstTex[3*((i/2)*(w/2)+j/2)+1]=g;
                DstTex[3*((i/2)*(w/2)+j/2)+2]=b;
            }
        }
        debug(printf("   ok.\n"););
        h/=2;
        w/=2;
        m->Tex[k+1].Width=w;
        m->Tex[k+1].Height=h;
        m->Tex[k+1].ShiftHeight=GetPowerOf2(h);
        m->Tex[k+1].ShiftWidth=GetPowerOf2(w);
        SrcTex=DstTex;
    }
    return COOL;
}

static int PV_CreateMipMapTexturesRGBDirect(PVMaterial *m)
{
    unsigned int i,j,w,h,k,r,g,b;
    UPVD8 *SrcTex,*DstTex,*t8b;
    UPVD16 *SrcTex16,*DstTex16;
    UPVD32 *SrcTex32,*DstTex32;
    UPVD32 c;
    PVRGB z;

    if(m->Tex[0].Texture==NULL) return INVALID_TEXTURE;
    if(!(m->TextureFlags&TEXTURE_RGBDIRECT)) return INVALID_TEXTURE;

    debug(printf("  Creating MipMapsRGBDirect...          \n"););

    h=m->Tex[0].Height;
    w=m->Tex[0].Width;
    SrcTex=&m->Tex[0].Texture[0];
    SrcTex16=(UPVD16*)SrcTex;
    SrcTex32=(UPVD32*)SrcTex16;

    for(k=0;k<(m->NbrMipMaps-1);k++)
    {

        debug(printf("  Dimension %d        \n",k););

        if(m->Tex[k+1].Texture==NULL)
            if((m->Tex[k+1].Texture=(UPVD8*)malloc(sizeof(UPVD8)*PixelSize*(h/2)*(w/2)))==NULL) return NO_MEMORY;

        DstTex=&m->Tex[k+1].Texture[0];
        DstTex16=(UPVD16*)DstTex;
        DstTex32=(UPVD32*)DstTex16;
        for(i=0;i<(h-1);i+=2)
        {
            debug(printf("\r   %d",i););
            for(j=0;j<(w-1);j+=2)
            {
                switch(PixelSize)
                {
                    case 2:c=SrcTex16[i*w+j];break;
                    case 3:t8b=&SrcTex[3*(i*w+j)];
                            c=(*t8b++);
                            c+=(*t8b++)<<8;
                            c+=(*t8b)<<16;
                            break;
                    case 4:c=SrcTex32[(i*w+j)];break;
                    default:PV_Fatal("CreateMipMapsRGBDirect() : unsupported PixelSize.",PixelSize);
                }

                z=PV_DecomposeNormalizedColor(c);
                r=z.r;
                g=z.g;
                b=z.b;

                switch(PixelSize)
                {
                    case 2:c=SrcTex16[i*w+j+1];break;
                    case 3:t8b=&SrcTex[3*(i*w+j+1)];
                            c=(*t8b++);
                            c+=(*t8b++)<<8;
                            c+=(*t8b)<<16;
                            break;
                    case 4:c=SrcTex32[(i*w+j+1)];break;
                    default:PV_Fatal("CreateMipMapsRGBDirect() : unsupported PixelSize.",PixelSize);
                }

                z=PV_DecomposeNormalizedColor(c);
                r+=z.r;
                g+=z.g;
                b+=z.b;

                switch(PixelSize)
                {
                    case 2:c=SrcTex16[(i+1)*w+j+1];break;
                    case 3:t8b=&SrcTex[3*((i+1)*w+j+1)];
                            c=(*t8b++);
                            c+=(*t8b++)<<8;
                            c+=(*t8b)<<16;
                            break;
                    case 4:c=SrcTex32[((i+1)*w+j+1)];break;
                    default:PV_Fatal("CreateMipMapsRGBDirect() : unsupported PixelSize.",PixelSize);
                }

                z=PV_DecomposeNormalizedColor(c);
                r+=z.r;
                g+=z.g;
                b+=z.b;

                switch(PixelSize)
                {
                    case 2:c=SrcTex16[(i+1)*w+j];break;
                    case 3:t8b=&SrcTex[3*((i+1)*w+j)];
                            c=(*t8b++);
                            c+=(*t8b++)<<8;
                            c+=(*t8b)<<16;
                            break;
                    case 4:c=SrcTex32[((i+1)*w+j)];break;
                    default:PV_Fatal("CreateMipMapsRGBDirect() : unsupported PixelSize.",PixelSize);
                }

                z=PV_DecomposeNormalizedColor(c);
                r+=z.r;
                g+=z.g;
                b+=z.b;

                r/=4;
                g/=4;
                b/=4;

                z.r=r;
                z.g=g;
                z.b=b;

                c=PV_MakeNormalizedColorRGB(z);

                switch(PixelSize)
                {
                    case 2:DstTex16[(i*w)/4+(j/2)]=c;break;
                    case 3:t8b=&DstTex[3*(i*w/4+j/2)];
                           (*t8b++)=(c&0xFF);
                           (*t8b++)=(c&0xFF00)>>8;
                           (*t8b)=(c&0xFF0000)>>16;
                            break;
                    case 4:DstTex32[(i*w/4+j/2)]=c;break;
                    default:PV_Fatal("CreateMipMapsRGBDirect() : unsupported PixelSize.",PixelSize);
                }
            }
        }
        debug(printf("   ok.\n"););
        h/=2;
        w/=2;
        m->Tex[k+1].Width=w;
        m->Tex[k+1].Height=h;
        m->Tex[k+1].ShiftHeight=GetPowerOf2(h);
        m->Tex[k+1].ShiftWidth=GetPowerOf2(w);
        SrcTex=DstTex;
        SrcTex16=(UPVD16*)SrcTex;
        SrcTex32=(UPVD32*)SrcTex16;
    }
    return COOL;
}

static int PV_CreateMipMapTextures8(PVMaterial *m,PVRGB *WorldPal,unsigned reserved)
{
    unsigned int i,j,w,h,k;
    PVRGB c;
    UPVD8 *SrcTex,*DstTex;

    if(m->Tex[0].Texture==NULL) return INVALID_TEXTURE;
    if(!(m->TextureFlags&TEXTURE_PALETIZED8)) return INVALID_TEXTURE;
    debug(printf("  Creating MipMaps8...          \n"););

    h=m->Tex[0].Height;
    w=m->Tex[0].Width;
    SrcTex=&m->Tex[0].Texture[0];

    for(k=0;k<(m->NbrMipMaps-1);k++)
    {

        debug(printf("  Dimension %d        \n",k););

        if(m->Tex[k+1].Texture==NULL)
            if((m->Tex[k+1].Texture=(UPVD8*)malloc((h/2)*(w/2)))==NULL) return NO_MEMORY;

        DstTex=&m->Tex[k+1].Texture[0];
        for(i=0;i<(h-1);i+=2)
        {
            debug(printf("\r   %d",i););
            for(j=0;j<(w-1);j+=2)
            {
                c.r=WorldPal[SrcTex[i*w+j]].r;
                c.g=WorldPal[SrcTex[i*w+j]].g;
                c.b=WorldPal[SrcTex[i*w+j]].b;

                c.r+=WorldPal[SrcTex[i*w+j+1]].r;
                c.g+=WorldPal[SrcTex[i*w+j+1]].g;
                c.b+=WorldPal[SrcTex[i*w+j+1]].b;

                c.r+=WorldPal[SrcTex[(i+1)*w+j]].r;
                c.g+=WorldPal[SrcTex[(i+1)*w+j]].g;
                c.b+=WorldPal[SrcTex[(i+1)*w+j]].b;

                c.r+=WorldPal[SrcTex[(i+1)*w+j+1]].r;
                c.g+=WorldPal[SrcTex[(i+1)*w+j+1]].g;
                c.b+=WorldPal[SrcTex[(i+1)*w+j+1]].b;


                c.r/=4;
                c.g/=4;
                c.b/=4;

                if(i==1) c.r/=2;
                if(i==2) c.b/=2;
                if(i==3) c.g/=2;

                DstTex[(i/2)*(w/2)+j/2]=PV_LookClosestColor(WorldPal,c,reserved);
            }
        }
        debug(printf("   ok.\n"););
        h/=2;
        w/=2;
        m->Tex[k+1].Width=w;
        m->Tex[k+1].Height=h;
        m->Tex[k+1].ShiftHeight=GetPowerOf2(h);
        m->Tex[k+1].ShiftWidth=GetPowerOf2(w);
        SrcTex=DstTex;
    }
    return COOL;
}

int PVAPI PV_CreateMipMapTextures(PVMaterial *m,PVRGB *WorldPal,unsigned reserved)
{
    if(!(m->TextureFlags&(TEXTURE_PALETIZED8|TEXTURE_RGB|TEXTURE_RGBDIRECT))) return COOL;

    if(m->TextureFlags&TEXTURE_MANUALMIPMAPS) return COOL;

    if(m->TextureFlags&TEXTURE_PALETIZED8) return PV_CreateMipMapTextures8(m,WorldPal,reserved);
    if(m->TextureFlags&TEXTURE_RGB) return PV_CreateMipMapTexturesRGB(m);
    if(m->TextureFlags&TEXTURE_RGBDIRECT) return PV_CreateMipMapTexturesRGBDirect(m);
    return COOL;
}

//---------------------------------------------------- MODE PVM_PALETIZED8

/*
    Converti toutes les textures pour un affichge 8 bits
*/
int PVAPI PV_CreateGlobal256Palette(PVMaterial *z,UPVD8 ReservedColors,PVRGB **finalpal)
{
    UPVD8       *newt;
    OctreeType  *octree;
    RGBType     color;
    RGBType     palette[256];
    byte        cli;
    int         n;
    PVMaterial *t=z;
    ulong i,j,limit;
    unsigned npal=256-ReservedColors;

    /*
    ** Initialize the color octree
	*/
	if(z==NULL) return ARG_INVALID;

    debug(printf("� Starting color quantization\n"););
    octree = CreateOctNode(0);
    if((octree = CreateOctNode(0))==NULL) return NO_MEMORY;

    // On sauvegarde la palette globale
    *finalpal=(PVRGB*)malloc(sizeof(PVRGB)*256);
    if(*finalpal==NULL) return NO_MEMORY;

	/*
    ** Loop through the image and store each unique color.
	*/

    while(t!=NULL)
    {

        if ((t->Tex[0].Texture!=NULL)&&(ISFLAGSET(t->TextureFlags,TEXTURE_QUANTIZED)==0))
        {
            /*
             Ici on traite les texture paletis�e
            */
            if(ISFLAGSET(t->TextureFlags,TEXTURE_PALETIZED8))
            {
                if(t->Pal==NULL) return ARG_INVALID;

				// Traitements textures 8 Bits
                // y compris les eventuels mips utilisateurs
                if(t->TextureFlags&TEXTURE_MANUALMIPMAPS) limit=t->NbrMipMaps;
                else limit=1;
				debug(printf("� Texture paletized\n"););

                // Quantization texture 8 bits
				for(j=0;j<limit;j++)
                for (i = 0L; i < t->Tex[j].Width*t->Tex[j].Height; i++) {
                    /*
                    ** Show progress...
                    */
                    debug(if ((i % 256) == 0L) printf(" %ld\r",i/256););

                    color.r=t->Pal[t->Tex[j].Texture[i]].r*4;
                    color.g=t->Pal[t->Tex[j].Texture[i]].g*4;
                    color.b=t->Pal[t->Tex[j].Texture[i]].b*4;

                    /*
                    ** Insert this color into the octree
                    */
                    if(InsertTree(&octree, &color, 0)!=0) return NO_MEMORY;

                    /*
                    ** If there are too many colors in the tree as a result of this
                    ** insert, reduce the octree
                    */
                    while (TotalLeafNodes() > npal) {
                        ReduceTree();
                    }
                }

            }

            /*
             Ici les PVRGB
            */
            if(ISFLAGSET(t->TextureFlags,TEXTURE_RGB))
            {
                debug(printf("� Texture PVRGB\n"););
                // Quantization texture 8 bits
                // u compris les eventuels mips utilisateurs

				if(t->TextureFlags&TEXTURE_MANUALMIPMAPS) limit=t->NbrMipMaps;
                else limit=1;

                for(j=0;j<limit;j++)
                for (i = 0L; i < t->Tex[j].Width*t->Tex[0].Height; i++) {
                    /*
                    ** Show progress...
                    */
                    debug(if ((i % 256) == 0L) printf(" %ld\r",i/256););

                    color.r=t->Tex[j].Texture[i*3];
                    color.g=t->Tex[j].Texture[i*3+1];
                    color.b=t->Tex[j].Texture[i*3+2];

                    /*
                    ** Insert this color into the octree
                    */
                    if(InsertTree(&octree, &color, 0)!=0) return NO_MEMORY;

                    /*
                    ** If there are too many colors in the tree as a result of this
                    ** insert, reduce the octree
                    */
                    while (TotalLeafNodes() > npal) {
                        ReduceTree();
                    }
                }

            }
        }
    t=t->Next;
    }
    /*
	** Make a pass through the completed octree to average down the
	** PVRGB components.  When done, 'n' contains the actual number of
	** colors in the palette table.
	*/
	n = 0;
	MakePaletteTable(octree, palette, &n);

    debug(printf("  %d quantized colors.(%d reserved by user)\n",n,ReservedColors););

    // Bon maintenant on va ramapper les textures !
    debug(printf("� Remapping textures ...\n"););
    t=z;
    while(t!=NULL)
    {
        if((t->Tex[0].Texture!=NULL)&&(ISFLAGSET(t->TextureFlags,TEXTURE_QUANTIZED)==0))
        {

            /*
             Remap les textures paletiz�e.
            */
            if(ISFLAGSET(t->TextureFlags,TEXTURE_PALETIZED8))
            {
                // Remapping texture 8 Bits
                // u compris les eventuels mips utilisateurs
                if(t->TextureFlags&TEXTURE_MANUALMIPMAPS) limit=t->NbrMipMaps;
                else limit=1;

                for(j=0;j<limit;j++)
                for(i=0;i<t->Tex[j].Width*t->Tex[j].Height;i++)
                {
                    color.r=t->Pal[t->Tex[j].Texture[i]].r*4;
                    color.g=t->Pal[t->Tex[j].Texture[i]].g*4;
                    color.b=t->Pal[t->Tex[j].Texture[i]].b*4;

                    cli = QuantizeColor(octree, &color);

                    t->Tex[j].Texture[i]=cli+ReservedColors;
                }
                ADDFLAG(t->TextureFlags,TEXTURE_QUANTIZED);
				t->Pal=NULL;
            }

            /*
             remap les PVRGB
            */
            if(ISFLAGSET(t->TextureFlags,TEXTURE_RGB))
            {
                // Remapping texture PVRGB en texture 8 bits
                // u compris les eventuels mips utilisateurs
                if(t->TextureFlags&TEXTURE_MANUALMIPMAPS) limit=t->NbrMipMaps;
                else limit=1;

                for(j=0;j<limit;j++)
                {
                    if((newt=(UPVD8*)malloc(t->Tex[j].Width*t->Tex[j].Height*sizeof(UPVD8)))==NULL) return NO_MEMORY;
                    for(i=0;i<t->Tex[j].Width*t->Tex[0].Height;i++)
                    {
                        color.r=t->Tex[j].Texture[i*3];
                        color.g=t->Tex[j].Texture[i*3+1];
                        color.b=t->Tex[j].Texture[i*3+2];

                        cli = QuantizeColor(octree, &color);

                        newt[i]=cli+ReservedColors;
                    }
                    if(!(t->TextureFlags&TEXTURE_TEX_DONT_FREE)) free(t->Tex[j].Texture);					
                    t->Tex[j].Texture=newt;
                }

                ADDFLAG(t->TextureFlags,TEXTURE_QUANTIZED);
                REMOVEFLAG(t->TextureFlags,TEXTURE_RGB);
                ADDFLAG(t->TextureFlags,TEXTURE_PALETIZED8);
            }
        }
        if(!(t->TextureFlags&TEXTURE_TEX_DONT_FREE)) free(t->Pal);
		else REMOVEFLAG(t->TextureFlags,TEXTURE_TEX_DONT_FREE);
        
        t=t->Next;
    }
    KillOctree(octree);

    for(i=0;i<256-ReservedColors;i++)
    {
        (*finalpal)[i+ReservedColors].r=palette[i].r/4;
        (*finalpal)[i+ReservedColors].g=palette[i].g/4;
        (*finalpal)[i+ReservedColors].b=palette[i].b/4;
    }

    return COOL;
}

//---------------------------------------------------- MODE PVM_RGB
/*
 Converti une texture 8Bits en PVRGB pour affichage direct si pas eclair�
*/
static int ConvertTexture8ToRGBDirect(PVTexture *t,PVRGB *p,char freeblock)
{
    UPVD8 *t8,*t8b;
    UPVD16 *t16;
    UPVD32 *t32;
    PVRGB c;
    unsigned i,j;
    PVD32 f;

    if(t->Texture==NULL) return COOL;
    if((t8=(UPVD8*)malloc(t->Width*t->Height*PixelSize))==NULL) return NO_MEMORY;
    debug(printf("� Promoting texture 8 to RGBDirect...\n"););

    for(i=0;i<t->Width;i++)
    for(j=0;j<t->Height;j++)
    {
        c=p[t->Texture[j*t->Width+i]];
        c.r*=4;
        c.g*=4;
        c.b*=4;
        f=PV_MakeNormalizedColorRGB(c);

        t16=(UPVD16*)t8;
        t32=(UPVD32*)t8;

        switch(PixelSize)
        {
            case 2:t16[(j*(t->Width)+i)]=f;break;
            case 3:t8b=&t8[3*(j*(t->Width)+i)];
                   (*t8b++)=(f&0xFF);
                   (*t8b++)=(f&0xFF00)>>8;
                   (*t8b)=(f&0xFF0000)>>16;
                   break;
            case 4:t32[(j*(t->Width)+i)]=(UPVD32)f;break;
            default:PV_Fatal("ConvertTexture8ToRGBDirect() : unsupported PixelSize.",PixelSize);
        }
    }
    if(freeblock) free(t->Texture);
    t->Texture=(UPVD8*)t8;

    return COOL;
}

static int ConvertTexture8ToRGB(PVTexture *t,PVRGB *p,char freeblock) {
    UPVD8 *t24;
    PVRGB c;
    unsigned i,j;
    PVD32 f;

    if(t->Texture==NULL) return COOL;
    if((t24=(UPVD8*)malloc(t->Width*t->Height*3*sizeof(UPVD8)))==NULL) return NO_MEMORY;
    debug(printf("� Promoting texture 8 to PVRGB...\n"););

    for(i=0;i<t->Width;i++)
    for(j=0;j<t->Height;j++)
    {
        c=p[t->Texture[j*t->Width+i]];
        c.r*=4;
        c.g*=4;
        c.b*=4;
        f=PV_MakeNormalizedColorRGB(c);

        t24[3*(j*(t->Width)+i)]=(f&RedMask)>>RFieldPos;
        t24[3*(j*(t->Width)+i)+1]=(f&GreenMask)>>GFieldPos;
        t24[3*(j*(t->Width)+i)+2]=(f&BlueMask)>>BFieldPos;
    }
    if(freeblock) free(t->Texture);
    t->Texture=(UPVD8*)t24;

    return COOL;
}

/*
 Converti une texture PVRGB en PVRGB pour affichage direct si pas eclair�
*/

static int ConvertTextureRGBToRGBDirect(PVTexture *t,char freeblock) {
    UPVD8 *t8,*t8b;
    UPVD16 *t16;
    UPVD32 *t32;
    PVRGB c;
    unsigned i,j;
    PVD32 f;

    if(t->Texture==NULL) return COOL;
    if((t8=(UPVD8*)malloc(t->Width*t->Height*PixelSize))==NULL) return NO_MEMORY;
    debug(printf("� Promoting texture PVRGB to RGBDirect...\n"););

	// Speed up si possible
	if((RMaskSize==8)&&(GMaskSize==8)&&(BMaskSize==8)&&
		(RFieldPos==0)&&(GFieldPos==8)&&(BFieldPos==16))
	{
		if(freeblock)
		{
			free(t8);
			t8=t->Texture;
			freeblock=0;
		}
		else
			memcpy(t8,t->Texture,t->Width*t->Height*PixelSize);
	}
	else
	{
		for(i=0;i<t->Width;i++)
		for(j=0;j<t->Height;j++)
		{
			c.r=t->Texture[3*(j*t->Width+i)];
			c.g=t->Texture[3*(j*t->Width+i)+1];
			c.b=t->Texture[3*(j*t->Width+i)+2];
			f=PV_MakeNormalizedColorRGB(c);

			t16=(UPVD16*)t8;
			t32=(UPVD32*)t8;

			switch(PixelSize)
			{
				case 2:t16[(j*(t->Width)+i)]=f;break;
				case 3:t8b=&t8[3*(j*(t->Width)+i)];
					   (*t8b++)=(f&0xFF);
					   (*t8b++)=(f&0xFF00)>>8;
					   (*t8b)=(f&0xFF0000)>>16;
					   break;
				case 4:t32[(j*(t->Width)+i)]=(UPVD32)f;break;
				default:PV_Fatal("ConvertTextureRGBToRGBDirect() : unsupported PixelSize.",PixelSize);
			}
		}
	}
    if(freeblock)free(t->Texture);
    t->Texture=(UPVD8*)t8;

    return COOL;
}

int ConvertTextureRGBAToRGB(PVTexture *t,char freeblock) {
    UPVD8 *t8;
    unsigned i,j;    

    if(t->Texture==NULL) return COOL;
    if((t8=(UPVD8*)malloc(t->Width*t->Height*4))==NULL) return NO_MEMORY;
    debug(printf("� Converting RGBA to RGB+A...\n"););

    // Transfert les couleurs
	for(i=0;i<t->Width;i++)
    for(j=0;j<t->Height;j++)
    {
        t8[3*(j*t->Width+i)]=t->Texture[4*(j*t->Width+i)];
        t8[3*(j*t->Width+i)+1]=t->Texture[4*(j*t->Width+i)+1];
        t8[3*(j*t->Width+i)+2]=t->Texture[4*(j*t->Width+i)+2];
    }

	// Et l'alpha
	for(i=0;i<t->Width;i++)
    for(j=0;j<t->Height;j++)
    {
        t8[3*(t->Width*t->Height)+(j*t->Width+i)]=t->Texture[4*(j*t->Width+i)+3];
    }
    if(freeblock)free(t->Texture);
    t->Texture=(UPVD8*)t8;

    return COOL;
}

static void ScaleRGBTextureComponents(PVTexture *t)
{
    unsigned i,j;

	if((RMaskSize==8)&&(GMaskSize==8)&&(BMaskSize==8)) return; // Scaling not needed

    for(i=0;i<t->Width;i++)
    for(j=0;j<t->Height;j++)
    {
        t->Texture[3*(j*t->Width+i)]=t->Texture[3*(j*t->Width+i)]>>(8-RMaskSize);
        t->Texture[3*(j*t->Width+i)+1]=t->Texture[3*(j*t->Width+i)+1]>>(8-GMaskSize);
        t->Texture[3*(j*t->Width+i)+2]=t->Texture[3*(j*t->Width+i)+2]>>(8-BMaskSize);
    }
}

int PVAPI PV_CompileMaterial(PVMaterial *m,UPVD8 (*CalcFunc)(PVRGB *pal,PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient,unsigned reserved),UPVD16 (*CalcFunc16)(PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient),PVRGBF ambient,unsigned reservedcolors)
{
    unsigned h,i,limit;
	char s[255];

    if(m==NULL) return COOL;
	if(m->TextureFlags&TEXTURE_PROCESSED) return COOL;

	debug(printf("  Material %s                       \n",m->Name););

	// Traitement multitexture, pas avec mapping
	if(m->Type&MULTITEXTURE)
	{
		m->Type&=~MAPPING;
	}

	// Traitement sp�cifique au sus dit material
	switch(m->Type&(RENDER_MASK|SHADE_MASK))
	{
		case BUMP|NOTHING:
		case PHONG|NOTHING:
			{
				h=PV_SetMaterialPhongPalette(m,ambient);
				if(h!=COOL) {
					strcpy(s,"CompileMaterial()::Not enough memory to create specific ");
					strcat(s,m->Name);
					PV_Fatal(s,m->Type);
				}
				break;
			}
	}

	if(m->TextureFlags&TEXTURE_RGBA)
	{
		// No mipmaps for RGBA textures
		REMOVEFLAG(m->TextureFlags,TEXTURE_MIPMAP);
		m->NbrMipMaps=1;
	}

	if((m->TextureFlags&TEXTURE_RGBA)&&(!(PV_Mode&PVM_USEHARDWARE)))
	{
	    limit=1;
	    if(m->TextureFlags&TEXTURE_MANUALMIPMAPS) limit=m->NbrMipMaps;	

		for(i=0;i<limit;i++)
			ConvertTextureRGBAToRGB(&m->Tex[i],!(m->TextureFlags&TEXTURE_TEX_DONT_FREE));
		REMOVEFLAG(m->TextureFlags,TEXTURE_RGBA);
		ADDFLAG(m->TextureFlags,TEXTURE_RGB);
		ADDFLAG(m->TextureFlags,TEXTURE_RGB_A);
	}

    // Sotie pal�tiz�e
    if(PV_Mode&PVM_PALETIZED8)
    {		
		debug(printf("\t=> Output is paletized, converting textures to a unique palette\n"););

		// Mode ecran paletiz�
		// Converti toutes les texture en 8 bits avec palette unique
		// sauf si palette gloabl deja specifi�e
		if((m->Pal==NULL)&&(m->Type&MAPPED_MATERIAL)&&(!(m->TextureFlags&TEXTURE_QUANTIZED)))
		{
			h=PV_CreateGlobal256Palette(m,reservedcolors,&m->Pal);
			if(h!=COOL) return h;
		}

		// Cr�e la table d'�clairage
        if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0))
        {
			h=PV_CreateMaterialLightTranscodeTable(m,0,m->Pal,CalcFunc,ambient,reservedcolors);
            if(h!=COOL) return h;
        }
    }

    // Sortie FAKE RGB16
    if(PV_Mode&PVM_RGB16){

        h=PV_ConvertMaterial(m);
        if(h!=COOL) return h;

        // Cr�e la table d'�calirage
        if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0))
        {
            if(m->TextureFlags&TEXTURE_RGB) return INVALID_TEXTURE;
            h=PV_CreateMaterialLightTranscodeTable16(m,0,CalcFunc16,ambient);
            if(h!=COOL) return h;
        }
    }

    // Sortie PVRGB, pas de table d'�calairage, on convertit les textures
    if(PV_Mode&PVM_RGB){		
        h=PV_ConvertMaterial(m);
        if(h!=COOL) return h;
    }

    // Les MipMaps
    if(ISFLAGSET(m->TextureFlags,TEXTURE_MIPMAP))
	{
        // Calcul nombre maxi de mips maps
		for(i=0;i<m->NbrMipMaps;i++)
		{
			if((m->Tex[0].Width>>i)==0) break;
			if((m->Tex[0].Height>>i)==0) break;
		}
		m->NbrMipMaps=i;

		if(PV_Mode&PVM_PALETIZED8)
        {
            h=PV_CreateMipMapTextures(m,m->Pal,reservedcolors);
            if(h!=COOL) return h;

            if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0))
            for(i=0;i<(m->NbrMipMaps-1);i++){
                h=PV_CreateMaterialLightTranscodeTable(m,i+1,m->Pal,CalcFunc,ambient,reservedcolors);
                if(h!=COOL) return h;
            }
        }

        if(PV_Mode&PVM_RGB16)
        {
            h=PV_CreateMipMapTextures(m,m->Pal,0);
            if(h!=COOL) return h;

            if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0))
            for(i=0;i<(m->NbrMipMaps-1);i++){
                h=PV_CreateMaterialLightTranscodeTable16(m,i+1,CalcFunc16,ambient);
                if(h!=COOL) return h;
            }
        }

        if(PV_Mode&PVM_RGB)
        {
            h=PV_CreateMipMapTextures(m,NULL,0);
            if(h!=COOL) return h;
        }
    }
    else m->NbrMipMaps=1;

	h=PV_FinalizeMaterial(m);
	if(h!=COOL) return h;

	// Processed !
    ADDFLAG(m->TextureFlags,TEXTURE_PROCESSED);

    return COOL;
}

int PVAPI PV_FinalizeMaterial(PVMaterial *m)
{
	int h;
	
	// Appel du driver
    if(PV_Mode&PVM_USEHARDWARE)
    {
        if(PV_GetHardwareDriver()!=NULL)
            {if(h=PV_GetHardwareDriver()->LoadTexture(m)!=COOL) return h;}
        else
            return NO_HARDWARE_SET;
    }

    // Select filler		
	if(m->Filler==NULL) m->Filler=(void (PVAPI *)(PVFace*))PV_GetFiller(m->Type);
	if(m->Filler==NULL)
    {
        char s[255];

		strcpy(s,"CompileMaterial() :: Unsupported material flags for  ");
        strcat(s,m->Name);
        PV_Fatal(s,m->Type);
    }
	return COOL;
}

//---------------------------------------- Fonction Wrapper pour PVRGB et RGB16
//---------------------------------------- Convertit une texture non �clair�e

int PVAPI PV_ConvertMaterial(PVMaterial *m)
{
    int b,texnumber,limit;
    PVRGB *p=m->Pal;

    if(m->TextureFlags&TEXTURE_PROCESSED) return COOL;
    if(!(m->TextureFlags&(TEXTURE_PALETIZED8|TEXTURE_RGB|TEXTURE_RGBA))) return COOL;

	if((PV_Mode&PVM_USEHARDWARE)&&(m->TextureFlags&TEXTURE_RGBA)) return COOL;

    limit=1;
    if(m->TextureFlags&TEXTURE_MANUALMIPMAPS) limit=m->NbrMipMaps;	

    for(texnumber=0;texnumber<limit;texnumber++)  // Convertit les mipmaps utilisateurs
    {
		if(PV_Mode&PVM_RGB16){
            // On ne traite ke les textures direct to screen
            if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0)) return COOL;

            if(m->TextureFlags&TEXTURE_PALETIZED8)
            {
                b=ConvertTexture8ToRGBDirect(&m->Tex[texnumber],p,!(m->TextureFlags&TEXTURE_TEX_DONT_FREE));
                if(b!=COOL) return b;
            }

            if(m->TextureFlags&TEXTURE_RGB)
            {
                b=ConvertTextureRGBToRGBDirect(&m->Tex[texnumber],!(m->TextureFlags&TEXTURE_TEX_DONT_FREE));
                if(b!=COOL) return b;
            }
        }

        if(PV_Mode&PVM_RGB){

            if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0))
            {
                if(m->TextureFlags&TEXTURE_PALETIZED8) 
				{
                    b=ConvertTexture8ToRGB(&m->Tex[texnumber],p,!(m->TextureFlags&TEXTURE_TEX_DONT_FREE));
                    if(b!=COOL) return b;
                }
                else
                ScaleRGBTextureComponents(&m->Tex[texnumber]);
            }
            else
            {
                // On ne traite ke les textures direct to screen
                if(m->TextureFlags&TEXTURE_PALETIZED8) {
                    b=ConvertTexture8ToRGBDirect(&m->Tex[texnumber],p,!(m->TextureFlags&TEXTURE_TEX_DONT_FREE));
                    if(b!=COOL) return b;
                }

                if(m->TextureFlags&TEXTURE_RGB) {
                    b=ConvertTextureRGBToRGBDirect(&m->Tex[texnumber],!(m->TextureFlags&TEXTURE_TEX_DONT_FREE));
                    if(b!=COOL) return b;
                }
            }
        }
    }

    // On set les flags d'etat
    if(PV_Mode&PVM_RGB16){
        if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0)) return COOL;

        if(m->TextureFlags&TEXTURE_PALETIZED8)
        {
            REMOVEFLAG(m->TextureFlags,TEXTURE_PALETIZED8);
            ADDFLAG(m->TextureFlags,TEXTURE_RGBDIRECT);
        }

        if(m->TextureFlags&TEXTURE_RGB)
        {
            REMOVEFLAG(m->TextureFlags,TEXTURE_RGB);
            ADDFLAG(m->TextureFlags,TEXTURE_RGBDIRECT);
        }
    }

    if(PV_Mode&PVM_RGB){
        if(((m->Type&RENDER_MASK)!=0)&&((m->Type&SHADE_MASK)!=0))
        {
            if(m->TextureFlags&TEXTURE_PALETIZED8) {
                REMOVEFLAG(m->TextureFlags,TEXTURE_PALETIZED8);
                ADDFLAG(m->TextureFlags,TEXTURE_RGB);
                if(!(m->TextureFlags&TEXTURE_TEX_DONT_FREE))free(m->Pal);
				else REMOVEFLAG(m->TextureFlags,TEXTURE_TEX_DONT_FREE);
                m->Pal=NULL;
            }
        }
        else
        {
            if(m->TextureFlags&TEXTURE_PALETIZED8) {
                REMOVEFLAG(m->TextureFlags,TEXTURE_PALETIZED8);
                ADDFLAG(m->TextureFlags,TEXTURE_RGBDIRECT);
                if(!(m->TextureFlags&TEXTURE_TEX_DONT_FREE))free(m->Pal);
				else REMOVEFLAG(m->TextureFlags,TEXTURE_TEX_DONT_FREE);
                m->Pal=NULL;
            }

            if(m->TextureFlags&TEXTURE_RGB) {
                REMOVEFLAG(m->TextureFlags,TEXTURE_RGB);
                ADDFLAG(m->TextureFlags,TEXTURE_RGBDIRECT);
            }
        }
    }

    return COOL;
}

//----------------------------------------- Genere une map de Bump
//----------------------------------------- a partir d'une image 8 bits de hauteur

int PVAPI PV_BuildBumpMap(PVMaterial *m,UPVD8 *Texture,unsigned width,unsigned height,float scale)
{
    unsigned i,j;

    if(m->BumpMap.Map!=NULL) free(m->BumpMap.Map);
    if((m->BumpMap.Map=(PVBumpInfo*)malloc(width*height*sizeof(PVBumpInfo)))==NULL) return NO_MEMORY;

    debug(printf("� Creating BumpMap..."););
    m->BumpMap.Width=width;
    m->BumpMap.Height=height;

    // Calcul des pseudos normales
    for(i=1;i<width-1;i++)
    for(j=1;j<height-1;j++)
    {
        m->BumpMap.Map[j*width+i].nx=(PVD8)((Texture[j*width+i+1]-Texture[j*width+i-1])*scale);
        m->BumpMap.Map[j*width+i].ny=(PVD8)((Texture[(j+1)*width+i]-Texture[(j-1)*width+i])*scale);
    }
    debug(printf("ok.\n"););
    return COOL;
}

void PVAPI PV_GammaCorrectCol(PVRGB *col,float gamma)
{
    float g=1.0/gamma;
    float b;
    
    b=256.0*pow(((float)col->r)/256.0,g);
    if(b<0) b=0;
    if(b>255) b=255;
    col->r=b;

    b=256.0*pow(((float)col->g)/256.0,g);
    if(b<0) b=0;
    if(b>255) b=255;
    col->g=b;

    b=256.0*pow(((float)col->b)/256.0,g);
    if(b<0) b=0;
    if(b>255) b=255;
    col->b=b;
}

int PVAPI PV_MaterialGammaCorrect(PVMaterial *m,float gamma)
{
   unsigned i,j;
   float g;
   float b;

   if(m==NULL) return ARG_INVALID;
   if(gamma==0) return COOL;

   if(m->TextureFlags&TEXTURE_PALETIZED8)
   {
        // Gamma correctionne la palette
        if(m->Pal==NULL) return BIZAR_ERROR;

        g=1.0/gamma;

        for(i=0;i<256;i++)
        {
            b=64.0*pow(((float)m->Pal[i].r)/64.0,g);
            if(b<0) b=0;
            if(b>63) b=63;
            m->Pal[i].r=b;

            b=64.0*pow(((float)m->Pal[i].g)/64.0,g);
            if(b<0) b=0;
            if(b>63) b=63;
            m->Pal[i].g=b;

            b=64.0*pow(((float)m->Pal[i].b)/64.0,g);
            if(b<0) b=0;
            if(b>63) b=63;
            m->Pal[i].b=b;
        }
   }

   if(m->TextureFlags&TEXTURE_RGB)
   {
        // Gamma correctionne l'image
        g=1.0/gamma;

        for(j=0;j<m->NbrMipMaps;j++)
        for(i=0;i<m->Tex[j].Width*m->Tex[j].Height;i++)
        {
            b=256.0*pow(((float)m->Tex[j].Texture[i*3])/256.0,g);
            if(b<0) b=0;
            if(b>255) b=255;
            m->Tex[j].Texture[i*3]=b;

            b=256.0*pow(((float)m->Tex[j].Texture[i*3+1])/256.0,g);
            if(b<0) b=0;
            if(b>255) b=255;
            m->Tex[j].Texture[i*3+1]=b;

            b=256.0*pow(((float)m->Tex[j].Texture[i*3+2])/256.0,g);
            if(b<0) b=0;
            if(b>255) b=255;
            m->Tex[j].Texture[i*3+2]=b;
        }
   }

   if(m->TextureFlags&TEXTURE_RGBA)
   {
        // Gamma correctionne l'image
        g=1.0/gamma;

        for(j=0;j<m->NbrMipMaps;j++)
        for(i=0;i<m->Tex[j].Width*m->Tex[j].Height;i++)
        {
            b=256.0*pow(((float)m->Tex[j].Texture[i*4])/256.0,g);
            if(b<0) b=0;
            if(b>255) b=255;
            m->Tex[j].Texture[i*4]=b;

            b=256.0*pow(((float)m->Tex[j].Texture[i*4+1])/256.0,g);
            if(b<0) b=0;
            if(b>255) b=255;
            m->Tex[j].Texture[i*4+1]=b;

            b=256.0*pow(((float)m->Tex[j].Texture[i*4+2])/256.0,g);
            if(b<0) b=0;
            if(b>255) b=255;
            m->Tex[j].Texture[i*4+2]=b;
        }
   }
   return COOL;
}

int PVAPI PV_GammaCorrectPal(PVRGB Pal[256],float gamma)
{
   unsigned i;
   float g;
   float b;

   if(Pal==NULL) return ARG_INVALID;
   if(gamma==0) return COOL;

    // Gamma correctionne la palette
    g=1.0/gamma;

    for(i=0;i<256;i++)
    {
        b=64.0*pow(((float)Pal[i].r)/64.0,g);
        if(b<0) b=0;
        if(b>63) b=63;
        Pal[i].r=b;

        b=64.0*pow(((float)Pal[i].g)/64.0,g);
        if(b<0) b=0;
        if(b>63) b=63;
        Pal[i].g=b;

        b=64.0*pow(((float)Pal[i].b)/64.0,g);
        if(b<0) b=0;
        if(b>63) b=63;
        Pal[i].b=b;
    }
    return COOL;
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "fillcom.h"

static int __cdecl Init1GMapping(int NumVtx,unsigned *vtx) {
    PVMesh *o=GenFill_CurrentFace->Father;
    float d,e,f;
    static double mn=6755399441055744.0;
    double r,g,b;
    unsigned *i1=(unsigned*)&r,*i2=(unsigned*)&g,*i3=(unsigned*)&b;

    d=(1<<RMaskSize)-1;
    e=(1<<GMaskSize)-1;
    f=(1<<BMaskSize)-1;

    r=min(1,(o->Shading[GenFill_CurrentFace->V[0]].Color.r+RGBAmbientLight->r)*GenFill_CurrentFace->MaterialInfo->Diffuse.r+GenFill_CurrentFace->MaterialInfo->Emissive.r)*RedFact*d;
    g=min(1,(o->Shading[GenFill_CurrentFace->V[0]].Color.g+RGBAmbientLight->g)*GenFill_CurrentFace->MaterialInfo->Diffuse.g+GenFill_CurrentFace->MaterialInfo->Emissive.g)*GreenFact*e;
    b=min(1,(o->Shading[GenFill_CurrentFace->V[0]].Color.b+RGBAmbientLight->b)*GenFill_CurrentFace->MaterialInfo->Diffuse.b+GenFill_CurrentFace->MaterialInfo->Emissive.b)*BlueFact*f;

    r+=mn; g+=mn; b+=mn;
    col=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);

    return 0;
}

static void __cdecl Init2GMapping(int NumVtx)
{

    switch(PixelSize)
    {
        case 2:HLineRoutine=HLineRGBFlat16;break;
        case 3:HLineRoutine=HLineRGBFlat24;break;
        case 4:HLineRoutine=HLineRGBFlat32;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct RGBFlat={Init1GMapping,Init2GMapping};

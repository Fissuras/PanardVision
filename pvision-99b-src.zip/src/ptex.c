/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "fillcom.h"

static int __cdecl Init1Mapping(int NumVtx,unsigned *vtx) {
    PVMesh *o=GenFill_CurrentFace->Father;
	unsigned i;

    if(GenFill_CurrentFace->Flags&AUTOMATIC_PERSPECTIVE)
    if(!PerspectiveNeeded(o->Rotated[vtx[0]].zf,o->Rotated[vtx[1]].zf,o->Rotated[vtx[NumVtx-1]].zf))
    {
        TriAffineMapping(GenFill_CurrentFace);
        return 1;
    }

    GenFill_NbrIncF=3;

	for(i=0;i<NumVtx;i++)
    {
        int a=vtx[i];

        GenFill_InitialValues[i][0]=o->Projected[a].InvertZ;
        GenFill_InitialValues[i][1]=o->Mapping[a].u*GenFill_InitialValues[i][0];
        GenFill_InitialValues[i][2]=o->Mapping[a].v*GenFill_InitialValues[i][0];
    }

    if((GenFill_CurrentFace->Flags&FLAT)||(GenFill_CurrentFace->Flags&GOURAUD))
    {
        col=GetRampIndex(GenFill_CurrentFace->V[0],o,GenFill_CurrentFace->MaterialInfo);
        MapLightTranslateTable=GenFill_CurrentFace->MaterialInfo->PaletteTranscodeTable;
        MapLightTranslateTable16=GenFill_CurrentFace->MaterialInfo->RGB16TranscodeTable;
        LineMapLightTransTable=&MapLightTranslateTable[col*256];
        LineMapLightTransTable16=&MapLightTranslateTable16[col*256];
    }
#ifdef __386__
	HLineRoutine=GenPHLineUV;
#else
    HLineRoutine=GenPHLine;
#endif

    if(PV_Mode&PVM_RGB16)
    {
        if((GenFill_CurrentFace->Flags&FLAT)||(GenFill_CurrentFace->Flags&GOURAUD))
        {
            SLineRoutine=&HLineAffineFlatMappingRGB16;
            #ifdef __386__
            HLPInitFunc=HLineAffineMapping_INIT;
            #endif
        }
        else
        {
            SLineRoutine=&HLineRGBTextureMapping16;
            #ifdef __386__
            HLPInitFunc=HLineRGBTextureMapping_INIT;
            #endif
        }
    }
    else
    {
       if((GenFill_CurrentFace->Flags&FLAT)||(GenFill_CurrentFace->Flags&GOURAUD)) SLineRoutine=&HLineAffineFlatMapping;
                                           else SLineRoutine=&HLineAffineMapping;
       #ifdef __386__
        HLPInitFunc=HLineAffineMapping_INIT;
       #endif

    }

    return 0;
}

static void __cdecl Init2Mapping(int NumVtx) {
    unsigned MipIndex;
    unsigned TextureW,TextureH,i;

    // MipMap
    if((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP))
    {
		MipIndex=GetMipMapIndex(GenFill_CurrentFace,1,2);

        Texture=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].ShiftWidth;
    }
    else
    {
        // No MipMap
        Texture=GenFill_CurrentFace->MaterialInfo->Tex[0].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[0].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[0].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[0].ShiftWidth;
    }

	for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][1]*=(TextureW);
        GenFill_InitialValues[i][2]*=(TextureH);
    }

    GenFill_GradientX[1]*=TextureW;
    GenFill_GradientX[2]*=TextureH;
    GenFill_GradientY[1]*=TextureW;
    GenFill_GradientY[2]*=TextureH;

    AndHeight=TextureH-1;
    AndWidth=TextureW-1;

    GradientXAff[0]=GenFill_GradientX[0]*AFFINE_LENGTH;
    GradientXAff[1]=GenFill_GradientX[1]*AFFINE_LENGTH;
    GradientXAff[2]=GenFill_GradientX[2]*AFFINE_LENGTH;

}

/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct PerspectiveMapping={Init1Mapping,Init2Mapping};

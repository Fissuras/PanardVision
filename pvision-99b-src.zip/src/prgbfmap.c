/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include "fillcom.h"

#include "cache.h"

static void __cdecl HLPNull(void)
{
}

static void __cdecl HLineRGBFTextureMapping32(unsigned deb,unsigned fin)
{
    unsigned length;
    UPVD32 *p;
    int o;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;

    while(length--!=0)
    {
        o=((((int*)GenFill_CurrentLeftVal)[1]>>16)*ShiftWidth+(((int*)GenFill_CurrentLeftVal)[0]>>16));
        p=(UPVD32*)Texture;
        p+=o;

        *((UPVD32*)ofs)=(*p);

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

static void __cdecl HLineRGBFTextureMapping24(unsigned deb,unsigned fin)
{
    unsigned length;
    PVD8 *p;
    int o;
    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;

    while(length--!=0)
    {
        o=3*((((int*)GenFill_CurrentLeftVal)[1]>>16)*ShiftWidth+(((int*)GenFill_CurrentLeftVal)[0]>>16));
        p=(PVD8*)Texture;
        p+=o;

        *(ofs++)=(*p++);
        *(ofs++)=(*p++);
        *(ofs++)=(*p);

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

static void __cdecl HLineRGBFTextureMapping16(unsigned deb,unsigned fin)
{
    unsigned length;
    PVD16 *p;
    int o;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;

    while(length--!=0)
    {
        o=((((int*)GenFill_CurrentLeftVal)[1]>>16)*ShiftWidth+(((int*)GenFill_CurrentLeftVal)[0]>>16));
        p=(PVD16*)Texture;
        p+=o;

        *(ofs16++)=(*p);

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

#ifndef __386__
static void __cdecl HLineRGBFTextureMapping8(unsigned deb,unsigned fin)
{
    unsigned length;
    PVD8 *p;
    int o;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;

    while(length--!=0)
    {
        o=((((int*)GenFill_CurrentLeftVal)[1]>>16)*ShiftWidth+(((int*)GenFill_CurrentLeftVal)[0]>>16));
        p=Texture;
        p+=o;

        *(ofs++)=(*p);

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}
#else
extern void __cdecl HLineRGBFTextureMapping8(unsigned deb,unsigned fin);
#endif

static int __cdecl Init1RGBF(int NumVtx,unsigned *vtx) {
    PVMesh *o=GenFill_CurrentFace->Father;
    unsigned i;

    // penser a jouter un jour la version perspective free
	/*if(GenFill_CurrentFace->Flags&AUTOMATIC_PERSPECTIVE)
    if(!PerspectiveNeeded(o->Rotated[GenFill_p1].zf,o->Rotated[GenFill_p2].zf,o->Rotated[GenFill_p3].zf))
    {
        TriRGBTextureMapping(GenFill_CurrentFace);
        return 1;
    } */

    GenFill_NbrIncF=3;

    for(i=0;i<NumVtx;i++)
    {
        int a=vtx[i];

        GenFill_InitialValues[i][0]=o->Projected[a].InvertZ;
        GenFill_InitialValues[i][1]=o->Mapping[a].u*GenFill_InitialValues[i][0];
        GenFill_InitialValues[i][2]=o->Mapping[a].v*GenFill_InitialValues[i][0];
    }

#ifdef __386__
	HLineRoutine=GenPHLineUV;
#else
	HLineRoutine=GenPHLine;
#endif

    return 0;
}

static void __cdecl Init2RGBF(int NumVtx)
{
    unsigned Bi=0;
    unsigned MipIndex;
    unsigned TextureW,TextureH;
    int i;

    // MipMap
    if((GenFill_CurrentFace->Flags&AUTOMATIC_BILINEAR)||((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP)))
		MipIndex=GetMipMapIndex(GenFill_CurrentFace,1,2);

    if((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP))
    {
        Texture=PV_GetCachedTexture(GenFill_CurrentFace,MipIndex,&TextureW,&TextureH);
        ShiftWidth=TextureW;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Height;
    }
    else
    {
        // No MipMap
        Texture=PV_GetCachedTexture(GenFill_CurrentFace,0,&TextureW,&TextureH);
        ShiftWidth=TextureW;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[0].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[0].Height;
    }

    for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][1]*=(TextureW);
        GenFill_InitialValues[i][2]*=(TextureH);
    }

    GenFill_GradientX[1]*=TextureW;
    GenFill_GradientX[2]*=TextureH;
    GenFill_GradientY[1]*=TextureW;
    GenFill_GradientY[2]*=TextureH;

    GradientXAff[0]=GenFill_GradientX[0]*AFFINE_LENGTH;
    GradientXAff[1]=GenFill_GradientX[1]*AFFINE_LENGTH;
    GradientXAff[2]=GenFill_GradientX[2]*AFFINE_LENGTH;

   /* implementer le bili un jour
   if((PV_Mode&PVM_BILINEAR)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_BILINEAR))
        if(GenFill_CurrentFace->Flags&AUTOMATIC_BILINEAR)
        { if(MipIndex==0) Bi=1;}
        else Bi=1;

    if(Bi)
    switch(PixelSize)
    {
        //case 2:SLineRoutine=HLineRGBTextureMapping16Bi;break;
        //case 3:SLineRoutine=HLineRGBTextureMapping24Bi;break;
        //case 4:SLineRoutine=HLineRGBTextureMapping32Bi;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }
    else*/
    switch(PixelSize)
    {
        case 1:SLineRoutine=HLineRGBFTextureMapping8;break;
        case 2:SLineRoutine=HLineRGBFTextureMapping16;break;
        case 3:SLineRoutine=HLineRGBFTextureMapping24;break;
        case 4:SLineRoutine=HLineRGBFTextureMapping32;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }

#ifdef __386__
    HLPInitFunc=HLPNull;
#endif
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct FastPerspectiveTextureMapping={Init1RGBF,Init2RGBF};

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision
// 3D Realtime Engine
// (C) 1996-2000, Olivier Brunet

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <malloc.h>
#include <stdarg.h>
#include "pvision.h"
#include "sb.h"
#include "shadow.h"
#include "brand.h"
#include "crc32.h"
#include "fillcom.h"

#if defined(__UNIX__) && !defined(DJGPP)
#include <sys/mman.h>
#include <errno.h>
#endif

#ifdef WIN32
#include <windows.h>
#endif

#define debug(x) //x

char *PVISION_DATE=__DATE__;
char *PVISION_TIME=__TIME__;

// License Informations ---------------------------------------------------------------------
static BrandInfo brand={"-+-","",0,0,0};

#ifdef __386__
         char *PVISION_VERSION="0.99b Beta6 (Intel Optimized)";
#else
         char *PVISION_VERSION="0.99b Beta6";
#endif

static char *PVISION_COPYRIGHT="Panard Vision - Realtime 3D Engine (C) 1996-2000, Olivier Brunet";

///////////////////////////////////////////////////////////////////////////

#ifdef __WATCOMC__
#pragma intrinsic(ProjectPoint)
#endif

//////////////////////////////////////////// PUBLIC

// Guess ?
PVFLAGS PV_Mode=PVM_PALETIZED8;
PVFLAGS PV_PipelineControl=0;

// Fonctions utilisateurs
static void PVAPI NullCallBack(unsigned a)
{
    a=a;
}

void (PVAPI *PV_UserCleanUp)(unsigned t)=NullCallBack;         // Called when a fatal error occur. T is the error code

/////////////////////////////////////////// PRIVATE
// Gestion Camera
static PVCam *CurrentCam;
static UPVD8 *RenderBuffer;

// Transfos
static PVMat3x3 FinalMatrix;
static PVPoint FinalTrans;
static PVPoint InvertCamPos; // Pour le culling

// Clipping
static PVFace **ovis;

/////////////////////////////////////////// Hints
typedef struct __PVHint
{
	unsigned FogRange;
} PVHint;

PVHint Hint;

/***************************************************************************/
/*                                  INIT                                   */
/***************************************************************************/
void *PVAPI pvmalloc( size_t size )
{
	return malloc(size);
}

void *PVAPI pvcalloc( size_t num, size_t size )
{
	return calloc(num,size);
}

void PVAPI pvfree( void *memblock )
{
	free(memblock);
}

void PVAPI PV_Fatal(char *s,unsigned int t)
{
    #ifdef WIN32
    char s2[255];
    #endif

	PV_UserCleanUp(t);
	#ifndef WIN32
	fprintf(stderr,"\n\nPanardVision: Fatal Error :\n %s (%u).\n",s,t);
	#else
    sprintf(s2,"%s (%u).",s,t);
		
	MessageBox(NULL,s2,"Panard Vision Fatal Error",MB_ICONERROR|MB_OK);
	#endif

	PV_Log("pvision.err","%s (%u)\n",s,t);
    exit(t);
}

void __cdecl PV_Log(char *logfile,char *fmt, ...)
{
    char ach[4096];
    va_list va;
	FILE *f;
	time_t ltime;

    va_start( va, fmt );
    vsprintf( ach, fmt, va );
    va_end( va );

	f=fopen(logfile,"a+");
	
	time( &ltime );    
    fprintf(f,"%s", ctime( &ltime ) );
	fprintf(f,"\t%s",ach);
#ifdef WIN32
	OutputDebugString(ach);
#endif
	fclose(f);
}


#ifdef WIN32
#include "resource.h"

BOOL APIENTRY DlgProc(HWND hwndDlg, UINT message,WPARAM  wParam,LPARAM lParam)
{
    return FALSE;
}
#endif


void TRIFILLP_Init(void);  // Defined in hlinep.c
static void InitMirrorMesh(void);
#include "fpu.h"
#include "sqrt.h"

void PVAPI InitPVisionMN(int mn)
{
	char t1[]="\nInitializing Panard Vision %s...\n";
	char t2[]="NOTE: This version of the engine must not be used in a commercial or shareware product.\n";

#ifdef WIN32
    MEMORY_BASIC_INFORMATION buffer;
	DWORD AncienStatus;
	HWND splash,old;

	HPALETTE pal;
	HDC dc,memdc;
	HANDLE bitmap;
	BITMAP bm;
	HGLOBAL res;
	unsigned conso=0;
#endif
	int i;
	int Splash=1,bypass=0;
	unsigned j;
	unsigned cc,uc;
	
	if(mn!=PV_MN) PV_Fatal("DLL and client version of PV does not match !",PV_MN);

	j=23;
	for(i=0;i<strlen(t1);i++) j+=t1[i];
	for(i=0;i<strlen(t2);i++) j+=t2[i];

	j^=0x52;
	if(j!=10992) InitPVisionMN(mn+1);

	// check reg	
	cc=CRC32_Array((uint8*)brand.CryptedRegName,strlen(brand.CryptedRegName));

	for(i=0;i<strlen(brand.CryptedRegName);i++)
	{
		brand.CryptedRegName[i]^=(255)&(brand.UnCryptCrc>>(8*(i%4)));
	}
	uc=CRC32_Array((uint8*)brand.CryptedRegName,strlen(brand.CryptedRegName));

	if((cc==brand.CryptCrc)&&(uc==brand.UnCryptCrc)&&(brand.CryptCrc!=0)&&(brand.UnCryptCrc!=0))
	{
		if(brand.PID==PID_PVISION0)
		Splash=0;
	}
	else
	{
		#ifdef WIN32
			conso=AllocConsole();
			if(conso) SetConsoleTitle("Panard Vision Infos");
			freopen( "CONOUT$", "w", stdout );
			freopen( "CONOUT$", "w", stderr );
		#endif
	}

    if(Splash)
	{
		fprintf(stderr,t1,PVISION_VERSION);
		fprintf(stderr,"Build: %s, %s\n",PVISION_DATE,PVISION_TIME);

		fprintf(stderr,t2);
	}
	
	debug(fprintf(stderr,"====> Debug Mode Actived <====\n");)

#ifdef WIN32

	if(getenv("PVISION")!=NULL)
	{
		if(strcmp(getenv("PVISION"),"NOSPLASH")==0)
		{
			Splash=0;
		}
	}
	
	// Awful splash screen	
    srand( (unsigned)time( NULL ) );
	if((unsigned)rand()>((unsigned)RAND_MAX/3)) bypass=1;

	if((Splash)&&(!bypass))
	{
		old=GetActiveWindow();

		bitmap=LoadImage(GetModuleHandle("pvision.dll"),MAKEINTRESOURCE(IDB_BITMAP1),IMAGE_BITMAP,0,0,LR_DEFAULTSIZE|LR_CREATEDIBSECTION);
		if(bitmap==NULL) return;
		GetObject(bitmap, sizeof(bm), &bm);

		dc=CreateDC("DISPLAY",NULL,NULL,NULL);

		splash=CreateWindow("STATIC","",WS_POPUP,GetDeviceCaps(dc,HORZRES)/2-bm.bmWidth/2,GetDeviceCaps(dc,VERTRES)/2-bm.bmHeight/2,bm.bmWidth,bm.bmHeight,NULL,NULL,GetModuleHandle("pvision.dll"),NULL);
		SetWindowText(splash,PVISION_VERSION);
		ShowWindow(splash,SW_SHOWNORMAL);

		DeleteDC(dc);
		dc=GetDC(splash);

		memdc=CreateCompatibleDC(dc);
		SelectObject(memdc, bitmap);

		res=LoadResource((HMODULE)GetModuleHandle("pvision.dll"),(HRSRC)FindResource(GetModuleHandle("pvision.dll"),(LPCSTR)IDR_PALETTE,"PALETTE"));
		if(res==NULL) return;

		pal=CreatePalette((LOGPALETTE*) ((int)res+20));
		SelectPalette(dc,pal,FALSE);
		RealizePalette(dc);

		BitBlt(dc, 0,0, bm.bmWidth, bm.bmHeight, memdc, 0, 0, SRCCOPY);
	}

#endif

    TRIFILLP_Init();
	init_sqrt_tab();
	MakeInverseSqrtLookupTable();
    pvReset();
	InitMirrorMesh();

#ifdef WIN32
    // Merci Pierre Larbier
	/* Autorise l'acc�s en �criture � l'int�gralit� des pages allou�es
  pour
     permettre le code automodifi� (correction du pb des .obj MASM qui
     sont
     prot�g�s en �criture) */
  i = -1;
  while(TRUE) {
    VirtualQuery((char*)InitPVisionMN + i*4096, &buffer, sizeof(buffer));
    if (buffer.State != MEM_COMMIT)
        break;
    if ((buffer.Protect != PAGE_READWRITE) && (buffer.Protect !=
    PAGE_NOACCESS))
	VirtualProtect((char*)InitPVisionMN +
        i*4096,1,PAGE_READWRITE,&AncienStatus);
    i = i-1;
  }
  i = 0;
  while(TRUE) {
    VirtualQuery((char*)InitPVisionMN + i*4096, &buffer, sizeof(buffer));
    if (buffer.State != MEM_COMMIT)
        break;
    if ((buffer.Protect != PAGE_READWRITE) && (buffer.Protect !=
    PAGE_NOACCESS))
        VirtualProtect((char*)InitPVisionMN +
        i*4096,1,PAGE_READWRITE,&AncienStatus);
    i = i+1;
  }
#endif

#if defined(__UNIX__) && defined(__386__)

  i=(((int)SetFPU_Near+4095)&(~4095))-4096*100;

  if(mprotect(i,0x8FFFF,PROT_WRITE|PROT_EXEC|PROT_READ))
  {
      perror("System");
      PV_Fatal("mprotect() error",errno);
  }
#endif

#ifdef WIN32
	if(Splash)
	{
		if(!bypass) Sleep(3000);
		UnrealizeObject(pal);
		ReleaseDC(splash,dc);
		DeleteDC(memdc);
		DeleteObject(pal);
		FreeResource(res);
		DestroyWindow(splash);
		SetActiveWindow(old);
	}
	if(conso) FreeConsole();	
#endif

	// Init hints
	Hint.FogRange=0;
}

static void FreeSBuffer(void)
{
    unsigned i;

    // Desallocation de l ancien SBuffer
    if(SBufferNbrBlocksAllocated!=0)
    {
        for(i=0;i<SBufferNbrBlocksAllocated;i++) if(SBufferBlocks[i]!=NULL) free(SBufferBlocks[i]);
        free(SBufferBlocks);
        SBufferBlocks=NULL;
    }
    SBufferNbrBlocksAllocated=0;
    free(SBuffer);
    SBuffer=NULL;
    SBufferSize=0;
}

static int SetupSBuffer(unsigned minx, unsigned maxx, unsigned miny, unsigned maxy)
{
    unsigned i,b;

    FreeSBuffer();

    // Calcul de la taille maxi du SBuffer pour cette taille de fenetre, tablo des blocs
    b=(((maxx-minx+1)*(maxy-miny+1))/(2*SBUFFER_BLOCK_SEG));
    if ((SBufferBlocks=(TSBuffer **)malloc(sizeof(TSBuffer*)*b))==NULL) return NO_MEMORY;
    SBufferNbrBlocksAllocated=b;
    for(i=0;i<b;i++) SBufferBlocks[i]=NULL;

    // Allocation du SBuffer
    b=(maxy-miny+1);
    if ((SBuffer=(TSBuffer **)malloc(sizeof(TSBuffer*)*(maxy-miny+1)))==NULL) return NO_MEMORY;
    SBufferSize=b;
    for(i=0;i<b;i++) SBuffer[i]=NULL;
    SBufferCurrentBlock=0;
    SBufferN=SBUFFER_BLOCK_SEG;

    return COOL;
}

extern float *ZBuffer; // pork !
extern UPVD8 *__MBTmpBuf;

static void GarbageCollectRecurse(PVMesh *m)
{
	PVMesh *o=m;

	while(o!=NULL)
    {
        free(o->VertexVisible);
        o->VertexVisible=NULL;

		GarbageCollectRecurse(o->Child);

        o=o->Next;
    }

}
void PVAPI PV_GarbageCollector(PVWorld *w)
{
	debug(printf("� Freeing SBuffer\n"););
    FreeSBuffer();
    free(ZBuffer);
    ZBuffer=NULL;

	free(__MBTmpBuf);
	__MBTmpBuf;

    if(w!=NULL)
    {
		debug(printf("� Freeing WV\n"););
        free(w->Visible);
        w->Visible=NULL;
		GarbageCollectRecurse(w->Objs);
    }
}

int PVAPI PV_SetMode(PVFLAGS mode)
{
    unsigned tot=0;

	if(((mode&(PVM_RGB|PVM_RGB16|PVM_PALETIZED8))&(-(mode&(PVM_RGB|PVM_RGB16|PVM_PALETIZED8))))!=(mode&(PVM_RGB|PVM_RGB16|PVM_PALETIZED8))) return ARG_INVALID;

    if((mode&(~(PVM_SHADOWS|PVM_ALPHABLENDING|PVM_ALPHATESTING|PVM_SBUFFER|PVM_BILINEAR|PVM_TRILINEAR|PVM_MIPMAPPING|PVM_ZBUFFER|PVM_RGB|PVM_RGB16|PVM_PALETIZED8|PVM_USEHARDWARE|PVM_VERTEXFOGGING|PVM_STENCILBUFFER)))) return ARG_INVALID;

    if(mode&PVM_USEHARDWARE)
	{
		// En moide acelera passe automatikement en RGB
        if(PV_GetHardwareDriver()==NULL) return NO_HARDWARE_SET;
		REMOVEFLAG(mode,PVM_PALETIZED8);
		REMOVEFLAG(mode,PVM_RGB16);
		ADDFLAG(mode,PVM_RGB);
		PV_SetRGBIndexingMode(8,8,8,0,8,16,0);
	}

	if(mode&PVM_PALETIZED8)
    {
        PixelSize=1;
    }

	PV_Mode=mode;
	
    return PV_SetClipLimit(ClipMinX,ClipMaxX,ClipMinY,ClipMaxY,ScanLength);
}

int PVAPI PV_SetPipelineControl(PVFLAGS mode)
{
	if(mode&(~(PVP_DISABLELIGHTING|PVP_DISABLESORTING|PVP_DISABLETRANSFORM|PVP_NO_ZBUFFERCLEAR|PVP_NO_TRIANGULATE|PVP_COMPUTEFOGVALUES|PVP_NO_STENCILCLEAR|PVP_HARDWARETL))) return ARG_INVALID;

	PV_PipelineControl=mode;

	return COOL;
}

PVFLAGS PVAPI PV_GetPipelineControl()
{
	return PV_PipelineControl;
}

PVFLAGS PVAPI PV_GetMode()
{
	return PV_Mode;
}

int PVAPI PV_SetClipLimit(unsigned int minx,unsigned int maxx, unsigned int miny, unsigned int maxy, unsigned int ScanLine)
{
    unsigned b;

    if(ClipMaxX<=ClipMinX) return ARG_INVALID;
    if(ClipMaxY<=ClipMinY) return ARG_INVALID;
    if((ClipMinX<0)||(ClipMaxX<0)||(ClipMaxY<0)||(ClipMinY<0)) return ARG_INVALID;
    if(ScanLine<=0) return ARG_INVALID;
    ClipMinX=minx;
    ClipMaxX=maxx;
    ClipMinY=miny;
    ClipMaxY=maxy;
    ScanLength=ScanLine;

    if((PV_Mode&PVM_SBUFFER)&&(!(PV_Mode&PVM_USEHARDWARE)))
    {
        if((b=SetupSBuffer(minx,maxx,miny,maxy))!=COOL) return b;
    }

    // ZBuffer
    free(ZBuffer);
    ZBuffer=NULL;
    if((PV_Mode&PVM_ZBUFFER)&&(!(PV_Mode&PVM_USEHARDWARE)))
    {
        ZBuffer=(float*)malloc(((maxx-minx+1)*(maxy-miny+1)+1)*sizeof(float));
        if(ZBuffer==NULL) return NO_MEMORY;
		PV_ClearZBuffer();
    }

	if(PV_Mode&PVM_USEHARDWARE)
        if(PV_GetHardwareDriver()!=NULL)
            return PV_GetHardwareDriver()->SetViewPort(ClipMinX,ClipMaxX,ClipMinY,ClipMaxY);
        else
            return NO_HARDWARE_SET;

    return COOL;
}

/***************************************************************************/
/*                                  ROUTINE 3D                             */
/***************************************************************************/
//----------------------------------- Projections
static void ProjectPoint(PVPoint *src,float invertz,PVScreenPoint *dest)
{
    dest->InvertZ=invertz;
	dest->xf=(src->xf*CurrentCam->W)*(-invertz)+CurrentCam->CenterX;
	dest->yf=(src->yf*CurrentCam->H)*(-invertz)+CurrentCam->CenterY;
}

static void ComputeObjFinalMatrix(PVMesh *o);
void PVAPI PV_TransformPointLikeMesh(PVPoint *src,PVMesh *m,PVCam *c,PVPoint *rotated,PVScreenPoint *dest)
{
	PVCam *oldcam;
	double z;

	if(src==NULL) return;	
	if(m==NULL) return;
	if(c==NULL) return;
	if(rotated==NULL) return;	
	
	oldcam=CurrentCam;
	CurrentCam=c;

	ComputeObjFinalMatrix(m);

	RotatePoint3x3(src,FinalMatrix,rotated);
    rotated->xf+=FinalTrans.xf;
    rotated->yf+=FinalTrans.yf;
    z=rotated->zf+=FinalTrans.zf;

    if(dest!=NULL) ProjectPoint(rotated,1/z,dest);
	
	CurrentCam=oldcam;
}

/***************************************************************************/
/*                          GESTION CAMERA & PLACEMENT OBJETS              */
/***************************************************************************/

static void ComputeObjFinalMatrix(PVMesh *o)
{
	PVMat3x3 m,m2;
	PVPoint C,A;
	
	PV_ComputeMeshToWorldMatrix(o);

	memcpy(m,o->WorldMatrix,sizeof(PVMat3x3));
    m[0][0]*=o->ScaleX;
    m[1][0]*=o->ScaleX;
    m[2][0]*=o->ScaleX;
    m[0][1]*=o->ScaleY;
    m[1][1]*=o->ScaleY;
    m[2][1]*=o->ScaleY;
    m[0][2]*=o->ScaleZ;
    m[1][2]*=o->ScaleZ;
    m[2][2]*=o->ScaleZ;
	memcpy(o->WorldMatrixScaled,m,sizeof(PVMat3x3));
    MatrixMul(CurrentCam->Matrix,m,FinalMatrix);

	MatrixMul(CurrentCam->Matrix,o->WorldMatrix,m2);
	C=o->WorldPos;
	A.xf=o->Pivot.xf-CurrentCam->pos.xf+C.xf;
    A.yf=o->Pivot.yf-CurrentCam->pos.yf+C.yf;
    A.zf=o->Pivot.zf-CurrentCam->pos.zf+C.zf;
    RotatePoint3x3(&A,CurrentCam->Matrix,&FinalTrans);
    RotatePoint3x3(&o->Pivot,m2,&A);
	FinalTrans.xf-=A.xf;
	FinalTrans.yf-=A.yf;
	FinalTrans.zf-=A.zf;
}

/***************************************************************************/
/*                            ambient                                      */
/***************************************************************************/

static void CreateambientCoordinates(PVVertex *v,PVMapInfo *s)
{
    PVPoint a;

    // On transforme la normales du pts comme l objet
    RotatePoint3x3(&v->Normal,FinalMatrix,&a);
    if(v->Flags&AMBIENT_MAPPING)
    {
        s->u=a.xf*0.5+0.5;
        s->v=a.yf*0.5+0.5;
    }
    if(v->Flags&(PHONG|U_PHONG|BUMP|U_BUMP))
    {
        s->AmbientU=a.xf*0.5+0.5;
        s->AmbientV=a.yf*0.5+0.5;
    }
}

/***************************************************************************/
/*                             BACKFACE & Transformations                  */
/***************************************************************************/
///////////////////////////////////////////////////////////////////////////
//////////// Frustum CLIP
///////////////////////////////////////////////////////////////////////////

#define CLIP_PLANE_EPSILON  0.0001

static PVPlane Frustum[6+(32-MAX_USER_CLIPPLANES-6)];
static unsigned NbrSpecialPlanes;

int PVAPI PV_GetNbrFreeSpecialClipPlanes(void)
{
    return 32-(6+MAX_USER_CLIPPLANES+NbrSpecialPlanes);
}

void PVAPI PV_FreeLastClipPlane(void)
{
    if(NbrSpecialPlanes==0) return;
    NbrSpecialPlanes--;
}

void PVAPI PV_FreeAllClipPlanes(void)
{
    NbrSpecialPlanes=0;
}

unsigned PVAPI PV_GetNbrClipPlanes(void)
{
    return NbrSpecialPlanes;
}

void PVAPI PV_SetNbrClipPlanes(unsigned nbr)
{
    NbrSpecialPlanes=nbr;
}

PVPlane *PVAPI PV_AllocClipPlanes(unsigned n)
{
    PVPlane *r;

    if((NbrSpecialPlanes+n+6+MAX_USER_CLIPPLANES)>=32) return NULL;
    r=&Frustum[6+NbrSpecialPlanes];
    NbrSpecialPlanes+=n;
    return r;
}

void PVAPI PV_SetPlane(PVPlane *plane,double position,PVPoint *normal)
{
    if(plane==NULL) return;
    if(normal==NULL) return;

    plane->d=position+CLIP_PLANE_EPSILON;
    plane->Normal=*normal;
}

static void PV_SetFrustum(PVCam *c,PVMat3x3 WorldView,PVPoint *trans,unsigned noback)
{
    double  angle, s, co;
    PVPoint   normal,normal2,posc,pos;

    posc.xf=trans->xf;
    posc.yf=trans->yf;
    posc.zf=trans->zf;

    angle = atan(2.0 / c->fieldofview * c->fscale / c->xscreenscale);
    s = sin(angle);
    co = cos(angle);

    // Left clip plane
    normal.xf = s;
    normal.yf = 0;
    normal.zf = co;
    RotateInvertPoint(&normal,WorldView,&normal2);
    PV_SetPlane(&Frustum[0],posc.xf*normal2.xf+posc.yf*normal2.yf+posc.zf*normal2.zf,&normal2);

    // Right clip plane
    normal.xf = -s;
    RotateInvertPoint(&normal,WorldView,&normal2);
    PV_SetPlane(&Frustum[1],posc.xf*normal2.xf+posc.yf*normal2.yf+posc.zf*normal2.zf,&normal2);

    angle = atan(2.0 /c-> fieldofview * c->fscale / c->yscreenscale);
    s = sin(angle);
    co = cos(angle);

    // Bottom clip plane
    normal.xf = 0;
    normal.yf = s;
    normal.zf = co;
    RotateInvertPoint(&normal,WorldView,&normal2);
    PV_SetPlane(&Frustum[2],posc.xf*normal2.xf+posc.yf*normal2.yf+posc.zf*normal2.zf,&normal2);

    // Top clip plane
    normal.yf = -s;
    RotateInvertPoint(&normal,WorldView,&normal2);
    PV_SetPlane(&Frustum[3],posc.xf*normal2.xf+posc.yf*normal2.yf+posc.zf*normal2.zf,&normal2);

    // Front clip Plane
    normal.xf = 0;
    normal.yf = 0;
    normal.zf = 1;
    RotateInvertPoint(&normal,WorldView,&normal2);

    pos.xf=normal2.xf*c->FrontDist;
    pos.yf=normal2.yf*c->FrontDist;
    pos.zf=normal2.zf*c->FrontDist;

    posc.xf=trans->xf;
    posc.yf=trans->yf;
    posc.zf=trans->zf;

    posc.xf-=pos.xf;
    posc.yf-=pos.yf;
    posc.zf-=pos.zf;

    PV_SetPlane(&Frustum[4],posc.xf*normal2.xf+posc.yf*normal2.yf+posc.zf*normal2.zf,&normal2);

    // back clip Plane
	if(noback)
	{
		PVPoint nul={0,0,0};

		PV_SetPlane(&Frustum[5],1,&nul);
	}
	else
	{
		normal.xf = 0;
		normal.yf = 0;
		normal.zf = -1;
		RotateInvertPoint(&normal,WorldView,&normal2);

		pos.xf=normal2.xf*c->BackDist;
		pos.yf=normal2.yf*c->BackDist;
		pos.zf=normal2.zf*c->BackDist;

		posc.xf=trans->xf;
		posc.yf=trans->yf;
		posc.zf=trans->zf;

		posc.xf+=pos.xf;
		posc.yf+=pos.yf;
		posc.zf+=pos.zf;

		PV_SetPlane(&Frustum[5],posc.xf*normal2.xf+posc.yf*normal2.yf+posc.zf*normal2.zf,&normal2);
	}
}

static void PV_SetUserFrustum(PVCam *c,PVMat3x3 WorldView)
{
    unsigned i;
    PVPoint normal2,posc,tx2;
	PVUserPlane *up;
	char *upe;

    // On s'occupe des plans utilisateurs
    for(i=0,up=&c->UserPlanes[0],upe=&c->UserPlanesEnabled[0];i<MAX_USER_CLIPPLANES;i++,up++,upe++)
    {
		if(*upe)
        {
			if(c->Flags&CAMERA_FIXED_USER_CLIP_PLANES)
			{
				normal2=up->Normal;
				posc=up->Pos;
			}
			else
			{
				RotateInvertPoint(&up->Normal,WorldView,&normal2);
				RotateInvertPoint(&up->Pos,WorldView,&tx2);

				posc.xf=InvertCamPos.xf+tx2.xf;
				posc.yf=InvertCamPos.yf+tx2.yf;
				posc.zf=InvertCamPos.zf+tx2.zf;
			}

			PV_SetPlane(&up->Plane,posc.xf*normal2.xf+posc.yf*normal2.yf+posc.zf*normal2.zf,&normal2);
        }
    }
}

static int SetVertexFlag(PVVertex *v,PVFLAGS boxor)
{
    double dot;
    unsigned i;
	PVPlane *frust;
	char *upe;
	PVUserPlane *up;

    // On classifie le PVPoint donn�
    // par rapport aux 6 plans de Frustum
    v->FrustumFlags=0;
    for (i=0,frust=&Frustum[0];i<6+NbrSpecialPlanes;i++,frust++)
    {		
		if(boxor&(1<<i))
		{
			dot=v->xf*frust->Normal.xf+v->yf*frust->Normal.yf+v->zf*frust->Normal.zf;
			if ((dot>frust->d)) v->FrustumFlags|=(1<<i);
		}
    }

    for(i=0,up=&CurrentCam->UserPlanes[0],upe=&CurrentCam->UserPlanesEnabled[0];i<MAX_USER_CLIPPLANES;i++,up++,upe++)
    {
        if(*upe)
        {
            if(boxor&(1<<(i+6+NbrSpecialPlanes)))
			{
				dot=v->xf*up->Plane.Normal.xf+v->yf*up->Plane.Normal.yf+v->zf*up->Plane.Normal.zf;
				if ((dot>up->Plane.d)) v->FrustumFlags|=(1<<(i+6+NbrSpecialPlanes));
			}
        }
    }

    return v->FrustumFlags;
}

int PVAPI PV_GetFrustumFlags(PVPoint *v)
{
    double dot;
    unsigned i,FrustumFlags;
	PVPlane *frust;
	char *upe;
	PVUserPlane *up;

    // On classifie le PVPoint donn�
    // par rapport aux 6 plans de Frustum
    FrustumFlags=0;
    for (i=0,frust=&Frustum[0];i<6+NbrSpecialPlanes;i++,frust++)
    {
		dot=v->xf*frust->Normal.xf+v->yf*frust->Normal.yf+v->zf*frust->Normal.zf;
        if ((dot>frust->d)) FrustumFlags|=(1<<i);
    }

    for(i=0,up=&CurrentCam->UserPlanes[0],upe=&CurrentCam->UserPlanesEnabled[0];i<MAX_USER_CLIPPLANES;i++,up++,upe++)
    {
        if(*upe)
        {
            dot=v->xf*up->Plane.Normal.xf+v->yf*up->Plane.Normal.yf+v->zf*up->Plane.Normal.zf;
            if ((dot>up->Plane.d)) FrustumFlags|=(1<<(i+6+NbrSpecialPlanes));
        }
    }

    return FrustumFlags;
}

#define CLIPUV  1
#define CLIPAUV 2
#define CLIPS   4
#define CLIPS2  8

void PVAPI PV_PrepareFace(PVFace *f)
{
    float maxu,minu,d;
    unsigned i;
    PVMesh *o=f->Father;

    static float u[MAX_VERTICES_PER_POLY],v[MAX_VERTICES_PER_POLY];
    static unsigned n[MAX_VERTICES_PER_POLY];
    static unsigned flags=0;

	unsigned *pn;
	float *pu,*pv,cu;
    PVMapInfo *pmap,*pmap2;
    PVVertex *pvtx;
    PVMaterial *mat;
    float sb[4],tb[4],oow,ooh;

	if(!((o->NbrMapIndex>o->NbrVertices)||(f->Flags&(TEXTURE_BASIS|U_WRAP|V_WRAP))))
		return;

    if(flags)
    {
        if (flags&1) for(i=0,pn=n,pu=u;i<f->NbrVertices;i++,pn++,pu++) o->Mapping[*pn].u=*pu;

        if (flags&2) for(i=0,pn=n,pv=v;i<f->NbrVertices;i++,pn++,pv++) o->Mapping[*pn].v=*pv;

        flags=0;
        return;
    }

    memcpy(n,f->V,sizeof(unsigned)*f->NbrVertices);

	if(o->NbrMapIndex>o->NbrVertices)
	{
		// PerFace Mapping
		flags=4;

        for(i=0,pn=n,pu=u,pv=v;i<f->NbrVertices;i++,pn++,pu++,pv++)
        {
            pmap=&o->Mapping[*pn];

            pmap2=&o->Mapping[o->NbrVertices+o->MaxNbrClippedVertices+f->MapInfos.MapIndex+i];
			pmap->u=pmap2->u;
			pmap->v=pmap2->v;
        }
	}

    // Gestion des textures par bases
    if(f->Flags&TEXTURE_BASIS)
    {
        if((f->MapInfos.TexBasis!=NULL)&&(f->MaterialInfo!=NULL))
        {
            mat=f->MaterialInfo;
            flags|=1+2;

            // Genere U,V et sauve en meme temps
            oow=1/(float)mat->Tex[0].Width;
            ooh=1/(float)mat->Tex[0].Height;

            sb[0]=f->MapInfos.TexBasis->SBasis[0]*oow;
            sb[1]=f->MapInfos.TexBasis->SBasis[1]*oow;
            sb[2]=f->MapInfos.TexBasis->SBasis[2]*oow;
            sb[3]=f->MapInfos.TexBasis->SBasis[3]*oow;

            tb[0]=f->MapInfos.TexBasis->TBasis[0]*ooh;
            tb[1]=f->MapInfos.TexBasis->TBasis[1]*ooh;
            tb[2]=f->MapInfos.TexBasis->TBasis[2]*ooh;
            tb[3]=f->MapInfos.TexBasis->TBasis[3]*ooh;

            for(i=0,pn=n,pu=u,pv=v;i<f->NbrVertices;i++,pn++,pu++,pv++)
            {
                pvtx=&o->Vertex[*pn];
                pmap=&o->Mapping[*pn];

                *pu=pmap->u;
                *pv=pmap->v;

                pmap->u=pvtx->xf*sb[0]+pvtx->yf*sb[1]+
                                   pvtx->zf*sb[2]+sb[3];
                pmap->v=pvtx->xf*tb[0]+pvtx->yf*tb[1]+
                                   pvtx->zf*tb[2]+tb[3];
            }
        }
    }

    // Gestion du Wrapping de texture en direct de Autodesk
    // u
    if(f->Flags&U_WRAP)
    {
        flags|=16;
        maxu=minu=o->Mapping[n[0]].u;
		for(i=1,pn=&n[1];i<f->NbrVertices;i++,pn++)
		{
			cu=o->Mapping[*pn].u;
			if(cu>maxu) maxu=cu;
			else if(cu<minu) minu=cu;
		}

        if((d=maxu-minu)>(0.8))
        {
            flags|=1;

            d=ceil(d);
            for(i=0,pn=n,pu=u;i<f->NbrVertices;i++,pn++,pu++)
			{
                *pu=o->Mapping[*pn].u;
                if(o->Mapping[*pn].u<0.5) o->Mapping[*pn].u+=d;;
			}
        }
    }

    // v
	if(f->Flags&V_WRAP)
    {
        flags|=16;
        maxu=minu=o->Mapping[n[0]].v;
		for(i=1,pn=&n[1];i<f->NbrVertices;i++,pn++)
		{
			cu=o->Mapping[*pn].v;
			if(cu>maxu) maxu=cu;
			else if(cu<minu) minu=cu;
		}

        if((d=maxu-minu)>(0.8))
        {
            flags|=2;

            d=ceil(d);
            for(i=0,pn=n,pv=v;i<f->NbrVertices;i++,pn++,pv++)
			{
                *pv=o->Mapping[*pn].v;
                if(o->Mapping[*pn].v<0.5) o->Mapping[*pn].v+=d;;
			}
        }
    }
}

static int ClipFaceAgainstPlane(PVFace *f,PVPlane *p)
{
    PVMesh *o=f->Father;
    PVPoly *po=f->Poly,newpoly;
    unsigned i,curver,nextvert,curin,nextin,flags,n1,n2;
    double curdot,nextdot,scale;

	PVVertex *pvtx,*pvtx1,*pvtx2;
	PVShadeInfo *pshad,*pshad1,*pshad2;
	PVMapInfo *pmap,*pmap1,*pmap2;

    if(po==NULL) return 0;
    if(p==NULL) return 0;
    if(po->NbrVertices<3) return 0;

    newpoly.NbrVertices=0;

    pvtx=&o->Vertex[po->Vertices[0]];
	curdot=pvtx->xf*p->Normal.xf+pvtx->yf*p->Normal.yf+pvtx->zf*p->Normal.zf;
    curin=(curdot<=p->d);
    curver=0;

    for(i=0;i<po->NbrVertices;i++)
    {
        nextvert=(i+1);
        if(nextvert>po->NbrVertices-1) nextvert=0;

        if(curin) newpoly.Vertices[newpoly.NbrVertices++]=po->Vertices[curver];

        n2=po->Vertices[nextvert];
		pvtx=&o->Vertex[n2];
        nextdot=pvtx->xf*p->Normal.xf+pvtx->yf*p->Normal.yf+pvtx->zf*p->Normal.zf;
        nextin = (nextdot<=p->d);

        if (curin != nextin)
        {
            scale = (p->d - curdot) /
                    (nextdot - curdot);

            // Cr�e un PVPoint interm�diarie
            if(o->nbrclipv>=o->MaxNbrClippedVertices) return 0;
            if(newpoly.NbrVertices>=MAX_VERTICES_PER_POLY*2) return 0;

            n1=po->Vertices[curver];

			pvtx=&o->Vertex[o->NbrVertices+o->nbrclipv];
			pvtx1=&o->Vertex[n1];
			pvtx2=&o->Vertex[n2];
            pvtx->xf=pvtx1->xf+((pvtx2->xf-pvtx1->xf)*scale);
            pvtx->yf=pvtx1->yf+((pvtx2->yf-pvtx1->yf)*scale);
            pvtx->zf=pvtx1->zf+((pvtx2->zf-pvtx1->zf)*scale);

            newpoly.Vertices[newpoly.NbrVertices++]=o->nbrclipv+o->NbrVertices;

            // Clip Les interpolants
            // S�l�ction des interpolants � clipper
            flags=0;
            switch((f->Flags&RENDER_MASK)&(~PERSPECTIVE))
            {
				case MULTITEXTURE|MAPPING:
				case MULTITEXTURE:
				case MAPPING:
                case AMBIENT_MAPPING:
                    flags|=CLIPUV;
                    break;
            }

            switch(f->Flags&SHADE_MASK)
            {
                case GOURAUD:				
                    flags|=CLIPS;
                    break;

                case PHONG:
                case BUMP:
                case U_PHONG:
                case U_BUMP:
                    flags|=(CLIPAUV|CLIPUV);
                    break;
            }

			// Hint 
			if((PV_PipelineControl&PVP_COMPUTEFOGVALUES)&&(o->Shading!=NULL)&&(f->Flags&FOGABLE)) flags|=CLIPS2;			

            // Clip!
            if(flags&CLIPS)
            {
                pshad=&o->Shading[o->NbrVertices+o->nbrclipv];
				pshad1=&o->Shading[n1];
				pshad2=&o->Shading[n2];
				pshad->Shade=(double)pshad1->Shade+(((double)pshad2->Shade-(double)pshad1->Shade)*scale);
                pshad->Color.r=pshad1->Color.r+((pshad2->Color.r-pshad1->Color.r)*scale);
                pshad->Color.g=pshad1->Color.g+((pshad2->Color.g-pshad1->Color.g)*scale);
                pshad->Color.b=pshad1->Color.b+((pshad2->Color.b-pshad1->Color.b)*scale);
				pshad->Color.a=pshad1->Color.a+((pshad2->Color.a-pshad1->Color.a)*scale);				
            }
			
			if(flags&CLIPS2)
            {
				if(!(flags&CLIPS))
				{
					pshad=&o->Shading[o->NbrVertices+o->nbrclipv];
					pshad1=&o->Shading[n1];
					pshad2=&o->Shading[n2];	
				}
				/*pshad->Specular.r=pshad1->Specular.r+((pshad2->Specular.r-pshad1->Specular.r)*scale);
                pshad->Specular.g=pshad1->Specular.g+((pshad2->Specular.g-pshad1->Specular.g)*scale);
                pshad->Specular.b=pshad1->Specular.b+((pshad2->Specular.b-pshad1->Specular.b)*scale);*/
				pshad->Specular.a=pshad1->Specular.a+((pshad2->Specular.a-pshad1->Specular.a)*scale);
			}

            if(flags&CLIPUV)
            {
                pmap=&o->Mapping[o->NbrVertices+o->nbrclipv];
				pmap1=&o->Mapping[n1];
				pmap2=&o->Mapping[n2];
				pmap->u=pmap1->u+((pmap2->u-pmap1->u)*scale);
                pmap->v=pmap1->v+((pmap2->v-pmap1->v)*scale);
            }

            if(flags&CLIPAUV)
            {
                pmap=&o->Mapping[o->NbrVertices+o->nbrclipv];
				pmap1=&o->Mapping[n1];
				pmap2=&o->Mapping[n2];
                pmap->AmbientU=pmap1->AmbientU+((pmap2->AmbientU-pmap1->AmbientU)*scale);
                pmap->AmbientV=pmap1->AmbientV+((pmap2->AmbientV-pmap1->AmbientV)*scale);
            }

            o->nbrclipv++;
        }

        curdot = nextdot;
        curin = nextin;
        curver=nextvert;
    }

    if(newpoly.NbrVertices<3) return 0;

    memcpy(f->Poly,&newpoly,sizeof(PVPoly));

    return 1;
}

static int ClipFaceAgainstFrustum(PVFace *f)
{
    unsigned i,a=1;

	PVPlane *frust;
	PVUserPlane *up;
	char *upe;
	PVFLAGS OrCod;

    PV_PrepareFace(f);

	// Calcul du flag or
	OrCod=0;
	for(i=0;i<f->NbrVertices;i++) OrCod|=f->Father->Vertex[f->V[i]].FrustumFlags;

	for(i=0,frust=&Frustum[0];i<6+NbrSpecialPlanes;i++,frust++)
    {
		if(OrCod&(1<<i))
		if(!ClipFaceAgainstPlane(f,frust))
		{
			a=0;
			break;
		}
    }

    if(a)
	for(i=0,up=&CurrentCam->UserPlanes[0],upe=&CurrentCam->UserPlanesEnabled[0];i<MAX_USER_CLIPPLANES;i++,up++,upe++)
    {
        if(*upe)
        {
            if(OrCod&(1<<(i+6+NbrSpecialPlanes)))
			if(!ClipFaceAgainstPlane(f,&up->Plane))
			{
				a=0;
				break;
			}
        }
    }

	PV_PrepareFace(f);

    return a;
}

///////////////////////////// la c un tantinet pork parce ke c'est exactment
///////////////////////////// la meme routine ke ci-dessus mais pour les polys
///////////////////////////// c utiliser dans les mirrors

static int ClipPolyAgainstPlane(PVPoly *po,PVPoint vtx[],unsigned *curclippt,unsigned maxvertx,PVPlane *p)
{
    PVPoly newpoly;
    unsigned i,curver,nextvert,curin,nextin,n1,n2,curclip=*curclippt;
    double curdot,nextdot,scale;

    if(po==NULL) return 0;
    if(p==NULL) return 0;
    if(po->NbrVertices<3) return 0;

    newpoly.NbrVertices=0;

    curdot=vtx[po->Vertices[0]].xf*p->Normal.xf+vtx[po->Vertices[0]].yf*p->Normal.yf+vtx[po->Vertices[0]].zf*p->Normal.zf;
    curin=(curdot<=p->d);
    curver=0;

    for(i=0;i<po->NbrVertices;i++)
    {
        nextvert=(i+1);
        if(nextvert>po->NbrVertices-1) nextvert=0;

        if(curin) newpoly.Vertices[newpoly.NbrVertices++]=po->Vertices[curver];

        n2=po->Vertices[nextvert];
        nextdot=vtx[n2].xf*p->Normal.xf+vtx[n2].yf*p->Normal.yf+vtx[n2].zf*p->Normal.zf;
        nextin = (nextdot<=p->d);

        if (curin != nextin)
        {
            scale = (p->d - curdot) /
                    (nextdot - curdot);

            // Cr�e un PVPoint interm�diarie
            if(curclip>=maxvertx) return 0;
            if(newpoly.NbrVertices>=MAX_VERTICES_PER_POLY*2) return 0;

            n1=po->Vertices[curver];
            n2=po->Vertices[nextvert];
            vtx[po->NbrVertices+curclip].xf=vtx[n1].xf+((vtx[n2].xf-vtx[n1].xf)*scale);
            vtx[po->NbrVertices+curclip].yf=vtx[n1].yf+((vtx[n2].yf-vtx[n1].yf)*scale);
            vtx[po->NbrVertices+curclip].zf=vtx[n1].zf+((vtx[n2].zf-vtx[n1].zf)*scale);

            newpoly.Vertices[newpoly.NbrVertices++]=curclip+po->NbrVertices;

            curclip++;
        }

        curdot = nextdot;
        curin = nextin;
        curver=nextvert;
    }

    if(newpoly.NbrVertices<3) return 0;

    memcpy(po,&newpoly,sizeof(PVPoly));

    *curclippt=curclip;

    return 1;
}

static int ClipPolyAgainstFrustum(PVPoly *f,PVPoint vtx[],unsigned *curclip,unsigned maxvrtx)
{
    unsigned i;

    for(i=0;i<6+NbrSpecialPlanes;i++)
    {        
		if(!ClipPolyAgainstPlane(f,vtx,curclip,maxvrtx,&Frustum[i])) return 0;
    }

    for(i=0;i<MAX_USER_CLIPPLANES;i++)
    {
        if(CurrentCam->UserPlanesEnabled[i])
        {
            if(!ClipPolyAgainstPlane(f,vtx,curclip,maxvrtx,&CurrentCam->UserPlanes[i].Plane)) return 0;
        }
    }

    return 1;
}

/////////////////////////////////////////////////////////////////////////

int PVAPI PV_ClipFaceToFrustum(PVFace *f)
{
    PVMesh *o=f->Father;
    PVVertex *ov2;
    PVPoint p,*or;
    unsigned OrCod,AndCod,j,n,Cod,*vtr,cindex;
    float z;

    if(PV_PipelineControl&PVP_HARDWARETL) return 1;
	
	// Face non cullable 
    OrCod=0;
    AndCod=0xffffffff;
    for(j=0,vtr=f->V;j<f->NbrVertices;j++,vtr++)
    {
        n=*vtr;
        if(o->VertexVisible[n]==0)
        {
            o->VertexVisible[n]=1;

            // Nouvo PVPoint
            // On calcul les codes de ce PVPoint
            Cod=SetVertexFlag(&o->Vertex[n],0xFFFFFFFF);

            if((!Cod)&&(!(PV_PipelineControl&PVP_DISABLETRANSFORM)))
            {
                // Transforme le PVPoint
                // Il est dans la pyramide
                ov2=&o->Vertex[n];
                p.xf=ov2->xf;
                p.yf=ov2->yf;
                p.zf=ov2->zf;
                RotatePoint3x3(&p,FinalMatrix,or=&o->Rotated[n]);
                or->xf+=FinalTrans.xf;
                or->yf+=FinalTrans.yf;
                z=or->zf+=FinalTrans.zf;

                ProjectPoint(or,1/z,&o->Projected[n]);
            }

            // Dans tout les cas calcul l'ambiance
            if(o->Vertex[n].Flags&(AMBIENT_MAPPING|PHONG|U_PHONG|BUMP|U_BUMP)) CreateambientCoordinates(&o->Vertex[n],&o->Mapping[n]);
        }
        else Cod=o->Vertex[n].FrustumFlags;

        OrCod|=Cod;
        AndCod&=Cod;
    }

    // Brutal Clip
	if(o->Flags&MESH_BRUTAL_CLIP)
	{
		if(OrCod&(1<<5)) return 0;
	}
	
	// On v�rifie si la face est completement dans le Frustum
    // ou completement out du Frustum	
	if(AndCod) return 0;          // Totalement dehors

    f->Poly=NULL;
	cindex=f-o->Face;
	o->FaceInfos[cindex].Poly=NULL;

    if(OrCod)
    {
        // La face est a cheval, on va la clippe
		// on Cr�e le polygone equivalent
		if(o->SwitchVal.NbrPolys>=o->MaxNbrClippedFaces) return 0;

		f->Poly=&o->Polys[o->SwitchVal.NbrPolys++];
		f->Poly->NbrVertices=f->NbrVertices;
		memcpy(f->Poly->Vertices,f->V,sizeof(unsigned)*f->NbrVertices);

		o->FaceInfos[cindex].Poly=f->Poly;
		return 2;
    }
    return 1;
}

static void PrepareBox(PVBox *b,PVMesh *o)
{
    unsigned m,i,j,*fi,AndCod,OrCod,Cod,n;
    PVPoint VP2,*VP3,p,*or;
    float z;
    PVVertex *ov2,*ov;
    PVFace *f;
	PVPoly **tmp;

    for(i=0,fi=&b->FaceIndex[0];i<b->NbrFaces;i++,fi++)
    {
        m=*fi;

		// Cacul du vecteur vision
		// uniquement si face non 'double sided)
		f=&o->Face[m];
		if(f->MaterialInfo==NULL) continue;    // sanity check
        ov=&o->Vertex[f->V[0]];

		if(!(f->MaterialInfo->Type&DOUBLE_SIDED))
		{
			VP2.xf=InvertCamPos.xf-ov->xf*o->ScaleX;
			VP2.yf=InvertCamPos.yf-ov->yf*o->ScaleY;
			VP2.zf=InvertCamPos.zf-ov->zf*o->ScaleZ;

			VP3=&f->Normal;
		}

        if((f->MaterialInfo->Type&DOUBLE_SIDED)||(((VP3->xf*o->ScaleZ*o->ScaleY*VP2.xf)+(VP3->yf*o->ScaleZ*o->ScaleX*VP2.yf)+(VP3->zf*o->ScaleX*o->ScaleY*VP2.zf))>0))
        {
            // Face non cullable
            OrCod=0;
            AndCod=0xffffffff;
            for(j=0;j<f->NbrVertices;j++)
            {
                n=f->V[j];
                if(o->VertexVisible[n]==0)
                {
                    o->VertexVisible[n]=1;

                    // Nouvo PVPoint
                    // On calcul les codes de ce PVPoint
                    Cod=SetVertexFlag(&o->Vertex[n],o->FrustumFlags);

                    if(!Cod)
                    {
                        // Transforme le PVPoint
                        // Il est dans la pyramide
                        ov2=&o->Vertex[n];
                        p.xf=ov2->xf;
                        p.yf=ov2->yf;
                        p.zf=ov2->zf;
                        RotatePoint3x3(&p,FinalMatrix,or=&o->Rotated[n]);
                        or->xf+=FinalTrans.xf;
                        or->yf+=FinalTrans.yf;
                        z=or->zf+=FinalTrans.zf;

                        ProjectPoint(or,1/z,&o->Projected[n]);
                    }

                    // Dans tout les cas calcul l'ambiance
                    if(o->Vertex[n].Flags&(AMBIENT_MAPPING|PHONG|U_PHONG|BUMP|U_BUMP)) CreateambientCoordinates(&o->Vertex[n],&o->Mapping[n]);
                }
                else Cod=o->Vertex[n].FrustumFlags;

                OrCod|=Cod;
                AndCod&=Cod;
			}

			// Brutal Clip
			if(o->Flags&MESH_BRUTAL_CLIP)
			{
				if(OrCod&(1<<5)) continue;
			}
                			
            // On v�rifie si la face est completement dans le Frustum
            // ou completement out du Frustum
			if(AndCod) continue;          // Totalement dehors

            f->Poly=NULL;
			tmp=&o->FaceInfos[m].Poly;
			*tmp=NULL;

            if(OrCod)
            {
                // La face est a cheval, on va la clippe
				// on Cr�e le polygone equivalent
				if(o->SwitchVal.NbrPolys>=o->MaxNbrClippedFaces) continue;
				
				f->Poly=&o->Polys[o->SwitchVal.NbrPolys++];
				f->Poly->NbrVertices=f->NbrVertices;
				memcpy(f->Poly->Vertices,f->V,sizeof(unsigned)*f->NbrVertices);				
            }
			*tmp=f->Poly;
            // Face visible
            *ovis=f;
            ovis++;
            o->NbrVisibles++;
        }
    }
}

static void PrepareBoxInFrustum(PVBox *b,PVMesh *o)
{
    unsigned m,i,j,*fi,n;
    PVPoint VP2,*VP3,p,*or;
    float z;
    PVVertex *ov2,*ov;
    PVFace *f;

    for(i=0,fi=&b->FaceIndex[0];i<b->NbrFaces;i++,fi++)
    {
        m=*fi;

        // Cacul du vecteur vision
        f=&o->Face[m];
		if(f->MaterialInfo==NULL) continue;    // sanity check
        ov=&o->Vertex[f->V[0]];
		if(!(f->MaterialInfo->Type&DOUBLE_SIDED))
		{
			VP2.xf=InvertCamPos.xf-ov->xf*o->ScaleX;
			VP2.yf=InvertCamPos.yf-ov->yf*o->ScaleY;
			VP2.zf=InvertCamPos.zf-ov->zf*o->ScaleZ;

			VP3=&f->Normal;
		}

        if((f->MaterialInfo->Type&DOUBLE_SIDED)||(((VP3->xf*o->ScaleZ*o->ScaleY*VP2.xf)+(VP3->yf*o->ScaleZ*o->ScaleX*VP2.yf)+(VP3->zf*o->ScaleX*o->ScaleY*VP2.zf))>0))
        {
            // Face non cullable
            for(j=0;j<f->NbrVertices;j++)
            {
                n=f->V[j];

                if(o->VertexVisible[n]==0)
                {
                    o->VertexVisible[n]=1;

                    // Nouvo PVPoint
                    // Transforme le PVPoint
                    // Il est dans la pyramide
                    ov2=&o->Vertex[n];
                    p.xf=ov2->xf;
                    p.yf=ov2->yf;
                    p.zf=ov2->zf;
                    RotatePoint3x3(&p,FinalMatrix,or=&o->Rotated[n]);
                    or->xf+=FinalTrans.xf;
                    or->yf+=FinalTrans.yf;
                    z=or->zf+=FinalTrans.zf;

                    ProjectPoint(or,1/z,&o->Projected[n]);

                    if(o->Vertex[n].Flags&(AMBIENT_MAPPING|PHONG|U_PHONG|BUMP|U_BUMP)) CreateambientCoordinates(&o->Vertex[n],&o->Mapping[n]);
                }
            }

            // Face visible
			f->Poly=NULL;
			*ovis=f;
			ovis++;
			o->NbrVisibles++;
			o->FaceInfos[m].Poly=NULL;
        }
    }
}

static void PrepareBoxWT(PVBox *b,PVMesh *o)
{
    unsigned m,i,j,*fi,AndCod,OrCod,Cod,n;
    PVPoint VP2,*VP3;
    PVFace *f;
    PVVertex *ov;
	PVPoly **tmp;

    for(i=0,fi=&b->FaceIndex[0];i<b->NbrFaces;i++,fi++)
    {
        m=*fi;

        // Cacul du vecteur vision
        f=&o->Face[m];
		if(f->MaterialInfo==NULL) continue;    // sanity check
        ov=&o->Vertex[f->V[0]];
		if(!(f->MaterialInfo->Type&DOUBLE_SIDED))
		{
			VP2.xf=InvertCamPos.xf-ov->xf*o->ScaleX;
			VP2.yf=InvertCamPos.yf-ov->yf*o->ScaleY;
			VP2.zf=InvertCamPos.zf-ov->zf*o->ScaleZ;

			VP3=&f->Normal;
		}

        if((f->MaterialInfo->Type&DOUBLE_SIDED)||(((VP3->xf*o->ScaleZ*o->ScaleY*VP2.xf)+(VP3->yf*o->ScaleZ*o->ScaleX*VP2.yf)+(VP3->zf*o->ScaleX*o->ScaleY*VP2.zf))>0))
        {
            // Face non cullable
            OrCod=0;
            AndCod=0xffffffff;
            for(j=0;j<f->NbrVertices;j++)
            {
                n=f->V[j];

                if(o->VertexVisible[n]==0)
                {
                    o->VertexVisible[n]=1;

                    // Nouvo PVPoint
                    // On calcul les codes de ce PVPoint
                    Cod=SetVertexFlag(&o->Vertex[n],o->FrustumFlags);

                    // Dans tout les cas calcul l'ambiance
                    if(o->Vertex[n].Flags&(AMBIENT_MAPPING|PHONG|U_PHONG|BUMP|U_BUMP)) CreateambientCoordinates(&o->Vertex[n],&o->Mapping[n]);
                }
                else Cod=o->Vertex[n].FrustumFlags;

                OrCod|=Cod;
                AndCod&=Cod;
            }

			// Brutal Clip
			if(o->Flags&MESH_BRUTAL_CLIP)
			{
				if(OrCod&(1<<5)) continue;
			}

            // On v�rifie si la face est completement dans le Frustum
            // ou completement out du Frustum
			if(AndCod) continue;          // Totalement dehors

            f->Poly=NULL;
			tmp=&o->FaceInfos[m].Poly;
			*tmp=NULL;

            if(OrCod)
            {
                // La face est a cheval, on va la clippe
				// on Cr�e le polygone equivalent
				if(o->SwitchVal.NbrPolys>=o->MaxNbrClippedFaces) continue;

				f->Poly=&o->Polys[o->SwitchVal.NbrPolys++];
				f->Poly->NbrVertices=f->NbrVertices;
				memcpy(f->Poly->Vertices,f->V,sizeof(unsigned)*f->NbrVertices);
            }

            // Face visible
            *ovis=f;
            ovis++;
            o->NbrVisibles++;
			*tmp=f->Poly;
	      }
    }
}

static int RecurseBox(PVMesh *o,PVBox *box)
{
    PVPoint P[8];
    PVBox **b;
    unsigned i,Cod,OrCod,AndCod;
    int WorkToDo=0;

    P[0].xf=box->p0.xf*o->ScaleX;  P[0].yf=box->p0.yf*o->ScaleY;  P[0].zf=box->p0.zf*o->ScaleZ;
    P[1].xf=box->t0.xf*o->ScaleX;  P[1].yf=P[0].yf;               P[1].zf=P[0].zf;
    P[2].xf=P[1].xf;               P[2].yf=P[0].yf;               P[2].zf=box->t0.zf*o->ScaleZ;
    P[3].xf=P[0].xf;               P[3].yf=P[0].yf;               P[3].zf=P[2].zf;
    P[4].xf=P[0].xf;               P[4].yf=box->t0.yf*o->ScaleY;  P[4].zf=P[0].zf;
    P[5].xf=P[1].xf;               P[5].yf=P[4].yf;               P[5].zf=P[0].zf;
    P[6].xf=P[1].xf;               P[6].yf=P[4].yf;               P[6].zf=P[2].zf;
    P[7].xf=P[0].xf;               P[7].yf=P[4].yf;               P[7].zf=P[2].zf;

    // Frustum classement
    AndCod=0xffffffff;
    OrCod=0;
    for(i=0;i<8;i++)
    {
        Cod=PV_GetFrustumFlags(&P[i]);
        OrCod|=Cod;
        AndCod&=Cod;
    }
		
	if(AndCod) return WorkToDo;          // Totalement dehors

    // Bouate visible
    if(box->Flags)
    {
        o->FrustumFlags|=OrCod;

		// Feuille de l'octree
        // On effectue la transformation
		if(PV_PipelineControl&PVP_HARDWARETL)
		{
			PVHardwareDriver *hd=PV_GetHardwareDriver();
			hd->RenderMesh(o,box,OrCod,(unsigned)RenderBuffer);

			if(!OrCod)
				return 0;
			else
				return MESH_FRUSTUM_CLIPPED;
		}
		else
        if(PV_PipelineControl&PVP_DISABLETRANSFORM)
            PrepareBoxWT(box,o);
            else
            {
				if(!OrCod)
				{
					PrepareBoxInFrustum(box,o);
				}
				else
				{
					PrepareBox(box,o);
					WorkToDo|=MESH_FRUSTUM_CLIPPED;
				}
            }
    }
    else
    {
        // On teste les fils jusqu'au feuille
        for(i=0,b=&box->Child[0];i<8;b++,i++) if ((*b)!=NULL) WorkToDo|=RecurseBox(o,*b);
    }

    return WorkToDo;
}

static int ProcessMesh(PVMesh *o)
{
    unsigned WorkToDo=0;

	// Recherche des boites visibles
    if(o->Box!=NULL)
        WorkToDo|=RecurseBox(o,o->Box);

    return WorkToDo;
}

/***************************************************************************/
/*                             GESTION LUMINEUSE                           */
/***************************************************************************/

static int AllLightsShadeMesh(PVMesh *o,PVLight *l2)
{
    int b;

	if(o->Flags&MESH_NOLIGHTING) return COOL;
	if(PV_PipelineControl&PVP_DISABLELIGHTING) return COOL;

	// Remet � Zero les eclairage
    if((b=PV_MeshRAZShade(o))!=COOL) return b;

    //    Recherche d'une light
    while ( l2!=NULL )
    {
         if(l2->Flags&LIGHT_FORGET)
         {
            l2=l2->Next;
            continue;
         }

         if(PV_Mode&PVM_RGB) PV_MeshLightRGB(o,l2);
                        else PV_MeshLight(o,l2);
         l2=l2->Next;
    }

    return COOL;
}

/*
static float GetSpecular(PVPoint *l,PVPoint *n,PVPoint *v)
{
    PVPoint R,vis;
    float no;

 // R = 2 (N.V) N - V
 vis.xf=(CurrentCam->pos.xf-v->xf);
 vis.yf=(CurrentCam->pos.yf-v->yf);
 vis.zf=(CurrentCam->pos.zf-v->zf);

 //no=sqrt(vis.xf*vis.xf+vis.yf*vis.yf+vis.zf*vis.zf);
 no=1;
 vis.xf/=no;
 vis.yf/=no;
 vis.zf/=no;

 //R.xf=2*(n->xf*vis.xf)*n->xf-vis.xf;
 //R.yf=2*(n->yf*vis.yf)*n->yf-vis.yf;
 //R.zf=2*(n->zf*vis.zf)*n->zf-vis.zf;
 R.xf=2*(n->xf*vis.xf)*n->xf-vis.xf;
 R.yf=2*(n->yf*vis.yf)*n->yf-vis.yf;
 R.zf=2*(n->zf*vis.zf)*n->zf-vis.zf;

 no=-(R.xf*l->xf+R.yf*l->yf+R.zf*l->zf);

 return (no>0)?no:0;
 //return no;
}  */

//////////////////////////////////////////////// Clearage du mirror

static PVMesh MirrorMesh;
static PVMaterial MirrorMat;
static PVScreenPoint MirrorPoint[2*MAX_VERTICES_PER_POLY];

static void InitMirrorMesh(void)
{

    MirrorMesh.Projected=MirrorPoint;

    MirrorMat.Type=FLAT|NOTHING|ZBUFFER;
	MirrorMat.DepthTest=CMP_ALWAYS;
}

///////////////////////////////////////////////////////// RENDERING

// Trie les mirroirs du fond vers l'avant selon leurs ZMin
static void SortMirrors(PVWorld *w)
{
    PVMirror *sorted=NULL,**ps=&sorted,**lm2,*m,*lm,**lm3;
    float ZMin=0;

    lm2=lm3=&w->Mirrors;
    lm=m=w->Mirrors;
    while(m!=NULL)
    {
        if(m->ZMin<ZMin)
        {
            lm2=lm3;
            lm=m;
            ZMin=m->ZMin;
        }

        if(m->Next==NULL)
        {
            // Transfert du noeud mini dans la liste tri�e
            *ps=lm;
            *lm2=lm->Next;

            lm->Next=NULL;
            ps=&lm->Next;

            // Reinit le cycle
            lm3=lm2=&w->Mirrors;
            lm=m=w->Mirrors;
        }
        else
        {
            lm3=&m->Next;
            m=m->Next;
        }
    }

    w->Mirrors=sorted;
}

//////////////////////////////////////////////////////////////// PORTALS

static void PV_PreparePortalFrustum(unsigned nbrvtx,unsigned vtxo[],PVPoint Transf[],PVMesh *por)
{
    PVPoint r,Up,z,tmp;
    unsigned i,nv,a,b;

    if(nbrvtx<3) return;

    // Calcul des N plans de coupure
    for(i=0;i<MAX_USER_CLIPPLANES;i++) PV_EnableClipPlane(CurrentCam,i,PV_DISABLE);
    for(i=0;i<nbrvtx;i++)
    {
		// Calcul d'un vecteur orthonormal � R Contenant le cot� du poly
		nv=i+1;
		if(nv>=nbrvtx) nv=0;

		a=vtxo[i];
		b=vtxo[nv];

		Up.xf=Transf[a].xf-Transf[b].xf;
		Up.yf=Transf[a].yf-Transf[b].yf;
		Up.zf=Transf[a].zf-Transf[b].zf;

		r.xf=Transf[a].xf;
		r.yf=Transf[a].yf;
		r.zf=Transf[a].zf;

		z.xf=Up.yf*r.zf-Up.zf*r.yf;
		z.yf=Up.zf*r.xf-Up.xf*r.zf;
		z.zf=Up.xf*r.yf-Up.yf*r.xf;

        tmp.xf=Transf[a].xf;
        tmp.yf=Transf[a].yf;
        tmp.zf=Transf[a].zf;
        PV_SetClipPlane(CurrentCam,i,tmp,z);
        PV_EnableClipPlane(CurrentCam,i,PV_ENABLE);
    }
}

static int PVAPI PortalPipe(PVMesh *m)
{
	PVFace *f=&m->Face[0];
    PVPoint tx,p,*or;
    unsigned j,n;
    PVVertex *ov2;

	RotatePoint3x3(&m->Face[0].Normal,FinalMatrix,&tx);
    if(tx.zf>=0)
	{
		ADDFLAG(m->Flags,MESH_FORGET_CHILD);
        return MESH_NOT_MOVED; // backfaced
	}
    else REMOVEFLAG(m->Flags,MESH_FORGET_CHILD);

	// Clip le poly 0 ki est le poly portal	
	if(f->NbrVertices<3) PV_Fatal("Portal() :: A portal should have 3 vertexes minimum",f->NbrVertices);
	if(f->NbrVertices>8) PV_Fatal("Portal() :: A portal should have 8 vertexes maximum",f->NbrVertices);

	if(PV_ClipFaceToFrustum(f))
    {
            // Nescessite un clip
            if(f->Poly!=NULL)
            {
				if(!ClipFaceAgainstFrustum(f))
                {				
					ADDFLAG(m->Flags,MESH_FORGET_CHILD);
                    return MESH_NOT_MOVED; // backfaced
                }		

                // Transforme les nouvos points
                for(j=0;j<f->Poly->NbrVertices;j++)
                {
                    n=f->Poly->Vertices[j];
                    if(n<m->NbrVertices) continue;

                    ov2=&m->Vertex[n];
                    p.xf=ov2->xf;
                    p.yf=ov2->yf;
                    p.zf=ov2->zf;
                    RotatePoint3x3(&p,FinalMatrix,or=&m->Rotated[n]);
                    or->xf+=FinalTrans.xf;
                    or->yf+=FinalTrans.yf;
                    or->zf+=FinalTrans.zf;
                }
            }

            // Visible
			// genere les clips planes ki vont bien
			if(f->Poly==NULL)
                PV_PreparePortalFrustum(f->NbrVertices,f->V,m->Rotated,m);
			else
                PV_PreparePortalFrustum(f->Poly->NbrVertices,f->Poly->Vertices,m->Rotated,m);

			// Bon alors on a un joli frustum, on serre les fesses ca doit etre bon :)

    }
    else
    {
        ADDFLAG(m->Flags,MESH_FORGET_CHILD);
        return MESH_NOT_MOVED; // clipped
    }
	return 0;
}

PVMesh *PVAPI PV_CreateMeshPortal(void)
{
	PVMesh *o;
	unsigned i,V[MAX_VERTICES_PER_POLY];

	o=PV_SimpleCreateMesh(1,MAX_VERTICES_PER_POLY,10,MAX_VERTICES_PER_POLY*2);
	if(o!=NULL)
	{
		o->Flags|=MESH_PORTAL|MESH_NOSORT|MESH_NOLIGHTING|MESH_INHERIT;
		o->UserPipeline=PortalPipe;
		PV_SetVerticesToFace(o->Face,V,MAX_VERTICES_PER_POLY);
		for(i=0;i<MAX_VERTICES_PER_POLY;i++) o->Face[0].V[i]=i;

		o->Name=strdup("$$ DUMMY PORTAL");
	}
	return o;
}

void PVAPI PV_SetupPortal(PVMesh *m)
{
    float nx,ny,nz,n;
    unsigned p1,p2,p3;

    if(m==NULL) return;
    if(m->NbrVertices<3) return;

    // Calcul de la normale
    p1=m->NbrVertices-1;
    p2=1;
    p3=0;
    nx=((m->Vertex[p2].yf-m->Vertex[p1].yf)*(m->Vertex[p3].zf-m->Vertex[p1].zf))-((m->Vertex[p2].zf-m->Vertex[p1].zf)*(m->Vertex[p3].yf-m->Vertex[p1].yf));
    ny=((m->Vertex[p2].zf-m->Vertex[p1].zf)*(m->Vertex[p3].xf-m->Vertex[p1].xf))-((m->Vertex[p2].xf-m->Vertex[p1].xf)*(m->Vertex[p3].zf-m->Vertex[p1].zf));
    nz=((m->Vertex[p2].xf-m->Vertex[p1].xf)*(m->Vertex[p3].yf-m->Vertex[p1].yf))-((m->Vertex[p2].yf-m->Vertex[p1].yf)*(m->Vertex[p3].xf-m->Vertex[p1].xf));
    n=(nx*nx+ny*ny+nz*nz);
	if(n>0)
	{
		//n=1/fsqrt(n);
		n=InvSqrt(n);
		nx*=n;
		ny*=n;
		nz*=n;
	}

    m->Face[0].Normal.xf=nx;
    m->Face[0].Normal.yf=ny;
    m->Face[0].Normal.zf=nz;
}

///////////////////////////////////////////////////////////////////////
static void PV_ComputeFogVertex(PVMesh *o)
{   
	unsigned int i;
    PVD8 *vv;
    PVShadeInfo *os;
	PVPoint *or,d;
	PVVertex *ov;
	double oorange,v;

	if(o->Shading==NULL) PV_MeshRAZShade(o);

	oorange=1/(o->Owner->Fog.End-o->Owner->Fog.Start);
	
	// Les points standard
	for(i=0,
    vv=o->VertexVisible,
	or=o->Rotated,
    os=o->Shading,
	ov=o->Vertex;
    i<o->NbrVertices;
    i++,vv++,os++,or++,ov++)
    {
        if (*vv==0) continue;

		if(!(ov->Flags&FOGABLE)) continue;

		if(Hint.FogRange)
		{
			d.xf=or->xf;
			d.yf=or->yf;
			d.zf=or->zf;
			v=-fsqrt(d.xf*d.xf+d.yf*d.yf+d.zf*d.zf);
		}
		else
			v=or->zf;

		os->Specular.a=(o->Owner->Fog.End+v)*oorange;
		if(os->Specular.a>1) os->Specular.a=1;
		if(os->Specular.a<0) os->Specular.a=0;		
		os->Specular.a=1-os->Specular.a;
	}

	// Les points clipp�s
	for(i=0,
	or=&o->Rotated[o->NbrVertices],
    os=&o->Shading[o->NbrVertices];
    i<o->nbrclipv;
    i++,os++,or++)
    {        
		if(Hint.FogRange)
		{
			d.xf=or->xf;
			d.yf=or->yf;
			d.zf=or->zf;
			v=-fsqrt(d.xf*d.xf+d.yf*d.yf+d.zf*d.zf);
		}
		else
			v=or->zf;

		os->Specular.a=(o->Owner->Fog.End+v)*oorange;
		if(os->Specular.a>1) os->Specular.a=1;
		if(os->Specular.a<0) os->Specular.a=0;		
		os->Specular.a=1-os->Specular.a;
	}
}

static int __cdecl comparemat( const void *arg1, const void *arg2 )
{
	return (unsigned)(((PVFace*)arg2)->MaterialInfo)-(unsigned)(((PVFace*)arg1)->MaterialInfo);
}

static int ComputeMeshList(PVMesh *o)
{
    int c;
    PVPoint tx;
    unsigned WorkToDo,i,j,n,d=MESH_NOT_MOVED;   // d est l'accumulateur pour tout les objets
    PVFace **fv;
    PVPoint p,*or;
    float z;
    PVVertex *ov2;
    PVCam OldCam;
	PVWorld *w;
	unsigned cindex;

    // tout les objets 1 par 1
    while(o!=NULL)
    {
		w=o->Owner;
		WorkToDo=0;

		// Test si on a deja rendere ce mesh (circuit dans le graph du monde)
		if(o->Owner->LastFrame==o->LastFrame)
		{
			o=o->Next;
			continue;
		}

		o->FrustumFlags=0xFFFFFFFF;

		// Compute la matrice de transfo
		ComputeObjFinalMatrix(o);

		// Handle Switch nodes
		if(o->Flags&MESH_SWITCHNODE)
		{
			PVMesh *hr;
			hr=o->SwitchInfos.SwitchCallBack(o);

			if(hr!=NULL)
			{
				PVMesh *old=hr->Next;

				// on isole le mesh des autres du switch
				hr->Next=NULL;
				
				if(o->SwitchVal.LastSwitchPath!=NULL) ADDFLAG(o->SwitchVal.LastSwitchPath->Flags,MESH_FORGET_ALL);
				REMOVEFLAG(hr->Flags,MESH_FORGET_ALL);
				o->SwitchVal.LastSwitchPath=hr;

				d&=ComputeMeshList(hr);
				hr->Next=old;
			}

			o=o->Next;
			continue;
		}

		// Portals land
		if(o->Flags&MESH_PORTAL)
		{
			REMOVEFLAG(o->Flags,MESH_FORGET_CHILD);
			OldCam=*CurrentCam;							// sauvegarde l'etat actuel des clippers
		}
		
		if(memcmp(&o->LastWorldPos,&o->Position,sizeof(PVPoint))==0)
		{
				if(memcmp(o->LastWorldMatrix,o->WorldMatrix,sizeof(PVMat3x3))!=0)
				{
					// Boug�, on recalcule les lights
					memcpy(o->LastWorldMatrix,o->WorldMatrix,sizeof(PVMat3x3));
					memcpy(&o->LastWorldPos,&o->WorldPos,sizeof(PVPoint));
					WorkToDo|=MESH_RECOMPUTE_LIGHT;
				}
		}
		else
		{
			memcpy(&o->LastWorldPos,&o->WorldPos,sizeof(PVPoint));
			memcpy(o->LastWorldMatrix,o->WorldMatrix,sizeof(PVMat3x3));

			WorkToDo|=MESH_RECOMPUTE_LIGHT;
		}
		
		if(!ISFLAGSET(o->Flags,MESH_FORGET))		
        {
			if(o->Flags&MESH_INHERIT_CULL)
				if(o->Father!=NULL)
					if(!(o->Father->Flags&MESH_VISIBLE)) 
					{
						o->NbrVisibles=0;
						o->nbrclipv=0;
						o->SwitchVal.NbrPolys=0;

						goto mesh_cull;// gosh !!
					}

			// Test pour l'allocation du buffer de face visible
			if(o->Visible==NULL) PV_Fatal("ProcessMesh():: Visible buffer not allocated",BIZAR_ERROR);

			// L'objet � t'il boug� � l'ecran
			if(!(PV_PipelineControl&PVP_HARDWARETL))
			if(memcmp(&FinalTrans,&o->OldPos,sizeof(PVPoint))==0)
			{ 
				if(memcmp(FinalMatrix,o->OldMatrix,sizeof(PVMat3x3))==0) WorkToDo|=MESH_NOT_MOVED;				
			}

			if(!(WorkToDo&MESH_NOT_MOVED))
			{
				// Oui On reacalule
				memcpy(&o->OldPos,&FinalTrans,sizeof(PVPoint));
				memcpy(o->OldMatrix,FinalMatrix,sizeof(PVMat3x3));

				o->NbrVisibles=0;
				o->nbrclipv=0;
				o->SwitchVal.NbrPolys=0;

				if(o->VertexVisible==NULL) if((o->VertexVisible=(char*)malloc(o->NbrVertices*sizeof(char)))==NULL) PV_Fatal("ProcessMesh(): Not enough memory for vertex index.",NO_MEMORY);
				memset(o->VertexVisible,0,o->NbrVertices*sizeof(char));

				// Setup Camera pour le backface
				tx=CurrentCam->pos;
                tx.xf-=o->Pivot.xf+o->WorldPos.xf;
				tx.yf-=o->Pivot.yf+o->WorldPos.yf;
				tx.zf-=o->Pivot.zf+o->WorldPos.zf;
		
				RotateInvertPoint(&tx,o->WorldMatrix,&InvertCamPos);
				InvertCamPos.xf+=o->Pivot.xf;
				InvertCamPos.yf+=o->Pivot.yf;
				InvertCamPos.zf+=o->Pivot.zf;				
				o->InvertCamPos=InvertCamPos;

				// Setup variable clip & co
				ovis=o->Visible;

				// Setup Frustum
				PV_SetFrustum(CurrentCam,FinalMatrix,&InvertCamPos,o->Flags&MESH_DO_NOT_CLIP_TO_BACKPLANE);
				PV_SetUserFrustum(CurrentCam,FinalMatrix);

				// Pipeline par defaut ?
				if(o->UserPipeline==NULL)
				{
					c=ProcessMesh(o);
				}
				else
				{
					c=o->UserPipeline(o);

					if(PV_PipelineControl&PVP_HARDWARETL)
					{
						PVHardwareDriver *hd=PV_GetHardwareDriver();

						// Sort Par Material
						if((!(o->Flags&MESH_NOSORT))&&(w->Flags&PVW_MATERIAL))
						{
							qsort(o->Visible,o->NbrVisibles,sizeof(PVFace*),comparemat);
						}
						
						hd->RenderMesh(o,NULL,c&MESH_FRUSTUM_CLIPPED,(unsigned)RenderBuffer);
					}
				}

				// Test erreur
				if(c<0) return -c;
				d&=c;
				WorkToDo|=c;
			}

			if(PV_PipelineControl&PVP_HARDWARETL) goto mesh_cull;

			// Eclairation du bignou
			// Un peu lourdant ici les conditions
			if(o->NbrVisibles!=0)
			{
				if(PV_LightRecomputeNeeded())
				{
					if((c=AllLightsShadeMesh(o,w->Lights))!=COOL) return c;
				}
				else
				{
					if(WorkToDo&MESH_RECOMPUTE_LIGHT)
					{
						// Boug�, et visible
						if((c=AllLightsShadeMesh(o,w->Lights))!=COOL) return c;
					}
					else
					{
						if((!(o->Flags&MESH_VISIBLE))&&(!(WorkToDo&MESH_FRUSTUM_CLIPPED)))
						{
							// Pas boug�, visible a cette frame, mais ne l'�tait pas a la
							// pr�c�dente, on calcul tout !
							memset(o->VertexVisible,1,o->NbrVertices*sizeof(char));
							if((c=AllLightsShadeMesh(o,w->Lights))!=COOL) return c;
						}
						else
						{
							// Clipp�
							if(WorkToDo&MESH_FRUSTUM_CLIPPED)
								if((c=AllLightsShadeMesh(o,w->Lights))!=COOL) return c;
						}
					}
				}				
			}

			//----------------------------------------------------------- 2nd passe
			// Clip des faces visibles ki le nescessitent			
			if((WorkToDo&MESH_FRUSTUM_CLIPPED)||
				(!(WorkToDo&MESH_NOT_MOVED)))
			{
				for(i=0,fv=o->Visible;i<o->NbrVisibles;i++,fv++)
				{					
					PVFaceInfo *fi;
					cindex=((*fv)-o->Face);

					fi=&o->FaceInfos[cindex];

					if(((*fv)->Poly=fi->Poly)!=NULL)
					{
						// Nescessite un clip
		                PVMesh *oldm=(*fv)->Father;

						(*fv)->Father=o;

						if(!ClipFaceAgainstFrustum(*fv))
						{
							// Polygone resultant bizarre, ou overflow des buffers de clip
							// Supprime la face de la liste des faces visibles en swappant
							// cette entr�e  avec la derniere de la liste
							// non on decale tout finalement
							(*fv)->Father=oldm;
							memmove(fv,fv+1,(o->NbrVisibles-i-1)*sizeof(fv));
							o->NbrVisibles--;
							i--;
							fv--;
							continue;
						}
						(*fv)->Father=oldm;

						// Transforme les nouvos points
						if(!(PV_PipelineControl&PVP_DISABLETRANSFORM))
						for(j=0;j<(*fv)->Poly->NbrVertices;j++)
						{
							n=(*fv)->Poly->Vertices[j];
							if(n<o->NbrVertices) continue;

							ov2=&o->Vertex[n];
							p.xf=ov2->xf;
							p.yf=ov2->yf;
							p.zf=ov2->zf;
							RotatePoint3x3(&p,FinalMatrix,or=&o->Rotated[n]);
							or->xf+=FinalTrans.xf;
							or->yf+=FinalTrans.yf;
							z=or->zf+=FinalTrans.zf;

							ProjectPoint(or,1/z,&o->Projected[n]);
						}

						// Calcul les donn�es de la face
						z=0;
						fi->DistanceToCam=-CurrentCam->BackDist;
						for(j=0;j<(*fv)->Poly->NbrVertices;j++)
						{
							n=(*fv)->Poly->Vertices[j];
							if(((*fv)->Flags&FLAT)&&(n>=o->NbrVertices)) memcpy(&o->Shading[n],&o->Shading[(*fv)->V[0]],sizeof(PVShadeInfo));
							z+=o->Rotated[n].zf;
							fi->DistanceToCam=max(fi->DistanceToCam,o->Rotated[n].zf);
						}

						if(w->Flags&PVW_MATERIAL) fi->ZAvg=(int)(*fv)->MaterialInfo;
						else fi->ZAvg=z/(*fv)->Poly->NbrVertices;
					}
					else
					{
						// Calcul les donn�es de la face
						fi->ZAvg=0;
						fi->DistanceToCam=-CurrentCam->BackDist;
						for(j=0;j<(*fv)->NbrVertices;j++)
						{
							fi->ZAvg+=o->Rotated[(*fv)->V[j]].zf;
							fi->DistanceToCam=max(fi->DistanceToCam,o->Rotated[(*fv)->V[j]].zf);
						}
						if(w->Flags&PVW_MATERIAL) fi->ZAvg=(int)(*fv)->MaterialInfo;
						else fi->ZAvg/=(*fv)->NbrVertices;
					}
				}
			}
			else
			{
				for(i=0,fv=o->Visible;i<o->NbrVisibles;i++,fv++)
				{
						// Calcul les donn�es de la face
						PVFaceInfo *fi;
						cindex=((*fv)-o->Face);
						fi=&o->FaceInfos[cindex];
						
						fi->ZAvg=0;
						fi->DistanceToCam=-CurrentCam->BackDist;
						for(j=0;j<(*fv)->NbrVertices;j++)
						{
							fi->ZAvg+=o->Rotated[(*fv)->V[j]].zf;
							fi->DistanceToCam=max(fi->DistanceToCam,o->Rotated[(*fv)->V[j]].zf);
						}
						if(w->Flags&PVW_MATERIAL) fi->ZAvg=(int)(*fv)->MaterialInfo;
						else fi->ZAvg/=(*fv)->NbrVertices;
				}
			}

			// Eventuel fogage du bignou
			if((PV_Mode&PVM_USEHARDWARE)&&(PV_PipelineControl&PVP_COMPUTEFOGVALUES))
			{
				if((!(WorkToDo&MESH_NOT_MOVED))||(PV_LightRecomputeNeeded()))
					PV_ComputeFogVertex(o);
			}

			// met a jour l'etat de l'objet
mesh_cull:
			if(o->NbrVisibles!=0)
			{
				w->NbrVisibles+=o->NbrVisibles;
				ADDFLAG(o->Flags,MESH_VISIBLE);
			}
			else REMOVEFLAG(o->Flags,MESH_VISIBLE);

			// Appel routine user
			if(o->AfterVisibilityPipe!=NULL) o->AfterVisibilityPipe(o);
		}

		if(!(ISFLAGSET(o->Flags,MESH_FORGET_CHILD))) 
		{
			if(o->Flags&MESH_CULL_CHILD)
			{
				if(o->Flags&MESH_VISIBLE) d&=ComputeMeshList(o->Child);
			}
			else d&=ComputeMeshList(o->Child);
		}

		// Portals land
		if(o->Flags&MESH_PORTAL)
		{
			// Restore les clipper
            *CurrentCam=OldCam;
		}

		o=o->Next;
    }

    return d;
}

static int ComputeWorld(PVWorld *w)
{
    int c;
    unsigned d=MESH_NOT_MOVED;   // d est l'accumulateur pour tout les objets

    if(w==NULL) return ARG_INVALID;

    if(CurrentCam==NULL) PV_Fatal("PV_ComputeWorld() :: No camera defined",INVALID_CAM);
    PV_ComputeCam(CurrentCam);	

    w->NbrVisibles=0;
	
	// Recherche du startup de la cam (portal rendering ?)
	if(CurrentCam->Flags&CAMERA_AUTOLOCATE)
	{
		w->LastFrame++;
		CurrentCam->StartingLocation=PV_FindCurrentCameraCell(w->Objs,CurrentCam);
	}	
	w->LastFrame++;

	if(CurrentCam->StartingLocation==NULL) 
		d&=ComputeMeshList(w->Objs);
	else
		d&=ComputeMeshList(CurrentCam->StartingLocation);
    PV_NoRecomputeLight();

    // Et le tri
	if ((w->NbrVisibles!=0)&&(!d)) if((c=PV_SortWorld(w))!=COOL) return c;

    return COOL;
}

static int Shadowed;
static int PVAPI ShadowDrawer(PVMesh *m,int userarg)
{	
	PVMaterial *StencilMat=(PVMaterial*)userarg;
	
	if(!(m->Flags&MESH_CAST_SHADOWS)) return COOL;
		
	pvSetCull(PV_CULL_CW);	
	StencilMat->StencilPass=STENCIL_DECR;
	PV_RefreshMaterial(StencilMat);
	PV_DrawShadows(m,(unsigned)RenderBuffer,(PVPoint*)&m->Owner->Camera->Matrix[2][0]);

	pvSetCull(PV_CULL_CCW);	
	StencilMat->StencilPass=STENCIL_INCR;
	PV_RefreshMaterial(StencilMat);
	PV_DrawShadows(m,(unsigned)RenderBuffer,(PVPoint*)&m->Owner->Camera->Matrix[2][0]);

	Shadowed=1;

	return COOL;
}

static void RenderShadows(PVWorld *w,unsigned stencildepth)
{	
	PVRGBF ambient={0,0,0};
	PVFLAGS oldflags=PV_Mode;
	PVMat3x3 idmat={1,0,0,0,1,0,0,0,1};
	PVPoint idpt={0,0,0};
	static PVMaterial *StencilMat=NULL,*ShadowMat=NULL,*CapMat=NULL;

	if(StencilMat==NULL)
	{
		StencilMat=PV_CreateMaterial("$$DUMMY STENCIL MAT",STENCILBUFFER|FLAT|ZBUFFER,TEXTURE_NONE,0);
		if(StencilMat==NULL) PV_Fatal("ShadowDrawer(): Not enough memory",0);
		PV_CompileMaterial(StencilMat,NULL,NULL,ambient,0);

		StencilMat->ZWrite=0;
		StencilMat->BlendRgbSrcFactor=BLEND_ZERO;// Do not update frame bufer
		StencilMat->BlendRgbDstFactor=BLEND_ONE;	
		StencilMat->StencilFunc=CMP_ALWAYS;
		StencilMat->StencilFail=STENCIL_KEEP;
		StencilMat->StencilZFail=STENCIL_KEEP;		
		StencilMat->StencilRef=0;

		ShadowMat=PV_CreateMaterial("$$DUMMY SHADOW MAT",STENCILBUFFER|FLAT,TEXTURE_NONE,0);
		if(ShadowMat==NULL) PV_Fatal("ShadowDrawer(): Not enough memory",1);
		PV_CompileMaterial(ShadowMat,NULL,NULL,ambient,0);

		ShadowMat->StencilFail=STENCIL_KEEP;
		ShadowMat->StencilZFail=STENCIL_KEEP;
		ShadowMat->StencilPass=STENCIL_KEEP;
		ShadowMat->StencilFunc=CMP_LESS;
		ShadowMat->BlendRgbSrcFactor=BLEND_SRC_ALPHA;
		ShadowMat->BlendRgbDstFactor=BLEND_ONE_MINUS_SRC_ALPHA;

		CapMat=PV_CreateMaterial("$$DUMMY CAP MAT",STENCILBUFFER|FLAT|ZBUFFER,TEXTURE_NONE,0);
		if(CapMat==NULL) PV_Fatal("ShadowDrawer(): Not enough memory",2);
		PV_CompileMaterial(CapMat,NULL,NULL,ambient,0);

		CapMat->ZWrite=0;		
		CapMat->StencilFail=STENCIL_KEEP;
		CapMat->StencilZFail=STENCIL_KEEP;
		CapMat->StencilPass=STENCIL_REPLACE;
		CapMat->StencilFunc=CMP_ALWAYS;
		CapMat->StencilRef=0;
		CapMat->StencilMask=(1<<(stencildepth-1));
		CapMat->StencilWriteMask=(1<<(stencildepth-1));
		CapMat->BlendRgbSrcFactor=BLEND_ZERO;
		CapMat->BlendRgbDstFactor=BLEND_ONE;	
	}	

	PV_SetMode(PV_Mode|PVM_ALPHABLENDING|PVM_STENCILBUFFER|PVM_ZBUFFER);
	
	pvSetMode(PV_3D);
	pvSetCamera(CurrentCam);
	pvSetMaterial(StencilMat);	
	pvSetModelMatrix(idmat);
	pvSetModelPos(idpt);
	pvSetModelPivot(idpt);
	
	Shadowed=0;
	PV_IterateMeshList(w->Objs,ShadowDrawer,(int)StencilMat);
   	
	if(Shadowed)
	{				
		ShadowMat->StencilRef=((1<<(stencildepth-1))|(1<<(stencildepth-2)))-(unsigned)PV_IsInShadows(w);	
		PV_RefreshMaterial(ShadowMat);
		
		pvSetCull(PV_CULL_NONE);		
		pvSetMode(PV_2D);
		pvSetDepthField(1,10);

		pvBegin(PV_QUADS,RenderBuffer);
		
		// Cap quad
		if(!(CurrentCam->Flags&CAMERA_DO_NOT_DRAW_SHADOW_CAP))
		{
			pvSetMaterial(CapMat);
			pvVertex(ClipMinX,ClipMinY,1/10);
			pvVertex(ClipMaxX,ClipMinY,1/10);
			pvVertex(ClipMaxX,ClipMaxY,1/10);
			pvVertex(ClipMinX,ClipMaxY,1/10);
		}
		
		// Shadow quad
		pvSetMaterial(ShadowMat);
		pvColor(0,0,0,0.5);
		pvVertex(ClipMinX,ClipMinY,1);
		pvVertex(ClipMaxX,ClipMinY,1);
		pvVertex(ClipMaxX,ClipMaxY,1);
		pvVertex(ClipMinX,ClipMaxY,1);
		pvEnd();
	}
}

static int RenderWorld(PVWorld *w,UPVD8 *Scr)
{
   unsigned i;
   PVFace **fv;
      
   // Let's call a user defined callback before throwing these triangles to rasterizers   
   if(w->UserRenderWorld!=NULL)
   {
		if(w->UserRenderWorld(w,Scr)!=COOL) return COOL;  // Si l'utilisateur renvoit un code d'erreur, on zap le renderworld de PV
   }

   if(!(PV_PipelineControl&PVP_HARDWARETL))
   {
	   if(PV_Mode&PVM_USEHARDWARE)
	   {
			PVHardwareDriver *hd=PV_GetHardwareDriver();
			PVMaterial *lastmat=NULL;
			
			if(hd==NULL) return NO_HARDWARE_SET;

			for(i=0,fv=w->Visible;i<w->NbrVisibles;i++,fv+=2)
			{
				if((*fv)->MaterialInfo!=NULL)
				{
					PV_PrepareFace(*fv);
	  				if(lastmat!=(*fv)->MaterialInfo)
					{
						hd->PrepareFace(*fv);
						lastmat=(*fv)->MaterialInfo;
					}
					PV_TriangulateFace(*fv,(*fv)->MaterialInfo->Filler,(PVMesh*)*(fv+1));
					PV_PrepareFace(*fv);
				}
			}
	   }
	   else
	   {
			// Rendering Soft
			for(i=0,fv=w->Visible;i<w->NbrVisibles;i++,fv+=2)
			{
				if((*fv)->MaterialInfo!=NULL)
				{				
					PV_SetNewSWRenderBuffer(Scr);
					PV_PrepareFace(*fv);
					PV_TriangulateFace(*fv,(*fv)->MaterialInfo->Filler,(PVMesh*)*(fv+1));
					PV_PrepareFace(*fv);
				}
			}
	#ifdef __386__
			SetFPU_Near();
	#endif
	   }
   }

   if((PV_Mode&PVM_SHADOWS)&&(PV_Mode&PVM_USEHARDWARE))
   {
		PVHardwareCaps *caps;
	    if(PV_GetHardwareDriver()==NULL) return COOL;	
		caps=PV_GetHardwareDriver()->GetInfo();
		if((caps->GeneralCaps&PHG_STENCILBUFFER)&&(caps->BitsPerStencil>1))
		{
			PV_UpdateShadows(w);
			RenderShadows(w,caps->BitsPerStencil);
		}
   }

   return COOL;
}

void PVAPI PV_RenderAdditionalFace(PVFace *f)
{
   if(PV_Mode&PVM_USEHARDWARE)
   {
		if(PV_GetHardwareDriver()==NULL) return;

        if(f->MaterialInfo!=NULL)
		{
			PV_PrepareFace(f);
	  		PV_GetHardwareDriver()->PrepareFace(f);
			PV_TriangulateFace(f,f->MaterialInfo->Filler,f->Father);
			PV_PrepareFace(f);
		}	
   }
   else
   {
		if(f->MaterialInfo!=NULL)
		{			
            PV_SetNewSWRenderBuffer(RenderBuffer);
			PV_PrepareFace(f);
			PV_TriangulateFace(f,f->MaterialInfo->Filler,f->Father);
			PV_PrepareFace(f);
		}        
#ifdef __386__
        SetFPU_Near();
#endif
   }
}

void PVAPI PV_RenderAdditionalFaces(PVFace *fs[],unsigned nbrf)
{
   PVFace **f;
   unsigned i;

   for(i=0,f=fs;i<nbrf;i++,f++)
   {
	   if(PV_Mode&PVM_USEHARDWARE)
	   {
			PVHardwareDriver *hd=PV_GetHardwareDriver();
			PVMaterial *lastmat=NULL;
		
			if(hd==NULL) return;

			if((*f)->MaterialInfo!=NULL)
			{
				PV_PrepareFace(*f);
				if(lastmat!=(*f)->MaterialInfo)
				{
					hd->PrepareFace(*f);
					lastmat=(*f)->MaterialInfo;
				}
				PV_TriangulateFace(*f,(*f)->MaterialInfo->Filler,(*f)->Father);
				PV_PrepareFace(*f);
			}	
	   }
	   else
	   {
			if((*f)->MaterialInfo!=NULL)
			{
                PV_SetNewSWRenderBuffer(RenderBuffer);				
				PV_PrepareFace(*f);
				PV_TriangulateFace(*f,(*f)->MaterialInfo->Filler,(*f)->Father);
				PV_PrepareFace(*f);
			}        
#ifdef __386__
            SetFPU_Near();
#endif
	   }
   }
}

int PVAPI PV_RenderWorld(PVWorld *w,UPVD8 *Scr)
{
    unsigned i;
    PVMirror *m;
    PVPlane *lastPl;

    static PVMat3x3 IDMatrix={1,0,0,0,1,0,0,0,1};
    PVMat3x3 MirrorMatrix,TMatrix,MirrorMatrixCam;
    PVPoint MirrorPos,tx,Transf[2*MAX_VERTICES_PER_POLY],FinalMirrorPos,D;
    PVPoly ZePoly;
    PVCam SymCam;
    unsigned NbrClipped;
	PVFLAGS oldpvm;

    if(w==NULL) return ARG_INVALID;

	if(!(PV_Mode&PVM_USEHARDWARE))
    {
		if(Scr==NULL) return ARG_INVALID;
    }
	else if(PV_GetHardwareDriver()==NULL) return NO_HARDWARE_SET;

	if(PV_Mode&PVM_USEHARDWARE)
	{
		i=PV_GetHardwareDriver()->PreRender(w,(unsigned int)Scr,PV_Mode,PV_PipelineControl);
		if(i!=COOL) return i;
	}

    RGBAmbientLight=&w->AmbientLight;

	PV_FreeAllClipPlanes();

    m=w->Mirrors;
    while(m!=NULL)
    {
        m->ZMin=0;

        // Calcul la position du bignou
        if(m->Father!=NULL)
        {
            MirrorPos=m->Father->WorldPos;
            memcpy(TMatrix,m->Father->WorldMatrix,sizeof(PVMat3x3));
        }
        else
        {
            memset(&MirrorPos,0,sizeof(MirrorPos));
            memcpy(TMatrix,IDMatrix,sizeof(MirrorMatrix));
        }
        MirrorPos.xf+=m->Pos.xf;
        MirrorPos.yf+=m->Pos.yf;
        MirrorPos.zf+=m->Pos.zf;
        MatrixMul(TMatrix,m->Matrix,MirrorMatrix);

        MatrixMul(MirrorMatrix,w->Camera->Matrix,MirrorMatrixCam);

        // Mirroir visible
        // Transforme le Mirroir en espace camera
        tx.xf=MirrorPos.xf+m->Pivot.xf-w->Camera->pos.xf;
        tx.yf=MirrorPos.yf+m->Pivot.yf-w->Camera->pos.yf;
        tx.zf=MirrorPos.zf+m->Pivot.zf-w->Camera->pos.zf;
        RotatePoint3x3(&tx,w->Camera->Matrix,&FinalMirrorPos);
        RotatePoint3x3(&m->Pivot,MirrorMatrixCam,&D);
        FinalMirrorPos.xf-=D.xf;
        FinalMirrorPos.yf-=D.yf;
        FinalMirrorPos.zf-=D.zf;

        for(i=0;i<m->NbrVertices;i++)
        {
            RotatePoint3x3(&m->Vertex[i],MirrorMatrixCam,&Transf[i]);
            Transf[i].zf+=FinalMirrorPos.zf;
            if(Transf[i].zf<m->ZMin) m->ZMin=Transf[i].zf;
        }

        m=m->Next;
    }
    if(w->Mirrors!=NULL) SortMirrors(w);

    // Mirrors
    m=w->Mirrors;
    while(m!=NULL)
    {
        if(m->Flags&PV_MIRROR_FORGET)
        {
            m=m->Next;
            continue;
        }

        // Sanity Check des mirrors
		if((m->NbrVertices>2)&&(m->NbrVertices<=8))
        {
            // Set up le frustum pour clipper le mirror
            tx=w->Camera->pos;
            tx.xf-=m->Pivot.xf+MirrorPos.xf;
            tx.yf-=m->Pivot.yf+MirrorPos.yf;
            tx.zf-=m->Pivot.zf+MirrorPos.zf;

            RotateInvertPoint(&tx,MirrorMatrix,&InvertCamPos);
            InvertCamPos.xf+=m->Pivot.xf;
            InvertCamPos.yf+=m->Pivot.yf;
            InvertCamPos.zf+=m->Pivot.zf;

            PV_SetFrustum(w->Camera,MirrorMatrixCam,&InvertCamPos,0);
            PV_SetUserFrustum(w->Camera,MirrorMatrixCam);

            ZePoly.NbrVertices=m->NbrVertices;
            for(i=0;i<m->NbrVertices;i++) ZePoly.Vertices[i]=i;

            // On a alou� dans PVMirror 16 vertex de plus ke la limite
			CurrentCam=w->Camera;
            NbrClipped=0;
            if(!ClipPolyAgainstFrustum(&ZePoly,m->Vertex,&NbrClipped,2*MAX_VERTICES_PER_POLY-m->NbrVertices))
            {
                // Pb durant le clip, ou face dehors
                m=m->Next;
                continue;
            }

            // Le mirroir est dans la pyramide
            RotatePoint3x3(&m->Normal,MirrorMatrixCam,&tx);
            if(tx.zf>=0)
            {
                // Backfaced
                m=m->Next;
                continue;
            }

            // Transformation
            for(i=0;i<ZePoly.NbrVertices;i++)
            {
                RotatePoint3x3(&m->Vertex[ZePoly.Vertices[i]],MirrorMatrixCam,&Transf[ZePoly.Vertices[i]]);
                Transf[ZePoly.Vertices[i]].xf+=FinalMirrorPos.xf;
                Transf[ZePoly.Vertices[i]].yf+=FinalMirrorPos.yf;
                Transf[ZePoly.Vertices[i]].zf+=FinalMirrorPos.zf;
            }

            // Setup de la camera Symetrik
            memcpy(&SymCam,w->Camera,sizeof(PVCam));
            SymCam.BackDist=m->CutDist;
            PV_PrepareMirror(&ZePoly,&SymCam,Transf);

            // Compute D
            RotateInvertPoint(&w->Camera->pos,m->SymMatrix,&SymCam.pos);
            MatrixMul(w->Camera->Matrix,m->SymMatrix,SymCam.Matrix);

            // Cr�e un plan de clip pour afficher la scene derriere le mirroir
            D.xf=-m->Normal.xf;
            D.yf=-m->Normal.yf;
            D.zf=-m->Normal.zf;
            lastPl=PV_AllocClipPlanes(1);
            if(lastPl==NULL) break;
            PV_SetPlane(lastPl,m->d,&D);


			for(i=0;i<ZePoly.NbrVertices;i++)
			{
				ProjectPoint(&Transf[ZePoly.Vertices[i]],1/Transf[ZePoly.Vertices[i]].zf,&MirrorMesh.Projected[ZePoly.Vertices[i]]);
			}

			// PreClear le mirroir en soft, a virer si j'implemente CMP_ALWAYS en soft pour le Z
			if((!(PV_Mode&PVM_USEHARDWARE))&&(PV_Mode&PVM_ZBUFFER))
			{
				pvSetMaterial(&MirrorMat);
				D.zf=1/w->Camera->FrontDist;
				pvBegin(PV_POLYS,Scr);
				pvColor(0,0,0,0);
				for(i=0;i<ZePoly.NbrVertices;i++) pvVertex(MirrorMesh.Projected[ZePoly.Vertices[i]].xf,MirrorMesh.Projected[ZePoly.Vertices[i]].yf,D.zf);
				pvEnd();
			}
			ComputeWorld(w);
			RenderWorld(w,Scr);

            // Clear le mirroir
			if((!(PV_Mode&PVM_USEHARDWARE))&&(PV_Mode&PVM_ZBUFFER))
			{
				oldpvm=PV_Mode;
				REMOVEFLAG(PV_Mode,PVM_ZBUFFER);
			}
			pvSetMaterial(&MirrorMat);
			D.zf=(1/w->Camera->BackDist);
			pvSetDepthField(w->Camera->FrontDist,w->Camera->BackDist+1000);
			pvBegin(PV_POLYS,Scr);
			pvColor(0,0,0,0);
			for(i=0;i<ZePoly.NbrVertices;i++) pvVertex(MirrorMesh.Projected[ZePoly.Vertices[i]].xf,MirrorMesh.Projected[ZePoly.Vertices[i]].yf,D.zf);
			pvEnd();
			if((!(PV_Mode&PVM_USEHARDWARE))&&(PV_Mode&PVM_ZBUFFER)) PV_Mode=oldpvm;

            // Render le mirror
            i=PV_GetNbrClipPlanes();
            PV_FreeAllClipPlanes();

            CurrentCam=&SymCam;
            ComputeWorld(w);
            RenderWorld(w,Scr);
            CurrentCam=w->Camera;

            // Revient en mode normal
            PV_AllocClipPlanes(i);

            lastPl->Normal.xf=-lastPl->Normal.xf;
            lastPl->Normal.yf=-lastPl->Normal.yf;
            lastPl->Normal.zf=-lastPl->Normal.zf;
        }

        m=m->Next;
    }

	RenderBuffer=Scr;
    CurrentCam=w->Camera;
    ComputeWorld(w);
    RenderWorld(w,Scr);

	if(PV_Mode&PVM_USEHARDWARE)
	{
		PV_GetHardwareDriver()->PostRender();
	}

	return COOL;
}


/////////////////////////////////////////////////////////////////////// DIVERS
int PVAPI PV_RayPolygonIntersection(float V[],unsigned n,PVPoint *norm,PVPoint *org,PVPoint *dir, float limit,float *dist,float P[3])
{
	PVPoint *V0;
	float d,t,m,u0,u1,u2,v0,v1,v2,h;
	float alpha,inter,beta;
	unsigned i1,i2,i;
	float p[3];

	V0=(PVPoint*)&V[0];
	d=-(V0->xf*norm->xf+V0->yf*norm->yf+V0->zf*norm->zf);

	h=(norm->xf*dir->xf+norm->yf*dir->yf+norm->zf*dir->zf);
	if(h==0) return 0;

	t=-(d+(norm->xf*org->xf+norm->yf*org->yf+norm->zf*org->zf))/h;
	if(t<0) return 0;	// Intersection behind origin of the ray

	if(limit>=0) if(t>limit) return 0;
	
	m=max(norm->xf,max(norm->yf,norm->zf));

	if(m==norm->xf)
	{
		i1=1; i2=2;
	}
	else
	if(m==norm->yf)
	{
		i1=0; i2=2;
	}
	else
	{
		i1=0; i2=1;
	}

	p[0] = org->xf + dir->xf*t;
	p[1] = org->yf + dir->yf*t;
	p[2] = org->zf + dir->zf*t;
	u0 = p[i1] - V[0*3+i1]; 
	v0 = p[i2] - V[0*3+i2];
	inter = 0; i = 2;
	do {
		/* The polygon is viewed as (n-2) triangles. */
		u1 = V[(i-1)*3+i1] - V[0*3+i1]; v1 = V[(i-1)*3+i2] - V[0*3+i2];
		u2 = V[i    *3+i1] - V[0*3+i1]; v2 = V[i    *3+i2] - V[0*3+i2];

		if (u1 == 0)    {
			beta = u0/u2;
			if ((beta >= 0.)&&(beta <= 1.)) {
				alpha = (v0 - beta*v2)/v1;
				inter = ((alpha >= 0.)&&((alpha+beta) <= 1.0));
			}
		} else {
			beta = (v0*u1 - u0*v1)/(v2*u1 - u2*v1);
			if ((beta >= 0.)&&(beta <= 1.)) {
				alpha = (u0 - beta*u2)/u1;
				inter = ((alpha >= 0)&&((alpha+beta) <= 1.0));
			}
		}
	} while ((!inter)&&(++i < n));
	*dist=t;
	memcpy(P,p,sizeof(p));
	return inter;
}

int PVAPI PV_RayFaceIntersection(PVFace *f,PVPoint *org,PVPoint *dir, float limit,float *dist,float P[3])
{
	PVVertex *V0;
	float d,t,m,u0,u1,u2,v0,v1,v2,h;
	PVMesh *o=f->Father;
	float V[MAX_VERTICES_PER_POLY][3],alpha,inter,beta;
	unsigned i1,i2,i;
	PVPoint norm;
	float p[3];

	norm=f->Normal;

	V0=&o->Vertex[f->V[0]];
	d=-(V0->xf*norm.xf+V0->yf*norm.yf+V0->zf*norm.zf);

	h=(norm.xf*dir->xf+norm.yf*dir->yf+norm.zf*dir->zf);
	if(h==0) return 0;

	t=-(d+(norm.xf*org->xf+norm.yf*org->yf+norm.zf*org->zf))/h;
	if(t<0) return 0;	// Intersection behind origin of the ray

	if(limit>=0) if(t>limit) return 0;
	
	m=max(norm.xf,max(norm.yf,norm.zf));

	if(m==norm.xf)
	{
		i1=1; i2=2;
	}
	else
	if(m==norm.yf)
	{
		i1=0; i2=2;
	}
	else
	{
		i1=0; i2=1;
	}

	for(i=0;i<f->NbrVertices;i++) memcpy(&V[i][0],&o->Vertex[f->V[i]].xf,sizeof(float)*3);

	p[0] = org->xf + dir->xf*t;
	p[1] = org->yf + dir->yf*t;
	p[2] = org->zf + dir->zf*t;
	u0 = p[i1] - V[0][i1]; 
	v0 = p[i2] - V[0][i2];
	inter = 0; i = 2;
	do {
		/* The polygon is viewed as (n-2) triangles. */
		u1 = V[i-1][i1] - V[0][i1]; v1 = V[i-1][i2] - V[0][i2];
		u2 = V[i  ][i1] - V[0][i1]; v2 = V[i  ][i2] - V[0][i2];

		if (u1 == 0)    {
			beta = u0/u2;
			if ((beta >= 0.)&&(beta <= 1.)) {
				alpha = (v0 - beta*v2)/v1;
				inter = ((alpha >= 0.)&&((alpha+beta) <= 1.0));
			}
		} else {
			beta = (v0*u1 - u0*v1)/(v2*u1 - u2*v1);
			if ((beta >= 0.)&&(beta <= 1.)) {
				alpha = (u0 - beta*u2)/u1;
				inter = ((alpha >= 0)&&((alpha+beta) <= 1.0));
			}
		}
	} while ((!inter)&&(++i < f->NbrVertices));
	*dist=t;
	memcpy(P,p,sizeof(p));
	return inter;
}

void PVAPI PV_TriangulateFace(PVFace *f,void (PVAPI * Func)(PVFace *f),PVMesh *o)
{
    unsigned j;
    PVFace ff;
    UPVD8 *Scr=TriFill_BufOfs;
	unsigned V[3],cindex;
	PVMesh *oldm;

    if(f==NULL) return;
    if(Func==NULL) return;

	oldm=f->Father;
	f->Father=o;

	// calcul de l'index de clip
	cindex=(f-oldm->Face);
	f->Poly=o->FaceInfos[cindex].Poly;
	
	if(((PV_PipelineControl&PVP_NO_TRIANGULATE)&&(PV_Mode&PVM_USEHARDWARE))
	||(f->Flags&POLYGON_PLANAR))
	{
		Func(f);
		f->Father=oldm;
		return;
	}
	
    if(f->Poly!=NULL)
    {
        memcpy(&ff,f,sizeof(PVFace));
		ff.V=V;
		ff.NbrVertices=3;
        ff.V[0]=f->Poly->Vertices[0];
		ff.Poly=(PVPoly*)f;
        for(j=1;j<f->Poly->NbrVertices-1;j++)
        {
            ff.V[1]=f->Poly->Vertices[j];
            ff.V[2]=f->Poly->Vertices[j+1];
			Func(&ff);
            TriFill_BufOfs=(UPVD8*)Scr;
        }
    }
    else
	{
		memcpy(&ff,f,sizeof(PVFace));
		ff.V=V;
		ff.NbrVertices=3;
        ff.V[0]=f->V[0];
		ff.Poly=(PVPoly*)f;
        for(j=1;j<f->NbrVertices-1;j++)
        {
            ff.V[1]=f->V[j];
            ff.V[2]=f->V[j+1];
			Func(&ff);
            TriFill_BufOfs=(UPVD8*)Scr;
        }
	}
	f->Father=oldm;
}

void PVAPI PV_Hint(char* hint, UPVD32 val)
{
	if(hint==NULL) return;

	if(strcmp(hint,"PV_FOG_RANGE")==0)
	{
		Hint.FogRange=val;
	}

	if(PV_Mode&PVM_USEHARDWARE)
		if(PV_GetHardwareDriver()->SetHint!=NULL)
			PV_GetHardwareDriver()->SetHint(hint,val);
}

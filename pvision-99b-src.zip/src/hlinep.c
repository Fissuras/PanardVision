/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include <string.h>
#include "pvision.h"

// Acces au tableau de Genfill
extern unsigned GenFill_Modifier[MAX_INCREMENT];

// Pour les SLINE
void (__cdecl *SLineRoutine)(unsigned, unsigned);
void (__cdecl *HLPInitFunc)(void);

/*static*/double FDIV_precalc[AFFINE_LENGTH];
          double FDIV_precalc2[AFFINE_LENGTH];

// 1/Z increment 0
double GradientXAff[MAX_INCREMENT];

// Nombre d'increment flottant a ne *pas* convertir en entier
int GenPHLine_NbrIncF2F=0;

// Ratio pour AUTOMATIC
static float AutoRatio=(float)0.6;

#ifndef __386__
static double GradientXSav[MAX_INCREMENT];
#endif

void TRIFILLP_Init(void)
{
    unsigned i;
    for(i=1;i<AFFINE_LENGTH;i++)
    {
        FDIV_precalc[i]=65536.0*1/(double)i;
        FDIV_precalc2[i]=1/(double)i;
    }
}

void PVAPI PV_SetAutomaticPerspectiveRatio(float r)
{
    AutoRatio=r;
}

float PVAPI PV_GetAutomaticPerspectiveRatio(float r)
{
    return AutoRatio;
}

int PVAPI PerspectiveNeeded(float z1,float z2,float z3)
{
    float min,max;

    // Cherche les extremas en Z
    if(z1>z2)
    {
        if(z2>z3)
        {
            min=z3;
            max=z1;
        }
        else
        {
            min=z2;
            if(z1>z3) max=z1; else max=z3;
        }
    }
    else
    {
        if(z1>z3)
        {
            max=z2;
            min=z3;
        }
        else
        {
            min=z1;
            if(z2>z3) max=z2; else max=z3;
        }
    }

    // Calul du ratio
    if(fabs(max/min)>AutoRatio) return 0; else return 1;
}

#ifndef __386__
void __cdecl GenPHLine(unsigned deb,unsigned fin)
{
    unsigned length=fin-deb;
    unsigned Subdivisions,LengthLeft;
    unsigned i;

    double RightValOverZ[MAX_INCREMENT];
    double LeftVal[MAX_INCREMENT];
    double RightVal[MAX_INCREMENT];
    double CombinedZ;
    double t;

    // Sauvegarde des valeurs
    memcpy(GradientXSav,GenFill_GradientX,GenFill_NbrIncF*sizeof(double));

    Subdivisions=length/AFFINE_LENGTH;
    LengthLeft=length&(AFFINE_LENGTH-1);

    if(Subdivisions)
        for(i=0;i<GenFill_NbrIncF;i++) {
            RightValOverZ[i]=GenFill_CurrentLeftValF[i]+GradientXAff[i];
        }
    else
        memcpy(RightValOverZ,GenFill_CurrentLeftValF,GenFill_NbrIncF*sizeof(double));

    // ZG*ZD
    CombinedZ=1/(GenFill_CurrentLeftValF[0]*RightValOverZ[0]);

    // ZG*ZD*1/ZD
    LeftVal[0]=CombinedZ*RightValOverZ[0];
    for(i=1;i<GenFill_NbrIncF;i++) {
        LeftVal[i]=LeftVal[0]*GenFill_CurrentLeftValF[i];
    }

    RightVal[0]=CombinedZ*GenFill_CurrentLeftValF[0];

    while(Subdivisions-->0)
    {
        for(i=1;i<GenPHLine_NbrIncF2F;i++) {
            RightVal[i]=RightVal[0]*RightValOverZ[i];
            GenFill_CurrentLeftValF[i-1]=LeftVal[i];
            GenFill_GradientX[i-1]=(RightVal[i]-LeftVal[i])*(1/((double)AFFINE_LENGTH));
        }

        for(i=GenPHLine_NbrIncF2F;i<GenFill_NbrIncF;i++) {
            RightVal[i]=RightVal[0]*RightValOverZ[i];
			GenFill_CurrentLeftVal[i-1]=(int)(LeftVal[i]*65536.0)+GenFill_Modifier[i];
            GenFill_iGradientX[i-1]=(int)((RightVal[i]-LeftVal[i])*(65536.0/AFFINE_LENGTH));
        }

		SLineRoutine(deb,deb+AFFINE_LENGTH);
		deb+=AFFINE_LENGTH;

        memcpy(LeftVal,RightVal,GenFill_NbrIncF*sizeof(double));

        if(Subdivisions>0)
        {
            for(i=0;i<GenFill_NbrIncF;i++) {
                RightValOverZ[i]+=GradientXAff[i];
            }
            RightVal[0]=1/RightValOverZ[0];
        }
    }

    if(LengthLeft)
    {
        for(i=0;i<GenFill_NbrIncF;i++){
            RightValOverZ[i]+=(LengthLeft-1)*GradientXSav[i];
        }

        RightVal[0]=1/RightValOverZ[0];

        for(i=1;i<GenPHLine_NbrIncF2F;i++) {
            RightVal[i]=RightVal[0]*RightValOverZ[i];
            GenFill_CurrentLeftValF[i-1]=LeftVal[i];
        }

        for(i=GenPHLine_NbrIncF2F;i<GenFill_NbrIncF;i++) {
            RightVal[i]=RightVal[0]*RightValOverZ[i];
            GenFill_CurrentLeftVal[i-1]=(int)(LeftVal[i]*65536.0)+GenFill_Modifier[i];
        }

        if(--LengthLeft)
        {
            // 1 pixel lines, gare a la div /0
            t=FDIV_precalc2[LengthLeft];
            for(i=1;i<GenPHLine_NbrIncF2F;i++) {
                GenFill_GradientX[i-1]=((RightVal[i]-LeftVal[i])*t);
            }
            t=FDIV_precalc[LengthLeft];
            for(i=GenPHLine_NbrIncF2F;i<GenFill_NbrIncF;i++) {
				GenFill_iGradientX[i-1]=(int)((RightVal[i]-LeftVal[i])*t);
            }
        }

        SLineRoutine(deb,deb+LengthLeft+1);


        // Correction SBuffer
        for(i=0;i<GenFill_NbrIncF;i++){
            RightValOverZ[i]+=GradientXSav[i];
        }
    }

    // MAJ pour le SBUffer
    memcpy(GenFill_CurrentLeftValF,RightValOverZ,GenFill_NbrIncF*sizeof(double));

    // Restauration des valeurs
    memcpy(GenFill_GradientX,GradientXSav,GenFill_NbrIncF*sizeof(double));

}
#endif

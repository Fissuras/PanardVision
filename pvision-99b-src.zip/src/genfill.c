/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "pvision.h"
#include "fpu.h"
#include "fillcom.h"

typedef struct _Edge
{
    double Slope;
    PVD32 ESlope;
    PVD32 FSlope;

    PVD32 EX;
    PVD32 FX;

    double XPreStep,YPreStep;

    int Direction,CurrentStart,CurrentEnd;
    int RemainingScans;
} Edge;

// Cliping
int   ClipMinX=0;
int   ClipMinY=0;
int   ClipMaxX=319;
int   ClipMaxY=199;

unsigned int ScanLength=320;
UPVD8 *TriFill_BufOfs;

// Veriables dispos pour l'user
unsigned GenFill_NbrInc,GenFill_NbrIncF;
float GenFill_InitialValues[2*MAX_VERTICES_PER_POLY][MAX_INCREMENT];

double GenFill_GradientX[MAX_INCREMENT];
int GenFill_iGradientX[MAX_INCREMENT];
double GenFill_GradientY[MAX_INCREMENT];

unsigned GenFill_CurrentLeftVal[MAX_INCREMENT];
double GenFill_CurrentLeftValF[MAX_INCREMENT];

unsigned GenFill_Modifier[MAX_INCREMENT];

PVFace *GenFill_CurrentFace;

unsigned GenFill_Height;
unsigned GenFill_CurrentY;

// Variables Internes
static Edge *lEdge,*rEdge;
static unsigned GenFill_EdgeStep[MAX_INCREMENT];
static double GenFill_EdgeStepF[MAX_INCREMENT];
static unsigned GenFill_CurrentEdgeVal[MAX_INCREMENT];
static double GenFill_CurrentEdgeValF[MAX_INCREMENT];

static Edge LeftEdge,RightEdge;

static PVMesh *o;
static float yf[2*MAX_VERTICES_PER_POLY],xf[2*MAX_VERTICES_PER_POLY];
static int yc[2*MAX_VERTICES_PER_POLY],xc[2*MAX_VERTICES_PER_POLY];
static double GradientDeno;

static char Clipped,Blending;
static void (*BlendRoutine)(unsigned, unsigned);

static unsigned tmp;

static unsigned i;
static int XG,XD;

static int NumVtx;
static unsigned *vtx;

// SBuffer
static TSBuffer *b,*LastSeg=NULL,**FSB;

// ZBuffer
float *ZBuffer=NULL;
static double *Gradient1OverZx=NULL;
static double *Current1OverZLeft=NULL;
static float *CurrentZBufferRow=NULL;
static char ZBEnable;
static void (PVAPI * ZBufferClearRoutine)(void)=PV_ClearZBufferNormal;

// MipMap
static float MipBias=1.5;

/*-------------------------------- Gestion des segments SBuffer ------------*/
TSBuffer **SBuffer=NULL;
unsigned SBufferNbrBlocksAllocated=0;
TSBuffer **SBufferBlocks=NULL;
unsigned SBufferSize=0;
unsigned SBufferN=SBUFFER_BLOCK_SEG,SBufferCurrentBlock=0;
TSBuffer *SBufferCurrentSeg=NULL;

// Conversion float -> Int sur x86
#ifdef __386__
static double intScale=6755399441055744.0;     // Pour des doubles en precision normal (53bits)
static double d1;
static int *pInt=(int*)&d1;                    // double
#endif


/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef __WATCOMC__
#pragma intrinsic(SetupEdge)
#pragma intrinsic(ComputeGradients)
#pragma intrinsic(ComputeGradientsDeno)
#pragma intrinsic(Int16Ceil)
#pragma intrinsic(SetupInc)
#pragma intrinsic(GenFill_StepScanLine)
#pragma intrinsic(SBInc)
#endif

static inline void ComputeGradientsDeno(void)
{
    GradientDeno=1/((xf[1]-xf[NumVtx-1])*(yf[0]-yf[NumVtx-1])-(xf[0]-xf[NumVtx-1])*(yf[1]-yf[NumVtx-1]));
}

static inline void ComputeGradients(double c1,double c2,double c3,double *GradientCX,double *GradientCY)
{
    *GradientCX=((c2-c3)*(yf[0]-yf[NumVtx-1])-(c1-c3)*(yf[1]-yf[NumVtx-1]))*GradientDeno;
    *GradientCY=-((c2-c3)*(xf[0]-xf[NumVtx-1])-(c1-c3)*(xf[1]-xf[NumVtx-1]))*GradientDeno;
}

static inline void SetupEdge(int i1,int i2,int decal,Edge *e)
{
    double a,b,c,ooc=1;
#ifndef __386__
    double m;
#endif

    if((c=yf[i2]-yf[i1])!=1)
    {
        ooc=1/c;
        a=(xf[i2]-xf[i1])*ooc;
    }
    else a=(xf[i2]-xf[i1]);

    e->Slope=a;

    b=(xf[i2]-xf[i1])*(yc[i1]-yf[i1]+decal);
    b*=ooc;
    b+=1+xf[i1];;

#ifdef __386__
    d1=a+intScale;
    e->ESlope=*pInt;
    e->FSlope=(a-(double)(*pInt))*(1<<30);

    d1=b+intScale;
    e->EX=*pInt;
    e->FX=(b-(double)(*pInt))*(1<<30);
#else
    e->ESlope=floor(a);
    e->FSlope=modf(a,&m)*(double)(1<<30);
    if(e->FSlope<0) e->FSlope=(1<<30)+e->FSlope;

    e->EX=floor(b);
    e->FX=modf(b,&m)*(double)(1<<30);
    if(e->FX<0) e->FX=(1<<30)+e->FX;

#endif
}

static inline void SetupInc(unsigned i1)
{
    lEdge->XPreStep=(double)(lEdge->EX)-xf[i1];
    lEdge->YPreStep=(double)GenFill_CurrentY-yf[i1];

    for(i=0;i<GenFill_NbrIncF;i++) {
        GenFill_CurrentEdgeValF[i]=GenFill_InitialValues[i1][i]
            +lEdge->YPreStep*GenFill_GradientY[i]+lEdge->XPreStep*GenFill_GradientX[i];
        GenFill_EdgeStepF[i]=(lEdge->ESlope*GenFill_GradientX[i])+GenFill_GradientY[i];
    }

#ifdef __386__
    for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) {
        d1=intScale+65536*(GenFill_InitialValues[i1][i]
            +lEdge->YPreStep*GenFill_GradientY[i]+lEdge->XPreStep*GenFill_GradientX[i]);
        GenFill_CurrentEdgeVal[i]=*pInt;

        d1=intScale+65536*((lEdge->ESlope*GenFill_GradientX[i])+GenFill_GradientY[i]);
        GenFill_EdgeStep[i]=*pInt;
    }
#else
    for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) {
        GenFill_CurrentEdgeVal[i]=(int)(65536*(GenFill_InitialValues[i1][i]
            +lEdge->YPreStep*GenFill_GradientY[i]+lEdge->XPreStep*GenFill_GradientX[i]));
        GenFill_EdgeStep[i]=(int)(65536*((lEdge->ESlope*GenFill_GradientX[i])+GenFill_GradientY[i]));
    }
#endif


    if(ZBEnable&2)
    {
        GenFill_CurrentEdgeValF[MAX_INCREMENT-1]=o->Projected[vtx[i1]].InvertZ+lEdge->YPreStep*GenFill_GradientY[MAX_INCREMENT-1]+lEdge->XPreStep*GenFill_GradientX[MAX_INCREMENT-1];
        GenFill_EdgeStepF[MAX_INCREMENT-1]=(lEdge->ESlope*GenFill_GradientX[MAX_INCREMENT-1])+GenFill_GradientY[MAX_INCREMENT-1];
    }
}

static inline void GenFill_StepScanLine(void)
{
        lEdge->EX+=lEdge->ESlope;
        rEdge->EX+=rEdge->ESlope;

        for(i=0;i<GenFill_NbrIncF;i++) GenFill_CurrentEdgeValF[i]+=GenFill_EdgeStepF[i];
        for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) GenFill_CurrentEdgeVal[i]+=GenFill_EdgeStep[i];

        if(ZBEnable&2)
        {
            GenFill_CurrentEdgeValF[MAX_INCREMENT-1]+=GenFill_EdgeStepF[MAX_INCREMENT-1];
        }

        lEdge->FX+=lEdge->FSlope;
        if(lEdge->FX>=(1<<30)) {
            lEdge->FX-=(1<<30);
            lEdge->EX++;

            for(i=0;i<GenFill_NbrIncF;i++) GenFill_CurrentEdgeValF[i]+=GenFill_GradientX[i];
            for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) GenFill_CurrentEdgeVal[i]+=GenFill_iGradientX[i];

            if(ZBEnable&2)
            {
                GenFill_CurrentEdgeValF[MAX_INCREMENT-1]+=GenFill_GradientX[MAX_INCREMENT-1];
            }
        }

        // Step Droit
        rEdge->FX+=rEdge->FSlope;
        if(rEdge->FX>=(1<<30)) {
            rEdge->FX-=(1<<30);
            rEdge->EX++;
        }
}

// Awful hack :)
#define POS_MODIFIERL	0
#define NEG_MODIFIERL	-0x8000
#define POS_MODIFIER	0
#define NEG_MODIFIER	POS_MODIFIER-1

static inline void SetupModifiersL(unsigned index)
{
    if(GenFill_GradientX[index]>0) GenFill_Modifier[index]=POS_MODIFIERL;
        else
            if(GenFill_GradientX[index]<0) GenFill_Modifier[index]=NEG_MODIFIERL;
            else
                if(GenFill_GradientY[index]>0) GenFill_Modifier[index]=POS_MODIFIERL;
                else GenFill_Modifier[index]=NEG_MODIFIERL;
}

static inline void SetupModifiers(unsigned index)
{
    double dUdXIndicator = GenFill_GradientX[index] * GenFill_InitialValues[0][0] - GenFill_InitialValues[0][index] * GenFill_GradientX[0];

	if(dUdXIndicator > 0)
	{
        GenFill_Modifier[index] = POS_MODIFIER;
	}
	else
	if(dUdXIndicator < 0)
	{
        GenFill_Modifier[index] = NEG_MODIFIER;
	}
	else
	{
        double dUdYIndicator = GenFill_GradientY[index] * GenFill_InitialValues[0][0] -
                                GenFill_InitialValues[0][index] * GenFill_GradientY[0];

		if(dUdYIndicator >= 0)
		{
            GenFill_Modifier[index] = POS_MODIFIER;
		}
		else
		{
            GenFill_Modifier[index] = NEG_MODIFIER;
		}
	}
}

void PVAPI GenFill_Wrap(unsigned i)
{
    float maxu,minu,d;

    // Gestion du Wrapping de texture en direct de Autodesk
    maxu=minu=GenFill_InitialValues[0][i];
    if (GenFill_InitialValues[1][i]>maxu) maxu=GenFill_InitialValues[1][i];
    else if (GenFill_InitialValues[1][i]<minu) minu=GenFill_InitialValues[1][i];

    if (GenFill_InitialValues[2][i]>maxu) maxu=GenFill_InitialValues[2][i];
    else if (GenFill_InitialValues[2][i]<minu) minu=GenFill_InitialValues[2][i];

    if((d=maxu-minu)>(0.8))
    {
        d=ceil(d);
        if(GenFill_InitialValues[0][i]<(0.5)) GenFill_InitialValues[0][i]+=d;
        if(GenFill_InitialValues[1][i]<(0.5)) GenFill_InitialValues[1][i]+=d;
        if(GenFill_InitialValues[2][i]<(0.5)) GenFill_InitialValues[2][i]+=d;
    }
}

unsigned PVAPI GetMipMap(unsigned nbrmips,float mu,float mv)   // Pour le gradients lineaires
{
        int i;
        float a;

        for(i=0;i<nbrmips;i++)
        {
            a=2<<i;
            if((mu<a)&&(mv<a)) return i;
        }
        return nbrmips-1;
}

unsigned PVAPI GetMipMapIndex(PVFace *f,unsigned incu,unsigned incv)          // Pour le perspective
{
    float dy,dx;
    float du,dv;
    float a,b,d;
	unsigned nbrmips,cindex;

	nbrmips=f->MaterialInfo->NbrMipMaps;
	cindex=f-f->Father->Face;
	d=f->Father->FaceInfos[cindex].DistanceToCam;

    // Recherche de la ligne  de Z Constant

    a=fabs(GenFill_GradientX[0]);
    b=fabs(GenFill_GradientY[0]);

    if(a==b) {dx=dy=1;}
    else
    if(a>b)
    {

        dx=-GenFill_GradientY[0]/GenFill_GradientX[0];
        dy=1;
    }
    else
    {
        dy=-GenFill_GradientX[0]/GenFill_GradientY[0];
        dx=1;
    }

    du=(dy*GenFill_GradientY[incu]+dx*GenFill_GradientX[incu])*d;
    dv=(dy*GenFill_GradientY[incv]+dx*GenFill_GradientX[incv])*d;
    du=fabs(MipBias*du*(GenFill_CurrentFace->MaterialInfo->Tex[0].Width));
    dv=fabs(MipBias*dv*(GenFill_CurrentFace->MaterialInfo->Tex[0].Height));

    return GetMipMap(nbrmips,du,dv);
}

void PVAPI PV_SetPerspectiveMipBias(float bias)
{
    MipBias=bias;
}

/////////////////////////////////////////////////////////////////// ZBufer

void PVAPI PV_SetZBufferClearRoutine(void (PVAPI * ZBufferRoutine)(void))
{
    ZBufferClearRoutine=ZBufferRoutine;
}

void PVAPI PV_ClearZBuffer(void)
{
    if(ZBufferClearRoutine!=NULL) ZBufferClearRoutine();
}

void PVAPI PV_ClearZBufferNormal(void)
{
#ifdef __386__
    static float clear=0;
    unsigned nbr=((ClipMaxX-ClipMinX+1)*(ClipMaxY-ClipMinY+1))>>1;
#endif

    if (ZBuffer==NULL) return;

#if defined(__386__) && !defined(__UNIX__) && !defined(DJGPP)
    _asm {
            fld clear
            mov edx,ZBuffer
            mov ecx,nbr

        zeloop:
            fst qword ptr [edx]
            add edx,8
            dec ecx
            jnz zeloop

            fstp st(0)
    }

#else
    memset(ZBuffer,0x00,((ClipMaxX-ClipMinX+1)*(ClipMaxY-ClipMinY+1))*sizeof(float));
#endif
}

float * PVAPI PV_GetZBuffer(void)
{
	return ZBuffer;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
static inline void SBInc(unsigned a,unsigned b)
{
     unsigned i;
     for(i=0;i<GenFill_NbrIncF;i++) GenFill_CurrentLeftValF[i]+=(a-b+1)*GenFill_GradientX[i];
     for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) GenFill_CurrentLeftVal[i]+=(a-b+1)*GenFill_iGradientX[i];
}

#include "gpart.inc"
#define __SBUFFER_H__
#include "gpart.inc"

/////////////////////////////////////////////////////////////////////////////////////////////////////

static int SetupPolyEdge(Edge *edge,int StartVert,int MaxVtx)
{
    int NextVert;

    if(edge->RemainingScans>0) return  1;

    for(;;)
    {
        if(StartVert==MaxVtx) return 0;

        NextVert=StartVert+edge->Direction;
        if(NextVert>=NumVtx)
            NextVert=0;
        else
            if(NextVert<0)
                NextVert=NumVtx-1;

        if((yc[NextVert]-yc[StartVert])>0)
        if(yc[NextVert]>=ClipMinY)
        if(yc[StartVert]<=ClipMaxY)
        {
            if (yc[NextVert]<=ClipMaxY)
               edge->RemainingScans=yc[NextVert]-GenFill_CurrentY;
            else
               edge->RemainingScans=ClipMaxY-GenFill_CurrentY;

            if(edge->RemainingScans>0)
            {
                edge->CurrentEnd=NextVert;
                edge->CurrentStart=StartVert;
                SetupEdge(StartVert,NextVert,GenFill_CurrentY-yc[StartVert],edge);
                return 1;
            }
        }
        StartVert=NextVert;
    }
}

///////////////////////////////////////////////////////////// Magic Blender
UPVD8 *__MBTmpBuf=NULL;
static UPVD8 *oldbuff=NULL;
static unsigned minx=0,maxx=0,maxy=0,miny=0;
static int stride;
static float calpha,omcalpha;

static void BlendFunc(PVRGB *src,PVRGB *dst)
{
	PVMaterial *m=GenFill_CurrentFace->MaterialInfo;
	unsigned R,G,B;

	// 0-0
	if((m->BlendRgbSrcFactor==BLEND_ZERO)&&(m->BlendRgbDstFactor==BLEND_ZERO))
	{
		dst->r=dst->g=dst->b=0;
		return;
	}
	else
	// 1-1
	if((m->BlendRgbSrcFactor==BLEND_ONE)&&(m->BlendRgbDstFactor==BLEND_ONE))
	{
		R=src->r+dst->r;
		G=src->g+dst->g;
		B=src->b+dst->b;
		
		if(R>255) R=255;
		if(G>255) G=255;
		if(B>255) B=255;

		dst->r=R;
		dst->g=G;
		dst->b=B;

		return;
	}
	else
	// DstCol-0
	if((m->BlendRgbSrcFactor==BLEND_DST_COLOR)&&(m->BlendRgbDstFactor==BLEND_ZERO))
	{
		R=src->r*dst->r;
		G=src->g*dst->g;
		B=src->b*dst->b;

		dst->r=R;
		dst->g=G;
		dst->b=B;

		return;
	}
	else
	// SrcAlpha-(1-SrcAlpha) with AlphaConstant
	if((m->BlendRgbSrcFactor==BLEND_SRC_ALPHA)&&(m->BlendRgbDstFactor==BLEND_ONE_MINUS_SRC_ALPHA))
	{
		float a,b;

		a=calpha;
		b=omcalpha;

#ifdef __386__
		d1=(a*((float)src->r)+b*((float)dst->r))+intScale;
		R=*pInt;		
		d1=(a*((float)src->g)+b*((float)dst->g))+intScale;
		G=*pInt;
		d1=(a*((float)src->b)+b*((float)dst->b))+intScale;
		B=*pInt;
#else
		R=(float)src->r*a+b*dst->r;
		G=(float)src->g*a+b*dst->g;
		B=(float)src->b*a+b*dst->b;
#endif
		dst->r=R;
		dst->g=G;
		dst->b=B;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////

static void HLineBlender16(unsigned deb,unsigned fin)
{
    unsigned length;
	UPVD16 *ofs2;
	PVRGB src,dst;
	UPVD16 t;

    length=fin-deb;
    ofs2=(UPVD16*)TriFill_BufOfs;
    ofs2+=deb;

	ofs16=(UPVD16*)(((unsigned)ofs2)-stride);

    while(length--!=0)
    {
		t=*(ofs16);

		dst.r=((t&RedMask)>>RFieldPos)<<(8-RMaskSize);
		dst.g=((t&GreenMask)>>GFieldPos)<<(8-GMaskSize);
		dst.b=((t&BlueMask)>>BFieldPos)<<(8-BMaskSize);

		t=*(ofs2);

		src.r=((t&RedMask)>>RFieldPos)<<(8-RMaskSize);
		src.g=((t&GreenMask)>>GFieldPos)<<(8-GMaskSize);
		src.b=((t&BlueMask)>>BFieldPos)<<(8-BMaskSize);

		BlendFunc(&src,&dst);

		t=((dst.r>>(8-RMaskSize))<<RFieldPos)|
		  ((dst.g>>(8-GMaskSize))<<GFieldPos)|
		  ((dst.b>>(8-BMaskSize))<<BFieldPos);

		*(ofs16)=t;

		ofs16++;
		ofs2++;
    }

}

static void HLineBlender24(unsigned deb,unsigned fin)
{
	unsigned length;
	PVRGB src,dst;
	UPVD8 *ofs2;

    length=fin-deb;
    ofs2=TriFill_BufOfs;
    ofs2+=deb*3;

	ofs=ofs2-stride;

    while(length--!=0)
    {
        dst.r=*(ofs++);
        dst.g=*(ofs++);
        dst.b=*(ofs++);

		src.r=*(ofs2++);
		src.g=*(ofs2++);
		src.b=*(ofs2++);

		ofs-=3;
		BlendFunc(&src,&dst);

		(*ofs++)=dst.r;
		(*ofs++)=dst.g;
		(*ofs++)=dst.b;
    }
}

static void HLineBlender32(unsigned deb,unsigned fin)
{
	unsigned length;
	PVRGB src,dst;
	UPVD8 *ofs2;
	UPVD32 t;

    length=fin-deb;
    ofs2=TriFill_BufOfs;
    ofs2+=deb*4;

	ofs=ofs2-stride;

    while(length--!=0)
    {

		t=*((PVD32*)ofs);

		dst.r=(t&RedMask)>>RFieldPos;
		dst.g=(t&GreenMask)>>GFieldPos;
		dst.b=(t&BlueMask)>>BFieldPos;

		t=*((PVD32*)ofs2);

		src.r=(t&RedMask)>>RFieldPos;
		src.g=(t&GreenMask)>>GFieldPos;
		src.b=(t&BlueMask)>>BFieldPos;

		BlendFunc(&src,&dst);

		t=(dst.r<<RFieldPos)|(dst.g<<GFieldPos)|(dst.b<<BFieldPos);

		*((PVD32*)ofs)=t;

		ofs+=4;
		ofs2+=4;
    }

}

void PVAPI PV_SetNewSWRenderBuffer(UPVD8 *buf)
{
    TriFill_BufOfs=buf;
    oldbuff=NULL;
}

static void PVAPI GenFillerPoly(PVFace *f,FillerUserFunct *FUT)
{
    unsigned a,c;
    int MaxI,MinI,b;
    float MaxY,MinY;	

    // Init
    GenFill_CurrentFace=f;
    o=f->Father;

	// MagicBlender	
	Blending=0;
	if(oldbuff!=NULL) {TriFill_BufOfs=oldbuff; oldbuff=NULL;}
	if((PV_Mode&PVM_ALPHABLENDING)&&(PV_Mode&(PVM_RGB|PVM_RGB16))&&(f->MaterialInfo->Type&BLENDING))
	{
		PVMaterial *m=f->MaterialInfo;

		// 0-1
		if((m->BlendRgbSrcFactor==BLEND_ZERO)&&(m->BlendRgbDstFactor==BLEND_ONE)) return;

		// 1-0
		if(!((m->BlendRgbSrcFactor==BLEND_ONE)&&(m->BlendRgbDstFactor==BLEND_ZERO)))
		{
			Blending=1;

			switch(PixelSize)
			{
				case 2:BlendRoutine=HLineBlender16;break;
				case 3:BlendRoutine=HLineBlender24;break;
				case 4:BlendRoutine=HLineBlender32;break;
				default:PV_Fatal("MBlender: Unsupported pixel size\n",PixelSize);
			}

				// Allocates tmp buffer
				if((minx!=ClipMinX)||(maxx!=ClipMaxX)||(maxy!=ClipMaxY)||(miny!=ClipMinY))
				{
				   free(__MBTmpBuf);
				   __MBTmpBuf=(UPVD8*)malloc((ScanLength/PixelSize)*(ClipMaxY+1)*PixelSize);
				   if(__MBTmpBuf==NULL) PV_Fatal("MagicBlender : Not enough memory\n",0);

				   minx=ClipMinX;
				   maxx=ClipMaxX;
				   miny=ClipMinY;
				   maxy=ClipMaxY;
				}

				stride=__MBTmpBuf-TriFill_BufOfs;

				// Render le triangle a blender dans le buffer tempo
				oldbuff=TriFill_BufOfs;
				TriFill_BufOfs=__MBTmpBuf;				

	 			if(f->MaterialInfo->Type&FLAT)
				{
					calpha=o->Shading[vtx[0]].Color.a*GenFill_CurrentFace->MaterialInfo->AlphaConstant;
					omcalpha=1.0-calpha;
				}
				else
				{
					calpha=GenFill_CurrentFace->MaterialInfo->AlphaConstant;
					omcalpha=1.0-calpha;
				}
		}
	}

	if(f->Flags&POLYGON_PLANAR)
	{
		if(f->Poly==NULL)
	    {
	        NumVtx=f->NbrVertices;
	        vtx=f->V;
	    }
	    else
	    {
	        NumVtx=f->Poly->NbrVertices;
	        vtx=f->Poly->Vertices;
	    }
	}
	else
	{
		NumVtx=f->NbrVertices;
	    vtx=f->V;
	}

    for(i=0;i<NumVtx;i++) yf[i]=o->Projected[vtx[i]].yf;

    // Tri des points
    MaxY=MinY=yf[MaxI=MinI=0];
    for(i=1;i<NumVtx;i++)
    {
        if(yf[i]<MinY) MinY=yf[MinI=i];
        else
        if(yf[i]>MaxY) MaxY=yf[MaxI=i];

    }

#ifdef __386__
    // Ceiling maison
    SetFPU_Up();

    for(i=0;i<NumVtx;i++)
    {
        d1=yf[i]+intScale;
        yc[i]=*pInt;
    }

    // Turbo Clip Y
    if ((yc[MaxI]-yc[MinI])==0) return;
    if (yc[MaxI]<ClipMinY) return;
    if (yc[MinI]>ClipMaxY) return;

    for(i=0;i<NumVtx;i++)
    {
        xf[i]=o->Projected[vtx[i]].xf-0.5;
        d1=xf[i]+intScale;
        xc[i]=*pInt;
    }

#else
    for(i=0;i<NumVtx;i++) yc[i]=(int)ceil(yf[i]);

    // Turbo Clip Y
    if ((yc[MaxI]-yc[MinI])==0) return;
    if (yc[MaxI]<ClipMinY) return;
    if (yc[MinI]>ClipMaxY) return;

    for(i=0;i<NumVtx;i++)
    {
        xf[i]=o->Projected[vtx[i]].xf-0.5;
        xc[i]=(int)ceil(xf[i]);
    }
#endif

    // Turbo Clip X
    for(i=0;i<NumVtx;i++)
    {
        if((xc[i]>=ClipMinX)&&(xc[i]<=ClipMaxX)) break;
    }
    if(i==NumVtx) return;

    // Init Utilisateur
    GenFill_NbrInc=GenFill_NbrIncF=0;
    GenPHLine_NbrIncF2F=0;
    if(FUT->InitFunc1(NumVtx,vtx)) return;	
    GenPHLine_NbrIncF2F++;

    ComputeGradientsDeno();
    for(i=0;i<GenFill_NbrIncF;i++) {
        ComputeGradients(GenFill_InitialValues[0][i],GenFill_InitialValues[1][i],GenFill_InitialValues[NumVtx-1][i],&GenFill_GradientX[i],&GenFill_GradientY[i]);
    }

#ifdef __386__
    SetFPU_Chop0();
    for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) {
        ComputeGradients(GenFill_InitialValues[0][i],GenFill_InitialValues[1][i],GenFill_InitialValues[NumVtx-1][i],&GenFill_GradientX[i],&GenFill_GradientY[i]);
        d1=GenFill_GradientX[i]*65536+intScale;
        GenFill_iGradientX[i]=*pInt;
    }
#else
    for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) {
        ComputeGradients(GenFill_InitialValues[0][i],GenFill_InitialValues[1][i],GenFill_InitialValues[NumVtx-1][i],&GenFill_GradientX[i],&GenFill_GradientY[i]);
        GenFill_iGradientX[i]=(int)(GenFill_GradientX[i]*65536);
    }
#endif
	
    // Init Utilisateur
    FUT->InitFunc2(NumVtx);

    // Enabling du ZBuffer
    if((PV_Mode&PVM_ZBUFFER)&&(f->MaterialInfo->Type&ZBUFFER))
    {
        if(f->MaterialInfo->Type&PERSPECTIVE)
        {
            ZBEnable=1;
            Gradient1OverZx=GenFill_GradientX;
            Current1OverZLeft=GenFill_CurrentLeftValF;
        }
        else
        {
            ZBEnable=2;
            Gradient1OverZx=&GenFill_GradientX[MAX_INCREMENT-1];
            Current1OverZLeft=&GenFill_CurrentLeftValF[MAX_INCREMENT-1];
            ComputeGradients(o->Projected[vtx[0]].InvertZ,o->Projected[vtx[1]].InvertZ,o->Projected[vtx[NumVtx-1]].InvertZ,&GenFill_GradientX[MAX_INCREMENT-1],&GenFill_GradientY[MAX_INCREMENT-1]);
        }
    }
    else ZBEnable=0;

    for(i=1;i<GenFill_NbrIncF;i++) SetupModifiers(i);
    for(i=GenFill_NbrIncF;i<GenFill_NbrInc;i++) SetupModifiersL(i);

    // Calcul Offset dans le buffer et setup variables de positions
    if(yc[MinI]<ClipMinY) GenFill_CurrentY=ClipMinY; else GenFill_CurrentY=yc[MinI];
    TriFill_BufOfs+=GenFill_CurrentY*ScanLength;

    if(ZBEnable)
        CurrentZBufferRow=ZBuffer+(GenFill_CurrentY-ClipMinY)*(ClipMaxX-ClipMinX+1);

    Clipped=0;
    for(i=0;i<NumVtx;i++)
    {
        if(xc[i]<ClipMinX)
        {Clipped=1;break;}
        if(xc[i]>ClipMaxX)
        {Clipped=1;break;}
    }

    LeftEdge.Direction=-1;
    LeftEdge.RemainingScans=0;
    SetupPolyEdge(&LeftEdge,MinI,MaxI);
    RightEdge.Direction=1;
    RightEdge.RemainingScans=0;
    SetupPolyEdge(&RightEdge,MinI,MaxI);

    // Selctionne l'edge gauche et droite
	rEdge=&LeftEdge;
	lEdge=&RightEdge;

	// WARNING !! C'est peut etre pas totalement juste comme conditions de
	// choix
	if(lEdge->CurrentStart==rEdge->CurrentStart)
	{
		if(lEdge->Slope>rEdge->Slope)
		{
			lEdge=&LeftEdge;
			rEdge=&RightEdge;
		}
	}
	else
	{
		if(lEdge->EX>rEdge->EX)
		{
			lEdge=&LeftEdge;
			rEdge=&RightEdge;
		}
		else
			if(lEdge->EX==rEdge->EX)
			{
				if(lEdge->CurrentEnd==rEdge->CurrentEnd)
				{
					if(lEdge->Slope<rEdge->Slope)
					{
						lEdge=&LeftEdge;
						rEdge=&RightEdge;
					}
				}
				else
				if(xf[lEdge->CurrentEnd]>xf[rEdge->CurrentEnd])
				{
					lEdge=&LeftEdge;
					rEdge=&RightEdge;
				}
			}
	}

    SetupInc(lEdge->CurrentStart);

    for(;;)
    {
        c=min(lEdge->RemainingScans,rEdge->RemainingScans);

        GenFill_Height=c;

        // Tracage
        if(ZBEnable) if(Clipped) DoPartClippedZ(); else DoPartNotClippedZ();
        else
        if(PV_Mode&PVM_SBUFFER)
            if(Clipped) DoPartClipped_SB(); else DoPartNotClipped_SB();
        else
            if(Clipped) DoPartClipped(); else DoPartNotClipped();

		lEdge->RemainingScans-=c;
        rEdge->RemainingScans-=c;

		GenFill_CurrentY+=c;
		if(GenFill_CurrentY>ClipMaxY) return;

        a=lEdge->CurrentEnd;
        b=lEdge->RemainingScans;
        if(SetupPolyEdge(lEdge,lEdge->CurrentEnd,MaxI)==0) return;
        if(b<=0) SetupInc(a);

        if(SetupPolyEdge(rEdge,rEdge->CurrentEnd,MaxI)==0) return;
    }
}

static void DoMagicBlender(PVFace *f,FillerUserFunct *FUT);
void PVAPI GenFiller(PVFace *f,FillerUserFunct *FUT)
{
	// MagicBlender
	if((f->MaterialInfo->Type&BLENDING)&&(PV_Mode&PVM_ALPHABLENDING)&&(PV_Mode&(PVM_RGB|PVM_RGB16)))
	{
		// rajouter un test sur la src et dst
		if((f->MaterialInfo->BlendRgbSrcFactor==BLEND_SRC_ALPHA)&&(f->MaterialInfo->BlendRgbDstFactor==BLEND_ONE_MINUS_SRC_ALPHA))
		{
			if(f->MaterialInfo->Type&GOURAUD) 
				DoMagicBlender(f,FUT);			
			else 
				GenFillerPoly(f,FUT);
		}
		else GenFillerPoly(f,FUT);
		return;
	}
	
	GenFillerPoly(f,FUT);
}

///////////////////////////////////////////////////////////// Magic Blender

static void BlendFunc2(PVRGB *src,PVRGB *dst,float alpha)
{
	PVMaterial *m=GenFill_CurrentFace->MaterialInfo;
	unsigned R,G,B;


	// SrcAlpha-(1-SrcAlpha)
	if((m->BlendRgbSrcFactor==BLEND_SRC_ALPHA)&&(m->BlendRgbDstFactor==BLEND_ONE_MINUS_SRC_ALPHA))
	{
		float a,b;

		a=alpha;
		b=1.0-a;

#ifdef __386__
		d1=(a*((float)src->r)+b*((float)dst->r))+intScale;
		R=*pInt;		
		d1=(a*((float)src->g)+b*((float)dst->g))+intScale;
		G=*pInt;
		d1=(a*((float)src->b)+b*((float)dst->b))+intScale;
		B=*pInt;
#else
		R=(float)src->r*a+b*dst->r;
		G=(float)src->g*a+b*dst->g;
		B=(float)src->b*a+b*dst->b;
#endif

	}

	dst->r=R;
	dst->g=G;
	dst->b=B;
}

static void __cdecl HLineBlender16b(unsigned deb,unsigned fin)
{
    unsigned length;
	UPVD16 *ofs2;
	PVRGB src,dst;
	UPVD16 t;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;

	ofs2=(UPVD16*)(((unsigned)ofs16)+stride);

    while(length--!=0)
    {
		t=*(ofs16);

		dst.r=((t&RedMask)>>RFieldPos)<<(8-RMaskSize);
		dst.g=((t&GreenMask)>>GFieldPos)<<(8-GMaskSize);
		dst.b=((t&BlueMask)>>BFieldPos)<<(8-BMaskSize);

		t=*(ofs2);

		src.r=((t&RedMask)>>RFieldPos)<<(8-RMaskSize);
		src.g=((t&GreenMask)>>GFieldPos)<<(8-GMaskSize);
		src.b=((t&BlueMask)>>BFieldPos)<<(8-BMaskSize);

		BlendFunc2(&src,&dst,GenFill_CurrentLeftValF[0]);

		t=((dst.r>>(8-RMaskSize))<<RFieldPos)|
		  ((dst.g>>(8-GMaskSize))<<GFieldPos)|
		  ((dst.b>>(8-BMaskSize))<<BFieldPos);

		*(ofs16)=t;

		ofs16++;
		ofs2++;

		GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
    }

}

static void __cdecl HLineBlender24b(unsigned deb,unsigned fin)
{
	unsigned length;
	PVRGB src,dst;
	UPVD8 *ofs2;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;

	ofs2=ofs+stride;

    while(length--!=0)
    {
        dst.r=*(ofs++);
        dst.g=*(ofs++);
        dst.b=*(ofs++);

		src.r=*(ofs2++);
		src.g=*(ofs2++);
		src.b=*(ofs2++);

		ofs-=3;
		BlendFunc2(&src,&dst,GenFill_CurrentLeftValF[0]);

		(*ofs++)=dst.r;
		(*ofs++)=dst.g;
		(*ofs++)=dst.b;

		GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
    }
}

static void __cdecl HLineBlender32b(unsigned deb,unsigned fin)
{
	unsigned length;
	PVRGB src,dst;
	UPVD8 *ofs2;
	UPVD32 t;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;

	ofs2=ofs+stride;

    while(length--!=0)
    {

		t=*((PVD32*)ofs);

		dst.r=(t&RedMask)>>RFieldPos;
		dst.g=(t&GreenMask)>>GFieldPos;
		dst.b=(t&BlueMask)>>BFieldPos;

		t=*((PVD32*)ofs2);

		src.r=(t&RedMask)>>RFieldPos;
		src.g=(t&GreenMask)>>GFieldPos;
		src.b=(t&BlueMask)>>BFieldPos;

		BlendFunc2(&src,&dst,GenFill_CurrentLeftValF[0]);

		t=(dst.r<<RFieldPos)|(dst.g<<GFieldPos)|(dst.b<<BFieldPos);

		*((PVD32*)ofs)=t;

		ofs+=4;
		ofs2+=4;

		GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
    }

}

///////////////////////////////////////////////////////////////////////////////////////////

static int __cdecl MBlenderInit1b(int NumVtx,unsigned *vtx) {
	PVMesh *o=GenFill_CurrentFace->Father;

	switch(PixelSize)
	{
	case 2:HLineRoutine=HLineBlender16b;break;
	case 3:HLineRoutine=HLineBlender24b;break;
	case 4:HLineRoutine=HLineBlender32b;break;
	default:PV_Fatal("MBlender: Unsupported pixel size\n",PixelSize);
	}

	GenFill_NbrIncF=1;
	
	for(i=0;i<NumVtx;i++)
    {
		GenFill_InitialValues[i][0]=o->Shading[vtx[i]].Color.a*GenFill_CurrentFace->MaterialInfo->AlphaConstant;
	}

	stride=__MBTmpBuf-TriFill_BufOfs;

	return 0;
}

static void __cdecl MBlenderInit2b(int NumVtx) {
}

static FillerUserFunct FUTBlenderItAlpha={MBlenderInit1b,MBlenderInit2b};

static void DoMagicBlender(PVFace *f,FillerUserFunct *FUT)
{
	PVFLAGS pvm;
	UPVD8 *oldb=NULL;

	// Allocates tmp buffer
	if((minx!=ClipMinX)||(maxx!=ClipMaxX)||(maxy!=ClipMaxY)||(miny!=ClipMinY))
	{
	   free(__MBTmpBuf);
	   __MBTmpBuf=(UPVD8*)malloc((ScanLength/PixelSize)*(ClipMaxY+1)*PixelSize);
       if(__MBTmpBuf==NULL) PV_Fatal("MagicBlender : Not enough memory\n",0);

	   minx=ClipMinX;
	   maxx=ClipMaxX;
	   miny=ClipMinY;
	   maxy=ClipMaxY;
	}

	// Render le triangle a blender dans le buffer tempo
	oldb=TriFill_BufOfs;
	oldbuff=NULL;
	TriFill_BufOfs=__MBTmpBuf;

	pvm=PV_Mode;
	REMOVEFLAG(PV_Mode,PVM_ZBUFFER|PVM_ALPHABLENDING);
	GenFillerPoly(f,FUT);
	
	PV_Mode=pvm;
	REMOVEFLAG(PV_Mode,PVM_ALPHABLENDING);

	TriFill_BufOfs=oldb;	

	// Utilise le magic blender	
	GenFillerPoly(f,&FUTBlenderItAlpha);

	PV_Mode=pvm;
}

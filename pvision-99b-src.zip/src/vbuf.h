/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __PV_VERTEX_BUFFER_H__
#define __PV_VERTEX_BUFFER_H__

#include "pvision.h"

#include "base.h"	
#include "vector3.h"
#include "pverr.h"

#define PVVBT_XYZ							0x1
#define	PVVBT_XY_OOZ						0x2
#define PVVBT_RGBA_DIFF						0x4
#define PVVBT_RGBA_SPEC						0x8
#define PVVBT_XYZ_NORMAL					0x10
#define PVVBT_UV1
#define PVVBT_UV2
#define PVVBT_UV3
#define PVVBT_UV4
#define PVVBT_UV5
#define PVVBT_UV6
#define PVVBT_UV7
#define PVVBT_UV8

struct PVVBS_XYZ
{
	float x,y,z;
};

struct PVVBS_XY_OOZ
{
	float x,y;
	double ooz;
};


class pvVertexBuffer
{
private:
	UPVD8 *_Buffer;
	unsigned _LCount;

	PVFLAGS _Type;
	unsigned _Size,_N;
	bool _DoNotFree;

public:
	pvVertexBuffer();
	~pvVertexBuffer();

	PVERR Create(const PVFLAGS type,const unsigned n);
	PVERR CreateFromMesh(PVMesh *m);
	PVERR Kill();
	void *Lock();
	void UnLock();
	PVERR TransformTo(const pvBase3 &mat,const pvVector3D &p,class pvVertexBuffer &vb) const;
	//PVERR ProjectTo(const double k,const double ofx,const double ofy,pvVertexBuffer &vb) const;
	PVERR pvVertexBuffer::Find2DConvexHull(unsigned *cNumOutIdxs,unsigned **OutHullIdxs) const;

	inline PVFLAGS GetType() const {return _Type;};
	inline unsigned GetSize() const {return _Size;};
	inline unsigned GetNbrItems() const {return _N;};
	inline PVERR Shrink(unsigned newsize) {if(newsize<=_N) {_N=newsize; return PVERR_COOL;} else return PVERR_ARG_INVALID;};
};

#endif
/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard Vision Special FX Plugin
// (C) 1996-99, Olivier Brunet
//
//  You are not permitted to distribute, sell or use any part of
//  this source for your software without special permision of author.
//
// Before using this library consult the LICENSE file

#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "sqrt.h"
#include "pvision.h"

/////////////////////////////////////////////// FOG SPHERE ////////////////////////////////////

#define MAX_FACES_INSIDE_SPHERE		1024

typedef struct __fogParm
{
	float r,g,b;
	float radius;
	float a0,a1,a2;
	float density;
	PVFace *InsideFaces[MAX_FACES_INSIDE_SPHERE];
	unsigned nbrf;
	PVPoint pos;
	PVMesh *fog;
} PVFOGSPHEREParm;

/////////////////////////////////////////////////////////////////////// Honteusement pomp�

typedef struct {
    double  x, y, z;
} point;

typedef struct {
    point     pt[3];	/* Vertices of triangle */
    double    area;	/* Unused; might be used for adaptive subdivision */
} triangle;

typedef struct {
    int       npoly;	/* # of triangles in object */
    triangle *poly;	/* Triangles */
} object;

/* Six equidistant points lying on the unit sphere */
#define XPLUS {  1,  0,  0 }	/*  X */
#define XMIN  { -1,  0,  0 }	/* -X */
#define YPLUS {  0,  1,  0 }	/*  Y */
#define YMIN  {  0, -1,  0 }	/* -Y */
#define ZPLUS {  0,  0,  1 }	/*  Z */
#define ZMIN  {  0,  0, -1 }	/* -Z */

/* Vertices of a unit octahedron */
triangle octahedron[] = {
    { { XPLUS, ZPLUS, YPLUS }, 0.0 },
    { { YPLUS, ZPLUS, XMIN  }, 0.0 },
    { { XMIN , ZPLUS, YMIN  }, 0.0 },
    { { YMIN , ZPLUS, XPLUS }, 0.0 },
    { { XPLUS, YPLUS, ZMIN  }, 0.0 },
    { { YPLUS, XMIN , ZMIN  }, 0.0 },
    { { XMIN , YMIN , ZMIN  }, 0.0 },
    { { YMIN , XPLUS, ZMIN  }, 0.0 }
};

/* A unit octahedron */
object oct = {
    sizeof(octahedron) / sizeof(octahedron[0]),
    &octahedron[0]
};

/* Vertices of a tetrahedron */
#define sqrt_3 0.5773502692
#define PPP {  sqrt_3,	sqrt_3,  sqrt_3 }   /* +X, +Y, +Z */
#define MMP { -sqrt_3, -sqrt_3,  sqrt_3 }   /* -X, -Y, +Z */
#define MPM { -sqrt_3,	sqrt_3, -sqrt_3 }   /* -X, +Y, -Z */
#define PMM {  sqrt_3, -sqrt_3, -sqrt_3 }   /* +X, -Y, -Z */

/* Structure describing a tetrahedron */
triangle tetrahedron[] = {
    {{ PPP, MMP, MPM }, 0.0},
    {{ PPP, PMM, MMP }, 0.0},
    {{ MPM, MMP, PMM }, 0.0},
    {{ PMM, PPP, MPM }, 0.0}
};

object tet = {
    sizeof(tetrahedron) / sizeof(tetrahedron[0]),
    &tetrahedron[0]
};

/* Twelve vertices of icosahedron on unit sphere */
#define tau 0.8506508084      /* t=(1+sqrt(5))/2, tau=t/sqrt(1+t^2)  */
#define one 0.5257311121      /* one=1/sqrt(1+t^2) , unit sphere     */
#define ZA {  tau,  one,    0 }
#define ZB { -tau,  one,    0 }
#define ZC { -tau, -one,    0 }
#define ZD {  tau, -one,    0 }
#define YA {  one,   0 ,  tau }
#define YB {  one,   0 , -tau }
#define YC { -one,   0 , -tau }
#define YD { -one,   0 ,  tau }
#define XA {   0 ,  tau,  one }
#define XB {   0 , -tau,  one }
#define XC {   0 , -tau, -one }
#define XD {   0 ,  tau, -one }

/* Structure for unit icosahedron */
triangle icosahedron[] = {
    { { YA, XA, YD }, 0.0 },
    { { YA, YD, XB }, 0.0 },
    { { YB, YC, XD }, 0.0 },
    { { YB, XC, YC }, 0.0 },
    { { ZA, YA, ZD }, 0.0 },
    { { ZA, ZD, YB }, 0.0 },
    { { ZC, YD, ZB }, 0.0 },
    { { ZC, ZB, YC }, 0.0 },
    { { XA, ZA, XD }, 0.0 },
    { { XA, XD, ZB }, 0.0 },
    { { XB, XC, ZD }, 0.0 },
    { { XB, ZC, XC }, 0.0 },
    { { XA, YA, ZA }, 0.0 },
    { { XD, ZA, YB }, 0.0 },
    { { YA, XB, ZD }, 0.0 },
    { { YB, ZD, XC }, 0.0 },
    { { YD, XA, ZB }, 0.0 },
    { { YC, ZB, XD }, 0.0 },
    { { YD, ZC, XB }, 0.0 },
    { { YC, XC, ZC }, 0.0 }
};

/* A unit icosahedron */
object ico = {
    sizeof(icosahedron) / sizeof(icosahedron[0]),
    &icosahedron[0]
};

//////////////////////////////////////

/* Normalize a point p */
static point *normalize(p)
point *p;
{
    static point r;
    double mag;

    r = *p;
    mag = r.x * r.x + r.y * r.y + r.z * r.z;
    if (mag != 0.0) {
	//mag = 1.0 / sqrt(mag);
	mag=InvSqrt(mag);
	r.x *= mag;
	r.y *= mag;
	r.z *= mag;
    }

    return &r;
}

/* Return the midpoint on the line between two points */
static point *midpoint(a, b)
point *a, *b;
{
    static point r;

    r.x = (a->x + b->x) * 0.5;
    r.y = (a->y + b->y) * 0.5;
    r.z = (a->z + b->z) * 0.5;

    return &r;
}

/* Reverse order of points in each triangle */
static void flip_object(obj)
object *obj;
{
    int i;
    for (i = 0; i < obj->npoly; i++) {
	point tmp;
		       tmp = obj->poly[i].pt[0];
	obj->poly[i].pt[0] = obj->poly[i].pt[2];
	obj->poly[i].pt[2] = tmp;
    }
}

static object *GenerateSphere(unsigned maxlevel,int ccwflag)
{
    object *old = &oct,		/* Default is octahedron */
		   *new;
   int		i,
			level;			/* Current subdivision level */	    
   static int lastccw=0;
    
    if (lastccw)
    {
        lastccw=0;
		flip_object(old);
    }
    
    if (ccwflag) 
    {
        flip_object(old);
        lastccw=1;
    }

    /* Subdivide each starting triangle (maxlevel - 1) times */
    for (level = 1; level < maxlevel; level++) {
	
    /* Allocate a new object */
	new = (object *)malloc(sizeof(object));
	if (new == NULL) {
		PV_Fatal("FogSphere::Out of memory on subdivision\n",0);
	}
	new->npoly = old->npoly * 4;

	/* Allocate 4* the number of points in the current approximation */
	new->poly  = (triangle *)malloc(new->npoly * sizeof(triangle));
	if (new->poly == NULL) {
		PV_Fatal("FogSphere::Out of memory on subdivision\n",0);
	}

	/* Subdivide each triangle in the old approximation and normalize
	 *  the new points thus generated to lie on the surface of the unit
	 *  sphere.
	 * Each input triangle with vertices labelled [0,1,2] as shown
	 *  below will be turned into four new triangles:
	 *
	 *			Make new points
	 *			    a = (0+2)/2
	 *			    b = (0+1)/2
	 *			    c = (1+2)/2
	 *	  1
	 *	 /\		Normalize a, b, c
	 *	/  \
	 *    b/____\ c		Construct new triangles
	 *    /\    /\		    [0,b,a]
	 *   /	\  /  \		    [b,1,c]
	 *  /____\/____\	    [a,b,c]
	 * 0	  a	2	    [a,c,2]
	 */
	for (i = 0; i < old->npoly; i++) {
	    triangle
		 *oldt = &old->poly[i],
		 *newt = &new->poly[i*4];
	    point a, b, c;

	    a = *normalize(midpoint(&oldt->pt[0], &oldt->pt[2]));
	    b = *normalize(midpoint(&oldt->pt[0], &oldt->pt[1]));
	    c = *normalize(midpoint(&oldt->pt[1], &oldt->pt[2]));

	    newt->pt[0] = oldt->pt[0];
	    newt->pt[1] = b;
	    newt->pt[2] = a;
	    newt++;

	    newt->pt[0] = b;
	    newt->pt[1] = oldt->pt[1];
	    newt->pt[2] = c;
	    newt++;

	    newt->pt[0] = a;
	    newt->pt[1] = b;
	    newt->pt[2] = c;
	    newt++;

	    newt->pt[0] = a;
	    newt->pt[1] = c;
	    newt->pt[2] = oldt->pt[2];
	}

	if (level > 1) {
	    free(old->poly);
	    free(old);
	}

	/* Continue subdividing new triangles */
	old = new;
    }
	return old;
}

///////////////////////////////////////////////////////////////////////////////////////////////

static void PVAPI SphereCleanup(PVMesh *no)
{
	free(no->UserData);
}

static void PVAPI SphereVisibilityFinalize(PVMesh *o)
{
	unsigned i;

	for(i=0;i<o->NbrFaces;i++)
	{
		o->FaceInfos[i].ZAvg=0xFFFFFFFE;
	}
}

static void PVAPI SphereFogger(PVMesh *o,PVLight *l)
{
	unsigned i;
    PVD8 *vv;
    PVVertex *ov;
    PVShadeInfo *os;
	float densoorange2,d,omd,nb,c,D;
	PVPoint p3,k;
	PVFOGSPHEREParm *parm;	

	// Verifier ke le mesh en kestion est bien une sphere a fog
	if(o->Name==NULL) return;
	if(strcmp("$$ DUMMY FOG SPHERE",o->Name)!=0) return;
	
	parm=o->UserData;

	/// Coordon�es objet � partir d'ici					
    k=o->Owner->Camera->pos;
    k.xf-=o->Pivot.xf+o->WorldPos.xf;
    k.yf-=o->Pivot.yf+o->WorldPos.yf;
    k.zf-=o->Pivot.zf+o->WorldPos.zf;
    RotateInvertPoint(&k,o->LastWorldMatrix,&p3);
    p3.xf+=o->Pivot.xf;
    p3.yf+=o->Pivot.yf;
    p3.zf+=o->Pivot.zf;

	d=fsqrt(p3.xf*p3.xf+p3.yf*p3.yf+p3.zf*p3.zf);	

	densoorange2=parm->density/(2*parm->radius);
	c=p3.xf*p3.xf+p3.yf*p3.yf+p3.zf*p3.zf-parm->radius*parm->radius;

    for(i=0,
    vv=o->VertexVisible,
    ov=o->Vertex,
    os=o->Shading;
    i<o->NbrVertices;
    i++,ov++,vv++,os++)
    {
        PVPoint v;
		float nv;

		if (*vv==0) continue;
		
		// Vraie dist
		// Calcul vecteur directeur droite camera-point
		v.xf=ov->xf-p3.xf;
		v.yf=ov->yf-p3.yf;
		v.zf=ov->zf-p3.zf;		
		//nv=1/fsqrt(v.xf*v.xf+v.yf*v.yf+v.zf*v.zf);					
		nv=InvSqrt(v.xf*v.xf+v.yf*v.yf+v.zf*v.zf);					
		v.xf*=nv;
		v.yf*=nv;
		v.zf*=nv;

		nb= - (v.xf*p3.xf+ v.yf*p3.yf + v.zf*p3.zf);		
		d=2*fsqrt(nb*nb-c);
		D=d;
		d*=densoorange2;		

		omd=1-d;
		
		d-=(parm->a0+parm->a1*omd+parm->a2*(1+omd)*(1+omd));
		
		if(d<0) d=0;
		
		os->Color.r=(parm->r-o->Owner->AmbientLight.r);
		os->Color.g=(parm->g-o->Owner->AmbientLight.g);
		os->Color.b=(parm->b-o->Owner->AmbientLight.b);		
		os->Color.a=d;
    }
}

static PVMesh *PVAPI FogSphereSwitchCallBack(PVMesh *swnode)
{	
	PVCam *cam=swnode->Owner->Camera;
	PVMesh *m=PV_GetSwitchItem(swnode,0);
	PVFOGSPHEREParm *parm;	

	float dist=fsqrt((cam->pos.xf-m->Position.xf)*(cam->pos.xf-m->Position.xf)
					+(cam->pos.yf-m->Position.yf)*(cam->pos.yf-m->Position.yf)
					+(cam->pos.zf-m->Position.zf)*(cam->pos.zf-m->Position.zf));
	
	parm=m->UserData;	

	if(dist>parm->radius*1.1) return m;
	else 
	{
		PVMesh *m2=PV_GetSwitchItem(swnode,1);		
		PV_MeshSetupPos(m2,m->Position.xf,m->Position.yf,m->Position.zf);
		return m2;
	}
}

static int PVAPI InsideFogSphere(PVMesh *m)
{
	m->NbrVisibles=1;
	m->Visible[0]=&m->Face[0];

	m->Projected[0].xf=ClipMinX;
	m->Projected[0].yf=ClipMinY;
	m->Projected[0].InvertZ=1;

	m->Projected[1].xf=ClipMaxX;
	m->Projected[1].yf=ClipMinY;
	m->Projected[1].InvertZ=1;

	m->Projected[2].xf=ClipMaxX;
	m->Projected[2].yf=ClipMaxY;
	m->Projected[2].InvertZ=1;

	m->Projected[3].xf=ClipMinX;
	m->Projected[3].yf=ClipMaxY;
	m->Projected[3].InvertZ=1;

	return MESH_FRUSTUM_CLIPPED;
}

#define EPSILON     0.01

static int FindVertexIndex(PVMesh *m,unsigned limit,float x,float y,float z)
{
	int i;

	if(limit==0) return -1;
    for(i=limit-1;i>=0;i--)
	{
        if((fabs(m->Vertex[i].xf-x)<EPSILON)&&
		   (fabs(m->Vertex[i].yf-y)<EPSILON)&&
		   (fabs(m->Vertex[i].zf-z)<EPSILON)) return i;
	}
	return -1;
}
///////////////////////////////////////////////////////////////////////////////////////////////

static int PVAPI SearchInsideIterator(PVMesh *o,int t)
{
	PVFOGSPHEREParm *parm=(PVFOGSPHEREParm*)t;
	unsigned i,j;
	float d;
    PVPoint p2,k;

	if(o->Name!=NULL)
	{
		if(ISSYSTEMMESH(o)) return COOL;		
	}

    k=parm->pos;
    k.xf-=o->Pivot.xf+o->WorldPos.xf;
    k.yf-=o->Pivot.yf+o->WorldPos.yf;
    k.zf-=o->Pivot.zf+o->WorldPos.zf;
    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
    p2.xf+=o->Pivot.xf;
    p2.yf+=o->Pivot.yf;
    p2.zf+=o->Pivot.zf;

	for(i=0;i<o->NbrFaces;i++)
	{
		for(j=0;j<o->Face[i].NbrVertices;j++)
		{			
            d=(p2.xf-o->Vertex[o->Face[i].V[j]].xf)*(p2.xf-o->Vertex[o->Face[i].V[j]].xf)+ 
			  (p2.yf-o->Vertex[o->Face[i].V[j]].yf)*(p2.yf-o->Vertex[o->Face[i].V[j]].yf)+
			  (p2.zf-o->Vertex[o->Face[i].V[j]].zf)*(p2.zf-o->Vertex[o->Face[i].V[j]].zf);
			d=fsqrt(d);
			if(d<=parm->radius)
			{
				if(parm->nbrf<MAX_FACES_INSIDE_SPHERE) 
					parm->InsideFaces[parm->nbrf++]=&o->Face[i];
				else 
					return 1;
				break;
			}
		}
	}
	return COOL;
}

static void SearchInsideFaces(PVFOGSPHEREParm *parm,PVWorld *w)
{
	parm->nbrf=0;
	PV_IterateMeshList(w->Objs,SearchInsideIterator,(int)parm);
}

static int PVAPI AddFace(PVMesh *m)
{
	// Onevite les problems de materiaux precompiles pour un mode ou un autre en soft
    if(PV_Mode&PVM_USEHARDWARE)
	{
		m->NbrVisibles=1;
		m->Visible[0]=&m->Face[0];
	}
	else m->NbrVisibles=0;

	return 0; // pas de clipping
}

static void PVAPI VisibilityFinalize(PVMesh *o)
{
	o->FaceInfos[0].ZAvg=0xFFFFFFFF;
}

static int PVAPI AddNewFaces(PVFace *f)
{
	PVMesh *fog;
	PVFace *fa;
	PVFOGSPHEREParm *parm;
	unsigned i,j,a,nbrvtx,*vtx;
	float d,h,h2,ooradius;
	PVMaterial tmpmat,*oldmat;
    PVPoint p,p2,k;

	fog=f->Father;
	parm=(PVFOGSPHEREParm*)fog->UserData;

	// Calcul distance camera, centre fog
	h=(f->Father->Owner->Camera->pos.xf-parm->pos.xf)*(f->Father->Owner->Camera->pos.xf-parm->pos.xf)+
	  (f->Father->Owner->Camera->pos.yf-parm->pos.yf)*(f->Father->Owner->Camera->pos.yf-parm->pos.yf)+
	  (f->Father->Owner->Camera->pos.zf-parm->pos.zf)*(f->Father->Owner->Camera->pos.zf-parm->pos.zf);
	h=fsqrt(h);

    ooradius=1/parm->radius;

	for(i=0;i<parm->nbrf;i++)
	{
		PVMesh *o;		
		
		fa=parm->InsideFaces[i];
		if(fa->MaterialInfo==NULL) continue;		

		if(fa->MaterialInfo->Type&LIGHTMAP) continue;

		// On v�rifie ke cette face a �t� affich�e
		o=fa->Father;
		for(j=0;j<o->NbrVisibles;j++) if(fa==o->Visible[j]) break;
		if(j==o->NbrVisibles) continue;

        // Calcul de la posiiton d la camera relativement � l'objet       
		k=o->Owner->Camera->pos;
        k.xf-=o->Pivot.xf+o->WorldPos.xf;
        k.yf-=o->Pivot.yf+o->WorldPos.yf;
        k.zf-=o->Pivot.zf+o->WorldPos.zf;
        RotateInvertPoint(&k,o->LastWorldMatrix,&p);
        p.xf+=o->Pivot.xf;
        p.yf+=o->Pivot.yf;
        p.zf+=o->Pivot.zf;

        // Et de celle de la fog
   		k=parm->pos;
        k.xf-=o->Pivot.xf+o->WorldPos.xf;
        k.yf-=o->Pivot.yf+o->WorldPos.yf;
        k.zf-=o->Pivot.zf+o->WorldPos.zf;
        RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
        p2.xf+=o->Pivot.xf;
        p2.yf+=o->Pivot.yf;
        p2.zf+=o->Pivot.zf;

		memcpy(&tmpmat,fa->MaterialInfo,sizeof(tmpmat));
				
		ADDFLAG(tmpmat.Type,BLENDING);		
		tmpmat.BlendRgbSrcFactor=BLEND_SRC_ALPHA;
		tmpmat.BlendRgbDstFactor=BLEND_ONE_MINUS_SRC_ALPHA;		
		tmpmat.DepthTest=CMP_EQUAL;		

		// Calcul des valeurs alpha		
		if(fa->Poly!=NULL)
		{
			nbrvtx=fa->Poly->NbrVertices;
			vtx=fa->Poly->Vertices;
		}
		else
		{
			nbrvtx=fa->NbrVertices;
			vtx=fa->V;
		}

		for(j=0;j<nbrvtx;j++)
		{			
			a=vtx[j];

			o->Shading[a].Color.r=1.0;
			o->Shading[a].Color.g=1.0;
			o->Shading[a].Color.b=1.0;

			// est ce ke le point est devant ou derriere le centre de la sphere
			h2=(o->Vertex[a].xf-p.xf)*(o->Vertex[a].xf-p.xf)+
			  (o->Vertex[a].yf-p.yf)*(o->Vertex[a].yf-p.yf)+
			  (o->Vertex[a].zf-p.zf)*(o->Vertex[a].zf-p.zf);
			h2=fsqrt(h2);
			if(h2>h) 
			{
				o->Shading[a].Color.a=0;
				continue;
			}
			
			//Distance vtx centre sphere
			d=(o->Vertex[a].xf-p2.xf)*(o->Vertex[a].xf-p2.xf)+	
			  (o->Vertex[a].yf-p2.yf)*(o->Vertex[a].yf-p2.yf)+
			  (o->Vertex[a].zf-p2.zf)*(o->Vertex[a].zf-p2.zf);
			d=fsqrt(d);
			d*=ooradius;
			if(d>1) d=1;
			
			o->Shading[a].Color.a=d;
		}
				
		REMOVEFLAG(tmpmat.Type,FLAT);
		tmpmat.Type|=GOURAUD;
		tmpmat.Diffuse.r=1.0;tmpmat.Diffuse.g=1.0;tmpmat.Diffuse.b=1.0;		
		
		oldmat=fa->MaterialInfo;
		PV_RefreshMaterial(&tmpmat);
		fa->MaterialInfo=&tmpmat;
		PV_RenderAdditionalFace(fa);
		fa->MaterialInfo=oldmat;
	}
	return COOL;
}

PVMesh *PVAPI PVFX_AddFogSphere(PVWorld *w,float radius,unsigned precision)
{
	PVMesh *m,*m2,*Switch,*m8;
	PVMaterial *mat,*mat3;
	unsigned i,V[4],n;
	int h;
	object *old;
	PVRGBF zero={0,0,0,0};
	PVRGBF gone={1,1,1,1};
	PVRGBF half={0.3,0.3,0.3,0.3};
	PVLight *l;
	PVFOGSPHEREParm *parm;

	if(w==NULL) return NULL;
	if(radius<=0) return NULL;
	if(precision<1) return NULL;
	
	m=PV_SimpleCreateMesh((unsigned)(8*pow(4,precision-1)),(unsigned)((3*8*pow(4,precision-1)/6)+2),(unsigned)(8*pow(4,precision-1)/10),(unsigned)(3*8*pow(4,precision-1)/10));
	if(m==NULL) return NULL;

	// On cr�e le materiaux ki va bien sauf s'il existe deja
	mat=PV_GetMaterialPtrByName("$$ DUMMY FOGMAT1",w);
	if(mat==NULL)
	{
		mat=PV_CreateMaterial("$$ DUMMY FOGMAT1",GOURAUD|BLENDING|ZBUFFER,TEXTURE_BILINEAR|TEXTURE_NONE,0);
		if(mat==NULL) return NULL;

        mat->BlendRgbSrcFactor=BLEND_SRC_ALPHA;
		mat->BlendRgbDstFactor=BLEND_ONE_MINUS_SRC_ALPHA;		
		mat->ZWrite=0;

		PV_SetMaterialLightInfo(mat,zero,gone,gone,5);
		PV_CompileMaterial(mat,NULL,NULL,zero,0);
		PV_AddMaterial(w,mat);	
	}

	// Et la materiau special de course
	mat3=PV_GetMaterialPtrByName("$$ DUMMY FXFOG",w);
	if(mat3==NULL)
	{
		mat3=PV_CreateMaterial("$$ DUMMY FXFOG",0,0,0);
		if(mat3==NULL) return NULL;

		mat3->Filler=AddNewFaces;
		PV_CompileMaterial(mat3,NULL,NULL,zero,0);
		PV_AddMaterial(w,mat3);
	}
	
	// On cr�e une light speciale si elle existe pas.
	l=PV_GetLightPtr(w,"$$ DUMMY FOG LIGHT");
	if(l==NULL)
	{
		l=PV_CreateLight(PVL_USER_LIGHT,"$$ DUMMY FOG LIGHT");
		if(l==NULL)  return NULL;

        l->UserLightFunc=SphereFogger;
		PV_AddLight(w,l);
	}

	// Le bloc de parm
	parm=(PVFOGSPHEREParm*)malloc(sizeof(PVFOGSPHEREParm));
	if(parm==NULL) return NULL;

    m->UserData=parm;
	m->UserMeshCleanUp=SphereCleanup;
	m->AfterVisibilityPipe=SphereVisibilityFinalize;

	parm->radius=radius;
	parm->density=1;
	parm->r=parm->g=parm->b=1;
	parm->a0=0;
	parm->a1=0.1;
	parm->a2=0.1;
	parm->pos=m->Position;
	parm->nbrf=0;
	parm->fog=m;
	SearchInsideFaces(parm,w);

	// Le faux mesh avec une face
	m8=PV_SimpleCreateMesh(1,1,1,1);
	if(m8==NULL) return NULL;

	m8->UserData=parm;
	m8->UserPipeline=AddFace;
	m8->AfterVisibilityPipe=VisibilityFinalize;
	m8->Face[0].MaterialInfo=mat3;
	m8->Face[0].Flags|=POLYGON_PLANAR;
	m8->Flags|=MESH_NOLIGHTING;
	PV_CompileMesh(m8);	
	
	// transfert de la sphere
	old=GenerateSphere(precision,0);
	for(i=0,n=0;i<m->NbrFaces;i++)
	{
		float x,y,z;
		PVFace *f;

		f=&m->Face[i];

		PV_SetVerticesToFace(f,V,3);

		x=old->poly[i].pt[0].x*radius;
		y=old->poly[i].pt[0].y*radius;
		z=old->poly[i].pt[0].z*radius;
		h=FindVertexIndex(m,n,x,y,z);
		if(h==-1)
		{
			f->V[0]=n;			
			m->Vertex[n].xf=x;
			m->Vertex[n].yf=y;
			m->Vertex[n].zf=z;
			n++;
		}
		else f->V[0]=h;	

		x=old->poly[i].pt[1].x*radius;
		y=old->poly[i].pt[1].y*radius;
		z=old->poly[i].pt[1].z*radius;
		h=FindVertexIndex(m,n,x,y,z);
		if(h==-1)
		{
			f->V[1]=n;			
			m->Vertex[n].xf=x;
			m->Vertex[n].yf=y;
			m->Vertex[n].zf=z;
			n++;
		}
		else f->V[1]=h;

		x=old->poly[i].pt[2].x*radius;
		y=old->poly[i].pt[2].y*radius;
		z=old->poly[i].pt[2].z*radius;
		h=FindVertexIndex(m,n,x,y,z);
		if(h==-1)
		{
			f->V[2]=n;			
			m->Vertex[n].xf=x;
			m->Vertex[n].yf=y;
			m->Vertex[n].zf=z;
			n++;
		}
		else f->V[2]=h;
		
		f->MaterialInfo=mat;
    }
	m->Flags|=MESH_CULL_CHILD;    
    PV_MeshNormCalc(m);
    PV_MeshBuildBoxes(m,700);
	PV_CompileMesh(m);	

	// Prevents sphere from being lighted by other light sources (not perfect however, because it's still processed)
	for(i=0;i<m->NbrVertices;i++) {REMOVEFLAG(m->Vertex[i].Flags,GOURAUD);}

	if(precision>1)
	{
		free(old->poly);
		free(old);
	}

	PV_SetMeshName(m,"$$ DUMMY FOG SPHERE");

	// Create the inside-fog mesh
	// transfert de la sphere
	mat=PV_GetMaterialPtrByName("$$ DUMMY FOGMAT2",w);
	if(mat==NULL)
	{
		mat=PV_CreateMaterial("$$ DUMMY FOGMAT2",GOURAUD|BLENDING,TEXTURE_BILINEAR|TEXTURE_NONE,0);
		if(mat==NULL) return NULL;

        mat->BlendRgbSrcFactor=BLEND_SRC_ALPHA;
		mat->BlendRgbDstFactor=BLEND_ONE_MINUS_SRC_ALPHA;		
		mat->ZWrite=0;
		
		PV_SetMaterialLightInfo(mat,zero,gone,gone,5);
		PV_CompileMaterial(mat,NULL,NULL,zero,0);
		PV_AddMaterial(w,mat);	
	}

	m2=PV_SimpleCreateMesh((unsigned)(8*pow(4,precision-1)),(unsigned)((3*8*pow(4,precision-1)/6)+2),(unsigned)(8*pow(4,precision-1)/10),(unsigned)(3*8*pow(4,precision-1)/10));
	if(m2==NULL) return NULL;

	old=GenerateSphere(precision,1);
	for(i=0,n=0;i<m2->NbrFaces;i++)
	{
		float x,y,z;
		PVFace *f;

		f=&m2->Face[i];

		PV_SetVerticesToFace(f,V,3);

		x=old->poly[i].pt[0].x*radius;
		y=old->poly[i].pt[0].y*radius;
		z=old->poly[i].pt[0].z*radius;
		h=FindVertexIndex(m2,n,x,y,z);
		if(h==-1)
		{
			f->V[0]=n;			
			m2->Vertex[n].xf=x;
			m2->Vertex[n].yf=y;
			m2->Vertex[n].zf=z;
			n++;
		}
		else f->V[0]=h;	

		x=old->poly[i].pt[1].x*radius;
		y=old->poly[i].pt[1].y*radius;
		z=old->poly[i].pt[1].z*radius;
		h=FindVertexIndex(m2,n,x,y,z);
		if(h==-1)
		{
			f->V[1]=n;			
			m2->Vertex[n].xf=x;
			m2->Vertex[n].yf=y;
			m2->Vertex[n].zf=z;
			n++;
		}
		else f->V[1]=h;

		x=old->poly[i].pt[2].x*radius;
		y=old->poly[i].pt[2].y*radius;
		z=old->poly[i].pt[2].z*radius;
		h=FindVertexIndex(m2,n,x,y,z);
		if(h==-1)
		{
			f->V[2]=n;			
			m2->Vertex[n].xf=x;
			m2->Vertex[n].yf=y;
			m2->Vertex[n].zf=z;
			n++;
		}
		else f->V[2]=h;
		
		f->MaterialInfo=mat;
	}

    PV_MeshNormCalc(m2);
    PV_MeshBuildBoxes(m2,700);
	PV_CompileMesh(m2);	

	m2->UserData=parm;	
	m2->AfterVisibilityPipe=SphereVisibilityFinalize;

	// Prevents sphere from being lighted by other light sources (not perfect however, because it's still processed)
	for(i=0;i<m2->NbrVertices;i++) {REMOVEFLAG(m2->Vertex[i].Flags,GOURAUD);}
	
	if(precision>1)
	{
		free(old->poly);
		free(old);
	}

	PV_SetMeshName(m2,"$$ DUMMY FOG SPHERE");

	
	// Create the switch node
	Switch=PV_CreateSwitchNode(FogSphereSwitchCallBack);
	PV_AddMeshLast(w,Switch);

	// Add switch items
	PV_AddSwitch(Switch,m);
	PV_AddSwitch(Switch,m2);

	PV_AddChildMesh(m,m8);

	PV_SetMode(PV_Mode|PVM_ALPHABLENDING);

	return m;
}

int PVAPI PVFX_SetFogSphereColor(PVMesh *m,float r,float g,float b)
{
	PVFOGSPHEREParm *p;

	if(m==NULL) return ARG_INVALID;
	if(strcmp(m->Name,"$$ DUMMY FOG SPHERE")!=0) return ARG_INVALID;

	p=m->UserData;
	p->r=r;
	p->g=g;
	p->b=b;
	
	return COOL;
}

int PVAPI PVFX_SetFogSphereAttenuation(PVMesh *m,float a0,float a1,float a2)
{
	PVFOGSPHEREParm *p;

	if(m==NULL) return ARG_INVALID;
	if(strcmp(m->Name,"$$ DUMMY FOG SPHERE")!=0) return ARG_INVALID;

	p=m->UserData;
	p->a0=a0;
	p->a1=a1;
	p->a2=a2;
	
	return COOL;

}

int PVAPI PVFX_SetFogSphereDensity(PVMesh *m,float d)
{
	PVFOGSPHEREParm *p;

	if(m==NULL) return ARG_INVALID;
	if(strcmp(m->Name,"$$ DUMMY FOG SPHERE")!=0) return ARG_INVALID;

	p=m->UserData;
	p->density=d;
	
	return COOL;

}

int PVAPI PVFX_SetFogSpherePosition(PVMesh *m,float x,float y,float z)
{
	PVFOGSPHEREParm *p;
	
	if(m==NULL) return ARG_INVALID;
	if(strcmp(m->Name,"$$ DUMMY FOG SPHERE")!=0) return ARG_INVALID;

	m->Position.xf=x;
	m->Position.yf=y;
	m->Position.zf=z;

	p=(PVFOGSPHEREParm*)m->UserData;

	p->pos=m->Position;
	SearchInsideFaces(p,m->Owner);

	return COOL;
}

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

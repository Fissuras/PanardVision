/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pvision.h"
#include "vbuf.h"
#include "shadow.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define PVMEI_BACK		1
#define PVMEI_FRONT		2

class pvMeshEdgesInfo
{
private:	
	struct pvsEdge
	{
		unsigned a,b,count;
	};

	struct pvsFaceEdge
	{
		unsigned e[MAX_VERTICES_PER_POLY];
	};

	PVMesh *_Mesh;
	char *_Flags;
	unsigned _NbrEdges,_MaxEdges;
	pvsEdge *_Edges;
	pvsFaceEdge *_FEdges;

	void AddToTable(unsigned a,unsigned b);

public:
	pvMeshEdgesInfo(PVMesh *);
	~pvMeshEdgesInfo();	

	unsigned InTable(unsigned a,unsigned b);	
	unsigned SetEdgeFlagDirect(unsigned face, unsigned a,unsigned b,unsigned f);
	void ResetFlags();
	bool Check();

	inline unsigned GetNbrEdges() {return _NbrEdges;}
};

unsigned pvMeshEdgesInfo::InTable(unsigned a,unsigned b)
{
	for(unsigned i=0;i<_NbrEdges;i++)
	{
		if(((_Edges[i].a==a)&&(_Edges[i].b==b))||((_Edges[i].a==b)&&(_Edges[i].b==a))) return (i+1);
	}
	return 0;
}

unsigned pvMeshEdgesInfo::SetEdgeFlagDirect(unsigned face, unsigned a,unsigned b,unsigned f)
{
	unsigned i=_FEdges[face].e[a];

	if((_Flags[i]&(PVMEI_FRONT|PVMEI_BACK))==(PVMEI_FRONT|PVMEI_BACK)) return 0;
	if(_Flags[i]==f)
	{
		_Flags[i]=PVMEI_FRONT|PVMEI_BACK;
		return 0;
	}

	_Flags[i]|=f;
	
	return _Flags[i];
}

void pvMeshEdgesInfo::AddToTable(unsigned a,unsigned b)
{
	if(_NbrEdges==_MaxEdges)
	{
		_Edges=(pvsEdge*)realloc(_Edges,(_MaxEdges+100)*sizeof(pvsEdge));
		_MaxEdges+=100;
	}
	_Edges[_NbrEdges].a=a;
	_Edges[_NbrEdges].b=b;
	_Edges[_NbrEdges].count=1;
	_NbrEdges++;
}

void pvMeshEdgesInfo::ResetFlags()
{
	memset(_Flags,0,sizeof(char)*_NbrEdges);
}

bool pvMeshEdgesInfo::Check()
{
	for(unsigned i=0;i<_NbrEdges;i++)
	{
		if(_Edges[i].count!=2) return false;
	}
	return true;
}

pvMeshEdgesInfo::pvMeshEdgesInfo(PVMesh *m)
{
	unsigned e,i;

	_Mesh=NULL;
	_NbrEdges=_MaxEdges=0;
	_Edges=NULL;
	_Flags=NULL;

	///////////////////////////////////////
	for(i=0;i<m->NbrFaces;i++)
	{
		for(unsigned j=0;j<m->Face[i].NbrVertices;j++)
		{
			unsigned k=j+1;
			
			if(k>=m->Face[i].NbrVertices) k=0;

			if((e=InTable(m->Face[i].V[j],m->Face[i].V[k]))==0)
			{
				AddToTable(m->Face[i].V[j],m->Face[i].V[k]);
			}
			else
			{
				_Edges[e-1].count++;
			}
		}
	}

	_FEdges=new pvsFaceEdge[m->NbrFaces];
	
	for(i=0;i<m->NbrFaces;i++)
	{
		for(unsigned j=0;j<m->Face[i].NbrVertices;j++)
		{
			unsigned k=j+1;
			
			if(k>=m->Face[i].NbrVertices) k=0;

			_FEdges[i].e[j]=InTable(m->Face[i].V[j],m->Face[i].V[k])-1;
		}
	}

	_Mesh=m;
	_Flags=new char[_NbrEdges];
}

pvMeshEdgesInfo::~pvMeshEdgesInfo()
{
	free(_Edges);	
	delete[] _Flags;
	delete[] _FEdges;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define PVSV_CONVEX		1
#define PVSV_CONCAVE	2

class pvShadowVolume
{
private:
	PVPoint _LastLightDir,_LastMeshWorldPos;
	PVMat3x3 _LastMeshWorldMatrix;

	unsigned _dlist;
	pvVertexBuffer _SrcVb,_RotVb,_ShadVb,_TmpVb;
	unsigned _NbrVtxInShadow;

	unsigned _Flags;
	PVMesh *_Mesh;
	PVLight *_Light;

public:
	~pvShadowVolume();
	bool NeedRecompute(PVMesh *m,PVLight *l);
	void GenerateShadowVolume(PVMesh *m,PVLight *l);
	void DrawVolume(unsigned buf,PVPoint *camdir);
	bool IsPointInShadowVolume(PVPoint *p);

	inline PVVBS_XYZ *Lock() {return (PVVBS_XYZ*)_ShadVb.Lock();};
	inline void UnLock() {_ShadVb.UnLock();};
	inline unsigned GetNbrVtx() {return _ShadVb.GetNbrItems();};
};

int PVAPI PV_UpdateShadows(PVWorld *w)
{
	PVMesh *o=w->Objs;
	PVLight *l;
	pvShadowVolume *s;	
	unsigned i=0;

	if(w->Objs==NULL) return ARG_INVALID;
	if(w->Lights==NULL) return ARG_INVALID;

	// Allocation buffer de points	
	while(o!=NULL)
	{			
		if((!(o->Flags&MESH_CAST_SHADOWS))||(o->Flags&MESH_FORGET))
		{
			o=o->Next;
			continue;
		}
		
		l=w->Lights;		
		i=0;
		while(l!=NULL)
		{
			if((!(l->Flags&LIGHT_CAST_SHADOWS))||(l->Flags&LIGHT_FORGET)||(l->Type!=PVL_DIRECTIONAL))
			{
				l=l->Next;
				continue;
			}
			
			if((o->Shadows[i]==NULL)||((pvShadowVolume*)o->Shadows[i])->NeedRecompute(o,l))
			{								
				s=new pvShadowVolume;

				s->GenerateShadowVolume(o,l);

				if(o->Shadows[i]!=NULL) delete ((pvShadowVolume*)o->Shadows[i]);
				o->Shadows[i]=s;
			
				i++;
				if(i==MAX_SHADOW_VOLUMES) return COOL;
			}

			l=l->Next;
		}
		for(;i<MAX_SHADOW_VOLUMES;i++) 
		{
			delete ((pvShadowVolume*)o->Shadows[i]);
			o->Shadows[i]=NULL;
		}
		o=o->Next;
	}	

	return COOL;
}

/////////////////////////////////////////////////////////////////////////////////////////////////

bool pvShadowVolume::NeedRecompute(PVMesh *o,PVLight *l)
{
	// Check for ID
	if(memcmp(&_LastLightDir.xf,&l->Direction.xf,sizeof(PVPoint))==0)
		if(memcmp(&_LastMeshWorldPos.xf,&o->WorldPos.xf,sizeof(PVPoint))==0)
			if(memcmp(_LastMeshWorldMatrix,o->WorldMatrix,sizeof(PVMat3x3))==0)
				return false;

	return true;
}

void pvShadowVolume::GenerateShadowVolume(PVMesh *o,PVLight *l)
{
	PVCam cam;
	pvVector3D p;
	pvBase3 tbase,tbase2,r;	
	unsigned nbrv,*tmp,N,fl;
	PVVBS_XYZ *s1,*s2,*s3;	
	float x1,x2,x3,y1,y2,y3,z1,z2,z3;
	unsigned SHADOW_LENGTH=1000000;
	
	if(o==NULL) return;
	if(l==NULL) return;

	// Acquisition des pts
	_SrcVb.CreateFromMesh(o);

	// Init des autres VB
	_TmpVb.Create(PVVBT_XYZ,_SrcVb.GetNbrItems());
	_RotVb.Create(PVVBT_XYZ,_SrcVb.GetNbrItems());

	// Rotation/projection des points vus de la lumiere
	PV_RAZCam(&cam);	
	PV_SetCamPos(&cam,0,0,0);
	PV_SetCamTarget(&cam,l->Direction.xf,l->Direction.yf,l->Direction.zf);
		
	tbase2.FromArray(o->WorldMatrix);
	tbase2.Inverse();
	tbase.FromArray(cam.Matrix);
	tbase.Inverse();
	tbase=tbase*tbase2;

	p.FromArray((float*)&o->WorldPos.xf);
	p+=pvVector3D((float*)&o->Pivot.xf);
	
	r.FromArray(o->WorldMatrix);
	r.Inverse();
	p-=r.RotateVector(pvVector3D((float*)&o->Pivot.xf));
	
	_SrcVb.TransformTo(tbase2,p,_RotVb);   
	
	if(o->Flags&MESH_CONVEX)
	{									
		unsigned i;
		
		// Convex Hull	
		_SrcVb.TransformTo(tbase,p,_TmpVb);
		_TmpVb.Find2DConvexHull(&nbrv,&tmp);

		_ShadVb.Create(PVVBT_XYZ,nbrv*2);
		
		
		s1=(PVVBS_XYZ*)_RotVb.Lock();
		s3=(PVVBS_XYZ*)_ShadVb.Lock();
		
		for(i=0;i<nbrv;i++) 
		{
			s3[i]=s1[tmp[i]];
		}

		for(i=0;i<nbrv;i++) 
		{
			s3[i+nbrv].x = s3[i].x + SHADOW_LENGTH*l->Direction.xf;
			s3[i+nbrv].y = s3[i].y + SHADOW_LENGTH*l->Direction.yf;		
			s3[i+nbrv].z = s3[i].z + SHADOW_LENGTH*l->Direction.zf;
		}

		_ShadVb.UnLock();
		_RotVb.UnLock();

  		delete[] tmp;
		
		_Flags=PVSV_CONVEX;
	}
	else
	{
		// Test pour l'edge table
		if(o->EdgeTable==NULL)
		{
			o->EdgeTable=new pvMeshEdgesInfo(o);
			if(!(((pvMeshEdgesInfo *)(o->EdgeTable))->Check()))
				printf("WARNING : Shadow caster Mesh as orphan edges (%s)\n",o->Name);
		}

		pvMeshEdgesInfo *ei=(pvMeshEdgesInfo *)o->EdgeTable;
		if(ei==NULL) return;
		ei->ResetFlags();

		_ShadVb.Create(PVVBT_XYZ,ei->GetNbrEdges()*4);	
		
		s3=(PVVBS_XYZ*)_ShadVb.Lock();	
		s2=(PVVBS_XYZ*)_RotVb.Lock();
		N=0;

		for(unsigned i=0;(i<o->NbrFaces)&&(N<ei->GetNbrEdges()*2);i++)
		{			
			PVPoint p;

			RotateInvertPoint(&l->Direction,o->LastWorldMatrix,&p);
			double d=-(((p.xf*o->Face[i].Normal.xf))+((p.yf*o->Face[i].Normal.yf))+((p.zf*o->Face[i].Normal.zf)));
								
			// Mark corrsponding Edges
			for(unsigned j=0;j<o->Face[i].NbrVertices;j++)
			{
				unsigned k=j+1;
				unsigned i1,i2;

				if(k>=o->Face[i].NbrVertices) k=0;

				i1=o->Face[i].V[j];
				i2=o->Face[i].V[k];

				if(((fl=ei->SetEdgeFlagDirect(i,j,k,(d>=0)?PVMEI_FRONT:PVMEI_BACK))&(PVMEI_FRONT|PVMEI_BACK))==(PVMEI_FRONT|PVMEI_BACK))
				{										
					if(d<0)
					{
						k=i1;
						i1=i2;
						i2=k;
					}
					x1=s3[N].x=s2[i1].x;
					y1=s3[N].y=s2[i1].y;
					z1=s3[N].z=s2[i1].z;
					x2=s3[N+ei->GetNbrEdges()*2].x=s2[i1].x+SHADOW_LENGTH*l->Direction.xf;
					y2=s3[N+ei->GetNbrEdges()*2].y=s2[i1].y+SHADOW_LENGTH*l->Direction.yf;
					z2=s3[N+ei->GetNbrEdges()*2].z=s2[i1].z+SHADOW_LENGTH*l->Direction.zf;
					N++;
					s3[N].x=s2[i2].x;
					s3[N].y=s2[i2].y;
					s3[N].z=s2[i2].z;
					x3=s3[N+ei->GetNbrEdges()*2].x=s2[i2].x+SHADOW_LENGTH*l->Direction.xf;
					y3=s3[N+ei->GetNbrEdges()*2].y=s2[i2].y+SHADOW_LENGTH*l->Direction.yf;
					z3=s3[N+ei->GetNbrEdges()*2].z=s2[i2].z+SHADOW_LENGTH*l->Direction.zf;
					N++;
				}
			}
			_Flags=PVSV_CONCAVE;
		}

		_ShadVb.UnLock();
		_RotVb.UnLock();
		_NbrVtxInShadow=N;
	}

	_Mesh=o;
	_Light=l;
}

bool pvShadowVolume::IsPointInShadowVolume(PVPoint *p)
{
	PVVBS_XYZ *t,*t2,*t3,*t4,*t0;	
	unsigned j,k;
	double x,y,z,x1,y1,z1,d;
	PVPoint n;

	if(_Flags==PVSV_CONVEX)
	{
		t0=t=(PVVBS_XYZ*)_ShadVb.Lock();
		
		j=GetNbrVtx();
		j/=2;
		k=j;			
		
		while(j>0)
		{
			t2=t+1;
			t3=t+1+k;
			t4=t+k;

			if(j==1)
			{
				t2=t0;
				t3=t0+k;
			}

			// Normale
			x=t2->x-t->x;
			y=t2->y-t->y;
			z=t2->z-t->z;

			x1=t4->x-t->x;
			y1=t4->y-t->y;
			z1=t4->z-t->z;

			n.xf=y*z1-z*y1;
			n.yf=z*x1-x*z1;
			n.zf=x*y1-y*x1;
			d=n.xf*t->x+n.yf*t->y+n.zf*t->z;

			// test
			if(n.xf*p->xf+n.yf*p->yf+n.zf*p->zf-d<0) 
			{
				_ShadVb.UnLock();
				return false;
			}					
			j--;
			t++;
		}

		// Test cap
		// Normale
		t=t0+k+(k-1);
		t2=t-1;
		t4=t0+k;

		x=t2->x-t->x;
		y=t2->y-t->y;
		z=t2->z-t->z;

		x1=t4->x-t->x;
		y1=t4->y-t->y;
		z1=t4->z-t->z;

		n.xf=y*z1-z*y1;
		n.yf=z*x1-x*z1;
		n.zf=x*y1-y*x1;
		d=n.xf*t->x+n.yf*t->y+n.zf*t->z;

		// test
		if(n.xf*p->xf+n.yf*p->yf+n.zf*p->zf-d>0) 
		{
			_ShadVb.UnLock();
			return false;
		}

		// Normale
		t=t0+(k-1);
		t2=t-1;
		t4=t0;

		x=t2->x-t->x;
		y=t2->y-t->y;
		z=t2->z-t->z;

		x1=t4->x-t->x;
		y1=t4->y-t->y;
		z1=t4->z-t->z;

		n.xf=y*z1-z*y1;
		n.yf=z*x1-x*z1;
		n.zf=x*y1-y*x1;
		d=n.xf*t->x+n.yf*t->y+n.zf*t->z;

		// test
		if(n.xf*p->xf+n.yf*p->yf+n.zf*p->zf-d<0) 
		{
			_ShadVb.UnLock();
			return false;
		}

		_ShadVb.UnLock();
		return true;
	}

	if(_Flags==PVSV_CONCAVE)
	{
		t0=t=(PVVBS_XYZ*)_ShadVb.Lock();
		unsigned k=((pvMeshEdgesInfo*)_Mesh->EdgeTable)->GetNbrEdges()*2;

		unsigned j=_NbrVtxInShadow/2;
		
		// Calcul de PVue, dans le plan P-LightDir, et loin pour etre sur qu'on est pas dans un SV
		pvVector3D PVue,PEye;
		pvVector3D vdir;

		PEye.FromArray(&p->xf);
		
		vdir.FromArray(&_Light->Direction.xf);

		// 90 degr�s
		float tmp=vdir.x;
		vdir.x=vdir.y;
		vdir.y=-tmp;

		PVue=PEye+vdir*10e5;

		unsigned Count=0;
	
		while(j>0)
		{
			t2=t+1;
			t3=t+1+k;
			t4=t+k;

			float v[4*3];
			memcpy(&v[0],t,sizeof(float)*3);
			memcpy(&v[3],t2,sizeof(float)*3);
			memcpy(&v[6],t3,sizeof(float)*3);
			memcpy(&v[9],t4,sizeof(float)*3);

			// Normale
			x=t2->x-t->x;
			y=t2->y-t->y;
			z=t2->z-t->z;

			x1=t4->x-t->x;
			y1=t4->y-t->y;
			z1=t4->z-t->z;

			n.xf=y*z1-z*y1;
			n.yf=z*x1-x*z1;
			n.zf=x*y1-y*x1;
			d=n.xf*t->x+n.yf*t->y+n.zf*t->z;


			float di;
			PVPoint inter;
			if(PV_RayPolygonIntersection(v,4,&n,(PVPoint *)&PEye,(PVPoint *)&vdir,10e5,&di,(float *)&inter.xf))
			{
				// Intersection
				PVPoint p;

				RotateInvertPoint(&n,_Mesh->LastWorldMatrix,&p);
				if(p.zf>0)				
					Count++;
				else
					Count--;
			}

			j--;
			t+=2;
		}
		_ShadVb.UnLock();
		return (Count>0);
	}

	return false;
}

void pvShadowVolume::DrawVolume(unsigned buf,PVPoint *camdir)
{
	PVVBS_XYZ *t,*t2,*t3,*t4,*t0;	
	unsigned j,k;

	if(_Flags==PVSV_CONVEX)
	{
		t0=t=(PVVBS_XYZ*)_ShadVb.Lock();
		
		j=GetNbrVtx();
		j/=2;
		k=j;			
		
		pvBegin(PV_QUADS,(unsigned char*)buf);		
		while(j>0)
		{
			t2=t+1;
			t3=t+1+k;
			t4=t+k;

			if(j==1)
			{
				t2=t0;
				t3=t0+k;
			}
			
			pvColor(0,1,0,0.5);
			pvVertexfv((float*)t4);
			pvVertexfv((float*)t3);
			pvVertexfv((float*)t2);
			pvVertexfv((float*)t);						
			j--;
			t++;
		}
		pvEnd();
		_ShadVb.UnLock();
	}
	else
	{		
		t0=t=(PVVBS_XYZ*)_ShadVb.Lock();
		unsigned k=((pvMeshEdgesInfo*)_Mesh->EdgeTable)->GetNbrEdges()*2;

		unsigned j=_NbrVtxInShadow/2;

		pvBegin(PV_QUADS,(unsigned char*)buf);				
		while(j>0)
		{
			t2=t+1;
			t3=t+1+k;
			t4=t+k;

			pvColor(0,1,0,0.5);
			pvVertexfv((float*)t);
			pvVertexfv((float*)t2);
			pvVertexfv((float*)t3);
			pvVertexfv((float*)t4);

			j--;
			t+=2;
		}
		pvEnd();
		_ShadVb.UnLock();
	}
}

pvShadowVolume::~pvShadowVolume()
{
}

int PVAPI PV_DrawShadows(PVMesh *m,unsigned buf,PVPoint *camdir)
{
	unsigned i;
	pvShadowVolume *shad;

	i=0;
	while(m->Shadows[i]!=NULL)
	{
		shad=(pvShadowVolume*)m->Shadows[i];
		shad->DrawVolume(buf,camdir);

		i++;
	}

	return COOL;
}

static int PVAPI PV_IsInShadowsIterator(PVMesh *m,int n)
{
	unsigned i;
	pvShadowVolume *shad;
	unsigned *nbr=(unsigned*)n;

	if(!(m->Flags&MESH_CAST_SHADOWS)) return COOL;

	i=0;
	while(m->Shadows[i]!=NULL)
	{
		shad=(pvShadowVolume*)m->Shadows[i];
		if(shad->IsPointInShadowVolume(&m->Owner->Camera->pos)) 
		{
			(*nbr)++;
			return 1;
		}

		i++;
	}

	return COOL;	
}

int PVAPI PV_IsInShadows(PVWorld *w)
{
	unsigned nbr;
	
	nbr=0;

	if(PV_IterateMeshList(w->Objs,PV_IsInShadowsIterator,(int)&nbr)!=COOL) return 1;

	return nbr;	
}


void PVAPI PV_FinalizeMesh(PVMesh *m)
{
	if(m==NULL) return;

	if(!(m->Flags&MESH_INSTANCE)) delete ((pvMeshEdgesInfo *)m->EdgeTable);

	for(unsigned i=0;i<MAX_SHADOW_VOLUMES;i++) 
	{
		delete ((pvShadowVolume*)m->Shadows[i]);
	}
}

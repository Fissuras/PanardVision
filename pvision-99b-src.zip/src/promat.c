/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdlib.h>
#include <string.h>
#include "pvision.h"

PVMaterial *PVAPI PV_CreateProceduralMaterial(char *n,unsigned width, unsigned height,PVFLAGS type,PVFLAGS flags)
{
	PVMaterial *m;
	unsigned h;
	UPVD8 *texture=NULL;
	PVRGBF a={0,0,0,0};
	
	m=PV_CreateMaterial(n,type,flags,1);
	if(m==NULL) return NULL;

	// On alloue en 24 ou 32 bits puis on le compilera
	// pour que la surface hardware soit au format de la carte	
	if(flags&TEXTURE_RGBA) texture=(UPVD8*)malloc(width*height*4);
	if(flags&TEXTURE_RGB) texture=(UPVD8*)malloc(width*height*3);
	if(texture==NULL) 
	{
		PV_KillMaterial(m);
		return NULL;
	}

	h=PV_SetMaterialTexture(m,width,height,texture,NULL);
	if(h!=COOL) 
	{
		free(texture);
		PV_KillMaterial(m);
		return NULL;
	}
	
	m->Type|=PROCEDURAL;

	// Peut etre pas nescessaire
	PV_CompileMaterial(m,NULL,NULL,a,0);
	
	return m;
}

int PVAPI PV_LockProceduralMaterial(PVMaterial *m,PVRGBFormat *rgbaccess,UPVD8 **texture,PVFLAGS access)
{
	if(m==NULL) return ARG_INVALID;
	if(rgbaccess==NULL) return ARG_INVALID;
	if(!(m->Type&PROCEDURAL)) return ARG_INVALID;

	if(PV_Mode&PVM_USEHARDWARE)
	{
		PVHardwareDriver *hr=NULL;

		hr=PV_GetHardwareDriver();
		if(hr==NULL) return NO_HARDWARE_SET;

		if(hr->LockProceduralMaterial==NULL) return ACCEL_FUNCTION_UNSUPPORTED;

		*texture=hr->LockProceduralMaterial(m,rgbaccess,access);
	}
	else
	{ 		
		if(PV_Mode&PVM_PALETIZED8)
		{
			memset(rgbaccess,0,sizeof(PVRGBFormat));
			rgbaccess->Pitch=m->Tex[0].Width;
			rgbaccess->NbrBitsPerPixel=8;
		}
		else
		if((m->Type&SHADE_MASK)!=0)
		{
			rgbaccess->RedSize=8;
			rgbaccess->GreenSize=8;
			rgbaccess->BlueSize=8;
			rgbaccess->AlphaSize=0;
			rgbaccess->RedPos=0;
			rgbaccess->BluePos=16;
			rgbaccess->GreenPos=8;
			rgbaccess->AlphaPos=0;
			rgbaccess->NbrBitsPerPixel=24;
			rgbaccess->Pitch=m->Tex[0].Width*3;
		}
		else
		{
			rgbaccess->RedSize=RMaskSize;
			rgbaccess->GreenSize=GMaskSize;
			rgbaccess->BlueSize=BMaskSize;
			rgbaccess->AlphaSize=0;
			rgbaccess->RedPos=RFieldPos;
			rgbaccess->BluePos=BFieldPos;
			rgbaccess->GreenPos=GFieldPos;
			rgbaccess->AlphaPos=0;
			rgbaccess->NbrBitsPerPixel=PixelSize*8;
			rgbaccess->Pitch=m->Tex[0].Width*PixelSize;
		}
		*texture=m->Tex[0].Texture;
	}
	return COOL;
}

void PVAPI PV_UnLockProceduralMaterial(PVMaterial *m)
{
	if(m==NULL) return;
	if(!(m->Type&PROCEDURAL)) return;

	if(PV_Mode&PVM_USEHARDWARE)
	{
		PVHardwareDriver *hr=NULL;

		hr=PV_GetHardwareDriver();
		if(hr==NULL) return;

		if(hr->UnlockProceduralMaterial==NULL) return;
		
		hr->UnlockProceduralMaterial(m);
	}
	PV_RefreshMaterial(m);
}
/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include "fillcom.h"

static int __cdecl Init1GMapping(int NumVtx,unsigned *vtx) {
    PVMesh *o=GenFill_CurrentFace->Father;
    float a,b,c;
	unsigned i;

    // Accelerator
	for(i=1;i<NumVtx;i++) if(o->Shading[vtx[i]].Color.r!=o->Shading[vtx[i-1]].Color.r) break;
	if(i==NumVtx)
	{
		for(i=1;i<NumVtx;i++) if(o->Shading[vtx[i]].Color.g!=o->Shading[vtx[i-1]].Color.g) break;
		if(i==NumVtx)
		{
			for(i=1;i<NumVtx;i++) if(o->Shading[vtx[i]].Color.b!=o->Shading[vtx[i-1]].Color.b) break;
			if(i==NumVtx)
			{
				TriRGBFlatMapping(GenFill_CurrentFace);
				return 1;
			}
		}
	}

    GenFill_NbrIncF=3;
    GenFill_NbrInc=5;

    a=GenFill_CurrentFace->MaterialInfo->Emissive.r;
    b=GenFill_CurrentFace->MaterialInfo->Emissive.g;
    c=GenFill_CurrentFace->MaterialInfo->Emissive.b;

	for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][0]=min(1,(o->Shading[vtx[i]].Color.r+RGBAmbientLight->r)*GenFill_CurrentFace->MaterialInfo->Diffuse.r+a)*RedFact;
		GenFill_InitialValues[i][1]=min(1,(o->Shading[vtx[i]].Color.g+RGBAmbientLight->g)*GenFill_CurrentFace->MaterialInfo->Diffuse.g+b)*GreenFact;
		GenFill_InitialValues[i][2]=min(1,(o->Shading[vtx[i]].Color.b+RGBAmbientLight->b)*GenFill_CurrentFace->MaterialInfo->Diffuse.b+c)*BlueFact;
		GenFill_InitialValues[i][3]=o->Mapping[vtx[i]].u;
    	GenFill_InitialValues[i][4]=o->Mapping[vtx[i]].v;
    }

    return 0;
}

static void __cdecl Init2GMapping(int NumVtx) {
 float mu,mv;
 unsigned MipIndex;
 unsigned TextureW,TextureH;
 unsigned Bi=0,i;

    // MipMap
    if((GenFill_CurrentFace->Flags&AUTOMATIC_BILINEAR)||((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP)))
    {
        mu=fabs(GenFill_GradientX[3]*(GenFill_CurrentFace->MaterialInfo->Tex[0].Width));
        mv=fabs(GenFill_GradientX[4]*(GenFill_CurrentFace->MaterialInfo->Tex[0].Height));
        MipIndex=GetMipMap(GenFill_CurrentFace->MaterialInfo->NbrMipMaps,mu,mv);
    }

    if((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP))
    {
        Texture=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].ShiftWidth;
    }
    else
    {
        // No MipMap
        Texture=GenFill_CurrentFace->MaterialInfo->Tex[0].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[0].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[0].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[0].ShiftWidth;
    }

    GenFill_GradientX[3]*=TextureW;
    GenFill_GradientX[4]*=TextureH;
    GenFill_GradientY[3]*=TextureW;
    GenFill_GradientY[4]*=TextureH;
    GenFill_iGradientX[3]=(int)(GenFill_GradientX[3]*65536.0);
    GenFill_iGradientX[4]=(int)(GenFill_GradientX[4]*65536.0);

	for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][3]*=(TextureW);
        GenFill_InitialValues[i][4]*=(TextureH);
    }

    AndHeight=TextureH-1;
    AndWidth=TextureW-1;

    if((PV_Mode&PVM_BILINEAR)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_BILINEAR))
        if(GenFill_CurrentFace->Flags&AUTOMATIC_BILINEAR)
        { if(MipIndex==0) Bi=1;}
        else Bi=1;

    if(Bi)
    switch(PixelSize)
    {
        case 2:HLineRoutine=HLineRGBGouraudTextureMapping16Bi;break;
        case 3:HLineRoutine=HLineRGBGouraudTextureMapping24Bi;break;
        case 4:HLineRoutine=HLineRGBGouraudTextureMapping32Bi;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }
    else
    switch(PixelSize)
    {
        case 2:HLineRoutine=HLineRGBGouraudTextureMapping16;break;
        case 3:HLineRoutine=HLineRGBGouraudTextureMapping24;break;
        case 4:HLineRoutine=HLineRGBGouraudTextureMapping32;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }

#ifdef __386__
    HLineRGBGouraudMapping_INIT();
#endif
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct RGBGouraudAffineMapping={Init1GMapping,Init2GMapping};


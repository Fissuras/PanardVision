/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Spline code taken from spline_3.c of ADEPT/ESTEEM (adept@aquanet.co.il)

#include <malloc.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "pmotion.h"
#include "pvision.h"

#define debug(x) //x

typedef struct _InterCalcul
{
    float x,y,z;
    PVQuat q;
    PVPoint pivott;
} InterCalcul;

static InterCalcul Identity={0,0,0,1,0,0,0,0,0,0};
static PMotion *CurrentMotion;
static PVMat3x3 MatID={1,0,0,0,1,0,0,0,1};

char *PMOTION_DATE=__DATE__;
char *PMOTION_TIME=__TIME__;
char *PMOTION_VERSION="0.3d";

static char *PMOTION_COPYRIGHT="Panard Motion - Animation engine for Panard Vision (C) 1996-99, Olivier Brunet";

///////////////////////////////////////////////// Amis des splines, bonsoir

static float Ease( float t, float a, float b)  {
	float k;
	float s = a+b;

	if (s == 0.0) return t;
	if (s > 1.0) {
		a = a/s;
		b = b/s;
	}
	k = 1.0/(2.0-a-b);
	if (t < a) return ((k/a)*t*t);
	else	{
		if (t < 1.0-b)	{
			return (k*(2*t - a));
		}	else {
			t = 1.0-t;
			return (1.0-(k/b)*t*t);
		}
	}
}

/*---------------------------------------------------------------------------
 This computes the derivative at key, as a weighted average of the linear
 slopes into and out of key, the weights being determined by the tension and
 continuity parameters.
 Actually two derivatives are computed at key:
				"ds" is the "source derivative", or "arriving derivative"
				"dd" is the "destination derivative" or "departing derivative"
---------------------------------------------------------------------------*/
static void    CompDeriv( PMPKey *prevkey,PMPKey *key,PMPKey *nextkey,float lasttime ) {
	float dsA,dsB,ddA,ddB,dsAdjust,ddAdjust;
	float v1,v2;
	float pf,f,nf;

    pf = prevkey->Time;
    f =  key->Time;
    nf = nextkey->Time;
	if (pf > f)	{			// if track have LOOP flag.
        f += lasttime;
        nf += lasttime;
	} else
	if (f > nf)	{
        nf += lasttime;
	}
    dsA = (1.0 - key->SplineParms.tens) * (1.0 - key->SplineParms.cont) * (1.0 + key->SplineParms.bias);
    dsB = (1.0 - key->SplineParms.tens) * (1.0 + key->SplineParms.cont) * (1.0 - key->SplineParms.bias);
	dsAdjust = (f - pf)/(nf - pf);

    ddA = (1.0 - key->SplineParms.tens) * (1.0 + key->SplineParms.cont) * (1.0 + key->SplineParms.bias);
    ddB = (1.0 - key->SplineParms.tens) * (1.0 - key->SplineParms.cont) * (1.0 - key->SplineParms.bias);
	ddAdjust = (nf - f)/(nf - pf);

	// X derivative.
    v1 = key->Pos.xf - prevkey->Pos.xf;
    v2 = nextkey->Pos.xf - key->Pos.xf;
    key->SplineParms.ds.x = dsAdjust*( dsA*v1 + dsB*v2 );
    key->SplineParms.dd.x = ddAdjust*( ddA*v1 + ddB*v2 );

	// Y derivative.
    v1 = key->Pos.yf - prevkey->Pos.yf;
    v2 = nextkey->Pos.yf - key->Pos.yf;
    key->SplineParms.ds.y = dsAdjust*( dsA*v1 + dsB*v2 );
    key->SplineParms.dd.y = ddAdjust*( ddA*v1 + ddB*v2 );

	// Z derivative.
    v1 = key->Pos.zf - prevkey->Pos.zf;
    v2 = nextkey->Pos.zf - key->Pos.zf;
    key->SplineParms.ds.z = dsAdjust*( dsA*v1 + dsB*v2 );
    key->SplineParms.dd.z = ddAdjust*( ddA*v1 + ddB*v2 );
}

static void    CompDerivRoll( PMRollKey *prevkey,PMRollKey *key,PMRollKey *nextkey,float lasttime ) {
	float dsA,dsB,ddA,ddB,dsAdjust,ddAdjust;
	float v1,v2;
	float pf,f,nf;

    pf = prevkey->Time;
    f =  key->Time;
    nf = nextkey->Time;
	if (pf > f)	{			// if track have LOOP flag.
        f += lasttime;
        nf += lasttime;
	} else
	if (f > nf)	{
        nf += lasttime;
	}
    dsA = (1.0 - key->SplineParms.tens) * (1.0 - key->SplineParms.cont) * (1.0 + key->SplineParms.bias);
    dsB = (1.0 - key->SplineParms.tens) * (1.0 + key->SplineParms.cont) * (1.0 - key->SplineParms.bias);
	dsAdjust = (f - pf)/(nf - pf);

    ddA = (1.0 - key->SplineParms.tens) * (1.0 + key->SplineParms.cont) * (1.0 + key->SplineParms.bias);
    ddB = (1.0 - key->SplineParms.tens) * (1.0 - key->SplineParms.cont) * (1.0 - key->SplineParms.bias);
	ddAdjust = (nf - f)/(nf - pf);

	// X derivative.
    v1 = key->Roll - prevkey->Roll;
    v2 = nextkey->Roll - key->Roll;
    key->SplineParms.ds.x = dsAdjust*( dsA*v1 + dsB*v2 );
    key->SplineParms.dd.x = ddAdjust*( ddA*v1 + ddB*v2 );

}

static void    CompDerivFirst(PMPKey *key,PMPKey *keyn,PMPKey *keynn)
{
	float	f20,f10,v20,v10;
    f20 = keynn->Time-key->Time;
    f10 = keyn->Time-key->Time;

    v20 = keynn->Pos.xf - key->Pos.xf;
    v10 = keyn->Pos.xf - key->Pos.xf;
    key->SplineParms.dd.x = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);

    v20 = keynn->Pos.yf - key->Pos.yf;
    v10 = keyn->Pos.yf - key->Pos.yf;
    key->SplineParms.dd.y = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);

    v20 = keynn->Pos.zf - key->Pos.zf;
    v10 = keyn->Pos.zf - key->Pos.zf;
    key->SplineParms.dd.z = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);
}

static void    CompDerivLast(PMPKey *keypp,PMPKey *keyp,PMPKey *key)
{
	float	f20,f10,v20,v10;
    f20 = key->Time - keypp->Time;
    f10 = key->Time - keyp->Time;

    v20 = key->Pos.xf - keypp->Pos.xf;
    v10 = key->Pos.xf - keyp->Pos.xf;
    key->SplineParms.ds.x = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);

    v20 = key->Pos.yf - keypp->Pos.yf;
    v10 = key->Pos.yf - keyp->Pos.yf;
    key->SplineParms.ds.y = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);

    v20 = key->Pos.zf - keypp->Pos.zf;
    v10 = key->Pos.zf - keyp->Pos.zf;
    key->SplineParms.ds.z = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);
}

static void    CompDerivFirst2( PMPKey *key,PMPKey *keyn )   {
	float	v;
    v = keyn->Pos.xf - key->Pos.xf;
    key->SplineParms.dd.x = v*(1-key->SplineParms.tens);

    v = keyn->Pos.yf - key->Pos.yf;
    key->SplineParms.dd.y = v*(1-key->SplineParms.tens);

    v = keyn->Pos.zf - key->Pos.zf;
    key->SplineParms.dd.z = v*(1-key->SplineParms.tens);
}

static void    CompDerivLast2( PMPKey *keyp,PMPKey *key )    {
	float	v;
    v = key->Pos.xf - keyp->Pos.xf;
    key->SplineParms.ds.x = v*(1-key->SplineParms.tens);

    v = key->Pos.yf - keyp->Pos.yf;
    key->SplineParms.ds.y = v*(1-key->SplineParms.tens);

    v = key->Pos.zf - keyp->Pos.zf;
    key->SplineParms.ds.z = v*(1-key->SplineParms.tens);
}

static void    CompDerivFirstRoll(PMRollKey *key,PMRollKey *keyn,PMRollKey *keynn)
{
	float	f20,f10,v20,v10;
    f20 = keynn->Time-key->Time;
    f10 = keyn->Time-key->Time;

    v20 = keynn->Roll - key->Roll;
    v10 = keyn->Roll - key->Roll;
    key->SplineParms.dd.x = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);
}

static void    CompDerivLastRoll(PMRollKey *keypp,PMRollKey *keyp,PMRollKey *key)
{
	float	f20,f10,v20,v10;
    f20 = key->Time - keypp->Time;
    f10 = key->Time - keyp->Time;

    v20 = key->Roll - keypp->Roll;
    v10 = key->Roll - keyp->Roll;
    key->SplineParms.ds.x = (1-key->SplineParms.tens)*(v20*(0.25 - f10/(2*f20)) + (v10 - v20/2)*3/2 + v20/2);
}

static void    CompDerivFirst2Roll( PMRollKey *key,PMRollKey *keyn )   {
	float	v;
    v = keyn->Roll - key->Roll;
    key->SplineParms.dd.x = v*(1-key->SplineParms.tens);
}

static void    CompDerivLast2Roll( PMRollKey *keyp,PMRollKey *key )    {
	float	v;
    v = key->Roll - keyp->Roll;
    key->SplineParms.ds.x = v*(1-key->SplineParms.tens);
}

//---

static int CompAB( PMRKey *prev, PMRKey *cur, PMRKey *next )
{
    PVQuat qprev,qnext,q;
	PVQuat qp,qm,qa,qb,qae,qbe;
	float tm,cm,cp,bm,bp,tmcm,tmcp,ksm,ksp,kdm,kdp,c;
	float dt,fp,fn;

	if( prev != NULL ) {
        if (fabs(cur->SplineParms.angleaxis.w - prev->SplineParms.angleaxis.w) > 2*PI-.00001) {
            q = cur->SplineParms.angleaxis;
			q.w = 0;
            QuatLog( &q,&qm );
		} else {
            qprev = prev->q;
            if (QuatDotUnit( &qprev,&cur->q ) < 0) QuatNegate( &qprev );
            QuatLnDif( &qprev, &cur->q, &qm );
		}
	}

	if( next != NULL ) {
        if( fabs(next->SplineParms.angleaxis.w - cur->SplineParms.angleaxis.w) > 2*PI-.00001 ) {
            q = next->SplineParms.angleaxis;
			q.w = 0;
            QuatLog( &q, &qp );
		} else {
            qnext = next->q;
            if (QuatDotUnit( &qnext,&cur->q ) < 0) QuatNegate( &qnext );
            QuatLnDif(&cur->q, &qnext, &qp );
		}
	}

	if( prev == NULL ) qm = qp;
	if( next == NULL ) qp = qm;

	fp = fn = 1.0;
    cm = 1.0 - cur->SplineParms.cont;

	if( prev && next ) {
        dt = 0.5 * (float)(next->Time - prev->Time );
        fp = ((float)(cur->Time - prev->Time))/dt;
        fn = ((float)(next->Time - cur->Time))/dt;
        c = fabs( cur->SplineParms.cont );
		fp = fp + c - c * fp;
		fn = fn + c - c * fn;
	}
    tm = .5*(1.0 - cur->SplineParms.tens);
	cp = 2.0 - cm;
    bm = 1.0 - cur->SplineParms.bias;
	bp = 2.0 - bm;
	tmcm = tm * cm;
	tmcp = tm * cp;
	ksm  = 1.0 - tmcm * bp * fp;
	ksp  = -tmcp * bm * fp;
	kdm  = tmcp * bp * fn;
	kdp  = tmcm * bm * fn - 1.0;

	qa.x = .5 * ( kdm * qm.x + kdp * qp.x );
	qb.x = .5 * ( ksm * qm.x + ksp * qp.x );

	qa.y = .5 * ( kdm * qm.y + kdp * qp.y );
	qb.y = .5 * ( ksm * qm.y + ksp * qp.y );

	qa.z = .5 * ( kdm * qm.z + kdp * qp.z );
	qb.z = .5 * ( ksm * qm.z + ksp * qp.z );

	qa.w = .5 * ( kdm * qm.w + kdp * qp.w );
	qb.w = .5 * ( ksm * qm.w + ksp * qp.w );

    QuatExp( &qa, &qae );
    QuatExp( &qb, &qbe );

    QuatMul( &cur->q, &qae, &cur->SplineParms.ds );
    QuatMul( &cur->q, &qbe, &cur->SplineParms.dd );

	return 0;
}

/////////////////////////////////////////////////

PMotion * PVAPI PM_CreateTree(void)
{
    PMotion *m;

    if((m=(PMotion*)malloc(sizeof(PMotion)))==NULL) return NULL;

    m->CurrentTime=0;
    m->MaxTime=1;
    m->RootObj=PM_CreateNode(-1);
    if(m->RootObj==NULL)
    {
        PM_KillTree(m);
        return NULL;
    }

    return m;
}

void PVAPI PM_KillTree(PMotion *m)
{
    if(m==NULL) return;
	PM_KillNode(m->RootObj);
    free(m);
}

void PVAPI PM_SetCurrentTime(PMotion *m,float t)
{
    while(t>=m->MaxTime) t-=m->MaxTime;
    m->CurrentTime=t;
}

/////////////////////////////////////////////////


static void GetPosKey(PosKeys *n,float t,InterCalcul *ITmp)
{
    unsigned i;
    PMPKey *k,*kl;
    float a,b,c,c2,c3,h[4];

    if (n->Flags&(TRACK_LOOP||TRACK_REPEAT))
        t = n->Keys[0].Time + fmod( t,n->Keys[n->NbKeys-1].Time - n->Keys[0].Time );

    kl=k=&n->Keys[0];
    b=a=k->Time;
    for(i=0;i<n->NbKeys;i++)
    {
        b=k->Time;

        if(t<=b) break;

        a=b;
        kl=k;
        if((i+1)<n->NbKeys) k++;
    }

    if((b-a)!=0) c=(t-a)/(b-a); else c=1;

    // Splines land
	if(n->NbKeys>2)
	{
		c=Ease(c,kl->SplineParms.easefrom,k->SplineParms.easeto);
		c2=c*c;
		c3=c2*c;
		h[0]=2*c3-3*c2+1;
		h[1]=-2*c3+3*c2;
		h[2]=c3-2*c2+c;
		h[3]=c3-c2;

		ITmp->x=h[0]*kl->Pos.xf+h[1]*k->Pos.xf+h[2]*kl->SplineParms.dd.x+h[3]*k->SplineParms.ds.x;
		ITmp->y=h[0]*kl->Pos.yf+h[1]*k->Pos.yf+h[2]*kl->SplineParms.dd.y+h[3]*k->SplineParms.ds.y;
		ITmp->z=h[0]*kl->Pos.zf+h[1]*k->Pos.zf+h[2]*kl->SplineParms.dd.z+h[3]*k->SplineParms.ds.z;
	}
	else
	{
		ITmp->x=kl->Pos.xf+c*(k->Pos.xf-kl->Pos.xf);
		ITmp->y=kl->Pos.yf+c*(k->Pos.yf-kl->Pos.yf);
		ITmp->z=kl->Pos.zf+c*(k->Pos.zf-kl->Pos.zf);
	}
}

static void SetScale(PosKeys *n,float t,PVMesh *m)
{
    unsigned i;
    PMPKey *k,*kl;
    float a,b,c,c2,c3,h[4];


    if(n->NbKeys==0) return;

    if (n->Flags&(TRACK_LOOP||TRACK_REPEAT))
        t = n->Keys[0].Time + fmod( t,n->Keys[n->NbKeys-1].Time - n->Keys[0].Time );


    kl=k=&n->Keys[0];
    b=a=k->Time;
    for(i=0;i<n->NbKeys;i++)
    {
        b=k->Time;

        if(t<=b) break;

        a=b;
        kl=k;
        if((i+1)<n->NbKeys) k++;
    }

    if((b-a)!=0) c=(t-a)/(b-a); else c=1;

    // Splines land
    c=Ease(c,kl->SplineParms.easefrom,k->SplineParms.easeto);
    c2=c*c;
    c3=c2*c;
    h[0]=2*c3-3*c2+1;
    h[1]=-2*c3+3*c2;
    h[2]=c3-2*c2+c;
    h[3]=c3-c2;

    m->ScaleX=h[0]*kl->Pos.xf+h[1]*k->Pos.xf+h[2]*kl->SplineParms.dd.x+h[3]*k->SplineParms.ds.x;
    m->ScaleY=h[0]*kl->Pos.yf+h[1]*k->Pos.yf+h[2]*kl->SplineParms.dd.y+h[3]*k->SplineParms.ds.y;
    m->ScaleZ=h[0]*kl->Pos.zf+h[1]*k->Pos.zf+h[2]*kl->SplineParms.dd.z+h[3]*k->SplineParms.ds.z;
}

static float GetRollKey(RollKeys *n,float t)
{
    unsigned i;
    PMRollKey *k,*kl;
    float a,b,c,c2,c3,h[4];


    if(n->NbKeys==0) return 0;

    if (n->Flags&(TRACK_LOOP||TRACK_REPEAT))
        t = n->Keys[0].Time + fmod( t,n->Keys[n->NbKeys-1].Time - n->Keys[0].Time );


    kl=k=&n->Keys[0];
    b=a=k->Time;
    for(i=0;i<n->NbKeys;i++)
    {
        b=k->Time;

        if(t<=b) break;

        a=b;
        kl=k;
        if((i+1)<n->NbKeys) k++;
    }

    if((b-a)!=0) c=(t-a)/(b-a); else c=1;

    // Splines land
	if(n->NbKeys>2)
	{
		c=Ease(c,kl->SplineParms.easefrom,k->SplineParms.easeto);
		c2=c*c;
		c3=c2*c;
		h[0]=2*c3-3*c2+1;
		h[1]=-2*c3+3*c2;
		h[2]=c3-2*c2+c;
		h[3]=c3-c2;

		return h[0]*kl->Roll+h[1]*k->Roll+h[2]*kl->SplineParms.dd.x+h[3]*k->SplineParms.ds.x;
	}
	else
    return kl->Roll+c*(k->Roll-kl->Roll);
}

static void GetRotKey(RotKeys *n,float t,PVQuat *q1)
{
    unsigned i;
    PMRKey *k,*kl;
    float a,b,time,spin,angle;
    PVQuat p,q;

    if (n->Flags&(TRACK_LOOP||TRACK_REPEAT))
        t = n->Keys[0].Time + fmod( t,n->Keys[n->NbKeys-1].Time - n->Keys[0].Time );

    kl=k=&n->Keys[0];
    b=a=k->Time;
    for(i=0;i<n->NbKeys;i++)
    {
        b=k->Time;
        if(t<=b) break;

        a=b;
        kl=k;
        if((i+1)<n->NbKeys) k++;
    }

	if(n->NbKeys>2)
	{
		if((b-a)!=0)
		{
			time=(t-a)/(b-a);
			time=Ease(time,kl->SplineParms.easefrom,k->SplineParms.easeto);

			angle = (k->SplineParms.angleaxis.w - kl->SplineParms.angleaxis.w);

			if (angle > 0)
				spin = floor( angle/(2*PI) );
			else
				spin = ceil( angle/(2*PI) );
			//angle = angle - (2*PI)*spin;

			//if (fabs(angle) > PI) {
				QuatSlerpLong( &kl->q,&k->q,&p,time,spin );
				QuatSlerpLong( &kl->SplineParms.dd,&k->SplineParms.ds,&q,time,spin );
				time = (((1.0-time)*2.0)*time);
				QuatSlerpLong( &p,&q,q1,time,0 );
			/* from clax }   else    {
				QuatSlerp( &kl->q,&k->q,&p,time,spin );
				QuatSlerp( &kl->SplineParms.dd,&k->SplineParms.ds,&q,time,spin );
				time = (((1.0-time)*2.0)*time);
				QuatSlerp( &p,&q,q1,time,0 );
			} */
	//        QuatInv(&q2,q1);
		}
		else
		{
			(*q1)=k->q;
		}
	}
	else
	{
		if((b-a)!=0)
		{
			time=(t-a)/(b-a);

            angle = (k->SplineParms.angleaxis.w - kl->SplineParms.angleaxis.w);

			if (angle > 0)
				spin = floor( angle/(2*PI) );
			else
				spin = ceil( angle/(2*PI) );

			QuatSlerp(&kl->q,&k->q,q1,time,spin);
		}
		else
		{
			(*q1)=k->q;
		}
	}
}

static unsigned IsMeshVisible(HideKeys *n,float t)
{
    unsigned i;
    PMHideKey *k,*kl;
    float a,b;

    if(n->NbKeys==0) return 1;

    if (n->Flags&(TRACK_LOOP||TRACK_REPEAT))
        t=fmod(t,n->Keys[n->NbKeys-1].Time);

    kl=k=&n->Keys[0];
    b=a=k->Time;
    for(i=0;i<n->NbKeys;i++)
    {
        b=k->Time;
        if(t<=b) break;

        a=b;
        kl=k;
        if((i+1)<n->NbKeys) k++;
    }

    if(t<a) return 1;
    if(t>b) return k->Visible;
    return kl->Visible;
}
static PVPoint GetPivot(PMNode *n)
{
    PVPoint a={0,0,0};

    if(n!=NULL)
    switch(n->Type)
    {
        case CAM_POS:
                if(n->Object==NULL) PV_Fatal("PMotion GetPivot::Node without object being computed\n",n->ID);
                a.xf=((PVCam*)(n->Object))->pos.xf;
                a.yf=((PVCam*)(n->Object))->pos.yf;
                a.zf=((PVCam*)(n->Object))->pos.zf;
                break;
        case LIGHT_POS:
                if(n->Object==NULL) PV_Fatal("PMotion GetPivot::Node without object being computed\n",n->ID);
                a.xf=((PVLight*)(n->Object))->Position.xf;
                a.yf=((PVLight*)(n->Object))->Position.yf;
                a.zf=((PVLight*)(n->Object))->Position.zf;
                break;
        case CAM_TARGET:
                if(n->Object==NULL) PV_Fatal("PMotion GetPivot::Node without object being computed\n",n->ID);
                a.xf=((PVCam*)(n->Object))->target.xf;
                a.yf=((PVCam*)(n->Object))->target.yf;
                a.zf=((PVCam*)(n->Object))->target.zf;
                break;
        case LIGHT_TARGET:
                if(n->Object==NULL) PV_Fatal("PMotion GetPivot::Node without object being computed\n",n->ID);
                a.xf=((PVLight*)(n->Object))->Target.xf;
                a.yf=((PVLight*)(n->Object))->Target.yf;
                a.zf=((PVLight*)(n->Object))->Target.zf;
                break;
        case MESH:
                if(n->Object==NULL) PV_Fatal("PMotion GetPivot::Node without object being computed\n",n->ID);
                a.xf=((PVMesh*)(n->Object))->Pivot.xf;
                a.yf=((PVMesh*)(n->Object))->Pivot.yf;
                a.zf=((PVMesh*)(n->Object))->Pivot.zf;
                break;
    }
    return a;
}

static PVMat3x3 *GetFatherMatrix(PMNode *n)
{
    PVMat3x3 *a=&MatID;


    if((n!=NULL)&&(n->Father!=NULL))
    switch(n->Father->Type)
    {
        case CAM_POS:
                if(n->Father->Object==NULL) PV_Fatal("PMotion GetFatherMatrix::Node without object being computed\n",BIZAR_ERROR);
                a=&((PVCam*)(n->Father->Object))->Matrix;
                break;
        case MESH:
                if(n->Father->Object==NULL) PV_Fatal("PMotion GetFatherMatrix::Node without object being computed\n",BIZAR_ERROR);
                a=&((PVMesh*)(n->Father->Object))->WorldMatrix;
                break;
    }
    return a;
}

///////////////////////////////////////////////////////////////////////

static void PM_ComputeObject(PMNode *InitialNode,InterCalcul *w)
{
        PMNode *m=InitialNode;
        InterCalcul INT;
        PVQuat q;
        PVPoint piv,pi,p,p2,pi2;
        PVMesh *me;
        unsigned i;
		PVMat3x3 tmp;

        while(m!=NULL)
        {
            // Verifie si c'est lma premiere fois
            if(!m->Flags)
            {
                m->Flags|=1;

                // Calcul les splines
                // Pour les positions
                if(m->Pos.NbKeys>2)
                {
                    for(i=1;i<m->Pos.NbKeys-1;i++) CompDeriv(&m->Pos.Keys[i-1],&m->Pos.Keys[i],&m->Pos.Keys[i+1],m->Pos.Keys[m->Pos.NbKeys-1].Time);

                    if (m->Pos.Flags&TRACK_LOOP)  {
                        CompDeriv( &m->Pos.Keys[m->Pos.NbKeys-2],&m->Pos.Keys[0],&m->Pos.Keys[1],m->Pos.Keys[m->Pos.NbKeys-1].Time );
                        CompDeriv( &m->Pos.Keys[m->Pos.NbKeys-2],&m->Pos.Keys[m->Pos.NbKeys-1],&m->Pos.Keys[1],m->Pos.Keys[m->Pos.NbKeys-1].Time );
                    }   else    {
                        CompDerivFirst(&m->Pos.Keys[0],&m->Pos.Keys[1],&m->Pos.Keys[2]);
                        CompDerivLast(&m->Pos.Keys[m->Pos.NbKeys-3],&m->Pos.Keys[m->Pos.NbKeys-2],&m->Pos.Keys[m->Pos.NbKeys-1]);
                    }

                }
                else
                {
                    if(m->Pos.NbKeys==2)
					{
						CompDerivFirst2(&m->Pos.Keys[0],&m->Pos.Keys[1]);
						CompDerivLast2(&m->Pos.Keys[0],&m->Pos.Keys[1]);
					}
					else if(m->Pos.NbKeys==1)
					{
                        m->Pos.Keys[0].SplineParms.dd.x=0;
                        m->Pos.Keys[0].SplineParms.dd.y=0;
                        m->Pos.Keys[0].SplineParms.dd.z=0;
                        m->Pos.Keys[0].SplineParms.ds.x=0;
                        m->Pos.Keys[0].SplineParms.ds.y=0;
                        m->Pos.Keys[0].SplineParms.ds.z=0;
					}
                }

                // Pour les Scale
                if(m->Scale.NbKeys>2)
                {
                    for(i=1;i<m->Scale.NbKeys-1;i++) CompDeriv(&m->Scale.Keys[i-1],&m->Scale.Keys[i],&m->Scale.Keys[i+1],m->Scale.Keys[m->Scale.NbKeys-1].Time);

                    if (m->Scale.Flags&TRACK_LOOP)  {
                        CompDeriv( &m->Scale.Keys[m->Scale.NbKeys-2],&m->Scale.Keys[0],&m->Scale.Keys[1],m->Scale.Keys[m->Scale.NbKeys-1].Time );
                        CompDeriv( &m->Scale.Keys[m->Scale.NbKeys-2],&m->Scale.Keys[m->Scale.NbKeys-1],&m->Scale.Keys[1],m->Scale.Keys[m->Scale.NbKeys-1].Time );
                    }   else    {
                        CompDerivFirst(&m->Scale.Keys[0],&m->Scale.Keys[1],&m->Scale.Keys[2]);
                        CompDerivLast(&m->Scale.Keys[m->Scale.NbKeys-3],&m->Scale.Keys[m->Scale.NbKeys-2],&m->Scale.Keys[m->Scale.NbKeys-1]);
                    }

                }
                else
                {
                    if(m->Scale.NbKeys==2)
					{
                        CompDerivFirst2(&m->Scale.Keys[0],&m->Scale.Keys[1]);
                        CompDerivLast2(&m->Scale.Keys[0],&m->Scale.Keys[1]);
					}
                    else if(m->Scale.NbKeys==1)
					{
                        m->Scale.Keys[0].SplineParms.dd.x=0;
                        m->Scale.Keys[0].SplineParms.dd.y=0;
                        m->Scale.Keys[0].SplineParms.dd.z=0;
                        m->Scale.Keys[0].SplineParms.ds.x=0;
                        m->Scale.Keys[0].SplineParms.ds.y=0;
                        m->Scale.Keys[0].SplineParms.ds.z=0;
					}
                }

				// Pour les roll
                if(m->Roll.NbKeys>2)
                {
                    for(i=1;i<m->Roll.NbKeys-1;i++) CompDerivRoll(&m->Roll.Keys[i-1],&m->Roll.Keys[i],&m->Roll.Keys[i+1],m->Roll.Keys[m->Roll.NbKeys-1].Time);

                    if (m->Roll.Flags&TRACK_LOOP)  {
                        CompDerivRoll( &m->Roll.Keys[m->Roll.NbKeys-2],&m->Roll.Keys[0],&m->Roll.Keys[1],m->Roll.Keys[m->Roll.NbKeys-1].Time );
                        CompDerivRoll( &m->Roll.Keys[m->Roll.NbKeys-2],&m->Roll.Keys[m->Roll.NbKeys-1],&m->Roll.Keys[1],m->Roll.Keys[m->Roll.NbKeys-1].Time );
                    }   else    {
                        CompDerivFirstRoll(&m->Roll.Keys[0],&m->Roll.Keys[1],&m->Roll.Keys[2]);
                        CompDerivLastRoll(&m->Roll.Keys[m->Roll.NbKeys-3],&m->Roll.Keys[m->Roll.NbKeys-2],&m->Roll.Keys[m->Roll.NbKeys-1]);
                    }
                }
                else
                {
                    if(m->Roll.NbKeys==2)
					{
						CompDerivFirst2Roll(&m->Roll.Keys[0],&m->Roll.Keys[1]);
						CompDerivLast2Roll(&m->Roll.Keys[0],&m->Roll.Keys[1]);
					}
					else if(m->Roll.NbKeys==1)
					{
                        m->Roll.Keys[0].SplineParms.dd.x=0;
                        m->Roll.Keys[0].SplineParms.dd.y=0;
                        m->Roll.Keys[0].SplineParms.dd.z=0;
                        m->Roll.Keys[0].SplineParms.ds.x=0;
                        m->Roll.Keys[0].SplineParms.ds.y=0;
                        m->Roll.Keys[0].SplineParms.ds.z=0;
					}
                }

                // Pour les rotations
                if(m->Rot.NbKeys>2)
                {
                    for(i=1;i<m->Rot.NbKeys-1;i++) CompAB( &m->Rot.Keys[i-1],&m->Rot.Keys[i],&m->Rot.Keys[i+1]);
                }

                if(m->Rot.NbKeys>=2)
                {
                    CompAB( NULL,&m->Rot.Keys[0],&m->Rot.Keys[1] );
                    CompAB( &m->Rot.Keys[0],&m->Rot.Keys[m->Rot.NbKeys-1],NULL );
                }
                else if(m->Rot.NbKeys==1)
                {
                    m->Rot.Keys[0].SplineParms.dd.x=0;
                    m->Rot.Keys[0].SplineParms.dd.y=0;
                    m->Rot.Keys[0].SplineParms.dd.z=0;
                    m->Rot.Keys[0].SplineParms.dd.w=0;
                    m->Rot.Keys[0].SplineParms.ds.x=0;
                    m->Rot.Keys[0].SplineParms.ds.y=0;
                    m->Rot.Keys[0].SplineParms.ds.z=0;
                    m->Rot.Keys[0].SplineParms.ds.w=0;
                }
            }

            // Calcul de cet Objet
            INT=Identity;
            q.w=1;q.x=q.y=q.z=0;
            INT.pivott.xf=0;
            INT.pivott.yf=0;
            INT.pivott.zf=0;

            if(m->Pos.NbKeys!=0) GetPosKey(&m->Pos,CurrentMotion->CurrentTime,&INT);
            if(m->Rot.NbKeys!=0) GetRotKey(&m->Rot,CurrentMotion->CurrentTime,&q);

            QuatMul(&w->q,&q,&INT.q);

            // Mise a jour dans Panard Vision
            if(m->Object!=NULL)
            switch(m->Type)
            {
                case CAM_POS:
                            // On rotate le pivot de l objet par rapport au pivot du parent
                            piv=GetPivot(m->Father);
                            pi.xf=INT.x-piv.xf;
                            pi.yf=INT.y-piv.yf;
                            pi.zf=INT.z-piv.zf;
                            RotatePoint3x3(&pi,*GetFatherMatrix(m),&pi2);

                            INT.pivott.xf=pi2.xf+piv.xf-INT.x+w->pivott.xf;
                            INT.pivott.yf=pi2.xf+piv.xf-INT.x+w->pivott.yf;
                            INT.pivott.zf=pi2.xf+piv.xf-INT.x+w->pivott.zf;

                            INT.x=pi2.xf+piv.xf+w->x;
                            INT.y=pi2.yf+piv.yf+w->y;
                            INT.z=pi2.zf+piv.zf+w->z;



                            PV_SetCamPos((PVCam*)m->Object,INT.x,INT.y,INT.z);
                            PV_SetCamRoll((PVCam*)m->Object,GetRollKey(&m->Roll,CurrentMotion->CurrentTime));
                        break;
                case CAM_TARGET:
                            // On rotate le pivot de l objet par rapport au pivot du parent
                            piv=GetPivot(m->Father);
                            pi.xf=INT.x-piv.xf;
                            pi.yf=INT.y-piv.yf;
                            pi.zf=INT.z-piv.zf;
                            RotatePoint3x3(&pi,*GetFatherMatrix(m),&pi2);

                            INT.pivott.xf=pi2.xf+piv.xf-INT.x+w->pivott.xf;
                            INT.pivott.yf=pi2.xf+piv.xf-INT.x+w->pivott.yf;
                            INT.pivott.zf=pi2.xf+piv.xf-INT.x+w->pivott.zf;

                            INT.x=pi2.xf+piv.xf+w->x;
                            INT.y=pi2.yf+piv.yf+w->y;
                            INT.z=pi2.zf+piv.zf+w->z;

                            PV_SetCamTarget((PVCam*)m->Object,INT.x,INT.y,INT.z);
                        break;
                case LIGHT_POS:
                            // On rotate le pivot de l objet par rapport au pivot du parent
                            piv=GetPivot(m->Father);
                            pi.xf=INT.x-piv.xf;
                            pi.yf=INT.y-piv.yf;
                            pi.zf=INT.z-piv.zf;
                            RotatePoint3x3(&pi,*GetFatherMatrix(m),&pi2);

                            INT.pivott.xf=pi2.xf+piv.xf-INT.x+w->pivott.xf;
                            INT.pivott.yf=pi2.xf+piv.xf-INT.x+w->pivott.yf;
                            INT.pivott.zf=pi2.xf+piv.xf-INT.x+w->pivott.zf;

                            INT.x=pi2.xf+piv.xf+w->x;
                            INT.y=pi2.yf+piv.yf+w->y;
                            INT.z=pi2.zf+piv.zf+w->z;

                            PV_SetLightPosition((PVLight*)m->Object,INT.x,INT.y,INT.z);
                        break;
                case LIGHT_TARGET:
                            // On rotate le pivot de l objet par rapport au pivot du parent
                            piv=GetPivot(m->Father);
                            pi.xf=INT.x-piv.xf;
                            pi.yf=INT.y-piv.yf;
                            pi.zf=INT.z-piv.zf;
                            RotatePoint3x3(&pi,*GetFatherMatrix(m),&pi2);

                            INT.pivott.xf=pi2.xf+piv.xf-INT.x+w->pivott.xf;
                            INT.pivott.yf=pi2.xf+piv.xf-INT.x+w->pivott.yf;
                            INT.pivott.zf=pi2.xf+piv.xf-INT.x+w->pivott.zf;

                            INT.x=pi2.xf+piv.xf+w->x;
                            INT.y=pi2.yf+piv.yf+w->y;
                            INT.z=pi2.zf+piv.zf+w->z;

                            PV_SetLightTarget((PVLight*)m->Object,INT.x,INT.y,INT.z);
                        break;
                case MESH:
                        // Calcul de la matrice de rotation et du scale
                        me=((PVMesh*)m->Object);
                        QuatToMatrix(&INT.q,tmp);
						PV_MeshSetupMatrixDirect(me,tmp);

                        SetScale(&m->Scale,CurrentMotion->CurrentTime,me);
                        if((m->Father!=NULL)&&(m->Father->Type==MESH))
                        {
                            me->ScaleX*=((PVMesh*)m->Father->Object)->ScaleX;
                            me->ScaleY*=((PVMesh*)m->Father->Object)->ScaleY;
                            me->ScaleZ*=((PVMesh*)m->Father->Object)->ScaleZ;
                        }

                        // Enregistrment des positions finales
                        if((m->Father!=NULL)&&(m->Father->Type==MESH))
                        {
                            INT.x+=m->Father->Pivot.xf;
                            INT.y+=m->Father->Pivot.yf;
                            INT.z+=m->Father->Pivot.zf;

                            // Scale le PVPoint de pivot
                            me->Pivot=m->Pivot;
                            me->Pivot.xf*=me->ScaleX;
                            me->Pivot.yf*=me->ScaleY;
                            me->Pivot.zf*=me->ScaleZ;

                            // On rotate le pivot de l objet par rapport au pivot du parent
                            piv=GetPivot(m->Father);
                            pi.xf=me->Pivot.xf-piv.xf;
                            pi.yf=me->Pivot.yf-piv.yf;
                            pi.zf=me->Pivot.zf-piv.zf;
                            RotatePoint3x3(&pi,*GetFatherMatrix(m),&pi2);
                            pi2.xf+=piv.xf;
                            pi2.yf+=piv.yf;
                            pi2.zf+=piv.zf;

                            // On soustrait le pivot non rot� pour obtenir la translation equivalente
                            piv=GetPivot(m);
                            pi2.xf-=piv.xf;
                            pi2.yf-=piv.yf;
                            pi2.zf-=piv.zf;
                            INT.pivott.xf=pi2.xf+w->pivott.xf;
                            INT.pivott.yf=pi2.yf+w->pivott.yf;
                            INT.pivott.zf=pi2.zf+w->pivott.zf;

                            // On recalcul la nouvelle cl� de position
                            // en fonction du scale et des nouvos pivots
                            INT.x+=m->Pivot.xf;
                            INT.y+=m->Pivot.yf;
                            INT.z+=m->Pivot.zf;
                            INT.x-=m->Father->Pivot.xf;
                            INT.y-=m->Father->Pivot.yf;
                            INT.z-=m->Father->Pivot.zf;

                            INT.x*=me->ScaleX;
                            INT.y*=me->ScaleY;
                            INT.z*=me->ScaleZ;

                            INT.x-=me->Pivot.xf;
                            INT.y-=me->Pivot.yf;
                            INT.z-=me->Pivot.zf;
                            INT.x+=((PVMesh*)m->Father->Object)->Pivot.xf;
                            INT.y+=((PVMesh*)m->Father->Object)->Pivot.yf;
                            INT.z+=((PVMesh*)m->Father->Object)->Pivot.zf;

                            p.xf=INT.x;
                            p.yf=INT.y;
                            p.zf=INT.z;
                            RotatePoint3x3(&p,*GetFatherMatrix(m),&p2);
                            INT.x=p2.xf+w->x;
                            INT.y=p2.yf+w->y;
                            INT.z=p2.zf+w->z;

                            // utilisr mesh machin							
							PV_MeshSetupPos(me,INT.x+INT.pivott.xf,INT.y+INT.pivott.yf,INT.z+INT.pivott.zf);

                        }
                        else
                        {
                            me->Pivot=m->Pivot;

                            // On rotate le pivot de l objet par rapport au pivot du parent
                            piv=GetPivot(m->Father);
                            pi.xf=me->Pivot.xf-piv.xf;
                            pi.yf=me->Pivot.yf-piv.yf;
                            pi.zf=me->Pivot.zf-piv.zf;
                            RotatePoint3x3(&pi,*GetFatherMatrix(m),&pi2);
                            pi2.xf+=piv.xf;
                            pi2.yf+=piv.yf;
                            pi2.zf+=piv.zf;

                            // On soustrait le pivot non rot� pour obtenir la translation equivalente
                            piv=GetPivot(m);
                            pi2.xf-=piv.xf;
                            pi2.yf-=piv.yf;
                            pi2.zf-=piv.zf;
                            INT.pivott.xf=pi2.xf+w->pivott.xf;
                            INT.pivott.yf=pi2.yf+w->pivott.yf;
                            INT.pivott.zf=pi2.zf+w->pivott.zf;

                            // Rotate le vecteur de deplacement comme le parent
                            p.xf=INT.x;
                            p.yf=INT.y;
                            p.zf=INT.z;
                            RotatePoint3x3(&p,*GetFatherMatrix(m),&p2);
                            INT.x=p2.xf+w->x;
                            INT.y=p2.yf+w->y;
                            INT.z=p2.zf+w->z;

							PV_MeshSetupPos(me,INT.x+INT.pivott.xf,INT.y+INT.pivott.yf,INT.z+INT.pivott.zf);
                        }

                        if (IsMeshVisible(&m->Hide,CurrentMotion->CurrentTime))
                        {
                            if(me->NbrVertices!=0) REMOVEFLAG(me->Flags,MESH_FORGET);
                        }
                        else
                        {
                            ADDFLAG(me->Flags,MESH_FORGET);
                        }
                //        OrthonormalizeMatrix(((PVMesh*)(m->Object))->Matrix);
                        break;
            }

            // Calcul les fils
            PM_ComputeObject(m->Child,&INT);

            // Suivant au meme nivo
            m=m->Next;
        }
}

void PVAPI PM_ComputeCurrentTime(PMotion *m)
{
        PMNode *n;

        if(m==NULL) return;

        n=m->RootObj;

        CurrentMotion=m;

        // Youpla
        while(n!=NULL)
        {
            PM_ComputeObject(n,&Identity);
            n=n->Next;
        }
}

/////////////////////////////////////////////////

PMNode * PVAPI PM_CreateNode(int ID)
{
    PMNode *m;

    if((m=(PMNode*)malloc(sizeof(PMNode)))==NULL) return NULL;

    m->Type=UNKNOW;
    m->ID=ID;
    m->Object=NULL;
    m->Rot.Keys=NULL;
    m->Pos.Keys=NULL;
    m->Roll.Keys=NULL;
    m->Scale.Keys=NULL;
    m->Hide.Keys=NULL;
    m->Rot.NbKeys=m->Pos.NbKeys=m->Roll.NbKeys=m->Scale.NbKeys=m->Hide.NbKeys=0;
    m->Rot.Flags=m->Pos.Flags=m->Roll.Flags=m->Scale.Flags=m->Hide.Flags=0;
    m->Next=m->Child=NULL;
    m->Father=NULL;
    m->Flags=0;

    return m;
}

void PVAPI PM_KillNode(PMNode *o)
{
    PMNode *t,*u;

    if(o==NULL) return;

    // foirrrrrrreuuuuuuux
    free(o->Pos.Keys);
    free(o->Rot.Keys);
    free(o->Roll.Keys);
    o->Rot.Keys=NULL;
    o->Pos.Keys=NULL;
    o->Roll.Keys=NULL;

    t=o->Child;
    while(t!=NULL)
    {

        u=t->Next;
        PM_KillNode(t);
        t=u;
    }
    o->Child=NULL;
    free(o);
}

void PVAPI PM_AddChild(PMNode *father,PMNode *newnode)
{
    PMNode *u;


    if(father==NULL) return;

    debug(printf("Adding object ID: %d to node ID: %d\n",newnode->ID,father->ID););
    // ca pue
    u=father->Child;

    father->Child=newnode;
    if(u!=NULL) newnode->Next=u;

    // Lien vers le parent
    newnode->Father=father;
}

PMNode * PVAPI PM_GetNodePtrByID(PMNode *m,int id)
{
    PMNode *n,*t;
    if (m->ID==id ) return m;

    if(m->Child!=NULL) if ((n=PM_GetNodePtrByID(m->Child,id))!=NULL) return n;

    t=m->Next;
    while(t!=NULL)
    {
        if ((n=PM_GetNodePtrByID(t,id))!=NULL) return n;
        t=t->Next;

    }
    return NULL;
}

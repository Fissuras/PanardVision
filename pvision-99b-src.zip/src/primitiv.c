/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "pvision.h"
#include "fillcom.h"
#include "sqrt.h"


#define MAX_BATCHED_FACES		500
#define MAX_BATCHED_VERTICES	5*MAX_BATCHED_FACES
#define MAX_CLIPPED_FACES		MAX_BATCHED_FACES			// Valeurs calcul�es pour des triangls
#define MAX_CLIPPED_VERTICES	MAX_BATCHED_FACES*3

typedef struct __pvList
{
	unsigned NbrMeshes;
	PVMesh** Meshes;
} pvList;


static PVCam pCam;
static PVWorld *pWorld=NULL;
static PVMesh *pMesh=NULL;
static PVFace *pFace;
static PVVertex *pVertex;
static PVScreenPoint *pProjected;
static PVMapInfo *pMapping;
static PVShadeInfo *pShading;

// Les variables d'�tat
static pvMODE CurrentMode=PV_2D;
static pvLIGHT CurrentLight=PV_NOLIGHTING;
static pvPRIMIT CurrentPrim;
static unsigned NbrVtx=0;
static unsigned ErrorCode=COOL;
static pvCULL CurrentCull=PV_CULL_NONE;
static UPVD8* CurrentBuffer=NULL;
static unsigned NbrTri=0,MaxVtx=0;
static PVMaterial *CurrentMaterial=NULL;
static pvList *InsideList=NULL;

// Flags d'acceleration
static char PreRenderNeeded=1;
static PVFLAGS LastPVM=0;

// Indexed
typedef struct __PVStrideInfo
{
	char *Ptr;
	unsigned stride;
} PVStrideInfo;

static PVFLAGS CurrentEnabledIndex=0;
static PVStrideInfo MapStride,AmbMapStride,ColorStride,SpecularStride,NormalStride,ColorIndexStride,VertexStride;

//----------------------------------------------------------------------------------
static int PVAPI PrimPipe(PVMesh *m);
static int AddMeshToList(pvList *l)
{
	PVMesh **t;
	PVMesh *m;

	t=(PVMesh**)realloc(l->Meshes,sizeof(PVMesh*)*(l->NbrMeshes+1));
	if(t==NULL) return NO_MEMORY;

	l->Meshes=t;
	pMesh->SwitchInfos.NbrVertexBox=pMesh->NbrVertices;
	m=PV_CloneMesh(pMesh);
	l->Meshes[l->NbrMeshes++]=m;	
	m->UserPipeline=PrimPipe;
	m->Flags=MESH_NOSORT;
	
	m->Shading=(PVShadeInfo*)malloc(sizeof(PVShadeInfo)*(m->NbrVertices+m->MaxNbrClippedVertices));
	if(m->Shading==NULL)
	{
		ErrorCode=NO_MEMORY;
		return NO_MEMORY;
	}
	memcpy(m->Shading,pMesh->Shading,sizeof(PVShadeInfo)*m->NbrVertices);

	if(PV_GetPipelineControl()&PVP_HARDWARETL)
	{
		PV_GetHardwareDriver()->UpdateMesh(m);		
		m->UserPipeline=NULL;
	}

	return COOL;
}

static int Cull2D(PVFace *f)
{
    unsigned p1,p2,p3;
    PVMesh *o=f->Father;
    float nz;

	if(f==NULL) return 0;
    if(CurrentCull==PV_CULL_NONE) return 1;

    p1=f->V[f->NbrVertices-1];
    p2=f->V[1];
    p3=f->V[0];

    nz=((o->Projected[p2].xf-o->Projected[p1].xf)*(o->Projected[p3].yf-o->Projected[p1].yf))-((o->Projected[p2].yf-o->Projected[p1].yf)*(o->Projected[p3].xf-o->Projected[p1].xf));

    switch(CurrentCull)
    {
        case PV_CULL_CW:return (nz>=0); break;
        case PV_CULL_CCW:return (nz<0);break;
    }
    return 0;
}

static int Cull3D(PVFace *f)
{
    unsigned p1,p2,p3;
    PVMesh *o=f->Father;
    double nz;
	unsigned *v;
	float x1,x2,x3,y1,y2,y3,z1,z2,z3;

	if(CurrentCull==PV_CULL_NONE) return 1;
    if(f==NULL) return 0;

    v=f->V;
	
	p1=v[2];
    p2=v[1];
    p3=v[0];

	x1=o->Rotated[p1].xf;
	x2=o->Rotated[p2].xf;
	x3=o->Rotated[p3].xf;
	y1=o->Rotated[p1].yf;
	y2=o->Rotated[p2].yf;
	y3=o->Rotated[p3].yf;
	z1=o->Rotated[p1].zf;
	z2=o->Rotated[p2].zf;
	z3=o->Rotated[p3].zf;

    nz=x3*((z1*y2)-(y1*z2))+
       y3*((x1*z2)-(z1*x2))+
       z3*((y1*x2)-(x1*y2));

    switch(CurrentCull)
    {
        case PV_CULL_CW:return (nz>=0); break;
        case PV_CULL_CCW:return (nz<0);break;
    }
    return 0;
}

static int Cull3DClipped(PVFace *f)
{
    PVMesh *o=f->Father;
    double nx,ny,nz,n;
	unsigned j;	
	PVPoint VP2,*VP3;
	PVVertex *p0,*p1,*ov;

	if(CurrentCull==PV_CULL_NONE) return 1;
	if(f==NULL) return 0;
	
   // Calcul d'une normale pour cette face
   // Methode de newell pour les normales
   nx=ny=nz=0;
   for (j=0; j<f->NbrVertices; j++)
   {
	  p0 = &o->Vertex[f->V[j]];
	  if (j == f->NbrVertices-1)
		p1 = &o->Vertex[f->V[0]];
	  else
		p1 = &o->Vertex[f->V[j+1]];
	  nx += (double)((double)p1->yf - (double)p0->yf) * (double)((double)p1->zf + (double)p0->zf);
	  ny += (double)((double)p1->zf - (double)p0->zf) * (double)((double)p1->xf + (double)p0->xf);
	  nz += (double)((double)p1->xf - (double)p0->xf) * (double)((double)p1->yf + (double)p0->yf);
   }

    n=(nx*nx+ny*ny+nz*nz);
	if(n>0)
	{
		n=InvSqrt(n);  
		nx*=n;
		ny*=n;
		nz*=n;
	}

    // Sauvegarde normale � la face
    f->Normal.xf=nx;
    f->Normal.yf=ny;
    f->Normal.zf=nz;
	
	// Setup Camera pour le backface
    ov=&o->Vertex[f->V[0]]; 
	VP2.xf=o->InvertCamPos.xf-ov->xf;
	VP2.yf=o->InvertCamPos.yf-ov->yf;
	VP2.zf=o->InvertCamPos.zf-ov->zf;

	VP3=&f->Normal;

    nz=(VP3->xf*VP2.xf)+(VP3->yf*VP2.yf)+(VP3->zf*VP2.zf);

    switch(CurrentCull)
    {
        case PV_CULL_CW:return (nz>=0); break;
        case PV_CULL_CCW:return (nz<0);break;
    }
    return 0; 
}

// 2D Drawing
static void Draw(void)
{
	unsigned i;	

    pFace->MaterialInfo=CurrentMaterial;

    if(pFace->MaterialInfo==NULL)
    {
        ErrorCode=MATERIAL_NOT_REGISTERED;
        return;
    }

	if(!(PV_Mode&PVM_USEHARDWARE))
	if(CurrentBuffer==NULL)
	{
		ErrorCode=ARG_INVALID;
		return;
	}

    if(pFace->MaterialInfo->Filler==NULL)
    {
        ErrorCode=ARG_INVALID;
        return;
    }
    else
    {
        // Draw !		
        if(Cull2D(pFace))
        {
            if(PV_Mode&PVM_USEHARDWARE)
			{
				if(PV_GetHardwareDriver()==NULL)
				{

					ErrorCode=NO_HARDWARE_SET;
					return;
				}

				if((PreRenderNeeded)||(LastPVM!=PV_Mode))
				{
					PreRenderNeeded=1;
                    i=PV_GetHardwareDriver()->PreRender(pWorld,(unsigned int)CurrentBuffer,PV_Mode,PV_GetPipelineControl());
					if(i!=COOL)
					{
						ErrorCode=i;
						return;
					}					
				}

				pMesh->FaceInfos[0].Poly=NULL;
				PV_PrepareFace(pFace);
				if(PV_GetPipelineControl()&PVP_HARDWARETL) 
					PV_GetHardwareDriver()->OverrideCullMode(PV_CULL_NONE);
				PV_GetHardwareDriver()->PrepareFace(pFace);
				PV_TriangulateFace(pFace,pFace->MaterialInfo->Filler,pFace->Father);
				PV_PrepareFace(pFace);
				
				if(PreRenderNeeded)
				{
					PV_GetHardwareDriver()->PostRender();
					PreRenderNeeded=0;
                    LastPVM=PV_Mode;
				}
			}
			else
			{
				RGBAmbientLight=&pWorld->AmbientLight;				
                PV_SetNewSWRenderBuffer(CurrentBuffer);
				pMesh->FaceInfos[0].Poly=NULL;
				PV_PrepareFace(pFace);
				PV_TriangulateFace(pFace,pFace->MaterialInfo->Filler,pFace->Father);
				PV_PrepareFace(pFace);
			}
        }
    }
	
}

static void Draw3D(void)
{
	unsigned i,hashw;
	PVFace *f;
	PVMaterial *LastMaterial=NULL;
	
    if(pWorld->Camera==NULL)
    {
        ErrorCode=INVALID_CAM;
        return;
    }

	if(!(PV_Mode&PVM_USEHARDWARE))
	if(InsideList==NULL)
	if(CurrentBuffer==NULL)
	{
		ErrorCode=ARG_INVALID;
		return;
	}

	PV_ComputeCam(pWorld->Camera);
	
	for(i=0,f=pMesh->Face;i<pMesh->NbrFaces;i++,f++) 
	{
		f->Flags&=~(RENDER_MASK|SHADE_MASK|SPECIAL_MASK);
		f->Flags|=((f->MaterialInfo->Type)&(RENDER_MASK|SHADE_MASK|SPECIAL_MASK));
	}

    // Draw !		
	FORCE_MESH_RECALC(pMesh);

	if(CurrentLight==PV_NOLIGHTING)
	{
		pMesh->Flags|=MESH_NOLIGHTING;
	}
	else
	{
		REMOVEFLAG(pMesh->Flags,MESH_NOLIGHTING);
	}

    free(pMesh->VertexVisible);
    pMesh->VertexVisible=NULL;

	if(InsideList==NULL)
	{
		PVFLAGS pvm=PV_Mode;
		PV_Mode&=~PVM_SHADOWS;
		if(PV_GetPipelineControl()&PVP_HARDWARETL) 
		{
			PV_GetHardwareDriver()->OverrideCullMode(CurrentCull);

			if(pMesh->HardwarePrivate==NULL)
			{
				hashw=0;
				PV_MeshBuildBoxes(pMesh,1);
				pMesh->UserPipeline=NULL;
				PV_GetHardwareDriver()->UpdateMesh(pMesh);
			}
			else hashw=1;
		}
		ErrorCode=PV_RenderWorld(pWorld,CurrentBuffer);		

		if(PV_GetPipelineControl()&PVP_HARDWARETL) 
		{
			if(!hashw)
			{
				PV_KillBoxes(pMesh->Box);
				pMesh->Box=NULL;
				PV_GetHardwareDriver()->FinalizeMesh(pMesh);
				pMesh->HardwarePrivate=NULL;
			}
		}

		PV_Mode=pvm;
	}
	else
		ErrorCode=AddMeshToList(InsideList);
}

static int PVAPI PrimPipe(PVMesh *m)
{
    unsigned i,n=0,h,b=0;
	PVFace *f;
	int flags=0;
	unsigned a;

	m->NbrVisibles=0;

    for(i=0,f=m->Face;i<m->NbrFaces;i++,f++)
	{
		a=0;
		
		if(f->Flags&POLYGON_NOCLIP) a=1;
		if(PV_GetPipelineControl()&PVP_HARDWARETL)
		{
			a=1;
			b=1;
		}

		if(a==0)
		if(h=PV_ClipFaceToFrustum(f))
		{						
			if(h==2)
			{
				a=Cull3DClipped(f);
				b=1;
			}
			else
				a=Cull3D(f);
		}

		if(a)
		{
			m->Visible[n++]=f;
			m->NbrVisibles++;
		}
	}

    if(CurrentLight==PV_LIGHTING) flags|=MESH_RECOMPUTE_LIGHT;
	if(b) flags|=MESH_FRUSTUM_CLIPPED;

	return flags;
}

///////////////////////////////////////////////////////// API

void PVAPI pvSetMode(pvMODE mode)
{
    CurrentMode=mode;

    ErrorCode=COOL;
}

void PVAPI pvSetLightingMode(pvLIGHT mode)
{
    CurrentLight=mode;

    ErrorCode=COOL;
}

void PVAPI pvSetCamera(PVCam *cam)
{
    pWorld->Camera=cam;
	PreRenderNeeded=1;
    ErrorCode=COOL;
}

PVCam *PVAPI pvGetCamera(void)
{
	return pWorld->Camera;
}

void PVAPI pvSetModelMatrix(PVMat3x3 mat)
{    
	PV_MeshSetupMatrixDirect(pMesh,mat);

    ErrorCode=COOL;
}

void PVAPI pvSetModelPos(PVPoint p)
{
	PV_MeshSetupPos(pMesh,p.xf,p.yf,p.zf);

    ErrorCode=COOL;
}

void PVAPI pvSetModelPivot(PVPoint p)
{
    pMesh->Pivot=p;

    ErrorCode=COOL;
}

void PVAPI pvAddLight(PVLight *l,unsigned *handle)
{
    PVLight *li;

    // Gets a new light
    li=PV_CreateLight((PVLightType)0,"");
    if(li==NULL)
    {
        ErrorCode=NO_MEMORY;
        return;
    }

    memcpy(li,l,sizeof(PVLight));
    li->Name=NULL;
    li->Next=NULL;

    PV_AddLight(pWorld,li);

    ErrorCode=COOL;
}

void PVAPI pvRemoveLight(unsigned handle)
{
    PV_RemoveLightByPtr(pWorld,(PVLight*)handle);

    ErrorCode=COOL;
}

void PVAPI pvSetAmbientLight(float r,float g,float b,float a)
{
    ErrorCode=ARG_INVALID;
	if(r>1) return;
    if(r<0) return;
    if(g>1) return;
    if(g<0) return;
    if(b>1) return;
    if(b<0) return;
	if(a>1) return;
    if(a<0) return;

	ErrorCode=COOL;
	pWorld->AmbientLight.r=r;
	pWorld->AmbientLight.g=g;
	pWorld->AmbientLight.b=b;
	pWorld->AmbientLight.a=a;
}

static void Flush(void)
{
	unsigned i,V[MAX_VERTICES_PER_POLY];

	pFace=pMesh->Face;
	pVertex=pMesh->Vertex;
	pMapping=pMesh->Mapping;
	pShading=pMesh->Shading;
	pWorld->NbrFaces=pMesh->NbrFaces=0;
	pWorld->NbrVertices=pMesh->NbrMapIndex=pMesh->NbrVertices=0;
	pProjected=pMesh->Projected;

	NbrTri=NbrVtx=0;
	
	if(pMesh->Face[0].V==NULL)
	{
		PVFace *f;
        unsigned old=pMesh->NbrFaces;

		pMesh->NbrFaces=MAX_BATCHED_FACES;
		memset(V,0,sizeof(V));
		for(i=0,f=pMesh->Face;i<MAX_BATCHED_FACES;i++,f++) PV_SetVerticesToFace(f,V,MAX_VERTICES_PER_POLY);

        pMesh->NbrFaces=old;
	}
}

void PVAPI pvReset(void)
{
	if(pWorld!=NULL) 
	{
		pMesh->NbrFaces=0;
		PV_KillWorld(pWorld);
	}
	pWorld=PV_CreateWorld();

	pMesh=PV_SimpleCreateMesh(MAX_BATCHED_FACES,MAX_BATCHED_VERTICES,MAX_CLIPPED_FACES,MAX_CLIPPED_VERTICES);	
	if(pMesh==NULL)
	{
		ErrorCode=NO_MEMORY;
		return;
	}
	pMesh->UserPipeline=PrimPipe;
	pMesh->Flags=MESH_NOSORT|MESH_DYNAMIC;
	pMesh->Shading=(PVShadeInfo*)malloc(sizeof(PVShadeInfo)*(MAX_CLIPPED_VERTICES+MAX_BATCHED_VERTICES));
	if(pMesh->Shading==NULL)
	{
		ErrorCode=NO_MEMORY;
		return;
	}
	
	PV_AddMesh(pWorld,pMesh);
	pWorld->Camera=&pCam;
	   
	Flush();

	CurrentMode=PV_2D;
	CurrentLight=PV_NOLIGHTING;
	ErrorCode=COOL;
	CurrentCull=PV_CULL_NONE;
	CurrentBuffer=NULL;

	NbrVtx=0;
	NbrTri=0;
	MaxVtx=0;
}

void PVAPI pvSetDepthField(double front,double back)
{
	pCam.FrontDist=front;
	pCam.BackDist=back;
	PreRenderNeeded=1;
}

void PVAPI pvSetCull(pvCULL cull)
{
    CurrentCull=cull;
    ErrorCode=COOL;
}

void PVAPI pvSetFogType(PVFogType type)
{
	pWorld->Fog.Type=type;
	PreRenderNeeded=1;
	ErrorCode=COOL;
}

void PVAPI pvSetFogStart(float start)
{
	pWorld->Fog.Start=start;
	PreRenderNeeded=1;
	ErrorCode=COOL;
}

void PVAPI pvSetFogEnd(float end)
{
	pWorld->Fog.End=end;
	PreRenderNeeded=1;
	ErrorCode=COOL;
}

void PVAPI pvSetFogDensity(float density)
{
	pWorld->Fog.Density=density;
	PreRenderNeeded=1;
	ErrorCode=COOL;
}

void PVAPI pvSetFogColor(float r,float g,float b)
{
	pWorld->Fog.Color.r=r;
	pWorld->Fog.Color.g=g;
	pWorld->Fog.Color.b=b;
	PreRenderNeeded=1;
	ErrorCode=COOL;
}

void PVAPI pvBegin(pvPRIMIT prim,UPVD8 *Scr)
{
    int i;

	if((int)Scr!=-1) CurrentBuffer=Scr;
    CurrentPrim=prim;

    NbrVtx=0;

    NbrTri=0;

    switch(prim)
    {
        case PV_TRIANGLES_FAN:MaxVtx=MAX_VERTICES_PER_POLY;break;
        case PV_TRIANGLES_STRIP:
        case PV_TRIANGLES:MaxVtx=3;break;
        case PV_QUADS:MaxVtx=4;break;
        case PV_POLYS:MaxVtx=MAX_VERTICES_PER_POLY;break;
		case PV_LINES:
		case PV_LINES_STRIP:
		case PV_LINES_FAN:MaxVtx=2;break;
        default:PV_Fatal("Panard Primitives :: unknown primitive.",CurrentPrim);
    }

	Flush();

	// PP 2D Only	
	if(CurrentMode==PV_2D) 
	{
		for(i=0;i<MAX_VERTICES_PER_POLY;i++) pFace->V[i]=i;
		pFace->NbrVertices=MaxVtx;

		if(pWorld->Camera!=&pCam) 
		{
			pWorld->Camera=&pCam;
			PreRenderNeeded=1;
		}
	}
	
    ErrorCode=COOL;
}

void PVAPI pvSetMaterial(PVMaterial *m)
{
    if(m==NULL)
    {
        ErrorCode=ARG_INVALID;
        return;
    }

    ErrorCode=COOL;    
	CurrentMaterial=m;
}

void PVAPI pvMapCoord(float u,float v)
{
    pMapping[NbrVtx].u=u;
    pMapping[NbrVtx].v=v;
    ErrorCode=COOL;
}

void PVAPI pvMapCoordv(float *uv)
{
	memcpy(&pMapping[NbrVtx].u,uv,sizeof(float)*2);
    ErrorCode=COOL;
}

void PVAPI pvAmbMapCoord(float u,float v)
{
    pMapping[NbrVtx].AmbientU=u;
    pMapping[NbrVtx].AmbientV=v;
    ErrorCode=COOL;
}

void PVAPI pvAmbMapCoordv(float *uv)
{
    memcpy(&pMapping[NbrVtx].AmbientU,uv,sizeof(float)*2);
    ErrorCode=COOL;
}


void PVAPI pvColor(float r,float g,float b,float a)
{
    pShading[NbrVtx].Color.r=r;
    pShading[NbrVtx].Color.g=g;
    pShading[NbrVtx].Color.b=b;
    pShading[NbrVtx].Color.a=a;
    ErrorCode=COOL;
}

void PVAPI pvColorv(float *rgba)
{
    memcpy(&pShading[NbrVtx].Color,rgba,sizeof(float)*4);
    ErrorCode=COOL;
}

void PVAPI pvSpecular(float r,float g,float b,float a)
{
    pShading[NbrVtx].Specular.r=r;
    pShading[NbrVtx].Specular.g=g;
    pShading[NbrVtx].Specular.b=b;
    pShading[NbrVtx].Specular.a=a;
    ErrorCode=COOL;
}

void PVAPI pvSpecularv(float *rgba)
{
    memcpy(&pShading[NbrVtx].Specular,rgba,sizeof(float)*4);
    ErrorCode=COOL;
}

void PVAPI pvNormal(float x,float y,float z)
{
    pVertex[NbrVtx].Normal.xf=x;
    pVertex[NbrVtx].Normal.yf=y;
    pVertex[NbrVtx].Normal.zf=z;
    ErrorCode=COOL;
}

void PVAPI pvNormalv(float *xyz)
{
	memcpy(&pVertex[NbrVtx].Normal,xyz,sizeof(float)*3);
	ErrorCode=COOL;
}

void PVAPI pvColorIndex(UPVD8 index)
{
    pShading[NbrVtx].Shade=index;
    ErrorCode=COOL;
}

void PVAPI pvSetWrapFlag(PVFLAGS flags)
{
    pFace->Flags=flags;
    ErrorCode=COOL;
}

void PVAPI pvSetClipFlag(PVFLAGS flags)
{
    pMesh->Flags=flags;
    ErrorCode=COOL;
}

void PVAPI pvEnableIndex(PVFLAGS flags)
{
	CurrentEnabledIndex=flags;
	ErrorCode=COOL;
}

void PVAPI pvSetVertexIndex(float *xyz0,unsigned stride)
{
	VertexStride.Ptr=(char*)xyz0;
	VertexStride.stride=stride;
	ErrorCode=COOL;
}

void PVAPI pvSetMapIndex(float *xyz0,unsigned stride)
{
	MapStride.Ptr=(char*)xyz0;
	MapStride.stride=stride;
	ErrorCode=COOL;
}

void PVAPI pvSetAmbMapIndex(float *xyz0,unsigned stride)
{
	AmbMapStride.Ptr=(char*)xyz0;
	AmbMapStride.stride=stride;
	ErrorCode=COOL;
}

void PVAPI pvSetColorIndex(float *xyz0,unsigned stride)
{
	ColorStride.Ptr=(char*)xyz0;
	ColorStride.stride=stride;
	ErrorCode=COOL;
}

void PVAPI pvSetSpecularIndex(float *xyz0,unsigned stride)
{
	SpecularStride.Ptr=(char*)xyz0;
	SpecularStride.stride=stride;
	ErrorCode=COOL;
}

void PVAPI pvSetNormalIndex(float *xyz0,unsigned stride)
{
	NormalStride.Ptr=(char*)xyz0;
	NormalStride.stride=stride;
	ErrorCode=COOL;
}

void PVAPI pvSetColorIndexIndex(UPVD8 *xyz0,unsigned stride)
{
	ColorIndexStride.Ptr=(char*)xyz0;
	ColorIndexStride.stride=stride;
	ErrorCode=COOL;
}

void PVAPI pvEnd(void)
{
	unsigned i;

    ErrorCode=COOL;
    switch(CurrentMode)
    {
    case PV_2D:
        if((CurrentPrim==PV_POLYS)||(CurrentPrim==PV_TRIANGLES_FAN))
        {
            // Ferme un eventuel polygone restant
            if(NbrVtx<3) return;
            pFace->NbrVertices=NbrVtx;
            Draw();
        }
        break;
    case PV_3D:
			if(CurrentPrim==PV_POLYS)
			{           			
				// Ferme un eventuel polygone restant
				if(NbrVtx>=3)
				{
					for(i=0;i<NbrVtx;i++)
							pFace->V[i]=pMesh->NbrVertices+i;

					pFace->NbrVertices=NbrVtx;
					pFace->MaterialInfo=CurrentMaterial;
					pMesh->NbrMapIndex=(pMesh->NbrVertices+=NbrVtx);
					pMesh->NbrFaces++;
					pWorld->NbrFaces=pMesh->NbrFaces;
					pWorld->NbrVertices=pMesh->NbrVertices;
				}
					
			}
			if(pWorld->NbrFaces!=0)
			{				
				Draw3D();
			}

        break;
    }
}

unsigned PVAPI pvCompileList(void)
{
	pvList *l;	
	
	if(InsideList!=NULL) 
	{
		ErrorCode=ALREADY_ASSIGNED;
		return 0;
	}

	l=(pvList*)malloc(sizeof(pvList));
	if(l==NULL)
	{
		ErrorCode=NO_MEMORY;
		return 0;
	}
    l->NbrMeshes=0;
    l->Meshes=NULL;

	InsideList=l;

	ErrorCode=COOL;
	return (unsigned)l;
}

void PVAPI pvEndList(void)
{
	if(InsideList==NULL) 
	{
		ErrorCode=ARG_INVALID;
		return;
	}

	InsideList=NULL;
	ErrorCode=COOL;
}

void PVAPI pvDestroyList(unsigned list)
{
	pvList *l;
	unsigned i;

	if(list==0) return;

	l=(pvList*)list;

	for(i=0;l->NbrMeshes;i++)
	{
		l->Meshes[i]->Owner=NULL;
        PV_KillMesh(l->Meshes[i]);
	}
	free(l->Meshes);
	free(l);
	
	ErrorCode=COOL;
}

void PVAPI pvDisplayList(unsigned list,UPVD8* screen)
{
	pvList *l;
	PVMesh *m=pMesh;
	unsigned i;

	if(list==0) return;

	l=(pvList*)list;
	CurrentBuffer=screen;

	for(i=0;i<l->NbrMeshes;i++)
	{		
        pMesh=l->Meshes[i];
		pWorld->Objs=pMesh;
		pMesh->Owner=pWorld;
        pWorld->NbrFaces=pMesh->NbrFaces;
		pWorld->NbrVertices=pMesh->NbrVertices;					

		pvSetModelMatrix(m->Matrix);
		pvSetModelPos(m->Position);
		pvSetModelPivot(m->Pivot);

		Draw3D();
        pMesh->Owner=NULL;
	}
	pMesh=m;
	pWorld->Objs=m;
    pWorld->NbrFaces=pMesh->NbrFaces;
	pWorld->NbrVertices=pMesh->NbrVertices;					

	ErrorCode=COOL;
}

int PVAPI pvGetErrorCode(void)
{
    return ErrorCode;
}

/////////////////////////////////////////////////////////////////////////// pour debugger peinard
void PVAPI pvVertexf(float x,float y,float z)
{
#include "pvvertex.inc"
}

void PVAPI pvVertex(double x,double y,double z)
{
#include "pvvertex.inc"
}

void PVAPI pvVertexfv(float *xyz)
{
	float x,y,z;
	x=xyz[0];
	y=xyz[1];
	z=xyz[2];
#include "pvvertex.inc"
}

void PVAPI pvVertexv(double *xyz)
{
	double x,y,z;
	x=xyz[0];
	y=xyz[1];
	z=xyz[2];

#include "pvvertex.inc"
}

void PVAPI pvVertexIndexedf(unsigned index)
{
	char *ptr;
	float x,y,z;
	
	if(CurrentEnabledIndex&PPI_MAPCOORD)
	{
		ptr=MapStride.Ptr+index*MapStride.stride;
		memcpy(&pMapping[NbrVtx].u,ptr,sizeof(float)*2);
	}
	if(CurrentEnabledIndex&PPI_AMBMAPCOORD)
	{
		ptr=AmbMapStride.Ptr+index*AmbMapStride.stride;		
		memcpy(&pMapping[NbrVtx].AmbientU,ptr,sizeof(float)*2);
	}
	if(CurrentEnabledIndex&PPI_COLOR)
	{
		ptr=ColorStride.Ptr+index*ColorStride.stride;		
		memcpy(&pShading[NbrVtx].Color,ptr,sizeof(float)*4);    
	}
	if(CurrentEnabledIndex&PPI_SPECULAR)
	{
		ptr=SpecularStride.Ptr+index*SpecularStride.stride;		
		memcpy(&pShading[NbrVtx].Specular,ptr,sizeof(float)*4);    
	}
	if(CurrentEnabledIndex&PPI_NORMAL)
	{
		ptr=NormalStride.Ptr+index*NormalStride.stride;		
		memcpy(&pVertex[NbrVtx].Normal,ptr,sizeof(float)*3);
	}
	if(CurrentEnabledIndex&PPI_COLORINDEX)
	{
		ptr=ColorIndexStride.Ptr+index*ColorIndexStride.stride;		
		pShading[NbrVtx].Shade=*ptr;
	}
	
	ptr=VertexStride.Ptr+index*VertexStride.stride;
	x=((float*)ptr)[0];
	y=((float*)ptr)[1];
	z=((float*)ptr)[2];

	#include "pvvertex.inc"
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef _TRIFILL_H_
#define _TRIFILL_H_

#include "pvision.h"
#include "sb.h"
#include "hline.h"

//-----------------------------------------------------------------
#define GetRampIndex(n,o,m) (o->Shading[n].Shade);

// Filler prototypes
#ifdef __cplusplus
extern "C" {
#endif

void PVAPI TriNULL(PVFace *f);
void PVAPI TriFlat(PVFace *f);
void PVAPI TriGouraud(PVFace *f);

void PVAPI TriAffineMapping(PVFace *f);
void PVAPI TriGouraudAffineMapping(PVFace *f);

void PVAPI TriPerspectiveMapping(PVFace *f);
void PVAPI TriPerspectiveAmbientMapping(PVFace *f);
void PVAPI TriGouraudPerspectiveMapping(PVFace *f);

void PVAPI TriAmbientAffineMapping(PVFace *f);

void PVAPI TriRGBTextureMapping(PVFace *f);
void PVAPI TriRGBFlat(PVFace *f);
void PVAPI TriRGBGouraud(PVFace *f);
void PVAPI TriRGBGouraudMapping(PVFace *f);
void PVAPI TriRGBFlatMapping(PVFace *f);

void PVAPI TriRGBPerspectiveMapping(PVFace *f);
void PVAPI TriRGBPerspectiveFlatMapping(PVFace *f);
void PVAPI TriRGBPerspectiveGouraudMapping(PVFace *f);

void PVAPI TriFastPerspectiveMapping(PVFace *f);

#ifdef __cplusplus
}
#endif

//////////////////////////////////////////////////////////////////////////

extern UPVD8 *Texture;
extern unsigned AndWidth,AndHeight,ShiftWidth;

extern PVD32 col;

extern UPVD8 *MapLightTranslateTable,*LineMapLightTransTable;
extern UPVD16 *MapLightTranslateTable16,*LineMapLightTransTable16;

extern UPVD8 *AuxiliaryTex;
extern unsigned ShiftWidthA;
extern unsigned AndWidthA,AndHeightA;

extern PVBumpInfo *BumpMap;

extern UPVD8 *ofs;
extern UPVD16 *ofs16;

extern PVRGBF *RGBAmbientLight;
extern PVRGBF RGBFlatColor;

#endif

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __PVERR_H__
#define __PVERR_H__

typedef unsigned PVERR;

#define PVERR_COOL						0x0
#define PVERR_ARG_INVALID				0x1
#define PVERR_LOCKED					0x2
#define PVERR_SRC_AND_TARGET_DOES_NOT_MATCH	0x3
#define PVERR_TARGET_NOT_READY			0x4
#define PVERR_TARGET_INVALID			0x5

#endif
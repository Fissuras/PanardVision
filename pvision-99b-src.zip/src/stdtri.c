/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <malloc.h>
#include <string.h>
#include "fillcom.h"

static void __cdecl HLineFlat(unsigned deb,unsigned fin)
{
    memset(TriFill_BufOfs+deb,col,fin-deb);
}

static int __cdecl Init1(int NumVtx,unsigned *vtx) {

    PVMesh *o=GenFill_CurrentFace->Father;
    unsigned si,ei;

    col=GetRampIndex(GenFill_CurrentFace->V[0],o,f->MaterialInfo);

    si=GenFill_CurrentFace->MaterialInfo->StartingColorIndex;
    ei=GenFill_CurrentFace->MaterialInfo->EndingColorIndex;
    col=((col*(ei-si))/255)+si;

    GenFill_NbrInc=0;
    HLineRoutine=HLineFlat;
    return 0;
}

static void __cdecl Init2(int NumVtx) {
}

FillerUserFunct Flat={Init1,Init2};

/////////////////////////////////////////////////////////////////////////////////////////////////////

static int __cdecl Init1G(int NumVtx,unsigned *vtx) {

    PVMesh *o=GenFill_CurrentFace->Father;
    unsigned si,ei,i;

	si=GenFill_CurrentFace->MaterialInfo->StartingColorIndex;
    ei=GenFill_CurrentFace->MaterialInfo->EndingColorIndex;

	for(i=0;i<NumVtx;i++)
    {
        int a=vtx[i];

        GenFill_InitialValues[i][0]=GetRampIndex(a,o,GenFill_CurrentFace->MaterialInfo);
		GenFill_InitialValues[i][0]=((GenFill_InitialValues[i][0]*(ei-si))/255)+si;
    }

	for(i=1;i<NumVtx;i++) if(GenFill_InitialValues[i][0]!=GenFill_InitialValues[i-1][0]) break;
	if(i==NumVtx)
    {
        TriFlat(GenFill_CurrentFace);
        return 1;
    }

    GenFill_NbrInc=1;

    HLineRoutine=HLineGouraud;
    return 0;
}

static void __cdecl Init2G(int NumVtx) {
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct Gouraud={Init1G,Init2G};


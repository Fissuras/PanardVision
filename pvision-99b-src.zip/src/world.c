/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include "pvision.h"
#include "oct1.h"
#include "fillcom.h"
#include "sqrt.h"

#define debug(x) //x

////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////

static int PVAPI NullCallBack(PVMesh *m,PVMaterial *mat,unsigned i)
{
    char s[255];

    strcpy(s,"You must specify a PV_UserCompileMaterials function to use the USER_FX flag !\n Material using this flag is ");
    strcat(s,mat->Name);
    PV_Fatal(s,mat->Type);
    return 1;
}

int ( PVAPI *PV_UserCompileMaterials)(PVMesh*,PVMaterial*,unsigned)=NullCallBack;

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////// World management

PVWorld * PVAPI PV_CreateWorld(void)
{
    PVWorld *w;

    if((w=(PVWorld*)calloc(sizeof(PVWorld),1))==NULL) return NULL;

    w->NbrFaces=w->NbrVertices=w->NbrVisibles=0;
    w->Objs=NULL;
    w->Lights=NULL;
    w->Visible=NULL;
    w->Materials=NULL;
    w->Global256Palette=NULL;
    w->NbrObjs=0;
    w->ReservedColors=0;
    w->AmbientLight.r=0;
    w->AmbientLight.g=0;
    w->AmbientLight.b=0;
    w->Flags=0;
    w->Camera=NULL;
    w->Mirrors=NULL;

	w->LastFrame=1;

	w->Fog.Density=1.0;	
	w->Fog.End=2000.0;
	w->Fog.Start=0.0;
	w->Fog.Type=PVF_NONE;

	w->HardwarePrivate=NULL;

	w->UserRenderWorld=NULL;

	w->NbrBufferVisible=0;

    return w;
}

void PVAPI PV_KillWorld(PVWorld *w)
{
    PVMaterial *m,*m2;
    PVLight *l,*l2;
    PVMirror *mi,*mi2;

	if(w==NULL) return;
	debug(printf("� freeing objects\n"););
    PV_KillMeshList(w->Objs,NULL,NULL);
    w->Objs=NULL;

    debug(printf("� freeing materials\n"););
    m=w->Materials;
    while(m!=NULL)
    {
        m2=m->Next;
        PV_KillMaterial(m);
        m=m2;
    }
    w->Materials=NULL;

    debug(printf("� freeing lights\n"););
    l=w->Lights;
    while(l!=NULL)
    {
        l2=l->Next;
        PV_KillLight(l);
        l=l2;
    }
    w->Lights=NULL;

    debug(printf("� freeing mirrors\n"););
    mi=w->Mirrors;
    while(mi!=NULL)
    {
        mi2=mi->Next;
        PV_KillMirror(mi);
        mi=mi2;
    }
    w->Mirrors=NULL;


    free(w->Visible);
    w->Visible=NULL;
    free(w->Global256Palette);
    w->Global256Palette=NULL;

    free(w);
}

////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////// World members access

int PVAPI PV_WorldSetAmbientLight(PVWorld *w,PVRGBF a)
{
    if(a.r>1) return ARG_INVALID;
    if(a.r<0) return ARG_INVALID;
    if(a.g>1) return ARG_INVALID;
    if(a.g<0) return ARG_INVALID;
    if(a.b>1) return ARG_INVALID;
    if(a.b<0) return ARG_INVALID;
	if(a.a>1) return ARG_INVALID;
    if(a.a<0) return ARG_INVALID;

    w->AmbientLight=a;

    return COOL;
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////// World 3D routine

static void ScaleWorldRecurse(PVMesh *m,float ax,float ay,float az)
{
	while(m!=NULL)
	{
		PV_MeshScaleVertexes(m,ax,ay,az);

		ScaleWorldRecurse(m->Child,ax,ay,az);

		m=m->Next;
	}
}

void PVAPI PV_ScaleWorld(PVWorld *w,float ax,float ay,float az)
{
    ScaleWorldRecurse(w->Objs,ax,ay,az); 
}

////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////  Sorting

int PVAPI PV_SetSortOrder(PVWorld *w,PVFLAGS f)
{
    PVFLAGS all=PVW_BACK_2_FRONT|PVW_FRONT_2_BACK|PVW_MATERIAL;

	if(f&(~all)) return ARG_INVALID;

    if(((f&all)&(-(f&all)))!=(f&all)) return ARG_INVALID;

    w->Flags=w->Flags&(~all);
    w->Flags|=f;

    return COOL;
}

static void SortCopyMeshList(PVMesh *o,PVWorld *w)
{
	unsigned i;
	PVFace **vis=w->Visible;

    while(o!=NULL)
    {		
		if(o->Flags&MESH_INHERIT_CULL)
		    if(o->Father!=NULL)
			    if(!(o->Father->Flags&MESH_VISIBLE)) 
                {
                    o=o->Next;
                    continue;
                }

        if(!(ISFLAGSET(o->Flags,MESH_FORGET_CHILD)))
        {
            if(!(o->Flags&MESH_CULL_CHILD))
                SortCopyMeshList(o->Child,w);
            else
            {
                if(o->Flags&MESH_VISIBLE) SortCopyMeshList(o->Child,w);
            }
        }
        
		if(ISFLAGSET(o->Flags,MESH_VISIBLE))
		if(!(ISFLAGSET(o->Flags,MESH_FORGET)))
        {
			PVFace **p;
			for(i=0,p=o->Visible;i<o->NbrVisibles;i++,vis+=2,p++)
			{				
				*vis=*p;
				*(vis+1)=(PVFace*)o;
			}
        }
        o=o->Next;
    }
}

static void SortAccumul(PVMesh *o,PVWorld *w,unsigned *n,UPVD16 *tab,unsigned *k)
{
	unsigned i;
	PVFace **ov;
	PVD32 z;

	while(o!=NULL)
    {        
		if(o->Flags&MESH_INHERIT_CULL)
		    if(o->Father!=NULL)
			    if(!(o->Father->Flags&MESH_VISIBLE)) 
                {
                    o=o->Next;
                    continue;
                }
        
        if(!(ISFLAGSET(o->Flags,MESH_FORGET_CHILD)))
        {
            if(!(o->Flags&MESH_CULL_CHILD))                
                SortAccumul(o->Child,w,n,tab,k);
            else
            {
                if(o->Flags&MESH_VISIBLE) SortAccumul(o->Child,w,n,tab,k);
            }
        }
		
		if(ISFLAGSET(o->Flags,MESH_VISIBLE))
		if(!(ISFLAGSET(o->Flags,MESH_FORGET)))
        {
            if(ISFLAGSET(o->Flags,MESH_NOSORT))
            {
				PVFace **t,**r;
				for(i=0,t=&w->Visible[2*(*k)],r=o->Visible;i<o->NbrVisibles;i++,(*k)++,t+=2,r++)
				{
					*t=*r;
					*(t+1)=(PVFace*)o;
				}
                (*n)-=o->NbrVisibles;
            }
            else
            for(i=0,ov=o->Visible;i<o->NbrVisibles;i++,ov++)
            {
                unsigned cindex=(*ov)-o->Face;
				
				z=o->FaceInfos[cindex].ZAvg;
                tab[z&0xFF]++;
                tab[((z>>8)&0xFF)+256]++;
                tab[((z>>16)&0xFF)+512]++;
                tab[((z>>24)&0xFF)+768]++;
            }
        }

        o=o->Next;
    }
}

static void SortFinalize(PVMesh *o,PVFace **buff,UPVD16 *tab)
{
	unsigned i;
	PVFace **ov;

    while (o!=NULL)
    {		
   		if(o->Flags&MESH_INHERIT_CULL)
		    if(o->Father!=NULL)
			    if(!(o->Father->Flags&MESH_VISIBLE)) 
                {
                    o=o->Next;
                    continue;
                }

        if(!(ISFLAGSET(o->Flags,MESH_FORGET_CHILD)))
        {
            if(!(o->Flags&MESH_CULL_CHILD))                                
                SortFinalize(o->Child,buff,tab);
            else
            {
                if(o->Flags&MESH_VISIBLE) SortFinalize(o->Child,buff,tab);
            }
        }

		
		if(ISFLAGSET(o->Flags,MESH_VISIBLE))
		if(!(ISFLAGSET(o->Flags,MESH_FORGET)))
        if(!(ISFLAGSET(o->Flags,MESH_NOSORT)))
        {
            for(i=0,ov=o->Visible;i<o->NbrVisibles;i++,ov++)
            {
                unsigned cindex=(*ov)-o->Face;
				PVD32 z;
                PVFace **bu;
				
				z=o->FaceInfos[cindex].ZAvg;

				bu=&buff[tab[z&0xff]*2];

				*bu=(PVFace *)(*ov);				
				*(bu+1)=(PVFace*)o;
				tab[z&0xff]++;
            }
        }
        o=o->Next;
    }
}

int PVAPI PV_SortWorld(PVWorld *w)
{
    UPVD16 tab[512*2];
    PVD16 t;
//    PVD16 t1,t2;

    UPVD32 n,k=0;
    PVD32 i,z;
    PVFace **buff=NULL,**bu;
    PVFace *h2,**ov;

    /*  Teste le buffer final */
    if(w->NbrBufferVisible<w->NbrFaces)
    {
        /*
         premiere fois on alloue de la place
        */
		free(w->Visible);
        if((w->Visible=(PVFace**)malloc(2*2*sizeof(PVFace*)*w->NbrFaces))==NULL) return NO_MEMORY;
		w->NbrBufferVisible=w->NbrFaces;
    }

    if(PV_GetPipelineControl()&(PVP_DISABLESORTING|PVP_HARDWARETL))
    {
        // Kan sorting disabled, on cpope le contenu de chaque tablo
        // visible mesh dans le tablo visible de world dans le meme ordre
        if(w->Camera->StartingLocation==NULL) 
			SortCopyMeshList(w->Objs,w);
		else
			SortCopyMeshList(w->Camera->StartingLocation,w);
        return COOL;
    }

    /*
     On tri les faces
     init
    */
    memset(tab,0,sizeof(tab));
    n=w->NbrVisibles;
    buff=&w->Visible[2*w->NbrFaces];

    /* Accumulation des occurences */
	if(w->Camera->StartingLocation==NULL) 
		SortAccumul(w->Objs,w,&n,tab,&k);
	else
		SortAccumul(w->Camera->StartingLocation,w,&n,tab,&k);

    /* Integration des occurences */
    if ((PV_Mode&PVM_SBUFFER)||(w->Flags&PVW_FRONT_2_BACK))
    {
        for(i=1, tab[0]=n-tab[0], tab[256]=n-tab[256], tab[512]=n-tab[512], tab[768]=n-tab[768]; i<256 ; i++) {
            tab[i] = tab[i-1] - tab[i];
            tab[i+256] = tab[i+255] - tab[i+256];
            tab[i+512] = tab[i+511] - tab[i+512];
            tab[i+768] = tab[i+767] - tab[i+768];
        }
//        t2 = n - tab[384];
//        t1 = -tab[384];
    }
    else
    {
        for(i=1023, tab[255]=tab[255]-n,tab[511]=tab[511]-n, tab[767]=tab[767]-n, t=n; i>=0 ; i--)
        {
                t=tab[i]=t-tab[i];
        }

//        t1=n-tab[384];
//        t2=-tab[384];
    }

    /* Ajustement des nombres signes */
    /*for(i=256;i<384;i++)
    {
        tab[i]+=t1;
        tab[i+128]+=t2;
    } */

    // Et zou tri !  16 bits faibles
	if(w->Camera->StartingLocation==NULL) 
		SortFinalize(w->Objs,buff,tab);
	else
		SortFinalize(w->Camera->StartingLocation,buff,tab);

	for(i=0,bu=buff; i<n ; i++,bu+=2)
    {
        PVFace **vi;
		unsigned cindex;

		h2=*bu;

		cindex=h2-((PVMesh*)*(bu+1))->Face;

        z=((PVMesh*)*(bu+1))->FaceInfos[cindex].ZAvg;

		vi=&w->Visible[(k+tab[((z>>8)&0xff)+256])*2];
        *vi= h2;
		*(vi+1) = *(bu+1);
		tab[((z>>8)&0xff)+256]++;
    }

    // 16 bits fort
	for(i=0,ov=&w->Visible[2*k];i<n;i++,ov+=2)
    {
        PVFace **vi;
		unsigned cindex;

		cindex=*ov-((PVMesh*)*(ov+1))->Face;
		z=((PVMesh*)*(ov+1))->FaceInfos[cindex].ZAvg;

		vi=&buff[tab[((z>>16)&0xff)+512]*2];
		*vi=(PVFace *)(*ov);
		*(vi+1)=*(ov+1);
		tab[((z>>16)&0xff)+512]++;
    }

	for(i=0,bu=&buff[0]; i<n ; i++,bu+=2)
    {
        PVFace **vi;
		unsigned cindex;
		
		h2=*bu;

		cindex=h2-((PVMesh*)*(bu+1))->Face;

        z=((PVMesh*)*(bu+1))->FaceInfos[cindex].ZAvg;

		vi=&w->Visible[(k+tab[((z>>24)&0xff)+768])*2];
        *vi= h2;
		*(vi+1)= *(bu+1);

		tab[((z>>24)&0xff)+768]++;
    }
    return COOL;
}

////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////// In-World Mesh management

int PVAPI PV_AddMesh(PVWorld *w,PVMesh *no)
{
   if (no==NULL) return ARG_INVALID;
   if (w==NULL) return ARG_INVALID;
   if (no->Owner!=NULL) return ALREADY_IN_HIERARCHY;

   no->Owner=w;
   no->Next=w->Objs;
   w->Objs=no;
   w->NbrObjs++;
   w->NbrFaces+=no->NbrFaces;
   w->NbrVertices+=no->NbrVertices;

   return COOL;
}

int PVAPI PV_AddMeshLast(PVWorld *w,PVMesh *no)
{
   PVMesh *m;

   if (no==NULL) return ARG_INVALID;
   if (w==NULL) return ARG_INVALID;
   if (no->Owner!=NULL) return ALREADY_IN_HIERARCHY;

   
   
   m=w->Objs;
   if(m==NULL)
   {
	   no->Next=w->Objs;
	   w->Objs=no;
   }
   else
   {
	   while(m->Next!=NULL) m=m->Next;
	   m->Next=no;	
   }
      
   no->Owner=w;
   w->NbrObjs++;
   w->NbrFaces+=no->NbrFaces;
   w->NbrVertices+=no->NbrVertices;

   return COOL;
}

int PVAPI PV_RemoveMeshByPtr(PVMesh *o)
{
    PVMesh *b,**h;
	PVWorld *w;
	unsigned af,av,no;

    if (o==NULL) return ARG_INVALID;
	w=o->Owner;
	if(w==NULL) return ARG_INVALID;

	if(o->Father==NULL)
	{
		b=w->Objs;
		h=&w->Objs;
	}
	else
	{
		b=o->Father->Child;
		h=&o->Father->Child;
	}

    if (b==o)
    {
        *h=o->Next;
		o->Next=NULL;

		no=PV_KillMeshList(o,&af,&av);

		w->NbrVertices-=av;
        w->NbrFaces-=af;
        w->NbrObjs-=no;

        return COOL;
    }

    while(b!=NULL)
    {
        if (b->Next==o)
        {
            b->Next=o->Next;
			o->Next=NULL;

            no=PV_KillMeshList(o,&af,&av);
			w->NbrVertices-=av;
            w->NbrFaces-=af;
            w->NbrObjs-=no;
            return COOL;
        }
        else b=b->Next;
    }

    return ITEM_NOT_FOUND;
}

PVMesh *  PVAPI PV_GetMeshPtr(PVWorld *w,char *s)
{
    if (w==NULL) return NULL;
    if (s==NULL) return NULL;

    return PV_SearchMeshList(w->Objs,s);
}

int PVAPI PV_RemoveMeshByName(PVWorld *w,char *s)
{
    PVMesh *o;

    if (w==NULL) return ARG_INVALID;
    if (s==NULL) return ARG_INVALID;

    if ((o=PV_GetMeshPtr(w,s))==NULL) return ITEM_NOT_FOUND;
    PV_RemoveMeshByPtr(o);
    return COOL;
}

PVMesh *PVAPI PV_UnlinkMesh(PVMesh *o)
{
    PVMesh *b,**h;
	PVWorld *w;

    if (o==NULL) return NULL;
	if (o->Child!=NULL) return NULL;
	w=o->Owner;
	if (w==NULL) return NULL;
	o->Owner=NULL;

	if(o->Father==NULL)
	{
		b=w->Objs;
		h=&w->Objs;
	}
	else
	{
		b=o->Father->Child;
		h=&o->Father->Child;
	}

    if (b==o)
    {
        *h=o->Next;
		o->Next=NULL;

		w->NbrVertices-=o->NbrVertices;
        w->NbrFaces-=o->NbrFaces;
        w->NbrObjs--;

        return o;
    }

    while(b!=NULL)
    {
        if (b->Next==o)
        {
            b->Next=o->Next;
			o->Next=NULL;

			w->NbrVertices-=o->NbrVertices;
			w->NbrFaces-=o->NbrFaces;
			w->NbrObjs--;

            return o;
        }
        else b=b->Next;
    }

    return NULL;
}

int PVAPI PV_AddChildMesh(PVMesh *father,PVMesh *child)
{
	if(father==NULL) return ARG_INVALID;
	if(child==NULL) return ARG_INVALID;

	if(father->Flags&MESH_SWITCHNODE) return ARG_INVALID;

	if(!(father->Flags&MESH_PORTAL))
	{
		if(child->Father!=NULL) return ALREADY_IN_HIERARCHY;
		if(child->Next!=NULL) return ALREADY_IN_HIERARCHY;
		if(child->Owner!=NULL) return ALREADY_IN_HIERARCHY;
		if(child->Child!=NULL) return MESH_HAS_CHILD;
	}
	else
	{		
		if(child->Owner!=NULL)
		{
			// cas ou on reboucle un portal sur un mesh dans la hierarchie
			// one ne compte pas le mesh dans le monde
			child->Owner=father->Owner;
			child->Next=father->Child;
			child->Father=father;
			father->Child=child;		
			return COOL;
		}
		else
		{
			// cas opu on ajoute un child simple
			if(child->Father!=NULL) return ALREADY_IN_HIERARCHY;
			if(child->Next!=NULL) return ALREADY_IN_HIERARCHY;			
			if(child->Child!=NULL) return MESH_HAS_CHILD;						
		}
	}

	child->Owner=father->Owner;
	child->Next=father->Child;
	child->Father=father;
	father->Child=child;		

	child->Owner->NbrObjs++;
	child->Owner->NbrFaces+=child->NbrFaces;
	child->Owner->NbrVertices+=child->NbrVertices;

	return COOL;
}

////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////// In-World Materials management

void PVAPI PV_AddMaterial(PVWorld *w,PVMaterial *m)
{
    if (m==NULL) return;
    if (w==NULL) return;

	m->RefCnt++;
    m->Next=w->Materials;
    w->Materials=m;
}

PVMaterial *  PVAPI PV_GetMaterialPtrByName(char *name,PVWorld *z)
{
    PVMaterial *m;

    if(z==NULL) return NULL;
    if(name==NULL) return NULL;

    m=z->Materials;
    while(m!=NULL)
    {
        if(strcmp(m->Name,name)==0) return m;
        m=m->Next;
    }
    return NULL;
}

////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////// In-World lights management

void PVAPI PV_AddLight(PVWorld *w,PVLight *l)
{
     if (l==NULL) return;
     if (w==NULL) return;

     l->RefCnt++;
	 l->Next=w->Lights;
     w->Lights=l;
     PV_RecomputeLight();
}

PVLight *  PVAPI PV_GetLightPtr(PVWorld *w,char *s)
{
    PVLight *o;

    if(w==NULL) return NULL;
    if(s==NULL) return NULL;

    o=w->Lights;

    while(o!=NULL)
    {
        if(o->Name!=NULL)
			if(strcmp(o->Name,s)==0) return o;
        o=o->Next;
    }
    return NULL;
}

int PVAPI PV_RemoveLightByPtr(PVWorld *w,PVLight *o)
{
    PVLight *b;

    if(w==NULL) return ARG_INVALID;

    b=w->Lights;

    if (o==NULL) return ARG_INVALID;

    if (b==o)
    {
        w->Lights=o->Next;

        PV_KillLight(b);
        return COOL;
    }

    while(b!=NULL)
    {
        if (b->Next==o)
        {
            b->Next=o->Next;

            PV_KillLight(o);
            return COOL;
        }
        else b=b->Next;
    }

    return ITEM_NOT_FOUND;
}

int PVAPI PV_RemoveLightByName(PVWorld *w,char *s)
{
    PVLight *o;

    if(w==NULL) return ARG_INVALID;
    if(s==NULL) return ARG_INVALID;

    if ((o=PV_GetLightPtr(w,s))==NULL) return ITEM_NOT_FOUND;
    PV_RemoveLightByPtr(w,o);
    PV_RecomputeLight();
    return COOL;
}

////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////// In-World mirrors management

void PVAPI PV_AddMirror(PVWorld *w,PVMirror *l)
{
     if (l==NULL) return;
     if (w==NULL) return;

	 l->RefCnt++;

     l->Next=w->Mirrors;
     w->Mirrors=l;
}

int PVAPI PV_RemoveMirrorByPtr(PVWorld *w,PVMirror *o)
{
    PVMirror *b;

    if(w==NULL) return ARG_INVALID;

    b=w->Mirrors;

    if (o==NULL) return ARG_INVALID;

    if (b==o)
    {
        w->Mirrors=o->Next;

        PV_KillMirror(b);
        return COOL;
    }

    while(b!=NULL)
    {
        if (b->Next==o)
        {
            b->Next=o->Next;

            PV_KillMirror(o);
            return COOL;
        }
        else b=b->Next;
    }

    return ITEM_NOT_FOUND;
}

////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////// Compilation Mesh

static void PV_CompileVertexesMeshList(PVMesh *o)
{
    while(o!=NULL)
    {
        if(o->Child!=NULL) PV_CompileVertexesMeshList(o->Child);
		PV_MeshCompileVertexes(o);
        o=o->Next;
    }
}

void *PVAPI PV_GetFiller(PVFLAGS flags)
{
    flags&=(RENDER_MASK|SHADE_MASK|SPECIAL_MASK);
	flags&=~FOGABLE;

	// Selectionne le Filler qui va bien 16 Bits
    if(PV_Mode&PVM_RGB16)
    {
        if(flags&MULTITEXTURE)
		{
			flags&=~MULTITEXTURE;
			flags|=MAPPING;
		}
		// 16 bits
        switch (flags&(RENDER_MASK|SHADE_MASK|SPECIAL_MASK))
        {
            case FLAT|NOTHING:  return (void*)TriRGBFlat;break;
            case U_PHONG|NOTHING:
            case PHONG|NOTHING: return (void*)TriAffineMapping;break;
            case U_BUMP|NOTHING:
            case BUMP|NOTHING:  return (void*)TriAmbientAffineMapping;break;

            case NOTHING|MAPPING:
            case FLAT|MAPPING:      return (void*)TriAffineMapping;break;
            case GOURAUD|MAPPING:   return (void*)TriGouraudAffineMapping;break;
            case U_BUMP|MAPPING:
            case U_PHONG|MAPPING:
            case BUMP|MAPPING:
            case PHONG|MAPPING:     return (void*)TriAmbientAffineMapping;break;

            case U_PHONG|NOTHING|PERSPECTIVE:
            case PHONG|NOTHING|PERSPECTIVE:
            case NOTHING|PERSPECTIVE|MAPPING:
            case NOTHING|PERSPECTIVE|AMBIENT_MAPPING:
            case FLAT|PERSPECTIVE|AMBIENT_MAPPING:
            case FLAT|PERSPECTIVE|MAPPING:          return (void*)TriPerspectiveMapping;break;
            case GOURAUD|PERSPECTIVE|AMBIENT_MAPPING:
            case GOURAUD|PERSPECTIVE|MAPPING:       return (void*)TriGouraudPerspectiveMapping;break;
            case U_BUMP|PERSPECTIVE|MAPPING:
            case U_PHONG|PERSPECTIVE|MAPPING:
            case BUMP|PERSPECTIVE|MAPPING:
            case PHONG|PERSPECTIVE|AMBIENT_MAPPING:
            case PHONG|PERSPECTIVE|MAPPING:         return (void*)TriPerspectiveAmbientMapping;break;

            case FLAT|AMBIENT_MAPPING:
            case NOTHING|AMBIENT_MAPPING:   return (void*)TriAffineMapping;break;
            case GOURAUD|AMBIENT_MAPPING:   return (void*)TriGouraudAffineMapping;break;
            case PHONG|AMBIENT_MAPPING:     return (void*)TriAmbientAffineMapping;break;

            default:
                return NULL;
        }
    }

    if(PV_Mode&PVM_PALETIZED8)
    {
        if(flags&MULTITEXTURE)
		{
			flags&=~MULTITEXTURE;
			flags|=MAPPING;
		}

        // 8 bits
        switch (flags&(RENDER_MASK|SHADE_MASK|SPECIAL_MASK))
        {
            case FLAT|NOTHING:      return (void*)TriFlat;break;
            case GOURAUD|NOTHING:   return (void*)TriGouraud;break;
            case U_PHONG|NOTHING:
            case PHONG|NOTHING:     return (void*)TriAffineMapping;break;
            case U_BUMP|NOTHING:
            case BUMP|NOTHING:      return (void*)TriAmbientAffineMapping;break;

            case FLAT|MAPPING:
            case NOTHING|MAPPING:   return (void*)TriAffineMapping;break;
            case GOURAUD|MAPPING:   return (void*)TriGouraudAffineMapping;break;
            case U_BUMP|MAPPING:
            case U_PHONG|MAPPING:
            case BUMP|MAPPING:
            case PHONG|MAPPING:     return (void*)TriAmbientAffineMapping;break;

            case U_PHONG|NOTHING|PERSPECTIVE:
            case PHONG|NOTHING|PERSPECTIVE:
            case FLAT|PERSPECTIVE|MAPPING:
            case FLAT|PERSPECTIVE|AMBIENT_MAPPING:
            case NOTHING|PERSPECTIVE|AMBIENT_MAPPING:
            case NOTHING|PERSPECTIVE|MAPPING:return (void*)TriPerspectiveMapping;break;
            case GOURAUD|PERSPECTIVE|AMBIENT_MAPPING:
            case GOURAUD|PERSPECTIVE|MAPPING:return (void*)TriGouraudPerspectiveMapping;break;
            case U_BUMP|PERSPECTIVE|MAPPING:
            case U_PHONG|PERSPECTIVE|MAPPING:
            case BUMP|PERSPECTIVE|MAPPING:
            case PHONG|PERSPECTIVE|AMBIENT_MAPPING:
            case PHONG|PERSPECTIVE|MAPPING:return (void*)TriPerspectiveAmbientMapping;break;

            case FLAT|AMBIENT_MAPPING:
            case NOTHING|AMBIENT_MAPPING:   return (void*)TriAffineMapping;break;
            case GOURAUD|AMBIENT_MAPPING:   return (void*)TriGouraudAffineMapping;break;
            case PHONG|AMBIENT_MAPPING:     return (void*)TriAmbientAffineMapping;break;

            case LIGHTMAP|MAPPING|PERSPECTIVE:
                return (void*)TriFastPerspectiveMapping;break;

            default:
                return NULL;
        }
    }

    if(PV_Mode&PVM_USEHARDWARE)
    {
        if(PV_GetHardwareDriver()!=NULL)
            return PV_GetHardwareDriver()->GetFiller(flags);
        else
            return NULL;
    }
    else
    if(PV_Mode&PVM_RGB)
    {
        if(flags&MULTITEXTURE)
		{
			flags&=~MULTITEXTURE;
			flags|=MAPPING;
		}

        // PVRGB
        switch (flags&(RENDER_MASK|SHADE_MASK|SPECIAL_MASK))
        {
            case FLAT|NOTHING:return (void*)TriRGBFlat;break;
            case GOURAUD|NOTHING:return (void*)TriRGBGouraud;break;
            case U_PHONG:
            case PHONG|NOTHING:return (void*)TriRGBTextureMapping;break;

            case NOTHING|MAPPING:return (void*)TriRGBTextureMapping;break;
            case FLAT|MAPPING:return (void*)TriRGBFlatMapping;break;
            case GOURAUD|MAPPING:return (void*)TriRGBGouraudMapping;break;

            case NOTHING|AMBIENT_MAPPING:return (void*)TriRGBTextureMapping;break;
            case FLAT|AMBIENT_MAPPING:return (void*)TriRGBFlatMapping;break;
            case GOURAUD|AMBIENT_MAPPING:return (void*)TriRGBGouraudMapping;break;

            case U_PHONG|NOTHING|PERSPECTIVE:
            case PHONG|NOTHING|PERSPECTIVE:
            case NOTHING|PERSPECTIVE|AMBIENT_MAPPING:
            case NOTHING|PERSPECTIVE|MAPPING:return (void*)TriRGBPerspectiveMapping;break;
            case FLAT|PERSPECTIVE|AMBIENT_MAPPING:
            case FLAT|PERSPECTIVE|MAPPING:return (void*)TriRGBPerspectiveFlatMapping;break;
            case GOURAUD|PERSPECTIVE|AMBIENT_MAPPING:
            case GOURAUD|PERSPECTIVE|MAPPING:return (void*)TriRGBPerspectiveGouraudMapping;break;

            case LIGHTMAP|MAPPING|PERSPECTIVE:
                return (void*)TriFastPerspectiveMapping;break;

            default:
                return NULL;
        }
    }

    PV_Fatal("PV_GetFiller():: PV_Mode is invalid",BIZAR_ERROR);
    return NULL;
}

static int PV_CompileOneMesh(PVMesh *o)
{
	unsigned i,h;
	PVWorld *z;
	PVMaterial *m;

	if(o==NULL) return ARG_INVALID;
	if(o->Flags&MESH_INSTANCE) return COOL;
	z=o->Owner;

	for(i=0;i<o->NbrFaces;i++)
    {
        // Pas clipp�e
        o->Face[i].Poly=NULL;

        if((o->Face[i].Material!=NULL)||(o->Face[i].MaterialInfo!=NULL))
        {
            if((o->Face[i].MaterialInfo!=NULL)||((o->Face[i].MaterialInfo=PV_GetMaterialPtrByName(o->Face[i].Material,z))!=NULL))
            {
				m=o->Face[i].MaterialInfo;

				m->RefCnt++;

                // Material enregistr�
                o->Face[i].Flags|=m->Type&(RENDER_MASK|SHADE_MASK|SPECIAL_MASK);  // preserve les Flags de Wrapping

                // D�truit le nom de materiaux pour la m�moire
                free(o->Face[i].Material);
                o->Face[i].Material=NULL;

				// Set le father eventuellement
				if(o->Face[i].Father==NULL) o->Face[i].Father=o;

                // V�rifie ke les faces marqu�s "MAPPING" appartiennet bien a un objet contenant des coord de mapping
                if(o->Face[i].Flags&MAPPED_MATERIAL)
                    if(o->Mapping==NULL) {
                        debug(printf("� CompileOneMesh() : %s has invalid mapping rules.\n",o->Name););
                        o->Face[i].Flags=0;
                        continue;
                    }

                // Cr�e un tableau mapping pour les objets contenant des faces PHONGouBUMP
                if(o->Face[i].Flags&(PHONG|BUMP|U_PHONG|U_BUMP))
                {
                    if(o->Mapping==NULL)
                    {
                        if ((o->Mapping=(PVMapInfo *)malloc(sizeof(PVMapInfo)*(o->NbrVertices+o->MaxNbrClippedVertices)))==NULL ) return NO_MEMORY;
                    }
                }

                // Appel eventuellement la routine de Dispatch utilisateur
                if(m->Type&USER_FX)
                    if((h=PV_UserCompileMaterials(o,m,i))) PV_Fatal("PV_UserCompileMaterials returned with error.",h);

                // Si lightmap, remplis les champs Width et Height                    
                if(m->Type&LIGHTMAP)
                {
                    if(o->Face[i].LightMap!=NULL) PV_SetLightMapExtent(&o->Face[i],0,o->Face[i].LightMap);

                    // If hardware, download lightmap
                    if(PV_Mode&PVM_USEHARDWARE)
                    {
                        if(PV_GetHardwareDriver()!=NULL)
                        if(PV_GetHardwareDriver()->LoadLightMap!=NULL)
                            {if((h=PV_GetHardwareDriver()->LoadLightMap(o->Face[i].LightMap))!=COOL) return h;}
                    }
                }
            }
            else o->Face[i].Flags&=~(SHADE_MASK|RENDER_MASK|SPECIAL_MASK); // Pas de materiaux pour cette face, on l'anhilie
        }
    }

	if(PV_GetPipelineControl()&PVP_HARDWARETL)
	{		
		unsigned h=PV_GetHardwareDriver()->UpdateMesh(o);
		if(h!=COOL) return h;
	}

	return COOL;
}

static int PV_CompileMeshesList(PVMesh *o)
{
	unsigned h;	

	while(o!=NULL)
    {
        if(o->Child!=NULL) PV_CompileMeshesList(o->Child);
		
		if((h=PV_CompileOneMesh(o))!=COOL) return h;
        o=o->Next;
    }

	return COOL;
}

int PVAPI PV_CompileMeshes(PVWorld *z)
{
    unsigned int hr;

    debug(printf("Started meshes compilation\n"););

    hr=PV_CompileMeshesList(z->Objs);
	if(hr!=COOL) return hr;
    PV_CompileVertexesMeshList(z->Objs);

    return COOL;
}

int PVAPI PV_CompileMesh(PVMesh *m)
{
	unsigned hr;

	hr=PV_CompileOneMesh(m);
	if(hr!=COOL) return hr;
	PV_MeshCompileVertexes(m);
	return COOL;
}

///////////////////////////////////////////////////////////////// Material Compilation

int PVAPI PV_CompileMaterials(PVWorld *w,UPVD8 (*CalcFunc)(PVRGB *pal,PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient,unsigned reserved),UPVD16 (*CalcFunc16)(PVMaterial *m,unsigned col,unsigned lightlevel,PVRGBF ambient))
{
    PVMaterial *m=w->Materials;
    int h;

    debug(printf("� Processing materials...\n"););
	
    if(PV_Mode&PVM_PALETIZED8)
    {
        debug(printf("\t=> Output is paletized, converting textures to a unique palette\n"););

        // Mode ecran paletiz�
        // Converti toutes les texture en 8 bits avec palette unique
        // sauf si palette gloabl deja specifi�e
        if(w->Global256Palette==NULL)
        {
            h=PV_CreateGlobal256Palette(w->Materials,w->ReservedColors,&w->Global256Palette);
            if(h!=COOL) return h;
        }
    }

    while(m!=NULL)
    {
		// On fait pointer pal sur la palete global, afin de s'en servir
		// Comme p�lette de reference pour les tables HACK
		if(PV_Mode&PVM_PALETIZED8)
		{
			if(m->TextureFlags&TEXTURE_QUANTIZED) m->Pal=w->Global256Palette;
		}
		h=PV_CompileMaterial(m,CalcFunc,CalcFunc16,w->AmbientLight,w->ReservedColors);
		if(PV_Mode&PVM_PALETIZED8)
		{
			if(m->TextureFlags&TEXTURE_QUANTIZED) m->Pal=NULL;
		}
		if(h!=COOL) return h;

        m=m->Next;
    }
    return COOL;
}


//
// oct1.c
//
// Color octree routines.
//
// Dean Clark
// for Dr. Dobbs Journal
// June 1995
//

// revisit� par moi

#include	<stdio.h>
#include	<stdlib.h>
#include	"oct1.h"

#define		COLORBITS	8
#define     TREEDEPTH   8

static byte MASK[COLORBITS] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
#define BIT(b,n)    (((b)&MASK[n])>>n)
#define LEVEL(c,d)  ((BIT((c)->r,(d)))<<2 | BIT((c)->g,(d))<<1 | BIT((c)->b,(d)))


static OctreeType  *reducelist[TREEDEPTH];             // List of reducible nodes

static byte glbLeafLevel = TREEDEPTH;
static uint glbTotalLeaves = 0;

static void MakeReducible(int level, OctreeType *node);
static OctreeType *GetReducible(void);

//----------------------------------------------------------------------------
//
// InsertTree
//
// Insert a color into the octree
//
int InsertTree(OctreeType **tree, RGBType *color, uint depth)
{
    if ((*tree) == NULL) {
        if(((*tree) = CreateOctNode(depth))==NULL) return -1;
	}

    if ((*tree)->isleaf) {

        (*tree)->npixels++;
        (*tree)->redsum += color->r;
        (*tree)->greensum += color->g;
        (*tree)->bluesum += color->b;
	}
	else {
        return InsertTree(&((*tree)->child[LEVEL(color, TREEDEPTH-depth)]),
				   color,
				   depth+1);
	}
    return 0;
}



//--------------------------------------------------------------------------
//
// ReduceTree
//
// Combines all the children of a node into the parent, makes the parent
// into a leaf
//
void ReduceTree()
{
	OctreeType  *node;
	ulong   sumred=0, sumgreen=0, sumblue=0;
	byte    i, nchild=0;

	node = GetReducible();
    for (i = 0; i < COLORBITS; i++) {
		if (node->child[i]) {
			nchild++;
			sumred += node->child[i]->redsum;
			sumgreen += node->child[i]->greensum;
			sumblue += node->child[i]->bluesum;
			node->npixels += node->child[i]->npixels;
			free(node->child[i]);
		}
	}
    node->isleaf = (1==1);//True;
	node->redsum = sumred;
	node->greensum = sumgreen;
	node->bluesum = sumblue;
    glbTotalLeaves -= (nchild - 1);
}

//--------------------------------------------------------------------------
//
// CreateOctNode
//
// Allocates and initializes a new octree node.  The level of the node is
// determined by the caller.
//
// Arguments:
//  level   int     Tree level where the node will be inserted.
//
// Returns:
//  Pointer to newly allocated node.  Does not return on failure.
//
OctreeType *CreateOctNode(int level)
{
    OctreeType  *newnode;
    int                i;

    if((newnode = (OctreeType *)malloc(sizeof(OctreeType)))==NULL) return NULL;
    newnode->level = level;
    newnode->isleaf = (level == glbLeafLevel);
    if (newnode->isleaf) {
        glbTotalLeaves++;
    }
    else {
        MakeReducible(level, newnode);
    }
	newnode->index = 0;
    newnode->npixels = 0;
    newnode->redsum = newnode->greensum = newnode->bluesum = 0;
    for (i = 0; i < COLORBITS; i++) {
        newnode->child[i] = NULL;
	}
	return newnode;
}


//-----------------------------------------------------------------------
//
// MakeReducible
//
// Adds a node to the reducible list for the specified level
//
static void MakeReducible(int level, OctreeType *node)
{
    node->nextnode = reducelist[level];
    reducelist[level] = node;
}


//-----------------------------------------------------------------------
//
// GetReducible
//
// Returns the next available reducible node at the tree's leaf level
//
static OctreeType *GetReducible(void)
{
    OctreeType *node;

    while (reducelist[glbLeafLevel-1] == NULL) {
        glbLeafLevel--;
    }
    node = reducelist[glbLeafLevel-1];
    reducelist[glbLeafLevel-1] = reducelist[glbLeafLevel-1]->nextnode;
	return node;
}

//---------------------------------------------------------------------------
//
// MakePaletteTable
//
// Given a color octree, traverse the tree and do the following:
//	- Add the averaged RGB leaf color to the color palette table;
//	- Store the palette table index in the tree;
//
// When this recursive function finally returns, 'index' will contain
// the total number of colors in the palette table.
//
void MakePaletteTable(OctreeType *tree, RGBType table[], int *index)
{
	int	i;

	if (tree->isleaf) {
		table[*index].r = (byte)(tree->redsum / tree->npixels);
        table[*index].g = (byte)(tree->greensum / tree->npixels);
        table[*index].b = (byte)(tree->bluesum / tree->npixels);
		tree->index = *index;
		(*index)++;
	}
	else {
        for (i = 0; i < COLORBITS; i++) {
			if (tree->child[i]) {
				MakePaletteTable(tree->child[i], table, index);
			}
		}
	}
}

//---------------------------------------------------------------------------
//
// QuantizeColor
//
// Returns the palette table index of an RGB color by traversing the
// octree to the leaf level
//
byte QuantizeColor(OctreeType *tree, RGBType *color)
{
    if (tree->isleaf) {
		return tree->index;
	}
	else {
        return QuantizeColor(tree->child[LEVEL(color,TREEDEPTH-tree->level)],color);
	}
}

//---------------------------------------------------------------------------
//
// TotalLeafNodes
//
// Returns the total leaves in the tree (glbTotalLeaves)
//
ulong TotalLeafNodes()
{
	return glbTotalLeaves;
}

void KillOctree(OctreeType *tree)
{
   int i;

   if (tree==NULL) return;

   if(tree->isleaf) return;

   for (i = 0; i < COLORBITS; i++) {

         KillOctree(tree->child[i]);
         free(tree->child[i]);
	}
    glbTotalLeaves = 0;
	if(tree->level==0) free(tree);
}

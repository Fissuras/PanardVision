/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include <string.h>
#include "pvision.h"

void PVAPI SetupMatrix3x3(PVMat3x3 Matrix,float AngleX,float AngleY,float AngleZ)
{
    float cox,coy,coz,six,siy,siz;

    // matrice de rotation de l'objet
    cox=cos(AngleX); coy=cos(AngleY); coz=cos(AngleZ);
    six=sin(AngleX); siy=sin(AngleY); siz=sin(AngleZ);

    Matrix[0][0]=coz*coy;
    Matrix[0][1]=coz*siy*six-siz*cox;
    Matrix[0][2]=coz*siy*cox+siz*six;
    Matrix[1][0]=siz*coy;
    Matrix[1][1]=siz*siy*six+coz*cox;
    Matrix[1][2]=siz*siy*cox-coz*six;
    Matrix[2][0]=-siy;
    Matrix[2][1]=six*coy;
    Matrix[2][2]=cox*coy;
}

void PVAPI SetupMatrix3x3YPR(PVMat3x3 Matrix,float yaw,float pitch, float roll)
{
	float           ci, cj, ch, si, sj, sh;
	float           cc, cs, sc, ss;

	ci = (float)cos( roll );
	cj = (float)cos( pitch );
	ch = (float)cos( yaw );

	si = (float)sin( roll );
	sj = (float)sin( pitch );
	sh = (float)sin( yaw );

	cc = ci * ch;
	cs = ci * sh;
	sc = si * ch;
	ss = si * sh;

	Matrix[0][0] = (sj * ss) + cc;
	Matrix[0][1] = (sj * cs) - sc;
	Matrix[0][2] = cj * sh;

	Matrix[1][0] = cj * si;
	Matrix[1][1] = cj * ci;
	Matrix[1][2] = -sj;

	Matrix[2][0] = (sj * sc) - cs;
	Matrix[2][1] = (sj * cc) + ss;
	Matrix[2][2] = cj * ch;
}

//----------------------------------- Rotations

void PVAPI RotatePoint3x3(PVPoint *v,PVMat3x3 m,PVPoint *p) // 9 muls
{
    p->xf=m[0][0]*v->xf+m[0][1]*v->yf+m[0][2]*v->zf;
    p->yf=m[1][0]*v->xf+m[1][1]*v->yf+m[1][2]*v->zf;
    p->zf=m[2][0]*v->xf+m[2][1]*v->yf+m[2][2]*v->zf;
}

void PVAPI RotateInvertPoint(PVPoint *v,PVMat3x3 m,PVPoint *p) // 9 muls
{
    p->xf=m[0][0]*v->xf+m[1][0]*v->yf+m[2][0]*v->zf;
    p->yf=m[0][1]*v->xf+m[1][1]*v->yf+m[2][1]*v->zf;
    p->zf=m[0][2]*v->xf+m[1][2]*v->yf+m[2][2]*v->zf;
}


void PVAPI OrthonormalizeMatrix(PVMat3x3 m)
{
    PVMat3x3 o;
    float n,z,z2,v[3];

    n=sqrt(m[0][0]*m[0][0]+m[1][0]*m[1][0]+m[2][0]*m[2][0]);
    o[0][0]=m[0][0]/n;
    o[1][0]=m[1][0]/n;
    o[2][0]=m[2][0]/n;

    z=(m[0][1]*o[0][0]+m[1][1]*o[1][0]+m[2][1]*o[2][0]);
    v[0]=m[0][1]-z*o[0][0];
    v[1]=m[1][1]-z*o[1][0];
    v[2]=m[2][1]-z*o[2][0];
    n=sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
    o[0][1]=v[0]/n;
    o[1][1]=v[1]/n;
    o[2][1]=v[2]/n;

    z=(m[0][2]*o[0][0]+m[1][2]*o[1][0]+m[2][2]*o[2][0]);
    z2=(m[0][2]*o[0][1]+m[1][2]*o[1][1]+m[2][2]*o[2][1]);
    v[0]=m[0][2]-z*o[0][0]-z2*o[0][1];
    v[1]=m[1][2]-z*o[1][0]-z2*o[1][1];
    v[2]=m[2][2]-z*o[2][0]-z2*o[2][1];
    n=sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
    o[0][2]=v[0]/n;
    o[1][2]=v[1]/n;
    o[2][2]=v[2]/n;

    memcpy(m,&o,sizeof(PVMat3x3));
}

///////////////////////////////////////////////////////////////////////

void PVAPI QuatScale( PVQuat *q,float s,PVQuat *dest ) // Scale quaternion by value.
{
    dest->w = q->w*s;
    dest->x = q->x*s;
    dest->y = q->y*s;
    dest->z = q->z*s;
}

void PVAPI QuatUnit( PVQuat *q,PVQuat *dest ) // Normalize quaternion.
{
	float s;
    s = 1.0/QuatMod(q);
    QuatScale( q,s,dest );
}

void PVAPI OrientationToQuat(float x,float y,float z,float a,PVQuat *q)
{
    float s=sin(a/2);

    q->w=cos(a/2);
    q->x=s*x;
    q->y=s*y;
    q->z=s*z;
}


void PVAPI QuatToOrientation( PVQuat *q, float *x,float *y,float *z,float *angle )
{
	float halfang,s;
	PVQuat qn;

    QuatUnit( q,&qn );
	halfang = acos( qn.w );
	*angle = 2.0*halfang;
	s = sin(halfang);
	*x = qn.x/s;
	*y = qn.y/s;
	*z = qn.z/s;
}

void PVAPI QuatMul(PVQuat *q1,PVQuat *q2,PVQuat *q3)
{
    float v1xv2[3];

    v1xv2[0]=q1->y*q2->z-q1->z*q2->y;
    v1xv2[1]=q1->z*q2->x-q1->x*q2->z;
    v1xv2[2]=q1->x*q2->y-q1->y*q2->x;

    q3->w=q1->w*q2->w-(q1->x*q2->x+q1->y*q2->y+q1->z*q2->z);

    q3->x=q1->w*q2->x+q2->w*q1->x+v1xv2[0];
    q3->y=q1->w*q2->y+q2->w*q1->y+v1xv2[1];
    q3->z=q1->w*q2->z+q2->w*q1->z+v1xv2[2];
}

void PVAPI QuatExp( PVQuat *q, PVQuat *dest ) // Calculate quaternion`s exponent.
{
	float d,d1;
    d = sqrt( q->x*q->x + q->y*q->y + q->z*q->z );
	if (d > 0) d1 = sin(d)/d; else d1 = 1;
	dest->w = cos(d);
    dest->x = q->x*d1;
    dest->y = q->y*d1;
    dest->z = q->z*d1;
}

void PVAPI QuatInv( PVQuat *q, PVQuat *dest ) //  Multiplicative inverse of q.
{
	float d;
    d = q->x*q->x + q->y*q->y + q->z*q->z + q->w*q->w;
    if (d != 0) d = 1.0/d;  else    d = 1;
    dest->w =  q->w * d;
    dest->x = -q->x * d;
    dest->y = -q->y * d;
    dest->z = -q->z * d;
}

void PVAPI QuatLog( PVQuat *q, PVQuat *dest ) // Calculate quaternion`s logarithm.
{
	float d;
    d = sqrt( q->x*q->x + q->y*q->y + q->z*q->z );
    if (q->w != 0.0) d = atan(d/q->w);    else    d = PI/2;
    dest->w = 0.0;
    dest->x = q->x*d;
    dest->y = q->y*d;
    dest->z = q->z*d;
}

// Calculate logarithm of the relative rotation from p to q
void PVAPI QuatLnDif( PVQuat *p, PVQuat *q, PVQuat *dest )
{
	PVQuat inv,dif;
	float d,d1;
	float s;

    QuatInv( p,&inv );         // inv = -p;
    QuatMul(&inv,q,&dif ); // dif = -p*q

    d = sqrt( dif.x*dif.x + dif.y*dif.y + dif.z*dif.z );
    s = p->x*q->x + p->y*q->y + p->z*q->z + p->w*q->w;
    if (s != 0) d1 = atan(d/s); else    d1 = PI/2;
	if (d != 0) d1 /= d;

	dest->w = 0;

    dest->x = dif.x*d1;
    dest->y = dif.y*d1;
    dest->z = dif.z*d1;
}

float PVAPI QuatMod(PVQuat *q )  // Returns modul of quaternion
{
	float d;
    d = sqrt(q->x*q->x + q->y*q->y + q->z*q->z + q->w*q->w);
	if (d == 0) d = 1;	// for some case.
	return d;
}

float PVAPI QuatDot( PVQuat *q1, PVQuat *q2 )    // Returns dot product of q1*q2
{
	float d;
    d = (q1->x*q2->x + q1->y*q2->y + q1->z*q2->z + q1->w*q2->w)/(QuatMod(q1)*QuatMod(q2));
	return d;
}

// Returns dot product of normilized quternions q1*q2
float PVAPI QuatDotUnit( PVQuat *q1, PVQuat *q2 )    {
    return q1->x*q2->x + q1->y*q2->y + q1->z*q2->z + q1->w*q2->w;
}

void PVAPI QuatNegate( PVQuat *q ) // Negates q;
{
	float d;
    d = 1.0/QuatMod(q);
	q->w *=  d;
	q->x *= -d;
	q->y *= -d;
	q->z *= -d;
}

#define EPSILON 1.0E-06

void PVAPI QuatSlerp( PVQuat *a,PVQuat *b, PVQuat *dest, float time,float spin )  {
	double k1,k2;					// interpolation coefficions.
	double angle;					// angle between A and B
	double angleSpin;			// angle between A and B plus spin.
	double sin_a, cos_a;	// sine, cosine of angle
	int flipk2;						// use negation of k2.

    cos_a = QuatDotUnit( a,b );
	if (cos_a < 0.0) 	cos_a = -cos_a, flipk2 = -1;  else flipk2 = 1;

//    if( (1.0+cos_a)>EPSILON)
    {
        if ((1.0 - cos_a) < EPSILON) {
            k1 = 1.0 - time;
            k2 = time;
        } else {                /* normal case */
            angle = acos(cos_a);
            sin_a = 1/sin(angle);
            angleSpin = angle + spin*PI;
            k1 = sin( angle - time*angleSpin ) * sin_a;
            k2 = sin( time*angleSpin ) * sin_a;
        }
        k2 *= flipk2;

        dest->x = k1*a->x + k2*b->x;
        dest->y = k1*a->y + k2*b->y;
        dest->z = k1*a->z + k2*b->z;
        dest->w = k1*a->w + k2*b->w;
    }
  /*  else
    {
        dest->x=-a->y;
        dest->y=a->x;
        dest->z=-a->w;
        dest->w=a->z;

        k1=sin((1.0-time)*(PI/2.0));
        k2=sin(time*(PI/2.0))*flipk2;
        dest->x=k1*a->x+k2*dest->x;
        dest->y=k1*a->y+k2*dest->y;
        dest->z=k1*a->z+k2*dest->z;
    }*/
}

void PVAPI QuatSlerpLong( PVQuat *a,PVQuat *b, PVQuat *dest, float time,float spin )  {
	double k1,k2;					// interpolation coefficions.
	double angle;					// angle between A and B
	double angleSpin;			// angle between A and B plus spin.
	double sin_a, cos_a;	// sine, cosine of angle

    cos_a = QuatDotUnit( a,b );
    if( (1.0+cos_a)>EPSILON)
    {
        if (1.0 - (cos_a) < EPSILON) {
            k1 = 1.0 - time;
            k2 = time;
        } else {                /* normal case */
            angle = acos(cos_a);
            sin_a = 1/sin(angle);
            angleSpin = angle + spin*PI;
            k1 = sin( angle - time*angleSpin ) * sin_a;
            k2 = sin( time*angleSpin ) * sin_a;
        }

        dest->x = k1*a->x + k2*b->x;
        dest->y = k1*a->y + k2*b->y;
        dest->z = k1*a->z + k2*b->z;
        dest->w = k1*a->w + k2*b->w;
    }
    else
    {
        // Opposite quats, take a perpendicular quat and slerp in this direction
        dest->x=-a->y;
        dest->y=a->x;
        dest->z=-a->w;
        dest->w=a->z;

        k1=sin((1.0-time)*(PI/2.0));
        k2=sin(time*(PI/2.0));
        dest->x=k1*a->x+k2*dest->x;
        dest->y=k1*a->y+k2*dest->y;
        dest->z=k1*a->z+k2*dest->z;
    }
}

void PVAPI QuatToMatrix(PVQuat *q,PVMat3x3 Matrix)
{
	float d,s,xs,ys,zs,wx,wy,wz,xx,xy,xz,yy,yz,zz;

    d = q->x*q->x + q->y*q->y + q->z*q->z + q->w*q->w;
	if (d == 0.0) s = 1.0; else s = 2.0/d;

    xs = q->x * s;   ys = q->y * s;  zs = q->z * s;
    wx = q->w * xs;  wy = q->w * ys; wz = q->w * zs;
    xx = q->x * xs;  xy = q->x * ys; xz = q->x * zs;
    yy = q->y * ys;  yz = q->y * zs; zz = q->z * zs;

    Matrix[0][0] = 1.0 - (yy + zz);
    Matrix[0][1] = xy - wz;
    Matrix[0][2] = xz + wy;

    Matrix[1][0] = xy + wz;
    Matrix[1][1] = 1.0 - (xx + zz);
    Matrix[1][2] = yz - wx;

    Matrix[2][0] = xz - wy;
    Matrix[2][1] = yz + wx;
    Matrix[2][2] = 1.0 - (xx + yy);
}

void PVAPI MatrixToQuat(PVMat3x3 Matrix,PVQuat *q)
{
	float s,v;

    v = Matrix[0][0] + Matrix[1][1] + Matrix[2][2];
	if (v > 0.0) {
		s = sqrt(v + 1.0);
		q->w = 0.5 * s;
		s = 0.5 / s;
        q->x = (Matrix[2][1] - Matrix[1][2]) * s;
        q->y = (Matrix[0][2] - Matrix[2][0]) * s;
        q->z = (Matrix[1][0] - Matrix[0][1]) * s;
	}	else {
        if (Matrix[1][1] > Matrix[0][0])  {
            if (Matrix[2][2] > Matrix[1][1])  {
                s = sqrt( (Matrix[2][2] - (Matrix[0][0] + Matrix[1][1])) + 1.0 );
				q->z = s * 0.5;
				if (s != 0.0)	s = 0.5/s;
                q->w = (Matrix[1][0] - Matrix[0][1]) * s;
                q->x = (Matrix[0][2] + Matrix[2][0]) * s;
                q->y = (Matrix[1][2] + Matrix[2][1]) * s;
			}	else	{
                s = sqrt( (Matrix[1][1] - (Matrix[2][2] + Matrix[0][0])) + 1.0 );
				q->y = s * 0.5;
				if (s != 0.0)	s = 0.5/s;
                q->w = (Matrix[0][2] - Matrix[2][0]) * s;
                q->z = (Matrix[2][1] + Matrix[1][2]) * s;
                q->x = (Matrix[0][1] + Matrix[1][0]) * s;
			}
		}	else
        if (Matrix[2][2] > Matrix[0][0])  {
            s = sqrt( (Matrix[2][2] - (Matrix[0][0] + Matrix[1][1])) + 1.0 );
			q->z = s * 0.5;
			if (s != 0.0)	s = 0.5/s;
            q->w = (Matrix[1][0] - Matrix[0][1]) * s;
            q->x = (Matrix[0][2] + Matrix[2][0]) * s;
            q->y = (Matrix[1][2] + Matrix[2][1]) * s;
		}	else	{
            s = sqrt( (Matrix[0][0] - (Matrix[1][1] + Matrix[2][2])) + 1.0 );
			q->x = s * 0.5;
			if (s != 0.0)	s = 0.5/s;
            q->w = (Matrix[2][1] - Matrix[1][2]) * s;
            q->y = (Matrix[1][0] + Matrix[0][1]) * s;
            q->z = (Matrix[2][0] + Matrix[0][2]) * s;
		}
	}
}

///////////////////////////////////////////////////////////////////////

void PVAPI MatrixMul(PVMat3x3 in1, PVMat3x3 in2, PVMat3x3 out)
{
    int     i, j;

    for (i=0 ; i<3 ; i++)
    {
        for (j=0 ; j<3 ; j++)
        {
            out[i][j] = in1[i][0] * in2[0][j] +
                        in1[i][1] * in2[1][j] +
                        in1[i][2] * in2[2][j];
        }
    }
}

void PVAPI NormalizePoint(PVPoint *p)
{
	double n;
    
	n=(p->xf*p->xf+p->yf*p->yf+p->zf*p->zf);
	if(n>0)
	{
		n=1/sqrt(n);
		p->xf*=n;
		p->yf*=n;
		p->zf*=n;
	}
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <assert.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include "pvision.h"
#include "sqrt.h"
#include "shadow.h"

#define debug(x) //x

void PVAPI PV_KillBoxes(PVBox *b)
{
    unsigned i;

    if(b==NULL) return;

    if(b->Flags&1) free(b->FaceIndex);
    for(i=0;i<8;i++) PV_KillBoxes(b->Child[i]);
    free(b);
}

PVMesh * PVAPI PV_CreateMeshInstance(PVMesh *source)
{
	PVMesh *m;

	if(source==NULL) return NULL;
	if(source->Owner==NULL) return NULL;
	if(source->Flags&MESH_INSTANCE) return NULL;
	if(source->Flags&MESH_PORTAL) return NULL;

	m=PV_CreateMesh(source->MaxNbrClippedFaces,source->MaxNbrClippedVertices);
	if(m==NULL) return NULL;

	m->Flags|=MESH_INSTANCE;
	source->RefCnt++;

	m->NbrFaces=source->NbrFaces;
	m->NbrVertices=source->NbrVertices;
	m->NodeInfos.NbrBoxes=source->NodeInfos.NbrBoxes;
	m->Vertex=source->Vertex;
	m->Face=source->Face;
	m->NbrMapIndex=source->LastMapIndex;
	m->VerticesIndex=source->VerticesIndex;
	m->NbrIndex=source->NbrIndex;
	m->Mapping=source->Mapping;
    m->Rotated=(PVPoint*)calloc(m->NbrVertices+source->MaxNbrClippedVertices,sizeof(PVPoint));
    m->Projected=(PVScreenPoint*)calloc(m->NbrVertices+source->MaxNbrClippedVertices,sizeof(PVScreenPoint));
    m->Visible=(PVFace**)calloc(sizeof(PVFace*),m->NbrFaces);
	m->FaceInfos=(PVFaceInfo*)calloc(sizeof(PVFaceInfo),m->NbrFaces);
	if((m->Rotated==NULL)||(m->Projected==NULL)||(m->Visible==NULL)||(m->FaceInfos==NULL))
	{
		PV_Fatal("CreateInstance():: Not Enough memory\n",0);
		return NULL;
	}

	m->Box=source->Box;
	m->SwitchInfos.NbrVertexBox=source->SwitchInfos.NbrVertexBox;
	m->CollideInfo=source->CollideInfo;
	m->UserPipeline=source->UserPipeline;
	m->UserData=source->UserData;
	m->UserMeshCleanUp=source->UserMeshCleanUp;
	m->EdgeTable=source->EdgeTable;

	return m;
}

PVMesh * PVAPI PV_CreateMesh(unsigned maxclipface,unsigned maxclipvertex)
{
   PVMesh *no;
   unsigned i;

   if ( (no=(PVMesh *)malloc(sizeof(PVMesh)))==NULL ) return NULL;   

   no->MaxNbrClippedFaces=maxclipface;
   no->MaxNbrClippedVertices=maxclipvertex;

   no->Polys=NULL;
   if(maxclipface!=0)
   if((no->Polys=(PVPoly *)malloc(maxclipface*sizeof(PVPoly)))==NULL)
   {
        free(no);
        return NULL;
   }

   no->FaceInfos=NULL;
   no->RefCnt=1;
   no->NbrFaces=no->NbrVertices=no->NbrVisibles=0;
   no->Pivot.xf=no->Pivot.yf=no->Pivot.zf=0;
   no->Vertex=NULL;
   no->Face=NULL;
   no->VerticesIndex=NULL;
   no->NbrIndex=0;
   no->NbrMapIndex=no->LastMapIndex=0;
   no->Mapping=NULL;
   no->Rotated=NULL;
   no->Projected=NULL;
   no->Visible=NULL;
   no->Shading=NULL;
   no->Box=NULL;
   no->Position.xf=no->Position.yf=no->Position.zf=0;
   no->LastWorldPos.xf=no->OldPos.xf=-1;
   no->LastWorldMatrix[0][0]=no->OldMatrix[0][0]=-1;
   no->Flags=0;
   no->VertexVisible=NULL;
   no->nbrclipv=0;
   no->CollideInfo=NULL;
   no->UserData=NULL;
   no->ScaleX=no->ScaleY=no->ScaleZ=1;
   no->NodeInfos.NbrBoxes=0;
   no->SwitchVal.NbrPolys=0;
   no->UserPipeline=NULL;
   PV_MeshSetupMatrix(no,0,0,0);

   no->Owner=NULL;
   no->Child=NULL;
   no->Father=NULL;
   no->Next=NULL;
   no->Name=NULL;
   no->HardwarePrivate=NULL;

   no->LastFrame=0xFFFFFFFF;

   no->SwitchInfos.NbrVertexBox=0;
   no->UserMeshCleanUp=NULL;
   no->AfterVisibilityPipe=NULL;

   SetupMatrix3x3(no->LastWorldMatrix,0,0,0);
   no->WorldPos.xf=0;
   no->WorldPos.yf=0;
   no->WorldPos.zf=0;

   for(i=0;i<MAX_SHADOW_VOLUMES;i++) no->Shadows[i]=NULL;
   
   no->EdgeTable=NULL;

   no->NbrMapIndex=no->NbrVertices;
   no->Dirty.Flags=0;

   return no;
}

PVMesh * PVAPI PV_SimpleCreateMeshWithAdditionalMappings(unsigned nbrfaces,unsigned NbrVertices,unsigned maxclipface,unsigned maxclipvertex,unsigned nbrmapping)
{
	PVMesh *m;
	
	if(nbrmapping<NbrVertices) return NULL;

	m=PV_SimpleCreateMesh(nbrfaces,NbrVertices,maxclipface,maxclipvertex);
	if(m==NULL) return NULL;

	m->Mapping=(PVMapInfo*)realloc(m->Mapping,(m->NbrVertices+maxclipvertex+nbrmapping)*sizeof(PVMapInfo));
	if(m->Mapping==NULL)
	{
		PV_KillMesh(m);
		return NULL;
	}

	m->NbrMapIndex=nbrmapping+m->NbrVertices;

	return m;
}

PVMesh * PVAPI PV_SimpleCreateMesh(unsigned nbrfaces,unsigned NbrVertices,unsigned maxclipface,unsigned maxclipvertex)
{
   PVMesh *no;
   unsigned i;

   if ( (no=(PVMesh *)malloc(sizeof(PVMesh)))==NULL ) return NULL;

   no->MaxNbrClippedFaces=maxclipface;
   no->MaxNbrClippedVertices=maxclipvertex;

   no->Polys=NULL;
   if(maxclipface!=0)
   if((no->Polys=(PVPoly *)malloc(maxclipface*sizeof(PVPoly)))==NULL)
   {
        free(no);
        return NULL;
   }
	
   no->RefCnt=1;
   no->NbrFaces=nbrfaces;
   no->NbrVertices=NbrVertices;
   no->NbrVisibles=0;
   no->Pivot.xf=no->Pivot.yf=no->Pivot.zf=0;
   no->Vertex=(PVVertex*)calloc(NbrVertices+maxclipvertex,sizeof(PVVertex));
   no->Face=(PVFace*)calloc(sizeof(PVFace),nbrfaces);
   no->Mapping=(PVMapInfo*)calloc(NbrVertices+maxclipvertex,sizeof(PVMapInfo));
   no->Rotated=(PVPoint*)calloc(NbrVertices+maxclipvertex,sizeof(PVPoint));
   no->Projected=(PVScreenPoint*)calloc(NbrVertices+maxclipvertex,sizeof(PVScreenPoint));
   no->Visible=(PVFace**)calloc(sizeof(PVFace*),nbrfaces);
   no->FaceInfos=(PVFaceInfo*)calloc(sizeof(PVFaceInfo),nbrfaces);

   if((no->Vertex==NULL)||(no->Face==NULL)||(no->Mapping==NULL)||(no->Rotated==NULL)||(no->Projected==NULL)||(no->Visible==NULL)||(no->FaceInfos==NULL))
   {
        free(no->Vertex);
        free(no->Face);
        free(no->Mapping);
        free(no->Rotated);
        free(no->Projected);
        free(no->Visible);
        free(no->Polys);
        free(no);
	  return NULL;
   }
   no->VerticesIndex=NULL;
   no->NbrIndex=0;
   no->NbrMapIndex=no->LastMapIndex=0;
   no->Shading=NULL;
   no->Box=NULL;
   no->Position.xf=no->Position.yf=no->Position.zf=0;
   no->LastWorldPos.xf=no->OldPos.xf=-1;
   no->LastWorldMatrix[0][0]=no->OldMatrix[0][0]=-1;
   no->Flags=0;
   no->VertexVisible=NULL;
   no->nbrclipv=0;
   no->CollideInfo=NULL;
   no->UserData=NULL;
   no->ScaleX=no->ScaleY=no->ScaleZ=1;
   no->NodeInfos.NbrBoxes=0;
   no->SwitchVal.NbrPolys=0;
   no->UserPipeline=NULL;
   PV_MeshSetupMatrix(no,0,0,0);

   no->Owner=NULL;
   no->Child=NULL;
   no->Father=NULL;
   no->Next=NULL;
   no->Name=NULL;
   no->HardwarePrivate=NULL;

   no->LastFrame=0xFFFFFFFF;

   no->SwitchInfos.NbrVertexBox=0;
   no->UserMeshCleanUp=NULL;
   no->AfterVisibilityPipe=NULL;

   // atatch faces
   for(i=0;i<nbrfaces;i++) no->Face[i].Father=no;

   SetupMatrix3x3(no->LastWorldMatrix,0,0,0);
   no->WorldPos.xf=0;
   no->WorldPos.yf=0;
   no->WorldPos.zf=0;

   for(i=0;i<MAX_SHADOW_VOLUMES;i++) no->Shadows[i]=NULL;

   no->EdgeTable=NULL;

   no->NbrMapIndex=no->NbrVertices;

   no->Dirty.Flags=0;

   return no;
}

void PVAPI PV_SetMeshName(PVMesh *m,char *s)
{
	if(m==NULL) return;

	if(m->Name!=NULL) free(m->Name);
	m->Name=strdup(s);
}

PVMesh *PVAPI PV_CloneMesh(PVMesh *o)
{
	PVMesh *m;
	unsigned i;

	if(o==NULL) return NULL;

	if(o->NbrMapIndex>o->NbrVertices)
		m=PV_SimpleCreateMeshWithAdditionalMappings(o->NbrFaces,o->NbrVertices,o->MaxNbrClippedFaces,o->MaxNbrClippedVertices,o->NbrMapIndex-o->NbrVertices);
	else
		m=PV_SimpleCreateMesh(o->NbrFaces,o->NbrVertices,o->MaxNbrClippedFaces,o->MaxNbrClippedVertices);
	if(m==NULL) return NULL;

	memcpy(m->Vertex,o->Vertex,sizeof(PVVertex)*m->NbrVertices);
	memcpy(m->Face,o->Face,sizeof(PVFace)*m->NbrFaces);
	memcpy(m->Mapping,o->Mapping,sizeof(PVMapInfo)*m->NbrMapIndex);

	for(i=0;i<m->NbrFaces;i++) m->Face[i].V=NULL;
	for(i=0;i<m->NbrFaces;i++)
	{				
		m->Face[i].Father=m;
		PV_SetVerticesToFace(&m->Face[i],o->Face[i].V,o->Face[i].NbrVertices);

		if(m->Face[i].Material!=NULL) m->Face[i].Material=strdup(o->Face[i].Material);
		if(m->Face[i].MaterialInfo!=NULL) m->Face[i].MaterialInfo->RefCnt++;

		if(o->Face[i].Flags&TEXTURE_BASIS)
		{
			m->Face[i].MapInfos.TexBasis=NULL;
			PV_AttachTextureBasis(&m->Face[i],o->Face[i].MapInfos.TexBasis);		
		}

		m->Face[i].LightMap=NULL; 
		PV_AttachLightMap(&m->Face[i],o->Face[i].LightMap);			
	}

	PV_MeshBuildBoxes(m,o->SwitchInfos.NbrVertexBox);

	m->Flags=o->Flags;	
	
	return m;
}

void PVAPI PV_KillMesh(PVMesh *no)
{
    unsigned i;
	PVHardwareDriver *hd;

	if(no==NULL) return;
	if(no->RefCnt>1)
	{
		no->RefCnt--;
		return;
	}

	if(no->Flags&MESH_INSTANCE)
	{
		PV_KillMesh(no->Face[0].Father);
	}

	if(no->UserMeshCleanUp!=NULL) no->UserMeshCleanUp(no);

	PV_FinalizeMesh(no); 
	
	hd=PV_GetHardwareDriver();
	if(hd!=NULL)
	{
		if(hd->FinalizeMesh!=NULL)
			hd->FinalizeMesh(no);
	}

	free(no->Name);
	free(no->Projected);
	free(no->Visible);
	free(no->Polys);
	free(no->FaceInfos);
	free(no->VertexVisible);
	free(no->Rotated);
	free(no->Shading);	

	if(!(no->Flags&MESH_INSTANCE)) PV_KillBoxes(no->Box);
	if(!(no->Flags&MESH_INSTANCE)) PV_MeshKillCollisionTree(no);	
	if(!(no->Flags&MESH_INSTANCE)) free(no->Mapping);
	if(!(no->Flags&MESH_INSTANCE)) free(no->Vertex);
	if(!(no->Flags&MESH_INSTANCE)) free(no->VerticesIndex);	

	if(!(no->Flags&MESH_INSTANCE))
	for(i=0;i<no->NbrFaces;i++)
	{
		free(no->Face[i].Material);		
		if(no->NbrVertices==no->NbrMapIndex) if(no->Face[i].MapInfos.TexBasis!=NULL) PV_KillTextureBasis(no->Face[i].MapInfos.TexBasis);		
		if(no->Face[i].LightMap!=NULL) PV_KillLightMapInfo(no->Face[i].LightMap);
		if(no->Face[i].MaterialInfo!=NULL) no->Face[i].MaterialInfo->RefCnt--;
	}
	if(!(no->Flags&MESH_INSTANCE)) free(no->Face);

	free(no);
}

static unsigned PV_KillMeshBranch(PVMesh *m,unsigned *nbrfaces,unsigned *nbrvtx)
{
	PVMesh *o=m,*o2;
	unsigned a=0;

	if(m==NULL) return 0;

	while(o!=NULL)
	{
		a+=PV_KillMeshBranch(o->Child,nbrfaces,nbrvtx);

		if(nbrfaces!=NULL) *nbrfaces+=o->NbrFaces;
		if(nbrvtx!=NULL) *nbrvtx+=o->NbrVertices;

		o2=o->Next;
		PV_KillMesh(o);
		a++;

		o=o2;
	}
	return a;
}

unsigned PVAPI PV_KillMeshList(PVMesh *m,unsigned *nbrfaces,unsigned *nbrvtx)
{
	if(m==NULL) return 0;

	if(nbrfaces!=NULL) *nbrfaces=0;
	if(nbrvtx!=NULL) *nbrvtx=0;

	return PV_KillMeshBranch(m,nbrfaces,nbrvtx);
}

PVMesh *PVAPI PV_SearchMeshList(PVMesh *m,char *name)
{
	PVMesh *h;

	if(m==NULL) return NULL;
	if(name==NULL) return NULL;

    while(m!=NULL)
    {
        if(m->Name!=NULL)
			if (strcmp(m->Name,name)==0) return m;

		// cherche les fils
		h=PV_SearchMeshList(m->Child,name);
		if(h!=NULL) return h;

		m=m->Next;
    }

	return NULL;
}

int PVAPI PV_IterateMeshList(PVMesh *m,int (PVAPI * UserFunc)(PVMesh *,int userarg),int userarg)
{
    unsigned h;

	while(m!=NULL)
    {
        h=UserFunc(m,userarg);
		if(h) return h;

		// cherche les fils
		h=PV_IterateMeshList(m->Child,UserFunc,userarg);
		if(h) return h;

		m=m->Next;
    }
    return COOL;
}

void PVAPI PV_MeshSetFlags(PVMesh *o,PVFLAGS f)
{
    o->Flags|=f;
}

void PVAPI PV_MeshCompileVertexes(PVMesh *o)
{
    unsigned i,j;

    for(i=0;i<o->NbrFaces;i++)
    {
        // Recupere les infos de shading des faces et les repercute dans les points
		for(j=0;j<o->Face[i].NbrVertices;j++) o->Vertex[o->Face[i].V[j]].Flags|=o->Face[i].Flags;
    }
}

static void RecurseBoxScale(PVBox *B,float a,float b,float c)
{
    unsigned i;

    if(B==NULL) return;

    B->p0.xf*=a;
    B->p0.yf*=b;
    B->p0.zf*=c;
    B->t0.xf*=a;
    B->t0.yf*=b;
    B->t0.zf*=c;

	B->Volume*=a*b*c;

    for(i=0;i<8;i++) RecurseBoxScale(B->Child[i],a,b,c);
}

void PVAPI PV_MeshScaleVertexes(PVMesh *o,float a,float b, float c)
{
    unsigned int i;
    PVVertex *ov;

    for(i=0,ov=o->Vertex;i<o->NbrVertices;i++,ov++)
    {
        ov->xf*=a;
        ov->yf*=b;
        ov->zf*=c;
    }

    RecurseBoxScale(o->Box,a,b,c);

	PV_MeshSetupPos(o,o->Position.xf*a,o->Position.yf*b,o->Position.zf*c);

    o->Pivot.xf*=a;
    o->Pivot.yf*=b;
    o->Pivot.zf*=c;

	PV_MeshKillCollisionTree(o);
}

static void RecurseBoxRotate(PVBox *B,PVMat3x3 m)
{
    unsigned i;
    float a,b,c;

    if(B==NULL) return;

    a=B->p0.xf*m[0][0]+B->p0.yf*m[0][1]+B->p0.zf*m[0][2];
    b=B->p0.xf*m[1][0]+B->p0.yf*m[1][1]+B->p0.zf*m[1][2];
    c=B->p0.xf*m[2][0]+B->p0.yf*m[2][1]+B->p0.zf*m[2][2];
    B->p0.xf=a;
    B->p0.yf=b;
    B->p0.zf=c;

    a=B->t0.xf*m[0][0]+B->t0.yf*m[0][1]+B->t0.zf*m[0][2];
    b=B->t0.xf*m[1][0]+B->t0.yf*m[1][1]+B->t0.zf*m[1][2];
    c=B->t0.xf*m[2][0]+B->t0.yf*m[2][1]+B->t0.zf*m[2][2];
    B->t0.xf=a;
    B->t0.yf=b;
    B->t0.zf=c;

    for(i=0;i<8;i++) RecurseBoxRotate(B->Child[i],m);
}

void PVAPI PV_MeshRotateVertexes(PVMesh *o,PVMat3x3 m)
{
    float a,b,c;
    PVVertex *ov;
    unsigned int i;

    for(i=0,ov=o->Vertex;i<o->NbrVertices;i++,ov++)
    {
        a=ov->xf*m[0][0]+ov->yf*m[0][1]+ov->zf*m[0][2];
        b=ov->xf*m[1][0]+ov->yf*m[1][1]+ov->zf*m[1][2];
        c=ov->xf*m[2][0]+ov->yf*m[2][1]+ov->zf*m[2][2];
        ov->xf=a;
        ov->yf=b;
        ov->zf=c;
    }

    RecurseBoxRotate(o->Box,m);

    PV_MeshNormCalc(o);
	PV_MeshKillCollisionTree(o);
}

static void RecurseBoxTranslate(PVBox *B,float x,float y,float z)
{
    unsigned i;

    if(B==NULL) return;

    B->p0.xf+=x;
    B->p0.yf+=y;
    B->p0.zf+=z;

    for(i=0;i<8;i++) RecurseBoxTranslate(B->Child[i],x,y,z);
}

void PVAPI PV_MeshTranslateVertexes(PVMesh *o,float x,float y,float z)
{
    unsigned int i;
    PVVertex *ov;

    for(i=0,ov=o->Vertex;i<o->NbrVertices;i++,ov++)
    {

        ov->xf+=x;
        ov->yf+=y;
        ov->zf+=z;
    }

    RecurseBoxTranslate(o->Box,x,y,z);
	PV_MeshKillCollisionTree(o);
}

void PVAPI PV_MeshCopyPosition(PVMesh *dest,PVMesh *origin)
{
	if(dest==NULL) return;
	if(origin==NULL) return;

	dest->Position=origin->Position;
	dest->Pivot=origin->Pivot;
	memcpy(&dest->Matrix,&origin->Matrix,sizeof(PVMat3x3));		
}

int PVAPI PV_MeshNormCalc(PVMesh *o)
{
	unsigned int j;
    int *t;
    float nx,ny,nz,n;
    unsigned int i;
    PVVertex *p0,*p1;
	PVFace *f;

    if ((t=(int*)calloc(o->NbrVertices,sizeof(int)))==NULL) return NO_MEMORY;

    /*  Normales aux faces */
    for(i=0,f=o->Face;i<o->NbrFaces;i++,f++)
    {
       if(f->NbrVertices<3) continue;

	   // Methode de newell pour les normales
	   nx=ny=nz=0;
	   for (j=0; j<f->NbrVertices; j++)
	   {
		  p0 = &o->Vertex[f->V[j]];
		  if (j == f->NbrVertices-1)
			p1 = &o->Vertex[f->V[0]];
		  else
			p1 = &o->Vertex[f->V[j+1]];
		  nx += (p1->yf - p0->yf) * (p1->zf + p0->zf);
		  ny += (p1->zf - p0->zf) * (p1->xf + p0->xf);
		  nz += (p1->xf - p0->xf) * (p1->yf + p0->yf);
	   }

        n=(nx*nx+ny*ny+nz*nz);
		if(n>0)
		{
			//n=1/fsqrt(n);
			n=InvSqrt(n);
			nx*=n;
			ny*=n;
			nz*=n;
		}

        // Sauvegarde normale � la face
        f->Normal.xf=nx;
        f->Normal.yf=ny;
        f->Normal.zf=nz;

        // Normales aux points
		for(j=0;j<f->NbrVertices;j++)
		{
	        o->Vertex[f->V[j]].Normal.xf+=(nx);
			o->Vertex[f->V[j]].Normal.yf+=(ny);
			o->Vertex[f->V[j]].Normal.zf+=(nz);
			t[f->V[j]]++;
		}
    }

    // Calcul effectif des normales aux points
    for(i=0;i<o->NbrVertices;i++)
    {
            if(t[i]!=0)
            {
				n=1.0/(float)t[i];
                o->Vertex[i].Normal.xf*=n;
                o->Vertex[i].Normal.yf*=n;
                o->Vertex[i].Normal.zf*=n;
            }
    }

    free(t);
    return COOL;
}

///////////////////////////////////////////////////////////////////

static unsigned VERTEX_PER_BOX,TotalFaces;

static char *FaceNonLitigieuses;
typedef struct _BB
{
    float x,y,z,tx,ty,tz;
} BBVol;

static BBVol *DoBoxRecurse(PVMesh *o,PVBox **box,float x,float y,float z,float lox,float loy,float loz)
{   unsigned int n=0,i,j,*fi,l;
    PVBox *b;
    char *f;
    unsigned *vi2,NbrPts;
    unsigned result;
    unsigned k;
    PVFace *fa;
    float XMax=MINFLOAT,XMin=MAXFLOAT,YMax=MINFLOAT,YMin=MAXFLOAT,ZMax=MINFLOAT,ZMin=MAXFLOAT;
    BBVol *BB,*BB2;
	PVVertex *ov;
	unsigned *VertexIndex=NULL;

	if(TotalFaces==o->NbrFaces) return NULL;

    // Comptage du nbr de pts dans la boite
	if(o->Flags&MESH_DYNAMIC)
	{
		n=o->NbrVertices;
	}
	else
	{
		for(i=0,ov=o->Vertex;i<o->NbrVertices;i++,ov++)
		{
			if (!((ov->xf>=x) && (ov->xf<(x+lox)))) continue;
			if (!((ov->yf>=y) && (ov->yf<(y+loy)))) continue;
			if (!((ov->zf>=z) && (ov->zf<(z+loz)))) continue;
			
			// Lazzy alloc
			if(VertexIndex==NULL)
			{
				debug(printf("Creating temporary index for vertex ...\n"););		
				if ((VertexIndex=(unsigned int*)malloc(sizeof(unsigned int)*o->NbrVertices))==NULL ) PV_Fatal("DoBoxRecurse()::CreateVertexIndex no memory",NO_MEMORY);
			}
			
			VertexIndex[n++]=i;
		}
	}

    if (n==0) 
	{
		debug(printf("  Box p0: %f %f %f, t0 %f %f %f\n",x,y,z,lox,loy,loz););
		debug(printf("Empty box, quitting ...\n"););		
		free(VertexIndex);
		return NULL;
	}

    if ((b=(PVBox*)malloc(sizeof(PVBox)))==NULL) PV_Fatal("DoBoxRecurse::CreateBox no memory",NO_MEMORY);
    for(i=0;i<8;i++) b->Child[i]=NULL;

    b->Flags=0;
    b->p0.xf=x;
    b->p0.yf=y;
    b->p0.zf=z;
    b->t0.xf=x+lox;
    b->t0.yf=y+loy;
    b->t0.zf=z+loz;
    *box=b;

    if((BB=(BBVol*)malloc(sizeof(BBVol)))==NULL) PV_Fatal("DoBoxRecurse::CreateBBVol no memory",NO_MEMORY);
    BB->x=MAXFLOAT;
    BB->y=MAXFLOAT;
    BB->z=MAXFLOAT;
    BB->tx=MINFLOAT;
    BB->ty=MINFLOAT;
    BB->tz=MINFLOAT;

	if((n>VERTEX_PER_BOX)&&(lox/2>100)&&(loy/2>100)&&(loz/2>100)) // on evite les longueurs nulles
    {
        debug(printf("Too many vertices, Splitting ...\n"););		
		// On split en 8 zones
        BB2=DoBoxRecurse(o,&b->Child[0],x,y,z,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }

        BB2=DoBoxRecurse(o,&b->Child[1],x+lox/2,y,z,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }

        BB2=DoBoxRecurse(o,&b->Child[2],x,y+loy/2,z,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }
        BB2=DoBoxRecurse(o,&b->Child[3],x,y,z+loz/2,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }

        BB2=DoBoxRecurse(o,&b->Child[4],x+lox/2,y+loy/2,z,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }

        BB2=DoBoxRecurse(o,&b->Child[5],x+lox/2,y,z+loz/2,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }

        BB2=DoBoxRecurse(o,&b->Child[6],x,y+loy/2,z+loz/2,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }

        BB2=DoBoxRecurse(o,&b->Child[7],x+lox/2,y+loy/2,z+loz/2,lox/2,loy/2,loz/2);
        if(BB2!=NULL)
        {
            BB->x=min(BB->x,BB2->x);
            BB->y=min(BB->y,BB2->y);
            BB->z=min(BB->z,BB2->z);
            BB->tx=max(BB->tx,BB2->tx);
            BB->ty=max(BB->ty,BB2->ty);
            BB->tz=max(BB->tz,BB2->tz);
            free(BB2);
        }

        for(i=0;i<8;i++)
        {
            if(b->Child[i]!=NULL) break;
        }
        if(i==8)
        {
            // Tous les fils sont nuls
            free(b);
            *box=NULL;
            free(VertexIndex);
			free(BB);
			return NULL;
        }

        b->p0.xf=BB->x;
        b->p0.yf=BB->y;
        b->p0.zf=BB->z;
        b->t0.xf=BB->tx;
        b->t0.yf=BB->ty;
        b->t0.zf=BB->tz;
		b->Volume=fabs(BB->tx-BB->x)*fabs(BB->ty-BB->y)*fabs(BB->tz-BB->z);

        debug(printf("  Intermediate Box (%s) p0: %f %f %f, t0 %f %f %f\n",o->Name,b->p0.xf,b->p0.yf,b->p0.zf,b->t0.xf,b->t0.yf,b->p0.zf););

        free(VertexIndex);
		return BB;
    }
    else
    {
        // Cr�e une feuille
        o->NodeInfos.NbrBoxes++;
        
		b->Flags=1;
		b->NbrFaces=0;

        // Calcul du contenu de la boite
        debug(printf("  Box p0: %f %f %f, t0 %f %f %f\n",x,y,z,lox,loy,loz););

        NbrPts=n;
		
		// Comptage du nombre de faces dans la boite
        debug(printf("Searching inbox faces ...\n"););
       
        if((b->FaceIndex=(unsigned*)malloc(sizeof(unsigned)*o->NbrFaces))==NULL) PV_Fatal("DoBoxRecurse()::CreateFaceIndex no memory",NO_MEMORY);		
        fi=&b->FaceIndex[0];

		if(o->Flags&MESH_DYNAMIC)
		{			
	        // Init BBOx 
			XMin=x;
			YMin=y;
			ZMin=z;
			XMax=x+lox;
			YMax=y+loy;
			ZMax=z+loz;

			b->NbrFaces=o->NbrFaces;
			for(j=0;(j<o->NbrFaces);j++,fi++) *fi=j;
		}
		else
		{
			// Init BBOx 
			XMin=MAXFLOAT;
			YMin=MAXFLOAT;
			ZMin=MAXFLOAT;
			XMax=MINFLOAT;
			YMax=MINFLOAT;
			ZMax=MINFLOAT;

			for(j=0,fa=&o->Face[0],f=&FaceNonLitigieuses[0];(j<o->NbrFaces);j++,fa++,f++)
			{
				if (*f==1) continue;

        		result=0;
				for(k=0,vi2=&VertexIndex[0];(k<NbrPts)&&(result==0);k++,vi2++) 
				{
					for(l=0;(l<fa->NbrVertices)&&(result==0);l++) 
						if(*vi2==fa->V[l]) result=1;
				}		

				if (result!=0) 
				{
					b->NbrFaces++;
					TotalFaces++;

					*fi=j;
					fi++;

					*f=1;

					// Recalc la BB au mieux					
					for(l=0;l<fa->NbrVertices;l++)
					{
						if(o->Vertex[fa->V[l]].xf<XMin) XMin=o->Vertex[fa->V[l]].xf;
						//else 
						if(o->Vertex[fa->V[l]].xf>XMax) XMax=o->Vertex[fa->V[l]].xf;

						if(o->Vertex[fa->V[l]].yf<YMin) YMin=o->Vertex[fa->V[l]].yf;
						//else
						if(o->Vertex[fa->V[l]].yf>YMax) YMax=o->Vertex[fa->V[l]].yf;

						if(o->Vertex[fa->V[l]].zf<ZMin) ZMin=o->Vertex[fa->V[l]].zf;
						//else
						if(o->Vertex[fa->V[l]].zf>ZMax) ZMax=o->Vertex[fa->V[l]].zf;
					}
				}
			}
		}

        // Boite sans face
        if(b->NbrFaces==0)
        {
            free(b->FaceIndex);
            b->FaceIndex=NULL;
            free(b);
            *box=NULL;
            o->NodeInfos.NbrBoxes--;
            debug(printf("  Box without faces\n"););
            free(VertexIndex);
			free(BB);
			return NULL;
        }

        if((b->FaceIndex=(unsigned*)realloc(b->FaceIndex,sizeof(unsigned)*b->NbrFaces))==NULL)  PV_Fatal("DoBoxRecurse()::Realloc no memory",NO_MEMORY);
        debug(printf("  Box: %ld pts %ld faces\n",NbrPts,b->NbrFaces););

        debug(printf("    BB MiniMax: Xmin:%f Xmax:%f Ymin:%f Ymax:%f Zmin:%f Zmax:%f\n",XMin,XMax,YMin,YMax,ZMin,ZMax););

		BB->x=b->p0.xf=XMin;
        BB->y=b->p0.yf=YMin;
        BB->z=b->p0.zf=ZMin;
        BB->tx=XMax;
        BB->ty=YMax;
        BB->tz=ZMax;
        b->t0.xf=XMax;
        b->t0.yf=YMax;
        b->t0.zf=ZMax;

		b->Volume=fabs(BB->tx-BB->x)*fabs(BB->ty-BB->y)*fabs(BB->tz-BB->z);

        debug(printf("  New Box (%s) p0: %f %f %f, t0 %f %f %f\n",o->Name,b->p0.xf,b->p0.yf,b->p0.zf,b->t0.xf,b->t0.yf,b->t0.zf););

        free(VertexIndex);

		return BB;
    }
}

#include <time.h>
void PVAPI PV_MeshBuildBoxes(PVMesh *o,unsigned nbrptsperbox)
{
    unsigned int i;
    float XMax=MINFLOAT,XMin=MAXFLOAT,YMax=MINFLOAT,YMin=MAXFLOAT,ZMax=MINFLOAT,ZMin=MAXFLOAT;
    clock_t start,stop;
	PVVertex *ov;    
	
	if(o==NULL) return;
	if(nbrptsperbox==0) return;

	PV_KillBoxes(o->Box);
	o->Box=NULL;

	if(o->Flags&MESH_DYNAMIC) 
		VERTEX_PER_BOX=o->NbrVertices;
	else
		VERTEX_PER_BOX=nbrptsperbox;

    o->NodeInfos.NbrBoxes=0;

    debug(printf("� Computing boxes...\n"););

    // recherche des coordonn�es mini max
    for(i=0,ov=o->Vertex;i<o->NbrVertices;i++,ov++)
    {
        if (ov->xf<XMin) XMin=ov->xf;
		//else
        if (ov->xf>XMax) XMax=ov->xf;

        if (ov->yf<YMin) YMin=ov->yf;
		//else
        if (ov->yf>YMax) YMax=ov->yf;

        if (ov->zf<ZMin) ZMin=ov->zf;
		//else
        if (ov->zf>ZMax) ZMax=ov->zf;
    }
//    XMin-=0.1; ZMin-=0.1; YMin-=0.1;
    XMax+=0.1; ZMax+=0.1; YMax+=0.1;
    debug(printf("    Object pivot %f %f %f\n",o->Pivot.xf,o->Pivot.yf,o->Pivot.zf););
    debug(printf("    Object MiniMax: Xmin:%f Xmax:%f Ymin:%f Ymax:%f Zmin:%f Zmax:%f\n",XMin,XMax,YMin,YMax,ZMin,ZMax););

    debug(start=clock(););

	// Allocation des buffers
    if((FaceNonLitigieuses=(char*)calloc(sizeof(char),o->NbrFaces))==NULL) PV_Fatal("BuildBoxes()::FaceLitige no memory",NO_MEMORY);
	TotalFaces=0;        
    free(DoBoxRecurse(o,&o->Box,XMin,YMin,ZMin,XMax-XMin,YMax-YMin,ZMax-ZMin));

    free(FaceNonLitigieuses);
    debug(stop=clock(););
    debug(printf("Elapsed time %u seconds\n",(stop-start)/CLOCKS_PER_SEC););

	o->SwitchInfos.NbrVertexBox=VERTEX_PER_BOX;
}

int PVAPI PV_GetMeshAAExtent(PVMesh *m,PVPoint *org,PVPoint *extent)
{
	if(m==NULL) return ARG_INVALID;
	if(org==NULL) return ARG_INVALID;
	if(extent==NULL) return ARG_INVALID;

	if(m->Box==NULL) return NOT_AVAILABLE;

	*org=m->Box->p0;
	*extent=m->Box->t0;

	return COOL;
}

void PVAPI PV_ComputeMeshToWorldMatrix(PVMesh *o)
{
    PVPoint A,fatp2,fatpiv,B,hp,C,WorldT;
    PVMat3x3 fat,sfat;
	static PVMat3x3 MatID={1,0,0,0,1,0,0,0,1};

	if(o->Owner->LastFrame==o->LastFrame) return;
	o->LastFrame=o->Owner->LastFrame;

    if((o->Flags&MESH_INHERIT)&&(o->Father!=NULL))
	{
		PV_ComputeMeshToWorldMatrix(o->Father);
		memcpy(fat,o->Father->WorldMatrix,sizeof(PVMat3x3));
		memcpy(sfat,o->Father->Matrix,sizeof(PVMat3x3));
		memcpy(&fatp2,&o->Father->WorldHierPos,sizeof(PVPoint));
		memcpy(&fatpiv,&o->Father->Pivot,sizeof(PVPoint));
		memcpy(&hp,&o->Father->HierPivot,sizeof(PVPoint));
	}
	else
	{
		memcpy(fat,MatID,sizeof(PVMat3x3));
		memcpy(sfat,MatID,sizeof(PVMat3x3));
		memset(&fatp2,0,sizeof(PVPoint));
		memset(&fatpiv,0,sizeof(PVPoint));
		memset(&hp,0,sizeof(PVPoint));
	}

	// Allons y avec la matrice de la camera
	MatrixMul(fat,o->Matrix,o->WorldMatrix);

	A.xf=o->Pivot.xf-fatpiv.xf;
	A.yf=o->Pivot.yf-fatpiv.yf;
	A.zf=o->Pivot.zf-fatpiv.zf;
	RotatePoint3x3(&A,fat,&B);
	B.xf+=fatpiv.xf;
	B.yf+=fatpiv.yf;
	B.zf+=fatpiv.zf;

	B.xf-=o->Pivot.xf;
	B.yf-=o->Pivot.yf;
	B.zf-=o->Pivot.zf;

	o->HierPivot.xf=hp.xf+B.xf;
	o->HierPivot.yf=hp.yf+B.yf;
	o->HierPivot.zf=hp.zf+B.zf;

	RotatePoint3x3(&o->Position,fat,&B);

	WorldT.xf=B.xf+fatp2.xf;
	WorldT.yf=B.yf+fatp2.yf;
	WorldT.zf=B.zf+fatp2.zf;
	o->WorldHierPos=WorldT;

	C.xf=WorldT.xf+o->HierPivot.xf;
	C.yf=WorldT.yf+o->HierPivot.yf;
	C.zf=WorldT.zf+o->HierPivot.zf;

	o->WorldPos=C;	
	
}

void PVAPI PV_MeshSetupMatrixDirect(PVMesh *o,PVMat3x3 mat)		   
{	
	if(o==NULL) return;

	memcpy(o->Matrix,mat,sizeof(PVMat3x3));

	o->LastFrame=0;
}

void PVAPI PV_MeshSetupInvertMatrixDirect(PVMesh *no,PVMat3x3 t2)		   
{
    no->Matrix[0][0]=t2[0][0];
    no->Matrix[0][1]=t2[1][0];
    no->Matrix[0][2]=t2[2][0];

    no->Matrix[1][0]=t2[0][1];
    no->Matrix[1][1]=t2[1][1];
    no->Matrix[1][2]=t2[2][1];

    no->Matrix[2][0]=t2[0][2];
    no->Matrix[2][1]=t2[1][2];
    no->Matrix[2][2]=t2[2][2];

	no->LastFrame=0;
}

void PVAPI PV_MeshSetupMatrix(PVMesh *o,float AngleX,float AngleY,float AngleZ)
{
	if(o==NULL) return;

	SetupMatrix3x3(o->Matrix,AngleX,AngleY,AngleZ);

	o->LastFrame=0;
}

void PVAPI PV_MeshSetupMatrixYPR(PVMesh *o,float yaw,float pitch,float roll)
{
	if(o==NULL) return;

	SetupMatrix3x3YPR(o->Matrix,yaw,pitch,roll);

	o->LastFrame=0;
}

void PVAPI PV_MeshSetupPos(PVMesh *o,float X,float Y,float Z)
{
	if(o==NULL) return;

	o->Position.xf=X;
	o->Position.yf=Y;
	o->Position.zf=Z;

    o->LastFrame=0;
}

///////////////////////////////////////////////// Shade

int PVAPI PV_MeshRAZShade(PVMesh *o)
{
    if(o->Shading==NULL) if ( (o->Shading=(PVShadeInfo *)malloc(sizeof(PVShadeInfo)*(o->NbrVertices+o->MaxNbrClippedVertices)))==NULL ) return NO_MEMORY;
    memset(o->Shading,0,sizeof(PVShadeInfo)*(o->NbrVertices));
    return COOL;
}

void PVAPI PV_MeshLight(PVMesh *o,PVLight *l2)
{
    PVPoint p,dir,p2,p3,k;
    float g,h,d,d2,A;
    unsigned int i;
    PVD8 *vv;
    PVVertex *ov;
    PVShadeInfo *os;
	double oorange;

    switch ( l2->Type )
    {
    case PVL_DIRECTIONAL:
                    RotateInvertPoint(&l2->Direction,o->LastWorldMatrix,&p);

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;

						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));

                            g*=l2->Power.Intensity*127;
                            os->Shade=max(os->Shade,g+128);
                        }
                    }
                    break;
    case PVL_PARALLEL:
                    RotateInvertPoint(&l2->Direction,o->LastWorldMatrix,&dir);
                    
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;

                    d=dir.xf*p2.xf+dir.yf*p2.yf+dir.zf*p2.zf;

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;
                        
						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
	                        if((dir.xf*ov->xf+dir.yf*ov->yf+dir.zf*ov->zf-d)>0)
							{
								p.xf=dir.xf;
								p.yf=dir.yf;
								p.zf=dir.zf;
							}
							else
							{
								p.xf=-dir.xf;
								p.yf=-dir.yf;
								p.zf=-dir.zf;
							}

                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));

                            g*=l2->Power.Intensity*127;
                            os->Shade=max(os->Shade,g+128);
                        }
                    }
                    break;
    case PVL_INFINITEPOINT:
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;
        
                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;
                        
						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            p.xf=ov->xf-p2.xf;
                            p.yf=ov->yf-p2.yf;
                            p.zf=ov->zf-p2.zf;
                            d=(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
							//d=1/fsqrt(d);
							d=InvSqrt(d);
							p.xf*=d;
							p.yf*=d;
							p.zf*=d;

                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));

                            g*=l2->Power.Intensity*127;
                            os->Shade=max(os->Shade,g+128);
                        }
                    }
                    break;
    case PVL_POINT:
                    oorange=1/l2->Range;
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;
       
                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;
                        
						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            p.xf=ov->xf-p2.xf;
                            p.yf=ov->yf-p2.yf;
                            p.zf=ov->zf-p2.zf;
                            d=fsqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
							d2=1/d;
							p.xf*=d2;
							p.yf*=d2;
							p.zf*=d2;
                            
                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));
                            if (g<0) continue;

                            if(d>l2->Range) continue;
                            if(d<1) d=0;

                            A=1/(l2->Attenuation0+l2->Attenuation1*d+l2->Attenuation2*d*d);
							h=g*A;
                            if(h<=0) continue;
                            g*=l2->Power.Intensity*127;
                            os->Shade=max(os->Shade,g+128);
	                      }
                    }
                    break;
    case PVL_SPOT:
                    oorange=1/l2->Range;
					RotateInvertPoint(&l2->Direction,o->LastWorldMatrix,&p3);
                    
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;
                            
                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;
                        
						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            // Vecteur PVPoint->Light
                            p.xf=ov->xf-p2.xf;
                            p.yf=ov->yf-p2.yf;
                            p.zf=ov->zf-p2.zf;
                            d=fsqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
							d2=1/d;
                            p.xf*=d2;
                            p.yf*=d2;
                            p.zf*=d2;

                            // Angle
                            h=(((p.xf*p3.xf))+((p.yf*p3.yf))+((p.zf*p3.zf)));
                            if (h<l2->cosPh) continue;

                            // Distance PVPoint lumiere
                            if(d>l2->Range) continue;
                            if(d<1) d=0;

                            g=-(((p3.xf*ov->Normal.xf))+((p3.yf*ov->Normal.yf))+((p3.zf*ov->Normal.zf)));
                            if(h<l2->cosTh){
                                g-=l2->FallOff;
                            }
                            
							A=1/(l2->Attenuation0+l2->Attenuation1*d+l2->Attenuation2*d*d);
							g*=A;
                            g*=l2->Power.Intensity*127;
                            os->Shade=max(os->Shade,g+128);
                        }
                    }
                    break;
	case PVL_POINT_FOG:break;
    case PVL_USER_LIGHT:
                    l2->UserLightFunc(o,l2);
                    break;
    default :
            PV_Fatal("ShadeMesh() : Unknown light type",l2->Type);
    }
}

void PVAPI PV_MeshLightRGB(PVMesh *o,PVLight *l2)
{
    PVPoint p,dir,p2,p3,p4,pn,k;
    float g,h,d,d2,A;
    unsigned int i;
    PVD8 *vv;
    PVVertex *ov;
    PVShadeInfo *os;
	double oorange;

    switch ( l2->Type )
    {
    case PVL_DIRECTIONAL:
                    RotateInvertPoint(&l2->Direction,o->LastWorldMatrix,&p);

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;

                        if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));
                            if(g>0) {
                                g*=l2->Power.Intensity;
                                os->Color.r=min(1,os->Color.r+l2->Color.r*g);
                                os->Color.g=min(1,os->Color.g+l2->Color.g*g);
                                os->Color.b=min(1,os->Color.b+l2->Color.b*g);
                                os->Color.a=1;
                            }

                        }
                    }
                    break;
    case PVL_PARALLEL:
                    RotateInvertPoint(&l2->Direction,o->LastWorldMatrix,&dir);
        
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;

                    d=dir.xf*p2.xf+dir.yf*p2.yf+dir.zf*p2.zf;

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;

						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
							if((dir.xf*ov->xf+dir.yf*ov->yf+dir.zf*ov->zf-d)>0)
							{
								p.xf=dir.xf;
								p.yf=dir.yf;
								p.zf=dir.zf;
							}
							else
							{
								p.xf=-dir.xf;
								p.yf=-dir.yf;
								p.zf=-dir.zf;
							}

                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));
                            if(g>0) {
                                g*=l2->Power.Intensity;
                                os->Color.r=min(1,os->Color.r+l2->Color.r*g);
                                os->Color.g=min(1,os->Color.g+l2->Color.g*g);
                                os->Color.b=min(1,os->Color.b+l2->Color.b*g);
                                os->Color.a=1;
                            }
                        }
                    }
                    break;
    case PVL_INFINITEPOINT:
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;

						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            p.xf=ov->xf-p2.xf;
                            p.yf=ov->yf-p2.yf;
                            p.zf=ov->zf-p2.zf;
                            //d=1/fsqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
							d=InvSqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
                            p.xf*=d;
                            p.yf*=d;
                            p.zf*=d;

                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));
                            if(g>0) {
                                g*=l2->Power.Intensity;
                                os->Color.r=min(1,os->Color.r+l2->Color.r*g);
                                os->Color.g=min(1,os->Color.g+l2->Color.g*g);
                                os->Color.b=min(1,os->Color.b+l2->Color.b*g);
                                os->Color.a=1;
                            }
                        }
                    }
                    break;
    case PVL_POINT:
                    oorange=1/l2->Range;
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if(*vv==0) continue;

                        if(ov->Flags==0) continue;
                        
						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            os->Color.a=1;

                            p.xf=ov->xf-p2.xf;
                            p.yf=ov->yf-p2.yf;
                            p.zf=ov->zf-p2.zf;
                            d=fsqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
							d2=1/d;
                            p.xf*=d2;
                            p.yf*=d2;
                            p.zf*=d2;

                            g=-(((p.xf*ov->Normal.xf))+((p.yf*ov->Normal.yf))+((p.zf*ov->Normal.zf)));
                            if (g<0) continue;

                            if(d>l2->Range) continue;
                            if(d<1) d=0;

                            A=1/(l2->Attenuation0+l2->Attenuation1*d+l2->Attenuation2*d*d);
							h=g*A;
                            if(h<=0) continue;
                            
                            g*=l2->Power.Intensity;
                            os->Color.r=min(1,os->Color.r+l2->Color.r*g);
                            os->Color.g=min(1,os->Color.g+l2->Color.g*g);
                            os->Color.b=min(1,os->Color.b+l2->Color.b*g);
                        }
                    }
                    break;
    case PVL_SPOT:
					oorange=1/l2->Range;
                    RotateInvertPoint(&l2->Direction,o->LastWorldMatrix,&p3);
                    
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.xf;
                    k.zf-=o->Pivot.zf+o->WorldPos.xf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        if (*vv==0) continue;

                        if(ov->Flags==0) continue;

						if(((ov->Flags&(GOURAUD|FLAT))!=0))
                        {
                            os->Color.a=1;

                            // Vecteur PVPoint->Light
                            p.xf=ov->xf-p2.xf;
                            p.yf=ov->yf-p2.yf;
                            p.zf=ov->zf-p2.zf;
                            d=fsqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
							d2=1/d;
                            p.xf*=d2;
                            p.yf*=d2;
                            p.zf*=d2;

                            // Angle
                            h=(((p.xf*p3.xf))+((p.yf*p3.yf))+((p.zf*p3.zf)));
                            if (h<l2->cosPh) continue;

                            // Distance PVPoint lumiere
                            if(d>l2->Range) continue;
                            if(d<1) d=0;

                            g=-(((p3.xf*ov->Normal.xf))+((p3.yf*ov->Normal.yf))+((p3.zf*ov->Normal.zf)));
                            if(h<l2->cosTh){
                                g-=l2->FallOff;
                            }
							A=1/(l2->Attenuation0+l2->Attenuation1*d+l2->Attenuation2*d*d);
							g*=A;
                            if(g>0) {
                                g*=l2->Power.Intensity;
                                os->Color.r=min(1,os->Color.r+l2->Color.r*g);
                                os->Color.g=min(1,os->Color.g+l2->Color.g*g);
                                os->Color.b=min(1,os->Color.b+l2->Color.b*g);
                            }
                        }
                    }
                    break;
	case PVL_POINT_FOG:
					{
					char inside=1;
					float range2,d2,D,oorange2;

                    // V�rifie que la camera est dans la source ou pas
					/// Coordon�es objet � partir d'ici					
                    k=l2->Position;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p2);
                    p2.xf+=o->Pivot.xf;
                    p2.yf+=o->Pivot.yf;
                    p2.zf+=o->Pivot.zf;

                    k=o->Owner->Camera->pos;
                    k.xf-=o->Pivot.xf+o->WorldPos.xf;
                    k.yf-=o->Pivot.yf+o->WorldPos.yf;
                    k.zf-=o->Pivot.zf+o->WorldPos.zf;
                    RotateInvertPoint(&k,o->LastWorldMatrix,&p3);
                    p3.xf+=o->Pivot.xf;
                    p3.yf+=o->Pivot.yf;
                    p3.zf+=o->Pivot.zf;

					p.xf=p2.xf-p3.xf;
					p.yf=p2.yf-p3.yf;
					p.zf=p2.zf-p3.zf;
					// C'est exactement la mem chose ke le calcul pour savoir si on est 
					// dans la fog ou pas. voir si on peut pas virer le premier

					d=fsqrt(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
					if(d>l2->Range) inside=0;

					d=1/d;
					pn.xf=p.xf*d;
					pn.yf=p.yf*d;
					pn.zf=p.zf*d;

					oorange=1/l2->Range;
					oorange2=oorange; //2/(2*l2->Range);
					range2=l2->Range*l2->Range;

					// Le d pour le test de vue
					D=pn.xf*p2.xf+pn.yf*p2.yf+pn.zf*p2.zf;

                    for(i=0,
                    vv=o->VertexVisible,
                    ov=o->Vertex,
                    os=o->Shading;
                    i<o->NbrVertices;
                    i++,ov++,vv++,os++)
                    {
                        PVPoint v;
						float nv,nd;
						if (*vv==0) continue;

                        if(!(ov->Flags&FOGABLE)) continue;
						
						// Test si le point en cours est devant la source de fog
						if(!inside)
						{							
							if((pn.xf*ov->xf+pn.yf*ov->yf+pn.zf*ov->zf-D)<0)
							{
								// point devant, ragrde s'il n'est pas hors de port�e
								d=fsqrt((ov->xf-p2.xf)*(ov->xf-p2.xf)+(ov->yf-p2.yf)*(ov->yf-p2.yf)*(ov->zf-p2.zf)*(ov->zf-p2.zf));
								if(d>l2->Range) continue;
							}
						}

						// Calcul pseudo distance ligne-point
						// Calcul vecteur directeur droite camera-point
						v.xf=ov->xf-p3.xf;
						v.yf=ov->yf-p3.yf;
						v.zf=ov->zf-p3.zf;
						
						nv=fsqrt(v.xf*v.xf+v.yf*v.yf+v.zf*v.zf);
						
						p4.xf=(p.yf*v.zf)-(p.zf*v.yf);
						p4.yf=(p.zf*v.xf)-(p.xf*v.zf);
						p4.zf=(p.xf*v.yf)-(p.yf*v.xf);

						nd=fsqrt(p4.xf*p4.xf+p4.yf*p4.yf+p4.zf*p4.zf);

						d=nd/nv;
						
						if(d>l2->Range) continue;
						
						d2=d*d;
						d=l2->Power.Density*log(1+fsqrt(range2-d2)*oorange2);

						if(d>1) d=1;
						if(d<0) d=0;
			
						os->Specular.a=d;
                    }
					}
					break;

    case PVL_USER_LIGHT:
                    l2->UserLightFunc(o,l2);
                    break;
    default :
            PV_Fatal("ShadeMeshRGB() : Unknown light type",l2->Type);
    }
}


/////////////////////////////////////////////////////////////////////////
/// Gestion des collisions

PVMesh *PVAPI PV_CreateDummyMesh(float radiusx,float radiusy,float radiusz)
{
    PVMesh *m;
    unsigned V[3];
    
    
    m=PV_CreateMesh(0,0);
    if(m==NULL) return NULL;

    if ((m->Vertex=(PVVertex *)calloc(sizeof(PVVertex),6))==NULL ) return NULL;
    if ((m->Face=(PVFace *)calloc(sizeof(PVFace),8))==NULL ) return NULL;

    // Et hop un joli losange
    m->NbrFaces=8;
    m->NbrVertices=6;

    m->Vertex[0].xf=0;
    m->Vertex[0].yf=-radiusy;
    m->Vertex[0].zf=0;
    m->Vertex[0].Flags=0;
    m->Vertex[1].xf=0;
    m->Vertex[1].yf=radiusy;
    m->Vertex[1].zf=0;
    m->Vertex[1].Flags=0;
    m->Vertex[2].xf=-radiusx;
    m->Vertex[2].yf=0;
    m->Vertex[2].zf=0;
    m->Vertex[2].Flags=0;
    m->Vertex[3].xf=radiusx;
    m->Vertex[3].yf=0;
    m->Vertex[3].zf=0;
    m->Vertex[3].Flags=0;
    m->Vertex[4].xf=0;
    m->Vertex[4].yf=0;
    m->Vertex[4].zf=radiusz;
    m->Vertex[4].Flags=0;
    m->Vertex[5].xf=0;
    m->Vertex[5].yf=0;
    m->Vertex[5].zf=-radiusz;
    m->Vertex[5].Flags=0;

    V[0]=0;
    V[1]=3;
    V[2]=4;
    m->Face[0].Flags=0;
    m->Face[0].Material=NULL;
    m->Face[0].MaterialInfo=NULL;
    m->Face[0].Father=m;
    m->Face[0].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[0],V,3);

    V[0]=0;
    V[1]=3;
    V[2]=5;
    m->Face[1].Flags=0;
    m->Face[1].Material=NULL;
    m->Face[1].MaterialInfo=NULL;
    m->Face[1].Father=m;
    m->Face[1].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[1],V,3);
    
    V[0]=0;
    V[1]=5;
    V[2]=2;
    m->Face[2].Flags=0;
    m->Face[2].Material=NULL;
    m->Face[2].MaterialInfo=NULL;
    m->Face[2].Father=m;
    m->Face[2].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[2],V,3);

    V[0]=0;
    V[1]=2;
    V[2]=4;
    m->Face[3].Flags=0;
    m->Face[3].Material=NULL;
    m->Face[3].MaterialInfo=NULL;
    m->Face[3].Father=m;
    m->Face[3].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[3],V,3);

    V[0]=4;
    V[1]=1;
    V[2]=3;
    m->Face[4].Flags=0;
    m->Face[4].Material=NULL;
    m->Face[4].MaterialInfo=NULL;
    m->Face[4].Father=m;
    m->Face[4].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[4],V,3);

    V[0]=3;
    V[1]=1;
    V[2]=5;
    m->Face[5].Flags=0;
    m->Face[5].Material=NULL;
    m->Face[5].MaterialInfo=NULL;
    m->Face[5].Father=m;
    m->Face[5].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[5],V,3);

    V[0]=5;
    V[1]=1;
    V[2]=2;
    m->Face[6].Flags=0;
    m->Face[6].Material=NULL;
    m->Face[6].MaterialInfo=NULL;
    m->Face[6].Father=m;
    m->Face[6].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[6],V,3);

    V[0]=4;
    V[1]=2;
    V[2]=1;
    m->Face[7].Flags=0;
    m->Face[7].Material=NULL;
    m->Face[7].MaterialInfo=NULL;
    m->Face[7].Father=m;
    m->Face[7].NbrVertices=3;
    PV_SetVerticesToFace(&m->Face[7],V,3);

    m->Name=strdup("$$ DUMMY COLLIDE");
    m->Flags|=MESH_FORGET;

    if(PV_MeshComputeCollisionTree(m)!=COOL) return NULL;

    return m;
}

////////////////////////////////////////////////////////////////// Switchable nodes

PVMesh *PVAPI PV_CreateSwitchNode(PVMesh * (PVAPI *callback)(PVMesh*))
{
	PVMesh *sw;
	
	if(callback==NULL) return NULL;
	
	sw=PV_SimpleCreateMesh(1,1,0,0);
	if(sw==NULL) return NULL;

	sw->Flags|=MESH_SWITCHNODE|MESH_FORGET;
	sw->SwitchInfos.SwitchCallBack=callback;
	sw->NodeInfos.NbrSwitchItems=0;
	
	sw->NbrVertices=0;		// pour ke ca roule dans les autres routines PV
	sw->NbrFaces=0;			// pour ke ca roule dans les autres routines PV
	sw->SwitchVal.LastSwitchPath=NULL;

	sw->Name=strdup("$$ DUMMY SWITCH");

	return sw;
}

PVMesh *PVAPI PV_GetSwitchItem(PVMesh *switchnode,int itemnbr)
{
	PVMesh *o;
	int i;

	if(switchnode==NULL) return NULL;
	if(!(switchnode->Flags&MESH_SWITCHNODE)) return NULL;
	if(itemnbr>=switchnode->NodeInfos.NbrSwitchItems) return NULL;

	o=switchnode->Child;
	i=itemnbr;
	while((o!=NULL)&&(i>0))
	{
		o=o->Next;
		i--;
	}

	if(i==0) return o; else return NULL;
}

int PVAPI PV_AddSwitch(PVMesh *switchnode,PVMesh *switchitem)
{
	PVMesh *tmp;
	if(switchnode==NULL) return -ARG_INVALID;
	if(!(switchnode->Flags&MESH_SWITCHNODE)) return -ARG_INVALID;
	if(switchitem==NULL) return -ARG_INVALID;
	if(switchitem->Next!=NULL) return -ARG_INVALID;

	switchnode->Owner->NbrObjs++;
	switchnode->Owner->NbrFaces+=switchitem->NbrFaces;
	switchnode->Owner->NbrVertices+=switchitem->NbrVertices;

	switchitem->Flags|=MESH_FORGET_ALL;
	
	if(switchnode->NodeInfos.NbrSwitchItems==0)
	{
		switchnode->Child=switchitem;		
		switchnode->NodeInfos.NbrSwitchItems++;

		switchitem->Father=switchnode;		
		switchitem->Owner=switchnode->Owner;
		return 0;
	}
	
	tmp=PV_GetSwitchItem(switchnode,switchnode->NodeInfos.NbrSwitchItems-1);
	if(tmp!=NULL)
	{
		tmp->Next=switchitem;
		switchnode->NodeInfos.NbrSwitchItems++;

		switchitem->Father=switchnode;		
		switchitem->Owner=switchnode->Owner;
		return switchnode->NodeInfos.NbrSwitchItems-1;
	}
	return -BIZAR_ERROR;
}

PVMesh *PVAPI PV_RemoveSwitch(PVMesh *switchnode,int itemnbr)
{
	PVMesh *tmp,*o;

	if(switchnode==NULL) return NULL;
	if(!(switchnode->Flags&MESH_SWITCHNODE)) return NULL;
	if(itemnbr>=switchnode->NodeInfos.NbrSwitchItems) return NULL;
	
	tmp=PV_GetSwitchItem(switchnode,itemnbr);
	if(tmp==NULL) return NULL;

	tmp->Owner->NbrObjs--;
	tmp->Owner->NbrFaces-=tmp->NbrFaces;
	tmp->Owner->NbrVertices-=tmp->NbrVertices;
	tmp->Owner=NULL;
	tmp->Father=NULL;

	o=switchnode->Child;
	
	if(o==tmp)
	{
		switchnode->Child=tmp->Next;
	}
	else
	{
		while(o->Next!=tmp)	o=o->Next;
		o->Next=o->Next->Next;
	}

	switchnode->NodeInfos.NbrSwitchItems--;

	return tmp;
}

///////////////////////////////////////////////////////////////////////////// Face Index Mgmt

void PVAPI PV_SetMaterialNameToFace(PVFace *f,char *name)
{
	if(f->Material!=NULL) free(f->Material);
	f->Material=strdup(name);
}

int PVAPI PV_SetVerticesToFace(PVFace *f,unsigned *v,unsigned nbr)
{
	PVMesh *m;
	unsigned *t,i;
	
	if(f==NULL) return ARG_INVALID;
	if(v==NULL) return ARG_INVALID;
	if(nbr==0) return COOL;

	m=f->Father;
	if(m==NULL) return ARG_INVALID;
	if(f->V!=NULL) return ALREADY_ASSIGNED;
	if(nbr>MAX_VERTICES_PER_POLY) return ARG_INVALID;

	t=(unsigned*)realloc(m->VerticesIndex,(m->NbrIndex+nbr)*sizeof(unsigned));
	if(t==NULL) return NO_MEMORY;

	if(t!=m->VerticesIndex)
	{
		// Remappage des autres faces de l'objet
		int stride=t-m->VerticesIndex;

		if(m->VerticesIndex==NULL) stride=0;

		for(i=0;i<m->NbrFaces;i++) 
		{
			if(m->Face[i].V!=NULL) m->Face[i].V+=stride;
		}
		m->VerticesIndex=t;	
	}
		
	memcpy(&m->VerticesIndex[m->NbrIndex],v,sizeof(unsigned)*nbr);	

	f->V=&m->VerticesIndex[m->NbrIndex];
	m->NbrIndex+=nbr;
	f->NbrVertices=nbr;

	if(m->NbrVertices<m->NbrMapIndex)
	{
		f->MapInfos.MapIndex=m->LastMapIndex;
		m->LastMapIndex+=nbr;
	}
	
	return COOL;
}

void PVAPI PV_SetPerFaceUV(PVFace *f,unsigned nbrv,float u,float v)
{
	PVMesh *o;

	if(f==NULL) return;
	if(nbrv>=f->NbrVertices) return;

	o=f->Father;

	o->Mapping[o->NbrVertices+o->MaxNbrClippedVertices+f->MapInfos.MapIndex+nbrv].u=u;
	o->Mapping[o->NbrVertices+o->MaxNbrClippedVertices+f->MapInfos.MapIndex+nbrv].v=v;
}

/////////////////////////////////////////////////////////////////// Dirty API

void PVAPI PV_SetMeshDirty(PVMesh *m,PVFLAGS flags,unsigned firstindex,unsigned nbrindex)
{
	if(!(PV_Mode&PVM_USEHARDWARE)) return;
	if(!(PV_GetPipelineControl()&PVP_HARDWARETL)) return;
	if(m==NULL) return;
	if(PV_GetHardwareDriver()==NULL) return;

	m->Dirty.Flags=flags;
	m->Dirty.FirstIndex=firstindex;
	m->Dirty.NbrIndex=nbrindex;

	PV_GetHardwareDriver()->ModifyMesh(m);
}

////////////////////////////////////////////////////////////////////////////////////

/*static unsigned n=0,nv=0;
static float SufLimit;

static void GetNbrTriFor(PVFace *f)
{
	PVPoint v01,v02,n;
	PVMesh *o=f->Father;
	float d;

	// Calcul surface
	v01.xf=o->Vertex[f->V[1]].xf-o->Vertex[f->V[0]].xf;
	v01.yf=o->Vertex[f->V[1]].yf-o->Vertex[f->V[0]].yf;
	v01.zf=o->Vertex[f->V[1]].zf-o->Vertex[f->V[0]].zf;

	v02.xf=o->Vertex[f->V[2]].xf-o->Vertex[f->V[0]].xf;
	v02.yf=o->Vertex[f->V[2]].yf-o->Vertex[f->V[0]].yf;
	v02.zf=o->Vertex[f->V[2]].zf-o->Vertex[f->V[0]].zf;

	n.xf=v01.yf*v02.zf-v01.zf*v02.yf;
	n.yf=v01.zf*v02.xf-v01.xf*v02.zf;
	n.zf=v01.xf*v02.yf-v01.yf*v02.xf;

	d=n.xf*n.xf+n.yf*n.yf+n.zf*n.zf;
	d=fsqrt(d);

	if(d>SurfLimit)
	{
		unsigned i=0;

		while(d>SurfLimit)
		{
			d/=4;
			i++;
			n+=pow(4,i);
			nv+=pow(4,i-1)*3;
		}
	}
	else n++;
}

PVMesh *PVAPI PV_MakeOversampledMesh(PVMesh *src,PVFLAGS fl,float surface)
{
	PVMesh *m;
	
	if(src==NULL) return NULL;

	// On va cherches les faces ki nescessite un split
	SurfLimit=surface;
	for(i=0;i<src->NbrFaces;i++)
	{
		if(f->MaterialInfo!=NULL)
		{
			if((f->MaterialInfo->Type&fl)==fl)
				PV_TriangulateFace(&src->Face[i],GetNbrTriFor);
			else
				n++;
		}
		else n++;
	}

	PV_Log("mesh.log","Ne mesh will resuire %u faces, %u more vertices\n",n,nv);

	m=PV_SimpleCreateMesh(n,src->NbrVertices+nv,src->MaxNbrClippedFaces,src->MaxNbrClippedVertices);
	if(m==NULL) return NULL;

	// c parti
	for(i=0;i<src->NbrFaces;i++)
	{
	}
}*/

//----------------------------------------------------------------------------------------


/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "pvision.h"
#include "cache.h"

#define debug(x)        //x

typedef struct _PVCacheEntry
{
    unsigned ID;
    unsigned Size;
    unsigned User;
    unsigned ExtentU,ExtentV;
    struct _PVCacheEntry *Next;
} PVCacheEntry;

#define MAX_FRAGMENT                        4096

static UPVD8 *Heap=NULL;
static unsigned SizeOfHeap=0;
static PVCacheEntry *Rover;

///////////////////////////////////////////////////////////////////////////

void PVAPI PV_ResetTextureCache(void)
{
    debug(printf("� Resetting texture cache\n"););
    ((PVCacheEntry*)Heap)->ID=0;
    ((PVCacheEntry*)Heap)->Size=SizeOfHeap-sizeof(PVCacheEntry);
    ((PVCacheEntry*)Heap)->Next=NULL;
    Rover=(PVCacheEntry*)Heap;
}

int PVAPI PV_InitTextureCache(unsigned size)
{
    debug(printf("� Allocating %uMb of texture cache\n",size/(1024*1024)););
    PV_ReleaseTextureCache();

    if(size!=0)
	{
		Heap=(UPVD8*)malloc(size);
		if(Heap==NULL) return NO_MEMORY;

		SizeOfHeap=size;

		PV_ResetTextureCache();
	}

    return COOL;
}

void PVAPI PV_ReleaseTextureCache(void)
{
    debug(printf("� freeing texture cache\n"););
    if(Heap!=NULL) free(Heap);
    SizeOfHeap=0;
}

PVCacheHandle PVAPI PV_AllocCachedMem(unsigned size,unsigned id)
{
    PVCacheEntry *cur,*cur2;

    if(size==0) return 0;
    if(SizeOfHeap==0) PV_Fatal("PV_AllocCachedMem() :: No heap, use PV_InitTextureCache()",size);
    if(size>(SizeOfHeap-sizeof(PVCacheEntry))) PV_Fatal("PV_AllocCachedMem() :: Heap to small",size);

    // normalize la taille
    size=(size+7)&(~7);

    Rover=Rover->Next;
    if(Rover==NULL) Rover=(PVCacheEntry*)Heap;

    // Test pour le wrap
    if(((int)Rover+size+sizeof(PVCacheEntry))>((int)Heap+SizeOfHeap))
    {
        // wrap
        Rover=(PVCacheEntry*)Heap;
    }

    // Collecte des blocs
    cur=Rover;
    while(Rover->Size<size)
    {
        cur=cur->Next;
        cur->ID=0;
        Rover->Size+=cur->Size+sizeof(PVCacheEntry);
    }
    Rover->Next=cur->Next;
    Rover->ID=id;
    // si on a la taille exacte
    if(Rover->Size==size) return (PVCacheHandle)Rover;
    else
    {
        // on a du rab, cr�e un nouvo poste si il y a la place
        if((Rover->Size-size)>MAX_FRAGMENT)
        {
            cur2=(PVCacheEntry*)((int)(Rover)+sizeof(PVCacheEntry)+size);
            cur2->Next=cur->Next;
            cur2->Size=Rover->Size-size-sizeof(PVCacheEntry);

            Rover->Size=size;
            Rover->Next=cur2;
        }
        return (PVCacheHandle)Rover;
    }
 
	// Unreachable
    return 0;
}

UPVD8 *PVAPI PV_GetPointerFromHandle(PVCacheHandle mem)
{
    if(mem==0) return NULL;

    return (UPVD8*)((int)mem+sizeof(PVCacheEntry));
}

unsigned PVAPI PV_GetIdFromHandle(PVCacheHandle mem)
{
    if(mem==0) return 0;

    return ((PVCacheEntry*)mem)->ID;
}

void PVAPI PV_SetCacheUserData(PVCacheHandle mem,unsigned data)
{
    if(mem==0) return;

    ((PVCacheEntry*)mem)->User=data;
}

unsigned PVAPI PV_GetCacheUserData(PVCacheHandle mem)
{
    if(mem==0) return 0;

    return ((PVCacheEntry*)mem)->User;
}

void PVAPI PV_SetCacheTextureInfo(PVCacheHandle mem,unsigned Width,unsigned Height)
{
    if(mem==0) return;

    ((PVCacheEntry*)mem)->ExtentU=Width;
    ((PVCacheEntry*)mem)->ExtentV=Height;
}

void PVAPI PV_GetCacheTextureInfo(PVCacheHandle mem,unsigned *Width,unsigned *Height)
{
    if(mem==0) return;

    *Width=((PVCacheEntry*)mem)->ExtentU;
    *Height=((PVCacheEntry*)mem)->ExtentV;
}

//////////////////////////////////////////////////////////
void PVAPI PV_DumpCache(void)
{
    PVCacheEntry *c=(PVCacheEntry *)Heap;
    unsigned total=0,totfrag=0;

    if(Heap==NULL) return;
    printf("\nCacheDump()\n----\n");
    do
    {
        printf("Cache block : %u (%ux%u)bytes\n",c->Size,c->ExtentU,c->ExtentV);
        total+=c->Size+sizeof(PVCacheEntry);
        totfrag++;
        c=c->Next;
    }
    while(c!=NULL);

    printf("Total Memory %u/%u\nTotal blocks %u\n",total,SizeOfHeap,totfrag);
}

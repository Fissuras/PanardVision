/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "pvision.h"
#include "cache.h"

static int MinU,MinV,MaxU,MaxV;
static unsigned ExtentU,ExtentV,LWidth;
static int minu2,minv2;

static double mn=6755399441055744.0;
static double f1,f2,f3;
static unsigned *i1=(unsigned*)&f1,*i2=(unsigned*)&f2,*i3=(unsigned*)&f3;

static unsigned PS;


static void PV_ComputeFaceExtent(PVFace *f,unsigned MipMapNum)
{
    unsigned w0=f->MaterialInfo->Tex[0].Width;
    unsigned h0=f->MaterialInfo->Tex[0].Height;
    PVFace *f2;
    unsigned si;
    float s;

    float minu=9999999.0,minv=9999999999.0,maxu=-9999999.0,maxv=-99999999.0;
    float z;
    unsigned i;
    PVMesh *o=f->Father;

	if(f->Flags&POLYGON_PLANAR)
		f2=f;
	else
		f2=(PVFace*)f->Poly;

    maxu=minu=o->Mapping[f2->V[0]].u;
    maxv=minv=o->Mapping[f2->V[0]].v;
    for(i=1;i<f2->NbrVertices;i++)
    {
        z=o->Mapping[f2->V[i]].u;

        if(z>maxu) maxu=z;
        else if(z<minu) minu=z;

        z=o->Mapping[f2->V[i]].v;

        if(z>maxv) maxv=z;
        else if(z<minv) minv=z;
    }
    si=(1<<f->LightMap->Sampling);
    s=1.0/(float)si;

    MinU=floor(minu*w0*s)*si;
    MinV=floor(minv*h0*s)*si;
    MaxU=ceil(maxu*w0*s)*si;
    MaxV=ceil(maxv*h0*s)*si;
    minu2=minu*(float)w0;
    minv2=minv*(float)h0;

    ExtentU=MaxU-MinU;
    ExtentV=MaxV-MinV;
    LWidth=((ExtentU>>f->LightMap->Sampling)+1);

    ExtentU>>=MipMapNum;
    ExtentV>>=MipMapNum;
    MinU>>=MipMapNum;
    MinV>>=MipMapNum;
    minu2>>=MipMapNum;
    minv2>>=MipMapNum;
}

void PVAPI PV_SetLightMapExtent(PVFace *f,unsigned MipMapNum,PVLightMap *l)
{
    unsigned w0=f->MaterialInfo->Tex[0].Width;
    unsigned h0=f->MaterialInfo->Tex[0].Height;
    PVFace *f2=(PVFace*)f;
    unsigned si;
    float s,a,b,tu,tv;

    float minu=9999999.0,minv=9999999999.0,maxu=-9999999.0,maxv=-99999999.0;
    float z;
    unsigned i;
    PVMesh *o=f->Father;

	int MinU,MinV,MaxU,MaxV;
	unsigned ExtentU,ExtentV;

	PV_PrepareFace(f);

    maxu=minu=o->Mapping[f2->V[0]].u;
    maxv=minv=o->Mapping[f2->V[0]].v;
    for(i=1;i<f2->NbrVertices;i++)
    {
        z=o->Mapping[f2->V[i]].u;

        if(z>maxu) maxu=z;
        else if(z<minu) minu=z;

        z=o->Mapping[f2->V[i]].v;

        if(z>maxv) maxv=z;
        else if(z<minv) minv=z;
    }
    si=(1<<f->LightMap->Sampling);
    s=1.0/(float)si;
	
	MinU=floor(minu*w0*s)*si;
    MinV=floor(minv*h0*s)*si;
    MaxU=ceil(maxu*w0*s)*si;
    MaxV=ceil(maxv*h0*s)*si;

    ExtentU=MaxU-MinU;
    ExtentV=MaxV-MinV;
    
	l->Width=((ExtentU>>f->LightMap->Sampling)+1);
    l->Height=((ExtentV>>f->LightMap->Sampling)+1);

	l->MinU=minu;
	l->MinV=minv;
	l->MaxU=maxu;
	l->MaxV=maxv;
	
	a=l->su[0]=fabs(floor(minu*(float)w0)-(float)MinU);
	b=l->sv[0]=fabs(floor(minv*(float)h0)-(float)MinV);
	l->su[0]/=(float)ExtentU;
	l->sv[0]/=(float)ExtentV;
	if(l->su[0]<(0.5/(float)l->Width)) l->su[0]+=0.5/(float)l->Width;
	if(l->sv[0]<(0.5/(float)l->Height)) l->sv[0]+=0.5/(float)l->Height;

	for(i=1;i<MAX_LIGHTMAPS;i++)
	{
		l->su[i]=l->su[0];
		l->sv[i]=l->sv[0];
	}
	
	tu=fabs(floor((maxu-minu)*(float)w0));
	tv=fabs(floor((maxv-minv)*(float)h0));
	l->ScaleU=tu;
	l->ScaleV=tv;
	l->ScaleU/=(float)ExtentU;
	l->ScaleV/=(float)ExtentV;
	if(l->ScaleU>=((float)l->Width-1.0)/(float)l->Width) l->ScaleU-=1.0/(float)l->Width;
	if(l->ScaleV>=((float)l->Height-1.0)/(float)l->Height) l->ScaleV-=1.0/(float)l->Height;

	PV_PrepareFace(f);
}

//////////////////////////////////////////////////////////////////////////
static void PV_LightBlockRGB8(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0,c1,c,u2,v2;
    unsigned adrv,TWidth;
    int dc,c2,c3;
    UPVD8 *texo;
    unsigned lw;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    Out+=((v<<sample2)*ExtentU+(u<<sample2));
    end=1<<sample2;

    lw=LWidth*3;

    c0=(((*Light)+(*(Light+1))+(*(Light+2)))/3)<<16;    
    c1=(((*(Light+3))+(*(Light+4))+(*(Light+5)))/3)<<16;    
    Light+=lw;
    c2=(((*Light)+(*(Light+1))+(*(Light+2)))/3)<<16;    
    c3=(((*(Light+3))+(*(Light+4))+(*(Light+5)))/3)<<16;    

    c2 = ((int)c2 - (int)c0)>>sample2;
    c3 = ((int)c3 - (int)c1)>>sample2;

    TWidth=(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dc=((int)c1-(int)c0)>>sample2;
      c=c0;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        texo=&Tex[(adrv+u2)];

        *Out=f->MaterialInfo->PaletteTranscodeTable[((*texo)<<8)+(c>>16)];
        Out++;

        c+=dc;
      }
      Out+=TWidth;

      c0+=c2;
      c1+=c3;
    }
}

static void PV_LightBlockRGB16(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0r,c1r,cr,u2,v2;
    unsigned c0g,c1g,cg;
    unsigned c0b,c1b,cb;
    unsigned adrv,TWidth;
    int dcr,c2r,c3r;
    int dcg,c2g,c3g;
    int dcb,c2b,c3b;
    float flr,flg,flb;
    UPVD8 *texo;
    UPVD16 tot;
    unsigned a1,a2,a3,lw;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    lw=LWidth*3;

    Out+=((v<<sample2)*ExtentU+(u<<sample2))*PS;
    end=1<<sample2;

    c0r=(*Light)<<16;
    c0g=((*(Light+1)))<<16;
    c0b=((*(Light+2)))<<16;
    c1r=((*(Light+3)))<<16;
    c1g=((*(Light+4)))<<16;
    c1b=((*(Light+5)))<<16;
    Light+=lw;
    c2r=(*Light)<<16;
    c2g=((*(Light+1)))<<16;
    c2b=((*(Light+2)))<<16;
    c3r=((*(Light+3)))<<16;
    c3g=((*(Light+4)))<<16;
    c3b=((*(Light+5)))<<16;

    c2r = ((int)c2r - (int)c0r)>>sample2;
    c2g = ((int)c2g - (int)c0g)>>sample2;
    c2b = ((int)c2b - (int)c0b)>>sample2;
    c3r = ((int)c3r - (int)c1r)>>sample2;
    c3g = ((int)c3g - (int)c1g)>>sample2;
    c3b = ((int)c3b - (int)c1b)>>sample2;

    TWidth=PS*(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dcr=((int)c1r-(int)c0r)>>sample2;
      dcg=((int)c1g-(int)c0g)>>sample2;
      dcb=((int)c1b-(int)c0b)>>sample2;
      cr=c0r;
      cg=c0g;
      cb=c0b;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        flr=((float)(cr>>16))*(1.0/(255.0));
        flg=((float)(cg>>16))*(1.0/(255.0));
        flb=((float)(cb>>16))*(1.0/(255.0));

        texo=&Tex[(adrv+u2)*3];

        f1=((*(texo+0))<<(8-RMaskSize))*flr+mn;
        f2=((*(texo+1))<<(8-GMaskSize))*flg+mn;
        f3=((*(texo+2))<<(8-BMaskSize))*flb+mn;

        a1=(*i1)>>(8-RMaskSize);
        a2=(*i2)>>(8-GMaskSize);
        a3=(*i3)>>(8-BMaskSize);				

        tot=(a1<<RFieldPos)|(a2<<GFieldPos)|(a3<<BFieldPos);

        *((UPVD16*)Out)=tot;
        Out+=2;

        cr+=dcr;
        cg+=dcg;
        cb+=dcb;
      }
      Out+=TWidth;

      c0r+=c2r;
      c0g+=c2g;
      c0b+=c2b;
      c1r+=c3r;
      c1g+=c3g;
      c1b+=c3b;
    }
}

static void PV_LightBlockRGB24(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0r,c1r,cr,u2,v2;
    unsigned c0g,c1g,cg;
    unsigned c0b,c1b,cb;
    unsigned adrv,TWidth;
    int dcr,c2r,c3r;
    int dcg,c2g,c3g;
    int dcb,c2b,c3b;
    float flr,flg,flb;
    UPVD8 *texo;
    unsigned lw;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    lw=LWidth*3;

    Out+=((v<<sample2)*ExtentU+(u<<sample2))*PS;
    end=1<<sample2;

    c0r=(*Light)<<16;
    c0g=((*(Light+1)))<<16;
    c0b=((*(Light+2)))<<16;
    c1r=((*(Light+3)))<<16;
    c1g=((*(Light+4)))<<16;
    c1b=((*(Light+5)))<<16;
    Light+=lw;
    c2r=(*Light)<<16;
    c2g=((*(Light+1)))<<16;
    c2b=((*(Light+2)))<<16;
    c3r=((*(Light+3)))<<16;
    c3g=((*(Light+4)))<<16;
    c3b=((*(Light+5)))<<16;

    c2r = ((int)c2r - (int)c0r)>>sample2;
    c2g = ((int)c2g - (int)c0g)>>sample2;
    c2b = ((int)c2b - (int)c0b)>>sample2;
    c3r = ((int)c3r - (int)c1r)>>sample2;
    c3g = ((int)c3g - (int)c1g)>>sample2;
    c3b = ((int)c3b - (int)c1b)>>sample2;

    TWidth=PS*(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dcr=((int)c1r-(int)c0r)>>sample2;
      dcg=((int)c1g-(int)c0g)>>sample2;
      dcb=((int)c1b-(int)c0b)>>sample2;
      cr=c0r;
      cg=c0g;
      cb=c0b;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        flr=(float)((cr>>16))*(1/255.0);
        flg=(float)((cg>>16))*(1/255.0);
        flb=(float)((cb>>16))*(1/255.0);

        texo=&Tex[(adrv+u2)*3];

        f1=(float)(*(texo))*flb+mn;
        *Out=*i1;
        Out++;
        f1=(float)(*(texo+1))*flg+mn;
        *Out=*i1;
        Out++;
        f1=(float)(*texo+2)*flr+mn;
        *Out=*i1;
        Out++;

        cr+=dcr;
        cg+=dcg;
        cb+=dcb;
      }
      Out+=TWidth;

      c0r+=c2r;
      c0g+=c2g;
      c0b+=c2b;
      c1r+=c3r;
      c1g+=c3g;
      c1b+=c3b;
    }
}

static void PV_LightBlockRGB32(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0r,c1r,cr,u2,v2;
    unsigned c0g,c1g,cg;
    unsigned c0b,c1b,cb;
    unsigned adrv,TWidth;
    int dcr,c2r,c3r;
    int dcg,c2g,c3g;
    int dcb,c2b,c3b;
    float flr,flg,flb;
    UPVD8 *texo;
    unsigned lw;
    UPVD32 tot;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    lw=LWidth*3;

    Out+=((v<<sample2)*ExtentU+(u<<sample2))*PS;
    end=1<<sample2;

    c0r=(*Light)<<16;
    c0g=((*(Light+1)))<<16;
    c0b=((*(Light+2)))<<16;
    c1r=((*(Light+3)))<<16;
    c1g=((*(Light+4)))<<16;
    c1b=((*(Light+5)))<<16;
    Light+=lw;
    c2r=(*Light)<<16;
    c2g=((*(Light+1)))<<16;
    c2b=((*(Light+2)))<<16;
    c3r=((*(Light+3)))<<16;
    c3g=((*(Light+4)))<<16;
    c3b=((*(Light+5)))<<16;

    c2r = ((int)c2r - (int)c0r)>>sample2;
    c2g = ((int)c2g - (int)c0g)>>sample2;
    c2b = ((int)c2b - (int)c0b)>>sample2;
    c3r = ((int)c3r - (int)c1r)>>sample2;
    c3g = ((int)c3g - (int)c1g)>>sample2;
    c3b = ((int)c3b - (int)c1b)>>sample2;

    TWidth=PS*(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dcr=((int)c1r-(int)c0r)>>sample2;
      dcg=((int)c1g-(int)c0g)>>sample2;
      dcb=((int)c1b-(int)c0b)>>sample2;
      cr=c0r;
      cg=c0g;
      cb=c0b;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        flr=(float)((cr>>16))*(1/255.0);
        flg=(float)((cg>>16))*(1/255.0);
        flb=(float)((cb>>16))*(1/255.0);

        texo=&Tex[(adrv+u2)*3];

        f1=(float)(*(texo+0))*flb+mn;
        f2=(float)(*(texo+1))*flg+mn;
        f3=(float)(*(texo+2))*flr+mn;

        tot=(*i1)|((*i2)<<8)|((*i2)<<16);

        *((UPVD32*)Out)=tot;
        Out+=4;

        cr+=dcr;
        cg+=dcg;
        cb+=dcb;
      }
      Out+=TWidth;

      c0r+=c2r;
      c0g+=c2g;
      c0b+=c2b;
      c1r+=c3r;
      c1g+=c3g;
      c1b+=c3b;
    }
}

//////////////////////////////////////////////////////////////////////////

static void PV_LightBlock32(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0,c1,c,u2,v2;
    unsigned adrv,TWidth;
    int dc,c2,c3;
    float fl;
    UPVD8 *texo;
    UPVD32 tot;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    Out+=((v<<sample2)*ExtentU+(u<<sample2))*PS;
    end=1<<sample2;

    c0=(*Light)<<16;
    c1=(*(Light+1))<<16;
    Light+=LWidth;
    c2=(*Light)<<16;
    c3=(*(Light+1))<<16;

    c2 = ((int)c2 - (int)c0)>>sample2;
    c3 = ((int)c3 - (int)c1)>>sample2;

    TWidth=PS*(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dc=((int)c1-(int)c0)>>sample2;
      c=c0;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        fl=(float)((c>>16))*(1/255.0);

        texo=&Tex[(adrv+u2)*3];

        f1=(float)(*(texo+2))*fl+mn;
        f2=(float)(*(texo+1))*fl+mn;
        f3=(float)(*texo)*fl+mn;

        tot=(*i1)|((*i2)<<8)|((*i2)<<16);

        *((UPVD32*)Out)=tot;
        Out+=4;

        c+=dc;
      }
      Out+=TWidth;

      c0+=c2;
      c1+=c3;
    }
}

static void PV_LightBlock24(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0,c1,c,u2,v2;
    unsigned adrv,TWidth;
    int dc,c2,c3;
    float fl;
    UPVD8 *texo;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    Out+=((v<<sample2)*ExtentU+(u<<sample2))*PS;
    end=1<<sample2;

    c0=(*Light)<<16;
    c1=(*(Light+1))<<16;
    Light+=LWidth;
    c2=(*Light)<<16;
    c3=(*(Light+1))<<16;

    c2 = ((int)c2 - (int)c0)>>sample2;
    c3 = ((int)c3 - (int)c1)>>sample2;

    TWidth=PS*(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dc=((int)c1-(int)c0)>>sample2;
      c=c0;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        fl=(float)((c>>16))*(1/255.0);

        texo=&Tex[(adrv+u2)*3];

        f1=(float)(*(texo+2))*fl+mn;
        *Out=*i1;
        Out++;
        f1=(float)(*(texo+1))*fl+mn;
        *Out=*i1;
        Out++;
        f1=(float)(*texo)*fl+mn;
        *Out=*i1;
        Out++;

        c+=dc;
      }
      Out+=TWidth;

      c0+=c2;
      c1+=c3;
    }
}

static void PV_LightBlock16(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0,c1,c,u2,v2;
    unsigned adrv,TWidth;
    int dc,c2,c3;
    float fl;
    UPVD8 *texo;
    UPVD16 tot;
    unsigned a1,a2,a3;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    Out+=((v<<sample2)*ExtentU+(u<<sample2))*PS;
    end=1<<sample2;

    c0=(*Light)<<16;
    c1=(*(Light+1))<<16;
    Light+=LWidth;
    c2=(*Light)<<16;
    c3=(*(Light+1))<<16;

    c2 = ((int)c2 - (int)c0)>>sample2;
    c3 = ((int)c3 - (int)c1)>>sample2;

    TWidth=PS*(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dc=((int)c1-(int)c0)>>sample2;
      c=c0;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        fl=(float)((c>>16))*(1/255.0);

        texo=&Tex[(adrv+u2)*3];

        f1=((*(texo+2))<<(8-RMaskSize))*fl+mn;
        f2=((*(texo+1))<<(8-GMaskSize))*fl+mn;
        f3=((*(texo))<<(8-BMaskSize))*fl+mn;

        a3=(*i1)>>(8-RMaskSize);
        a2=(*i2)>>(8-GMaskSize);
        a1=(*i3)>>(8-BMaskSize);

        tot=(a1<<RFieldPos)|(a2<<GFieldPos)|(a3<<BFieldPos);

        *((UPVD16*)Out)=tot;
        Out+=2;

        c+=dc;
      }
      Out+=TWidth;

      c0+=c2;
      c1+=c3;
    }
}

static void PV_LightBlock8(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0,c1,c,u2,v2;
    unsigned adrv,TWidth;
    int dc,c2,c3;
    UPVD8 *texo;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    Out+=((v<<sample2)*ExtentU+(u<<sample2));
    end=1<<sample2;

    c0=(*Light)<<16;
    c1=(*(Light+1))<<16;
    Light+=LWidth;
    c2=(*Light)<<16;
    c3=(*(Light+1))<<16;

    c2 = ((int)c2 - (int)c0)>>sample2;
    c3 = ((int)c3 - (int)c1)>>sample2;

    TWidth=(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dc=((int)c1-(int)c0)>>sample2;
      c=c0;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        texo=&Tex[(adrv+u2)];

        *Out=f->MaterialInfo->PaletteTranscodeTable[((*texo)<<8)+(c>>16)];
        Out++;

        c+=dc;
      }
      Out+=TWidth;

      c0+=c2;
      c1+=c3;
    }
}

static void PV_LightBlock8_16(PVFace *f,unsigned MipMapNum,unsigned u,unsigned v,UPVD8* Light)
{
    unsigned i,j,end;
    unsigned c0,c1,c,u2,v2;
    unsigned adrv,TWidth;
    int dc,c2,c3;
    UPVD8 *texo;

    unsigned Andv=(f->MaterialInfo->Tex[MipMapNum].Height-1),Andu=(f->MaterialInfo->Tex[MipMapNum].Width-1);
    unsigned shift=f->MaterialInfo->Tex[MipMapNum].ShiftWidth;
    UPVD8 *Tex=f->MaterialInfo->Tex[MipMapNum].Texture;
    unsigned sample2=f->LightMap->Sampling-MipMapNum;
    UPVD8 *Out=PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum]);

    Out+=((v<<sample2)*ExtentU+(u<<sample2));
    end=1<<sample2;

    c0=(*Light)<<16;
    c1=(*(Light+1))<<16;
    Light+=LWidth;
    c2=(*Light)<<16;
    c3=(*(Light+1))<<16;

    c2 = ((int)c2 - (int)c0)>>sample2;
    c3 = ((int)c3 - (int)c1)>>sample2;

    TWidth=(ExtentU-end);

    for(i=0;i<end;i++)
    {
      dc=((int)c1-(int)c0)>>sample2;
      c=c0;

      v2=((v<<sample2)+i+MinV)&Andv;
      adrv=(v2<<shift);

      for(j=0;j<end;j++)
      {
        u2=((u<<sample2)+j+MinU)&Andu;

        texo=&Tex[(adrv+u2)];

        *((UPVD16*)Out)=f->MaterialInfo->RGB16TranscodeTable[((*texo)<<8)+(c>>16)];
        Out+=2;

        c+=dc;
      }
      Out+=TWidth;

      c0+=c2;
      c1+=c3;
    }
}

///////////////////////////////////////////////////////////////////////////

static void PV_ComputeMix(PVFace *f,unsigned MipMapNum)
{
    unsigned u,v,div,eu,ev;
    UPVD8 *Light;

    Light=f->LightMap->Maps[f->LightMap->CurrentLightMap];
    if(Light==NULL) PV_Fatal("ComputeLightMap :: null light map encountered\n",(unsigned)f);

    div=f->LightMap->Sampling-MipMapNum;
    eu=((ExtentU)>>div);
    ev=((ExtentV)>>div);
    for(v=0;v<ev;v++)
    {
        for(u=0;u<eu;u++)
        {
            switch(PS)
            {
            case 1:PV_LightBlock8(f,MipMapNum,u,v,Light);break;
            case 2:
                    if(PV_Mode&PVM_RGB)
                        PV_LightBlock16(f,MipMapNum,u,v,Light);
                    else
                        PV_LightBlock8_16(f,MipMapNum,u,v,Light);
                    break;
            case 3:PV_LightBlock24(f,MipMapNum,u,v,Light);break;
            case 4:PV_LightBlock32(f,MipMapNum,u,v,Light);break;
            default:
                PV_Fatal("LightBlock: Unsupported pixel size\n",PS);
            }
            Light++;
        }
        Light++;
    }
}

static void PV_ComputeMixRGB(PVFace *f,unsigned MipMapNum)
{
    unsigned u,v,div,eu,ev;
    UPVD8 *Light;

    Light=f->LightMap->Maps[f->LightMap->CurrentLightMap];
    if(Light==NULL) PV_Fatal("ComputeLightMapRGB :: null light map encountered\n",(unsigned)f);

    div=f->LightMap->Sampling-MipMapNum;
    eu=((ExtentU)>>div);
    ev=((ExtentV)>>div);
    for(v=0;v<ev;v++)
    {
        for(u=0;u<eu;u++)
        {
            switch(PS)
            {
            case 1:PV_LightBlockRGB8(f,MipMapNum,u,v,Light);break;
            case 2:PV_LightBlockRGB16(f,MipMapNum,u,v,Light);break;
            case 3:PV_LightBlockRGB24(f,MipMapNum,u,v,Light);break;
            case 4:PV_LightBlockRGB32(f,MipMapNum,u,v,Light);break;
            default:
                PV_Fatal("LightBlockRGB: Unsupported pixel size\n",PS);
            }
            Light+=3;
        }
        Light+=3;
    }
}

#define MKID (((unsigned)f->LightMap->Maps[f->LightMap->CurrentLightMap])&(~7)+MipMapNum)

static UPVD8 DefaultTexture[64*64];

UPVD8 *PVAPI PV_GetCachedTexture(PVFace *f,unsigned MipMapNum,unsigned *Width,unsigned *Height)
{
    unsigned id;

    if(f==NULL) return NULL;
    if(f->LightMap==NULL) PV_Fatal("GetCachedTexture() : Face withtou lightmap infos being rendered\n",(int)f);
    if(f->MaterialInfo==NULL) PV_Fatal("ComputeLightMap :: Tried to render a face wih no material\n",(unsigned)f);
    if(((int)f->LightMap->Sampling-(int)MipMapNum)<0) PV_Fatal("LightMap : Invalid ratio sampling/mipmap",MipMapNum);

    id=MKID;

    // Setup du type de surface
    if(PV_Mode&PVM_RGB) PS=PixelSize;
    else if(PV_Mode&PVM_RGB16) PS=2;
         if(PV_Mode&PVM_PALETIZED8) PS=1;

    // Is this face already cached ?
    if(PV_GetIdFromHandle(f->LightMap->SurfaceHandle[MipMapNum])!=id)
    {
        PV_ComputeFaceExtent(f,MipMapNum);

        // Compute the new texture with lightmap
        // Try to alloc a cache entry
        if((f->LightMap->SurfaceHandle[MipMapNum]=PV_AllocCachedMem(ExtentU*ExtentV*PS,id))!=0)
        {
            if(PV_Mode&PVM_RGB)
			{
				if(f->LightMap->Flags&LIGHTMAP_MONO) PV_ComputeMix(f,MipMapNum);
				if(f->LightMap->Flags&LIGHTMAP_RGB) PV_ComputeMixRGB(f,MipMapNum);
			}
			else 
            if(PV_Mode&PVM_PALETIZED8)
			{
   				if(f->LightMap->Flags&LIGHTMAP_MONO) PV_ComputeMix(f,MipMapNum);
				if(f->LightMap->Flags&LIGHTMAP_RGB) PV_ComputeMixRGB(f,MipMapNum);
			}
			else PV_Fatal("Lightmapping not supported in fake 16 bit modes",0);

            // Sets the new pointer (according to the new texture)
            PV_SetCacheUserData(f->LightMap->SurfaceHandle[MipMapNum],(int)PV_GetPointerFromHandle(f->LightMap->SurfaceHandle[MipMapNum])+PS*((minv2-MinV)*ExtentU+(minu2-MinU))-PS*(minv2*ExtentU+minu2));

            PV_SetCacheTextureInfo(f->LightMap->SurfaceHandle[MipMapNum],ExtentU,ExtentV);
            *Width=ExtentU;
            *Height=ExtentV;

            return (UPVD8*)PV_GetCacheUserData(f->LightMap->SurfaceHandle[MipMapNum]);
        }
        else
        {
            *Width=0;
            *Height=0;

            return DefaultTexture;
        }
    }
    else
    {
        PV_GetCacheTextureInfo(f->LightMap->SurfaceHandle[MipMapNum],Width,Height);
        return (UPVD8*)PV_GetCacheUserData(f->LightMap->SurfaceHandle[MipMapNum]);
    }
}

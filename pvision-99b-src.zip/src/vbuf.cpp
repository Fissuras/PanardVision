/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdlib.h>
#include "vbuf.h"

pvVertexBuffer::~pvVertexBuffer()
{
	Kill();
}

pvVertexBuffer::pvVertexBuffer()
{
	_Buffer=NULL;
	_LCount=0;
}

PVERR pvVertexBuffer::Create(PVFLAGS type, unsigned n)
{
	if(n==0) return PVERR_ARG_INVALID;
	if(type==0) return PVERR_ARG_INVALID;
	if(_LCount!=0) return PVERR_LOCKED;

	// Calcul taille d'un element du vb
	unsigned size=0;
	for(int i=0;i<32;i++)
	{
		if(type&(1<<i))
		{
			switch(1<<i)
			{
			case PVVBT_XY_OOZ:size+=sizeof(PVVBS_XY_OOZ);break;
			case PVVBT_XYZ_NORMAL:			
			case PVVBT_XYZ:size+=sizeof(PVVBS_XYZ);break;
			case PVVBT_RGBA_SPEC:
			case PVVBT_RGBA_DIFF:size+=4*sizeof(float);break;
			default: return PVERR_ARG_INVALID;
			}
		}
	}
	Kill();
	
	_Buffer=new UPVD8[size*n];	

	_N=n;
	_Size=size;
	_Type=type;

	_DoNotFree=false;

	return PVERR_COOL;
}

PVERR pvVertexBuffer::CreateFromMesh(PVMesh *m)
{
	if(_LCount!=0) return PVERR_LOCKED;
	if(m==NULL) return PVERR_ARG_INVALID;
	
	Kill();

	_N=m->NbrVertices;
	_Size=sizeof(PVVertex);
	_Type=PVVBT_XYZ;
	_Buffer=(UPVD8*)m->Vertex;
	_DoNotFree=true;

	return PVERR_COOL;
}

void *pvVertexBuffer::Lock()
{
	if(_LCount!=0) return NULL;
	_LCount++;

	return _Buffer;
}

void pvVertexBuffer::UnLock()
{
	if(_LCount==0) return;
	_LCount--;
}

PVERR pvVertexBuffer::Kill()
{
	if(_LCount!=0) return PVERR_LOCKED;
	
	if(!_DoNotFree) delete[] _Buffer;
	_Buffer=NULL;

	_Type=0;
	_N=0;
	_Size=0;

	return PVERR_COOL;
}

PVERR pvVertexBuffer::TransformTo(const pvBase3 &mat,const pvVector3D &p,pvVertexBuffer &vb) const
{
	// Transform XYZ from the source vb by mat and p, and store results in dest vb 
	// in place of dest's XYZ
	// Other members are copied as is

	// Both VB should be same type, and dest vb should be at least the same size than source

	if(_LCount!=0) return PVERR_LOCKED;
	if(vb.GetType()!=_Type) return PVERR_SRC_AND_TARGET_DOES_NOT_MATCH;
	if(vb.GetNbrItems()<_N) return PVERR_SRC_AND_TARGET_DOES_NOT_MATCH;

	pvVector3D t;
	UPVD8 *s;
	unsigned i,z=vb.GetSize();
	UPVD8 *dst;

	dst=(UPVD8*)vb.Lock();
	if(dst==NULL) return PVERR_TARGET_NOT_READY;

	for(i=0,s=_Buffer;i<_N;i++,s+=_Size)
	{
		t=mat.RotateVector(*(pvVector3D*)(s));
		t+=p;
		
		*((pvVector3D*)dst)=t;
		
		dst+=z;
	}
	vb.UnLock();
	
	return PVERR_COOL;
}

/*PVERR pvVertexBuffer::ProjectTo(const double k,const double ofx,const double ofy,pvVertexBuffer &vb) const
{
	// Project point (src vb should be at least PVVBT_XYZ to a dst vb
	// which should be PVVBT_XY_OOZ. Same size;
	
	if(_LCount!=0) return PVERR_LOCKED;
	if(!(GetType()&PVVBT_XYZ)) return PVERR_SRC_AND_TARGET_DOES_NOT_MATCH;
	if(vb.GetType()!=PVVBT_XY_OOZ) return PVERR_SRC_AND_TARGET_DOES_NOT_MATCH;
	if(vb.GetNbrItems()<_N) return PVERR_SRC_AND_TARGET_DOES_NOT_MATCH;

	pvVector3D t;
	unsigned i,si=vb.GetSize();
	UPVD8 *dst,*s;
	double K,K2;

	dst=(UPVD8*)vb.Lock();
	if(dst==NULL) return PVERR_TARGET_NOT_READY;

	for(i=0,s=_Buffer;i<_N;i++,s+=_Size)
	{		
		K2=-1/((pvVector3D*)s)->z;
		K=K2*k;

		((pvVector3D*)dst)->x=((pvVector3D*)s)->x*k+ofx;
		((pvVector3D*)dst)->y=((pvVector3D*)s)->y*k+ofy;
		*(double*)(&((pvVector3D*)dst)->z)=K2;
		
		dst+=si;
	}
	vb.UnLock();
	
	return PVERR_COOL;
}*/

////////////////////////////////////////////////////////////////////////////////////////// ConvexHull

static int ccw(PVVBS_XYZ *P[], int i, int j, int k) {
	double	a = P[i]->x - P[j]->x,
		b = P[i]->y - P[j]->y,
		c = P[k]->x - P[j]->x,
		d = P[k]->y - P[j]->y;
	return (a*d - b*c <= 0);	   /* true if points i, j, k counterclockwise */
}

static int __cdecl cmpl(const void *a, const void *b) {
	float v;
        PVVBS_XYZ **av,**bv;

        av=(PVVBS_XYZ **)a;
        bv=(PVVBS_XYZ **)b;

	v = (*av)->x - (*bv)->x;

	if( v>0 ) return 1;
	if( v<0 ) return -1;

	v = (*bv)->y - (*av)->y;

	if( v>0 ) return 1;
	if( v<0 ) return -1;

	return 0;
}

static int __cdecl cmph(const void *a, const void *b) {return cmpl(b,a);}

static int make_chain(PVVBS_XYZ *V[], int n, int (__cdecl * cmp)(const void*, const void*)) 
{
	int i, j, s = 1;
	PVVBS_XYZ *t;

	qsort(V, n, sizeof(PVVBS_XYZ*), cmp);

	for( i=2; i<n; i++ ) 
	{
		for( j=s; j>=1 && ccw(V, i, j, j-1); j-- )
		{}
		s = j+1;
		t = V[s]; V[s] = V[i]; V[i] = t;
	}
	return s;
}

static int ch2d(PVVBS_XYZ *P[], int n)  
{
	int u = make_chain(P, n, cmpl);		/* make lower hull */
	if( !n ) return 0;
	P[n] = P[0];
	return u+make_chain(P+u, n-u+1, cmph);	/* make upper hull */
}

PVERR pvVertexBuffer::Find2DConvexHull(unsigned *cNumOutIdxs,unsigned **OutHullIdxs) const
{
   PVVBS_XYZ **PntPtrs;
   unsigned i;

   if(GetType()!=PVVBT_XYZ) return PVERR_TARGET_INVALID;
   if(cNumOutIdxs==NULL) return PVERR_ARG_INVALID;
   if(OutHullIdxs==NULL) return PVERR_ARG_INVALID;

   *cNumOutIdxs=0;               //max space needed is n+1 indices
   *OutHullIdxs = new unsigned[(_N+1)];   

   PntPtrs = new (PVVBS_XYZ*[_N+1]);

   // alg requires array of ptrs to verts (for qsort) instead of array of verts, so do the conversion
   unsigned step=GetSize();
   PVVBS_XYZ *st;
   for(i=0,st=(PVVBS_XYZ*)_Buffer;i<_N;i++,*((unsigned*)(&st))+=step) {
      PntPtrs[i] = st;
   }

   *cNumOutIdxs=ch2d(PntPtrs,_N);

   // convert back to array of idxs
   for(i=0;i<*cNumOutIdxs;i++) {
      (*OutHullIdxs)[i]= (unsigned) ((((UPVD8*)PntPtrs[i])-_Buffer)/_Size);
   }

   // caller will free returned array
   delete[] PntPtrs;

   return PVERR_COOL;
}

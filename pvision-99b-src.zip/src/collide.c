/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "pvision.h"
#include "pvmac.h"
#include "sqrt.h"

#define debug(x)		//x

// Une boite orient�e
typedef struct _PVOBBT
{
	PVMat3x3 pR;				// Positionnement par rapport au parent
	PVPoint pT;

	float d[3];				// Demi Dimension suivant les axes

	struct _PVOBBT *P,*N;   // Les fils

	unsigned *Tri;          // Pointeur vers la face pour une feuille
} PVObbt;

typedef struct _PVMoment
{
	float A;				// Aire du triangle
	PVPoint m;				// Centre du triangle
	PVMat3x3 s;				// 2nd degree component
} PVMoment;

typedef struct _PVCollideMesh
{
	PVMesh *Father;
	unsigned *Tris;
	PVObbt *Root;
} PVCollideMesh;

//////////////////////////////////////////////////////////////////////////////////////

// a=b*([c].d)+e
#define sMxVpV(a,b,c,d,e) \
  (a)->xf = b * (c[0][0] * (d)->xf + c[0][1] * (d)->yf + c[0][2] * (d)->zf) + (e)->xf; \
  (a)->yf = b * (c[1][0] * (d)->xf + c[1][1] * (d)->yf + c[1][2] * (d)->zf) + (e)->yf; \
  (a)->zf = b * (c[2][0] * (d)->xf + c[2][1] * (d)->yf + c[2][2] * (d)->zf) + (e)->zf;


// a=b*([c]T.d)
#define sMTxV(a,b,c,d) \
  (a)->xf = b * (c[0][0] * (d)->xf + c[1][0] * (d)->yf + c[2][0] * (d)->zf); \
  (a)->yf = b * (c[0][1] * (d)->xf + c[1][1] * (d)->yf + c[2][1] * (d)->zf); \
  (a)->zf = b * (c[0][2] * (d)->xf + c[1][2] * (d)->yf + c[2][2] * (d)->zf);

//////////////////////////////////////////////////////////////////////////////////////
// Variables utilis�es lors du preprocess
static PVMoment *zMoments;
static unsigned *zTris;
static PVMesh *zMesh;
static PVObbt *zBoxes;
static unsigned NbrBoxUsed;

// Variables utilis�es lors du test de collision
static PVCollideMesh *zTree1,*zTree2;
static PVFLAGS Flags;
static PVMat3x3 mR;
static PVPoint mT;
static float ms;
static unsigned TotalContacts;


////////////////////////////////////////////////////////////////////////// PRE-PROCESS

#define minmax(a,b,c) \
	if(c<a) a=c; else if(c>b) b=c;

#define ROT(a,i,j,k,l) g=a[i][j]; h=a[k][l]; a[i][j]=g-s*(h+g*tau); a[k][l]=h+s*(g-h*tau);

static int Meigen(PVMat3x3 vout, float dout[3], PVMat3x3 a)
{
  int i;
  double tresh,theta,tau,t,sm,s,h,g,c;
  int nrot;
  double b[3];
  double z[3];
  PVMat3x3 v;
  double d[3];

  v[0][0] = v[1][1] = v[2][2] = 1.0;
  v[0][1] = v[1][2] = v[2][0] = 0.0;
  v[0][2] = v[1][0] = v[2][1] = 0.0;

  b[0] = a[0][0]; d[0] = a[0][0]; z[0] = 0.0;
  b[1] = a[1][1]; d[1] = a[1][1]; z[1] = 0.0;
  b[2] = a[2][2]; d[2] = a[2][2]; z[2] = 0.0;

  nrot = 0;

  for(i=0; i<50; i++)
    {

      sm=0.0; sm+=fabs(a[0][1]); sm+=fabs(a[0][2]); sm+=fabs(a[1][2]);
      if (sm == 0.0) { memcpy(vout,v,sizeof(PVMat3x3)); memcpy(dout,d,sizeof(dout)); return i; }

      if (i < 3) tresh=0.2*sm/(3*3); else tresh=0.0;

      {
	g = 100.0*fabs(a[0][1]);
	if (i>3 && fabs(d[0])+g==fabs(d[0]) && fabs(d[1])+g==fabs(d[1]))
	  a[0][1]=0.0;
	else if (fabs(a[0][1])>tresh)
	  {
	    h = d[1]-d[0];
	    if (fabs(h)+g == fabs(h)) t=(a[0][1])/h;
	    else
	      {
		theta=0.5*h/(a[0][1]);
		t=1.0/(fabs(theta)+fsqrt(1.0+theta*theta));
		if (theta < 0.0) t = -t;
	      }
	    c=1.0/fsqrt(1+t*t); s=t*c; tau=s/(1.0+c); h=t*a[0][1];
	    z[0] -= h; z[1] += h; d[0] -= h; d[1] += h;
	    a[0][1]=0.0;
	    ROT(a,0,2,1,2); ROT(v,0,0,0,1); ROT(v,1,0,1,1); ROT(v,2,0,2,1);
	    nrot++;
	  }
      }

      {
	g = 100.0*fabs(a[0][2]);
	if (i>3 && fabs(d[0])+g==fabs(d[0]) && fabs(d[2])+g==fabs(d[2]))
	  a[0][2]=0.0;
	else if (fabs(a[0][2])>tresh)
	  {
	    h = d[2]-d[0];
	    if (fabs(h)+g == fabs(h)) t=(a[0][2])/h;
	    else
	      {
		theta=0.5*h/(a[0][2]);
		t=1.0/(fabs(theta)+fsqrt(1.0+theta*theta));
		if (theta < 0.0) t = -t;
	      }
	    c=1.0/fsqrt(1+t*t); s=t*c; tau=s/(1.0+c); h=t*a[0][2];
	    z[0] -= h; z[2] += h; d[0] -= h; d[2] += h;
	    a[0][2]=0.0;
	    ROT(a,0,1,1,2); ROT(v,0,0,0,2); ROT(v,1,0,1,2); ROT(v,2,0,2,2);
	    nrot++;
	  }
      }


      {
	g = 100.0*fabs(a[1][2]);
	if (i>3 && fabs(d[1])+g==fabs(d[1]) && fabs(d[2])+g==fabs(d[2]))
	  a[1][2]=0.0;
	else if (fabs(a[1][2])>tresh)
	  {
	    h = d[2]-d[1];
	    if (fabs(h)+g == fabs(h)) t=(a[1][2])/h;
	    else
	      {
		theta=0.5*h/(a[1][2]);
		t=1.0/(fabs(theta)+fsqrt(1.0+theta*theta));
		if (theta < 0.0) t = -t;
	      }
	    c=1.0/fsqrt(1+t*t); s=t*c; tau=s/(1.0+c); h=t*a[1][2];
	    z[1] -= h; z[2] += h; d[1] -= h; d[2] += h;
	    a[1][2]=0.0;
	    ROT(a,0,1,0,2); ROT(v,0,1,0,2); ROT(v,1,1,1,2); ROT(v,2,1,2,2);
	    nrot++;
	  }
      }

      b[0] += z[0]; d[0] = b[0]; z[0] = 0.0;
      b[1] += z[1]; d[1] = b[1]; z[1] = 0.0;
      b[2] += z[2]; d[2] = b[2]; z[2] = 0.0;

    }

  debug(fprintf(stderr, "eigen: too many iterations in Jacobi transform (%d).\n", i););

  return i;
}

// not a full sort -- just makes column 1 the largest
static int eigen_and_sort1(PVMat3x3 evecs, PVMat3x3 cov)
{
  float t;
  float evals[3];
  int n;

  n = Meigen(evecs, evals, cov);

  if (evals[2] > evals[0])
    {
      if (evals[2] > evals[1])
	{
	  // 2 is largest, swap with column 0
	  t = evecs[0][2];
	  evecs[0][2] = evecs[0][0];
	  evecs[0][0] = t;
	  t = evecs[1][2];
	  evecs[1][2] = evecs[1][0];
	  evecs[1][0] = t;
	  t = evecs[2][2];
	  evecs[2][2] = evecs[2][0];
	  evecs[2][0] = t;
	}
      else
	{
	  // 1 is largest, swap with column 0
	  t = evecs[0][1];
	  evecs[0][1] = evecs[0][0];
	  evecs[0][0] = t;
	  t = evecs[1][1];
	  evecs[1][1] = evecs[1][0];
	  evecs[1][0] = t;
	  t = evecs[2][1];
	  evecs[2][1] = evecs[2][0];
	  evecs[2][0] = t;
	}
    }
  else
    {
      if (evals[0] > evals[1])
	{
	  // 0 is largest, do nothing
	}
      else
	{
  	  // 1 is largest
	  t = evecs[0][1];
	  evecs[0][1] = evecs[0][0];
	  evecs[0][0] = t;
	  t = evecs[1][1];
	  evecs[1][1] = evecs[1][0];
	  evecs[1][0] = t;
	  t = evecs[2][1];
	  evecs[2][1] = evecs[2][0];
	  evecs[2][0] = t;
	}
    }

  // we are returning the number of iterations Meigen took.
  // too many iterations means our chosen orientation is bad.
  return n;
}

static void CalcMoment(PVMoment *M, PVPoint *p,PVPoint *q,PVPoint *r)
{
	PVPoint u,v,w;

	VmV(&u,q,p);
	VmV(&v,r,p);
	VxV(&w,&u,&v);
	M->A=0.5*fsqrt(w.xf*w.xf+w.yf*w.yf+w.zf*w.zf);

	// centre du triangle
	M->m.xf = (p->xf + q->xf + r->xf) /3;
	M->m.yf = (p->yf + q->yf + r->yf) /3;
	M->m.zf = (p->zf + q->zf + r->zf) /3;

	if(M->A==0)
	{
		  // Aire=0, on utilise une formule speciale pour le calcul de la 2nd order component
		  M->s[0][0] = (p->xf*p->xf + q->xf*q->xf + r->xf*r->xf);
		  M->s[0][1] = (p->xf*p->yf + q->xf*q->yf + r->xf*r->yf);
		  M->s[0][2] = (p->xf*p->zf + q->xf*q->zf + r->xf*r->zf);
		  M->s[1][1] = (p->yf*p->yf + q->yf*q->yf + r->yf*r->yf);
		  M->s[1][2] = (p->yf*p->zf + q->yf*q->zf + r->yf*r->zf);
		  M->s[2][2] = (p->zf*p->zf + q->zf*q->zf + r->zf*r->zf);
		  M->s[2][1] = M->s[1][2];
		  M->s[1][0] = M->s[0][1];
		  M->s[2][0] = M->s[0][2];
	}
	else
	{
		  M->s[0][0] = M->A*(9*M->m.xf*M->m.xf+p->xf*p->xf+q->xf*q->xf+r->xf*r->xf)/12;
		  M->s[0][1] = M->A*(9*M->m.xf*M->m.yf+p->xf*p->yf+q->xf*q->yf+r->xf*r->yf)/12;
		  M->s[1][1] = M->A*(9*M->m.yf*M->m.yf+p->yf*p->yf+q->yf*q->yf+r->yf*r->yf)/12;
		  M->s[0][2] = M->A*(9*M->m.xf*M->m.zf+p->xf*p->zf+q->xf*q->zf+r->xf*r->zf)/12;
		  M->s[1][2] = M->A*(9*M->m.yf*M->m.zf+p->yf*p->zf+q->yf*q->zf+r->yf*r->zf)/12;
		  M->s[2][2] = M->A*(9*M->m.zf*M->m.zf+p->zf*p->zf+q->zf*q->zf+r->zf*r->zf)/12;
		  M->s[2][1] = M->s[1][2];
		  M->s[1][0] = M->s[0][1];
		  M->s[2][0] = M->s[0][2];
	}
}

static void CalcMoments(unsigned *Tris,PVMoment *Moments,unsigned NbrTris,PVMesh *m)
{
	unsigned i;
	char Zero=0;
	float Amin=MAXFLOAT;

	for(i=0;i<NbrTris;i++)
	{
		CalcMoment(&Moments[i],(PVPoint*)&m->Vertex[Tris[i*4]].xf,(PVPoint*)&m->Vertex[Tris[i*4+1]].xf,(PVPoint*)&m->Vertex[Tris[i*4+2]].xf);

		if(Moments[i].A==0) Zero=1;
		else
		{
			if(Moments[i].A<Amin) Amin=Moments[i].A;
		}
	}

	if(Zero)
	{
		debug(fprintf(stderr,"WARNING: Some triangles have zero area ...\n"););

		if (Amin==0.0) Amin=1;

		for(i=0; i<NbrTris; i++)
		{
			if (Moments[i].A == 0.0) Moments[i].A = Amin;
		}
	}
}

static int SplitRecurse1(PVObbt *box,unsigned *t)
{
  PVPoint u12, u23, u31,a1,a2;
  double d12,d23,d31;
  unsigned *ptr = zTris + t[0]*4;
  double a0[3];
  double l;
  float minval[3], maxval[3];
  PVPoint c;

  // ici on calcul la boite autour d'un unik triangle,
  // l'axe principal est parallele au cot� le plus grand du triangle
  // l'axe mineur est normal au triangle
  // et le dernier c le produit vectorile des deux autres

  // C'est ici kon set le pR, pT et d de la dite boite

  // Calcul des longueur des cot�s (au carr�)
  // et recherche du plus grand cot�, axe majeur
  VmV(&u12, &zMesh->Vertex[*ptr], &zMesh->Vertex[*(ptr+1)]);
  VmV(&u23, &zMesh->Vertex[*(ptr+1)], &zMesh->Vertex[*(ptr+2)]);
  VmV(&u31, &zMesh->Vertex[*(ptr+2)], &zMesh->Vertex[*ptr]);
  d12 = VdotV(&u12,&u12);
  d23 = VdotV(&u23,&u23);
  d31 = VdotV(&u31,&u31);

  if (d12 > d23)
  {

	if (d12 > d31)
	{
	  l = 1.0 / fsqrt(d12);
	  //l=InvSqrt(d12);
	  a0[0] = u12.xf * l;
	  a0[1] = u12.yf * l;
	  a0[2] = u12.zf * l;
	}
    else
	{
	  l = 1.0 / fsqrt(d31);
	  //l=InvSqrt(d31);
	  a0[0] = u31.xf * l;
	  a0[1] = u31.yf * l;
	  a0[2] = u31.zf * l;
	}
  }
  else
  {
    if (d23 > d31)
	{
	  l = 1.0 / fsqrt(d23);
	  //l=InvSqrt(d23);
	  a0[0] = u23.xf * l;
	  a0[1] = u23.yf * l;
	  a0[2] = u23.zf * l;
	}
    else
	{
	  l = 1.0 / fsqrt(d31);
	  //l=InvSqrt(d31);
	  a0[0] = u31.xf * l;
	  a0[1] = u31.yf * l;
	  a0[2] = u31.zf * l;
	}
  }

  // la normale au triangle
  VxV(&a2, &u12, &u23);
  l = 1.0 / fsqrt(a2.xf*a2.xf+a2.yf*a2.yf+a2.zf*a2.zf);
  //l=InvSqrt(a2.xf*a2.xf+a2.yf*a2.yf+a2.zf*a2.zf);
  a2.xf *= l;
  a2.yf *= l;
  a2.zf *= l;

  // et le dernier vecteur par un produit vectoriel
  a1.xf=a2.yf*a0[2]-a2.zf*a0[1];
  a1.yf=a2.zf*a0[0]-a2.xf*a0[2];
  a1.zf=a2.xf*a0[1]-a2.yf*a0[0];

  // Et hop voila la matrice pR
  box->pR[0][0] = a0[0];  box->pR[0][1] = a1.xf;  box->pR[0][2] = a2.xf;
  box->pR[1][0] = a0[1];  box->pR[1][1] = a1.yf;  box->pR[1][2] = a2.yf;
  box->pR[2][0] = a0[2];  box->pR[2][1] = a1.zf;  box->pR[2][2] = a2.zf;

  // Calcul des longeurs de la boite
  // pour cela on transforme les points du triangles
  MTxV(&c, box->pR, &zMesh->Vertex[*(ptr)]);
  minval[0] = maxval[0] = c.xf;
  minval[1] = maxval[1] = c.yf;
  minval[2] = maxval[2] = c.zf;

  MTxV(&c, box->pR, &zMesh->Vertex[*(ptr+1)]);
  minmax(minval[0], maxval[0], c.xf);
  minmax(minval[1], maxval[1], c.yf);
  minmax(minval[2], maxval[2], c.zf);

  MTxV(&c, box->pR, &zMesh->Vertex[*(ptr+2)]);
  minmax(minval[0], maxval[0], c.xf);
  minmax(minval[1], maxval[1], c.yf);
  minmax(minval[2], maxval[2], c.zf);

  // On en deduit les infos de la boite, centre et longueur
  c.xf = (minval[0] + maxval[0])*0.5;
  c.yf = (minval[1] + maxval[1])*0.5;
  c.zf = (minval[2] + maxval[2])*0.5;

  box->pT.xf = c.xf * box->pR[0][0] + c.yf * box->pR[0][1] + c.zf * box->pR[0][2];
  box->pT.yf = c.xf * box->pR[1][0] + c.yf * box->pR[1][1] + c.zf * box->pR[1][2];
  box->pT.zf = c.xf * box->pR[2][0] + c.yf * box->pR[2][1] + c.zf * box->pR[2][2];

  box->d[0] = (maxval[0] - minval[0])*0.5;
  box->d[1] = (maxval[1] - minval[1])*0.5;
  box->d[2] = (maxval[2] - minval[2])*0.5;

  // Et finalement la feuille :)
  box->Tri= ptr;

  return COOL;
}

static int SplitRecurse(PVObbt *box,unsigned *t,unsigned n)
{
	unsigned rc,n1=0,i,in,*ptr,temp;
	double axdmp;
	PVMoment M1,M2;
	PVPoint c;
	float minval[3], maxval[3];
	PVMat3x3 tR,C;

	if(n == 1) return SplitRecurse1(box,t);


  // On projete le PVPoint du milieu sur l'axe de split
  axdmp = (box->pR[0][0] * box->pT.xf + box->pR[1][0] * box->pT.yf + box->pR[2][0] * box->pT.zf);

  memset(&M1,0,sizeof(PVMoment));
  memset(&M2,0,sizeof(PVMoment));

  MTxV(&c,box->pR,&zMesh->Vertex[zTris[t[0]*4]]);
  minval[0] = maxval[0] = c.xf;
  minval[1] = maxval[1] = c.yf;
  minval[2] = maxval[2] = c.zf;

  for(i=0;i<n;i++)
  {
	  in=t[i];
	  ptr=&zTris[in*4];

	  MTxV(&c,box->pR,&zMesh->Vertex[*ptr]);
	  minmax(minval[0],maxval[0],c.xf);
	  minmax(minval[1],maxval[1],c.yf);
	  minmax(minval[2],maxval[2],c.zf);
	  ptr++;
	  MTxV(&c,box->pR,&zMesh->Vertex[*ptr]);
	  minmax(minval[0],maxval[0],c.xf);
	  minmax(minval[1],maxval[1],c.yf);
	  minmax(minval[2],maxval[2],c.zf);
	  ptr++;
	  MTxV(&c,box->pR,&zMesh->Vertex[*ptr]);
	  minmax(minval[0],maxval[0],c.xf);
	  minmax(minval[1],maxval[1],c.yf);
	  minmax(minval[2],maxval[2],c.zf);

	  // ici pour chaque triangle on prjete son PVPoint median, et on le compare a celui de la
	  // boite pour savoir s'il appartient au prmeir ou second groupe (respectivement
	  // 1er ou second fils)
	  c.xf=zMoments[in].m.xf;
	  c.yf=zMoments[in].m.yf;
	  c.zf=zMoments[in].m.zf;

	  if (((box->pR[0][0]*c.xf + box->pR[1][0]*c.yf + box->pR[2][0]*c.zf) < axdmp) && ((n!=2)) || ((n==2) && (i==0)))
	  {
		  M1.A+=zMoments[in].A;
		  M1.m.xf+=zMoments[in].m.xf*zMoments[in].A;
		  M1.m.yf+=zMoments[in].m.yf*zMoments[in].A;
		  M1.m.zf+=zMoments[in].m.zf*zMoments[in].A;

		  M1.s[0][0] += zMoments[in].s[0][0];
		  M1.s[0][1] += zMoments[in].s[0][1];
		  M1.s[0][2] += zMoments[in].s[0][2];
		  M1.s[1][0] += zMoments[in].s[1][0];
		  M1.s[1][1] += zMoments[in].s[1][1];
		  M1.s[1][2] += zMoments[in].s[1][2];
		  M1.s[2][0] += zMoments[in].s[2][0];
		  M1.s[2][1] += zMoments[in].s[2][1];
		  M1.s[2][2] += zMoments[in].s[2][2];
	      temp = t[i];
		  t[i] = t[n1];
		  t[n1] = temp;
		  n1++;
	  }
	  else
	  {
		  M2.A+=zMoments[in].A;
		  M2.m.xf+=zMoments[in].m.xf*zMoments[in].A;
		  M2.m.yf+=zMoments[in].m.yf*zMoments[in].A;
		  M2.m.zf+=zMoments[in].m.zf*zMoments[in].A;

		  M2.s[0][0] += zMoments[in].s[0][0];
		  M2.s[0][1] += zMoments[in].s[0][1];
		  M2.s[0][2] += zMoments[in].s[0][2];
		  M2.s[1][0] += zMoments[in].s[1][0];
		  M2.s[1][1] += zMoments[in].s[1][1];
		  M2.s[1][2] += zMoments[in].s[1][2];
		  M2.s[2][0] += zMoments[in].s[2][0];
		  M2.s[2][1] += zMoments[in].s[2][1];
		  M2.s[2][2] += zMoments[in].s[2][2];
	  }
  }

  // Test pour voir si la parition est valide
  if ((n1 == 0) || (n1 == n))
  {
	  // non on coupe dans la masse :)
	  n1 = n/2;
	  memset(&M1,0,sizeof(PVMoment));
	  memset(&M2,0,sizeof(PVMoment));
	  for(i=0;i<n1;i++)
	  {
		  M1.A+=zMoments[t[i]].A;
		  M1.m.xf+=zMoments[t[i]].m.xf*zMoments[t[i]].A;
		  M1.m.yf+=zMoments[t[i]].m.yf*zMoments[t[i]].A;
		  M1.m.zf+=zMoments[t[i]].m.zf*zMoments[t[i]].A;

		  M1.s[0][0] += zMoments[t[i]].s[0][0];
		  M1.s[0][1] += zMoments[t[i]].s[0][1];
		  M1.s[0][2] += zMoments[t[i]].s[0][2];
		  M1.s[1][0] += zMoments[t[i]].s[1][0];
		  M1.s[1][1] += zMoments[t[i]].s[1][1];
		  M1.s[1][2] += zMoments[t[i]].s[1][2];
		  M1.s[2][0] += zMoments[t[i]].s[2][0];
		  M1.s[2][1] += zMoments[t[i]].s[2][1];
		  M1.s[2][2] += zMoments[t[i]].s[2][2];
	  }
	  for(i=n1;i<n;i++)
	  {
		  M2.A+=zMoments[t[i]].A;
		  M2.m.xf+=zMoments[t[i]].m.xf*zMoments[t[i]].A;
		  M2.m.yf+=zMoments[t[i]].m.yf*zMoments[t[i]].A;
		  M2.m.zf+=zMoments[t[i]].m.zf*zMoments[t[i]].A;

		  M2.s[0][0] += zMoments[t[i]].s[0][0];
		  M2.s[0][1] += zMoments[t[i]].s[0][1];
		  M2.s[0][2] += zMoments[t[i]].s[0][2];
		  M2.s[1][0] += zMoments[t[i]].s[1][0];
		  M2.s[1][1] += zMoments[t[i]].s[1][1];
		  M2.s[1][2] += zMoments[t[i]].s[1][2];
		  M2.s[2][0] += zMoments[t[i]].s[2][0];
		  M2.s[2][1] += zMoments[t[i]].s[2][1];
		  M2.s[2][2] += zMoments[t[i]].s[2][2];
	  }
  }

  // On calcul les donn�es de la boite
  c.xf = (minval[0] + maxval[0])*0.5;
  c.yf = (minval[1] + maxval[1])*0.5;
  c.zf = (minval[2] + maxval[2])*0.5;

  box->pT.xf = c.xf * box->pR[0][0] + c.yf * box->pR[0][1] + c.zf * box->pR[0][2];
  box->pT.yf = c.xf * box->pR[1][0] + c.yf * box->pR[1][1] + c.zf * box->pR[1][2];
  box->pT.zf = c.xf * box->pR[2][0] + c.yf * box->pR[2][1] + c.zf * box->pR[2][2];
  box->d[0] = (maxval[0] - minval[0])*0.5;
  box->d[1] = (maxval[1] - minval[1])*0.5;
  box->d[2] = (maxval[2] - minval[2])*0.5;

  box->P=&zBoxes[NbrBoxUsed++];
  box->N=&zBoxes[NbrBoxUsed++];

  if (n1 > 1)
  {
      double z=1/M1.A;

	  box->P->pT.xf = M1.m.xf *z;
	  box->P->pT.yf = M1.m.yf *z;
	  box->P->pT.zf = M1.m.zf *z;

      C[0][0]=M1.s[0][0]-M1.m.xf*M1.m.xf*z;
  	  C[0][1]=M1.s[0][1]-M1.m.xf*M1.m.yf*z;
	  C[0][2]=M1.s[0][2]-M1.m.xf*M1.m.zf*z;
	  C[1][0]=M1.s[1][0]-M1.m.yf*M1.m.xf*z;
	  C[1][1]=M1.s[1][1]-M1.m.yf*M1.m.yf*z;
	  C[1][2]=M1.s[1][2]-M1.m.yf*M1.m.zf*z;
	  C[2][0]=M1.s[2][0]-M1.m.zf*M1.m.xf*z;
	  C[2][1]=M1.s[2][1]-M1.m.zf*M1.m.yf*z;
	  C[2][2]=M1.s[2][2]-M1.m.zf*M1.m.zf*z;

      if (eigen_and_sort1(tR, C) > 30)
	  {
	    tR[0][0] = tR[1][1] = tR[2][2] = 1.0;
		tR[0][1] = tR[1][2] = tR[2][0] = 0.0;
		tR[0][2] = tR[1][0] = tR[2][1] = 0.0;
	  }

	  memcpy(box->P->pR,tR,sizeof(PVMat3x3));

      if ((rc = SplitRecurse(box->P,t,n1)) != COOL) return rc;
  }
  else
  {
      if ((rc = SplitRecurse1(box->P,t)) != COOL) return rc;
  }

  memcpy(C,box->P->pR,sizeof(PVMat3x3));
  MTxM(box->P->pR,box->pR,C);
  VmV(&c,&box->P->pT,&box->pT);
  MTxV(&box->P->pT,box->pR,&c);

  if ((n-n1) > 1)
  {
	  double z=1/M2.A;

	  box->N->pT.xf = M2.m.xf *z;
	  box->N->pT.yf = M2.m.yf *z;
	  box->N->pT.zf = M2.m.zf *z;

      C[0][0]=M2.s[0][0]-M2.m.xf*M2.m.xf*z;
  	  C[0][1]=M2.s[0][1]-M2.m.xf*M2.m.yf*z;
	  C[0][2]=M2.s[0][2]-M2.m.xf*M2.m.zf*z;
	  C[1][0]=M2.s[1][0]-M2.m.yf*M2.m.xf*z;
	  C[1][1]=M2.s[1][1]-M2.m.yf*M2.m.yf*z;
	  C[1][2]=M2.s[1][2]-M2.m.yf*M2.m.zf*z;
	  C[2][0]=M2.s[2][0]-M2.m.zf*M2.m.xf*z;
	  C[2][1]=M2.s[2][1]-M2.m.zf*M2.m.yf*z;
	  C[2][2]=M2.s[2][2]-M2.m.zf*M2.m.zf*z;

      if (eigen_and_sort1(tR, C) > 30)
	  {
		tR[0][0] = tR[1][1] = tR[2][2] = 1.0;
		tR[0][1] = tR[1][2] = tR[2][0] = 0.0;
		tR[0][2] = tR[1][0] = tR[2][1] = 0.0;
	  }

  	  memcpy(box->N->pR,tR,sizeof(PVMat3x3));

      if (rc = SplitRecurse(box->N,t+n1,n-n1) != COOL) return rc;
   }
  else
  {
      if (rc = SplitRecurse1(box->N,t+n1) != COOL) return rc;
  }

  memcpy(C,box->N->pR,sizeof(PVMat3x3));
  MTxM(box->N->pR,box->pR,C);
  VmV(&c,&box->N->pT,&box->pT);
  MTxV(&box->N->pT,box->pR,&c);

  return COOL;
}

///////////////////////////////////////////////////////////////////////////////////

static PVCollidingFaces *Report=NULL;
static unsigned NbrReported=0;
static unsigned NbrAlloced=0;

static int PV_AddPair(PVFace *f1,PVFace *f2)
{
	PVCollidingFaces *t;

	if(NbrReported>=NbrAlloced)
	{
		// Alloue un nouvo buffer
		t=(PVCollidingFaces*)realloc(Report,sizeof(PVCollidingFaces)*(NbrAlloced+64));
		if(t==NULL) return NO_MEMORY;
		Report=t;
		NbrAlloced+=64;
	}

	Report[NbrReported].Face1=f1;
	Report[NbrReported].Face2=f2;
	NbrReported++;
	return COOL;
}

static double max3(double a, double b, double c)
{
  double t = a;
  if (b > t) t = b;
  if (c > t) t = c;
  return t;
}

static double min3(double a, double b, double c)
{
  double t = a;
  if (b < t) t = b;
  if (c < t) t = c;
  return t;
}

static int Project6(PVPoint *ax,PVPoint *p1, PVPoint *p2, PVPoint *p3,PVPoint *q1, PVPoint *q2, PVPoint *q3)
{
  double P1 = VdotV(ax, p1);
  double P2 = VdotV(ax, p2);
  double P3 = VdotV(ax, p3);
  double Q1 = VdotV(ax, q1);
  double Q2 = VdotV(ax, q2);
  double Q3 = VdotV(ax, q3);

  double mx1 = max3(P1, P2, P3);
  double mn1 = min3(P1, P2, P3);
  double mx2 = max3(Q1, Q2, Q3);
  double mn2 = min3(Q1, Q2, Q3);

  if (mn1 > mx2) return 0;
  if (mn2 > mx1) return 0;
  return 1;
}


static int TriContact(PVPoint *P1,  PVPoint *P2,  PVPoint *P3, PVPoint *Q1,  PVPoint *Q2,  PVPoint *Q3)
{
  PVPoint p1, p2, p3,q1, q2, q3,e1, e2, e3,f1, f2, f3,g1, g2, g3,h1, h2, h3,n1, m1,z;
  PVPoint ef11, ef12, ef13,ef21, ef22, ef23,ef31, ef32, ef33;

  z.xf = 0.0;  z.yf = 0.0;  z.zf = 0.0;

  p1.xf =0/* P1->xf - P1->xf*/;  p1.yf =0/* P1->yf - P1->yf*/;  p1.zf = 0/*P1->zf - P1->zf*/;
  p2.xf = P2->xf - P1->xf;  p2.yf = P2->yf - P1->yf;  p2.zf = P2->zf - P1->zf;
  p3.xf = P3->xf - P1->xf;  p3.yf = P3->yf - P1->yf;  p3.zf = P3->zf - P1->zf;


  q1.xf = Q1->xf - P1->xf;  q1.yf = Q1->yf - P1->yf;  q1.zf = Q1->zf - P1->zf;
  q2.xf = Q2->xf - P1->xf;  q2.yf = Q2->yf - P1->yf;  q2.zf = Q2->zf - P1->zf;
  q3.xf = Q3->xf - P1->xf;  q3.yf = Q3->yf - P1->yf;  q3.zf = Q3->zf - P1->zf;

  e1.xf = P2->xf - P1->xf;  e1.yf = P2->yf - P1->yf;  e1.zf = P2->zf - P1->zf;
  e2.xf = P3->xf - P2->xf;  e2.yf = P3->yf - P2->yf;  e2.zf = P3->zf - P2->zf;
  e3.xf = P1->xf - P3->xf;  e3.yf = P1->yf - P3->yf;  e3.zf = P1->zf - P3->zf;

  f1.xf = Q2->xf - Q1->xf;  f1.yf = Q2->yf - Q1->yf;  f1.zf = Q2->zf - Q1->zf;
  f2.xf = Q3->xf - Q2->xf;  f2.yf = Q3->yf - Q2->yf;  f2.zf = Q3->zf - Q2->zf;
  f3.xf = Q1->xf - Q3->xf;  f3.yf = Q1->yf - Q3->yf;  f3.zf = Q1->zf - Q3->zf;

  VxV(&n1, &e1, &e2);
  VxV(&m1, &f1, &f2);

  VxV(&g1, &e1, &n1);
  VxV(&g2, &e2, &n1);
  VxV(&g3, &e3, &n1);
  VxV(&h1, &f1, &m1);
  VxV(&h2, &f2, &m1);
  VxV(&h3, &f3, &m1);

  VxV(&ef11, &e1, &f1);
  VxV(&ef12, &e1, &f2);
  VxV(&ef13, &e1, &f3);
  VxV(&ef21, &e2, &f1);
  VxV(&ef22, &e2, &f2);
  VxV(&ef23, &e2, &f3);
  VxV(&ef31, &e3, &f1);
  VxV(&ef32, &e3, &f2);
  VxV(&ef33, &e3, &f3);

  if (!Project6(&n1, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&m1, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;

  if (!Project6(&ef11, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef12, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef13, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef21, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef22, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef23, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef31, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef32, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&ef33, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;

  if (!Project6(&g1, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&g2, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&g3, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&h1, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&h2, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;
  if (!Project6(&h3, &p1, &p2, &p3, &q1, &q2, &q3)) return 0;

  return 1;
}

static int TriContactBox(PVObbt *b1, PVObbt *b2)
{
  // Ici on exprime les coord d'un triangle dans l'autre
  PVPoint i1;
  PVPoint i2;
  PVPoint i3;
  int rc;

  sMxVpV(&i1, ms, mR, &zTree1->Father->Vertex[*b1->Tri], &mT);
  sMxVpV(&i2, ms, mR, &zTree1->Father->Vertex[*(b1->Tri+1)], &mT);
  sMxVpV(&i3, ms, mR, &zTree1->Father->Vertex[*(b1->Tri+2)], &mT);

  rc = TriContact(&i1, &i2, &i3,(PVPoint*)&zTree2->Father->Vertex[*b2->Tri].xf,(PVPoint*)&zTree2->Father->Vertex[*(b2->Tri+1)].xf,(PVPoint*) &zTree1->Father->Vertex[*(b2->Tri+2)].xf);

  if (rc)
  {
      TotalContacts++;
	  if ((rc = PV_AddPair((PVFace*)*(b1->Tri+3), (PVFace*)*(b2->Tri+3))) != COOL) return rc;
  }

  return COOL;
}

static int OBBDisjoint(PVMat3x3 B, PVPoint *T, float a[3], float b[3])
{
  register double t, s;
  register int r;
  double Bf[3][3];
  double reps = 1e-6;

  Bf[0][0] = fabs(B[0][0]);  Bf[0][0] += reps;
  Bf[0][1] = fabs(B[0][1]);  Bf[0][1] += reps;
  Bf[0][2] = fabs(B[0][2]);  Bf[0][2] += reps;
  Bf[1][0] = fabs(B[1][0]);  Bf[1][0] += reps;
  Bf[1][1] = fabs(B[1][1]);  Bf[1][1] += reps;
  Bf[1][2] = fabs(B[1][2]);  Bf[1][2] += reps;
  Bf[2][0] = fabs(B[2][0]);  Bf[2][0] += reps;
  Bf[2][1] = fabs(B[2][1]);  Bf[2][1] += reps;
  Bf[2][2] = fabs(B[2][2]);  Bf[2][2] += reps;

  r = 1;

  t = fabs(T->xf);

  r &= (t <=
	  (a[0] + b[0] * Bf[0][0] + b[1] * Bf[0][1] + b[2] * Bf[0][2]));
  if (!r) return 1;

  s = T->xf*B[0][0] + T->yf*B[1][0] + T->zf*B[2][0];
  t = fabs(s);

  r &= ( t <=
	  (b[0] + a[0] * Bf[0][0] + a[1] * Bf[1][0] + a[2] * Bf[2][0]));
  if (!r) return 2;

  t = fabs(T->yf);

  r &= ( t <=
	  (a[1] + b[0] * Bf[1][0] + b[1] * Bf[1][1] + b[2] * Bf[1][2]));
  if (!r) return 3;

  t = fabs(T->zf);

  r &= ( t <=
	  (a[2] + b[0] * Bf[2][0] + b[1] * Bf[2][1] + b[2] * Bf[2][2]));
  if (!r) return 4;

  s = T->xf*B[0][1] + T->yf*B[1][1] + T->zf*B[2][1];
  t = fabs(s);

  r &= ( t <=
	  (b[1] + a[0] * Bf[0][1] + a[1] * Bf[1][1] + a[2] * Bf[2][1]));
  if (!r) return 5;

  s = T->xf*B[0][2] + T->yf*B[1][2] + T->zf*B[2][2];
  t = fabs(s);

  r &= ( t <=
	  (b[2] + a[0] * Bf[0][2] + a[1] * Bf[1][2] + a[2] * Bf[2][2]));
  if (!r) return 6;

  s = T->zf * B[1][0] - T->yf * B[2][0];
  t = fabs(s);

  r &= ( t <=
	(a[1] * Bf[2][0] + a[2] * Bf[1][0] +
	 b[1] * Bf[0][2] + b[2] * Bf[0][1]));
  if (!r) return 7;

  s = T->zf * B[1][1] - T->yf * B[2][1];
  t = fabs(s);

  r &= ( t <=
	(a[1] * Bf[2][1] + a[2] * Bf[1][1] +
	 b[0] * Bf[0][2] + b[2] * Bf[0][0]));
  if (!r) return 8;

  s = T->zf * B[1][2] - T->yf * B[2][2];
  t = fabs(s);

  r &= ( t <=
	  (a[1] * Bf[2][2] + a[2] * Bf[1][2] +
	   b[0] * Bf[0][1] + b[1] * Bf[0][0]));
  if (!r) return 9;

  s = T->xf * B[2][0] - T->zf * B[0][0];
  t = fabs(s);

  r &= ( t <=
	  (a[0] * Bf[2][0] + a[2] * Bf[0][0] +
	   b[1] * Bf[1][2] + b[2] * Bf[1][1]));
  if (!r) return 10;

  s = T->xf * B[2][1] - T->zf * B[0][1];
  t = fabs(s);

  r &= ( t <=
	  (a[0] * Bf[2][1] + a[2] * Bf[0][1] +
	   b[0] * Bf[1][2] + b[2] * Bf[1][0]));
  if (!r) return 11;

  s = T->xf * B[2][2] - T->zf * B[0][2];
  t = fabs(s);

  r &= (t <=
	  (a[0] * Bf[2][2] + a[2] * Bf[0][2] +
	   b[0] * Bf[1][1] + b[1] * Bf[1][0]));
  if (!r) return 12;

  s = T->yf * B[0][0] - T->xf * B[1][0];
  t = fabs(s);

  r &= (t <=
	  (a[0] * Bf[1][0] + a[1] * Bf[0][0] +
	   b[1] * Bf[2][2] + b[2] * Bf[2][1]));
  if (!r) return 13;

  s = T->yf * B[0][1] - T->xf * B[1][1];
  t = fabs(s);

  r &= ( t <=
	  (a[0] * Bf[1][1] + a[1] * Bf[0][1] +
	   b[0] * Bf[2][2] + b[2] * Bf[2][0]));
  if (!r) return 14;

  s = T->yf * B[0][2] - T->xf * B[1][2];
  t = fabs(s);

  r &= ( t <=
	  (a[0] * Bf[1][2] + a[1] * Bf[0][2] +
	   b[0] * Bf[2][1] + b[1] * Bf[2][0]));
  if (!r) return 15;

  return 0;
}

#define Leaf(x) \
	((x->N==NULL)&&(x->P==NULL))

static int CollideRecursive(PVObbt *b1, PVObbt *b2, PVMat3x3 R, PVPoint *T, float s)
{
  float d[3];
  int rc;
  int f1;
  PVPoint U,cT;
  PVMat3x3 cR;
  float cs;

  if ((Flags&COLLISION_NO_REPORT) && (TotalContacts>0)) return COOL;

  d[0] = s * b2->d[0];
  d[1] = s * b2->d[1];
  d[2] = s * b2->d[2];
  f1 = OBBDisjoint(R, T, b1->d, d);

  if (f1 != 0) return COOL;		// On zap, elle sont disjointes

  if(Leaf(b1) && Leaf(b2))
  {
	  if(Flags&COLLISION_FAST)
	  {
		  TotalContacts++;
		  return COOL;
	  }
	  else
	  {
		  return TriContactBox(b1, b2);
	  }
  }

  if(Leaf(b2) || (!Leaf(b1) && (b1->d[0] > b2->d[0])))
  {
	  MTxM(cR, b1->N->pR, R);
	  VmV(&U, T, &b1->N->pT); MTxV(&cT, b1->N->pR, &U);
	  cs = s;

	  if ((rc=CollideRecursive(b1->N, b2, cR, &cT, cs))!=COOL) return rc;

	  MTxM(cR, b1->P->pR, R);
	  VmV(&U, T, &b1->P->pT); MTxV(&cT, b1->P->pR, &U);
	  cs = s;

	  if ((rc=CollideRecursive(b1->P, b2, cR, &cT, cs))!=COOL) return rc;

	  return COOL;
	}
    else
	{
	  MxM(cR, R, b2->N->pR); sMxVpV(&cT, s, R, &b2->N->pT, T);
	  cs = s;

	  if ((rc=CollideRecursive(b1, b2->N, cR, &cT, cs))!=COOL) return rc;

	  MxM(cR, R, b2->P->pR); sMxVpV(&cT, s, R, &b2->P->pT, T);
	  cs = s;

	  if ((rc=CollideRecursive(b1, b2->P, cR, &cT, cs))!=COOL) return rc;

	  return COOL;
	}

	// Unreachable
	return COOL;
}

static int PV_Collide(PVMat3x3 R1, PVPoint *T1, float s1, void *Tree1,
	      PVMat3x3 R2, PVPoint *T2, float s2, void *Tree2,
	      PVFLAGS flags)
{

  PVObbt *b1,*b2;
  PVMat3x3 tR1, tR2, R;
  static PVPoint tT1, tT2, T, U;
  float s;
  int hr;

  zTree1=(PVCollideMesh*)Tree1;
  zTree2=(PVCollideMesh*)Tree2;
  Flags=flags;

  b1=zTree1->Root;
  b2=zTree2->Root;

  MxM(tR1, R1, b1->pR);
  sMxVpV(&tT1, s1, R1, &b1->pT, T1);
  MxM(tR2, R2, b2->pR);
  sMxVpV(&tT2, s2, R2, &b2->pT, T2);

  MTxM(R, tR1, tR2);
  VmV(&U, &tT2, &tT1);  sMTxV(&T, 1.0/s1, tR1, &U);

  s = s2/s1;

  MTxM(mR, R2, R1);
  VmV(&U, T1, T2);  sMTxV(&mT, 1.0/s2, R2, &U);
  ms = s1/s2;

  // Set les champs globaux
  TotalContacts=0;
  NbrReported=0;

  hr=CollideRecursive(b1, b2, R, &T, s);
  if(hr!=COOL) return -hr;
  return TotalContacts;
}

/////////////////////////////// API utilisateur

int PVAPI PV_CollisionTest(PVMesh *m1,PVMesh *m2,PVFLAGS flags)
{
  	PVPoint T1,T2;
	PVPoint A;
    int hr;

    if(m1==NULL) return ARG_INVALID;
    if(m2==NULL) return ARG_INVALID;
    if(m1==m2) return ARG_INVALID;
	if(m1->Owner==NULL) return ARG_INVALID;
	if(m2->Owner==NULL) return ARG_INVALID;
    if(m1->CollideInfo==NULL) return NO_COLLISIONINFO;
    if(m2->CollideInfo==NULL) return NO_COLLISIONINFO;

	PV_ComputeMeshToWorldMatrix(m1);
	PV_ComputeMeshToWorldMatrix(m2);

    T1.xf=m1->WorldPos.xf+m1->Pivot.xf;
    T1.yf=m1->WorldPos.yf+m1->Pivot.yf;
    T1.zf=m1->WorldPos.zf+m1->Pivot.zf;
	RotatePoint3x3(&m1->Pivot,m1->WorldMatrix,&A);
	T1.xf-=A.xf;
	T1.yf-=A.yf;
	T1.zf-=A.zf;

    T2.xf=m2->WorldPos.xf+m2->Pivot.xf;
    T2.yf=m2->WorldPos.yf+m2->Pivot.yf;
    T2.zf=m2->WorldPos.zf+m2->Pivot.zf;
	RotatePoint3x3(&m2->Pivot,m2->WorldMatrix,&A);
	T2.xf-=A.xf;
	T2.yf-=A.yf;
	T2.zf-=A.zf;

	hr=PV_Collide(m1->WorldMatrix, &T1, m1->ScaleX,m1->CollideInfo, m2->WorldMatrix, &T2,m2->ScaleX, m2->CollideInfo, flags);
	if(hr<0) return -hr;
	if(hr!=0) return COLLIDE_YES; else return COLLIDE_NO;
}

PVCollidingFaces *PVAPI PV_GetCollisionTable(void)
{
    return (PVCollidingFaces*)Report;
}

unsigned PVAPI PV_GetNbrCollision(void)
{
	return TotalContacts;
}

int PVAPI PV_MeshComputeCollisionTree(PVMesh *m)
{
	unsigned NbrTris=0,i,n,j,NbrBoxes;
	PVObbt *Boxes;
	PVMoment *Moments,Accum;
	unsigned *Tris,*Index;
	double z;
	PVMat3x3 C;

	if(m==NULL) return ARG_INVALID;
	if(m->NbrFaces==0) return ARG_INVALID;
	if(m->CollideInfo!=NULL) PV_MeshKillCollisionTree(m);

	// Compte le nombre de triangles total
	for(i=0;i<m->NbrFaces;i++) NbrTris+=m->Face[i].NbrVertices-2;

	// Allocationne le buffer
	Tris=(unsigned *)malloc(4*sizeof(unsigned)*NbrTris);
	if(Tris==NULL) return NO_MEMORY;
	Index=(unsigned *)malloc(sizeof(unsigned)*NbrTris);
	if(Index==NULL)
	{
		free(Tris);
		return NO_MEMORY;
	}

	// Fill le buffer avec la version triangulis� du mesh
	for(i=0,n=0;i<m->NbrFaces;i++)
	{
		for(j=1;j<m->Face[i].NbrVertices-1;j++)
		{
			Tris[n*4]=m->Face[i].V[0];
			Tris[n*4+1]=m->Face[i].V[j];
			Tris[n*4+2]=m->Face[i].V[j+1];
			Tris[n*4+3]=(unsigned)&m->Face[i];
			n++;
		}
	}

	///////// Build l'arbre
	NbrBoxes=NbrTris*2;
	Boxes=(PVObbt *)calloc(NbrBoxes,sizeof(PVObbt));
	if(Boxes==NULL)
	{
		free(Tris);
		free(Index);
		return NO_MEMORY;
	}

	// Calcul de l'orientation initial et de l'axe de split
	Moments=(PVMoment*)malloc(NbrTris*sizeof(PVMoment));
	if(Moments==NULL)
	{
		free(Tris);
		free(Boxes);
		free(Index);
		return NO_MEMORY;
	}

	CalcMoments(Tris,Moments,NbrTris,m);

	memset(&Accum,0,sizeof(PVMoment));

	for(i=0;i<NbrTris;i++)
	{
		Accum.A += Moments[i].A;
		Accum.m.xf+=Moments[i].m.xf*Moments[i].A;
		Accum.m.yf+=Moments[i].m.yf*Moments[i].A;
		Accum.m.zf+=Moments[i].m.zf*Moments[i].A;

		Accum.s[0][0] += Moments[i].s[0][0];
		Accum.s[0][1] += Moments[i].s[0][1];
		Accum.s[0][2] += Moments[i].s[0][2];
		Accum.s[1][0] += Moments[i].s[1][0];
		Accum.s[1][1] += Moments[i].s[1][1];
		Accum.s[1][2] += Moments[i].s[1][2];
		Accum.s[2][0] += Moments[i].s[2][0];
		Accum.s[2][1] += Moments[i].s[2][1];
		Accum.s[2][2] += Moments[i].s[2][2];
	}

	// Les calculs serieux commencent
	// Mean PVPoint
	z=1/Accum.A;
	Boxes[0].pT.xf=Accum.m.xf*z;
	Boxes[0].pT.yf=Accum.m.yf*z;
	Boxes[0].pT.zf=Accum.m.zf*z;

	// Covariance
	C[0][0]=Accum.s[0][0]-Accum.m.xf*Accum.m.xf*z;
	C[0][1]=Accum.s[0][1]-Accum.m.xf*Accum.m.yf*z;
	C[0][2]=Accum.s[0][2]-Accum.m.xf*Accum.m.zf*z;
	C[1][0]=Accum.s[1][0]-Accum.m.yf*Accum.m.xf*z;
	C[1][1]=Accum.s[1][1]-Accum.m.yf*Accum.m.yf*z;
	C[1][2]=Accum.s[1][2]-Accum.m.yf*Accum.m.zf*z;
	C[2][0]=Accum.s[2][0]-Accum.m.zf*Accum.m.xf*z;
	C[2][1]=Accum.s[2][1]-Accum.m.zf*Accum.m.yf*z;
	C[2][2]=Accum.s[2][2]-Accum.m.zf*Accum.m.zf*z;

	eigen_and_sort1(Boxes[0].pR, C);

	// Creation d'un index
	for(i=0;i<NbrTris;i++) Index[i]=i;

	// Yoo!!!
	zMoments=Moments;
	zTris=Tris;
	zMesh=m;
	zBoxes=Boxes;
	NbrBoxUsed=1;
	i=SplitRecurse(&Boxes[0],Index,NbrTris);
	if(i!=COOL)
	{
		free(Boxes);
		free(Moments);
		free(Index);
		free(Tris);
		return i;
	}

	free(Moments);
	free(Index);

	m->CollideInfo=(void*)malloc(sizeof(PVCollideMesh));
	if(m->CollideInfo==NULL)
	{
		free(Tris);
		free(Boxes);
		return NO_MEMORY;
	}	

	((PVCollideMesh*)m->CollideInfo)->Tris=Tris;
	((PVCollideMesh*)m->CollideInfo)->Root=Boxes;
	((PVCollideMesh*)m->CollideInfo)->Father=m;

	debug(printf("Collision tree for %s : Nbr tris %u, Nbr Boxes alloced/used %u/%u\n",m->Name,NbrTris,NbrBoxes,NbrBoxUsed););	

	return COOL;
}

void PVAPI PV_MeshKillCollisionTree(PVMesh *m)
{
    PVCollideMesh *c;

	if(m==NULL) return;
	
    if(m->CollideInfo!=NULL) 
	{
		c=(PVCollideMesh*)m->CollideInfo;
		free(c->Tris);
		free(c->Root);
		free(c);
	}
    m->CollideInfo=NULL;
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <stdlib.h>
#include <string.h>
#include "pvision.h"
#include "sb.h"

static PVHardwareDriver *HardwareDriver=NULL;
static PVHardwareCaps *Caps=NULL;

static int PVAPI MeshIterator1(PVMesh *m,int j)
{
	unsigned i;

	for(i=0;i<m->NbrFaces;i++)  if(m->Face[i].LightMap!=NULL) PV_GetHardwareDriver()->DeleteLightMap(m->Face[i].LightMap);

	return COOL;
}

static int PVAPI MeshIterator2(PVMesh *m,int j)
{
	unsigned i;
	
	for(i=0;i<m->NbrFaces;i++)  
	{
		if(m->Face[i].LightMap!=NULL)
		{
			PV_SetLightMapExtent(&m->Face[i],0,m->Face[i].LightMap);
			PV_GetHardwareDriver()->LoadLightMap(m->Face[i].LightMap);
		}
	}

	return COOL;
}

int PVAPI PV_SwitchHardwareDriver(PVHardwareDriver *hd,PVWorld *w,PVMaterial **mattab,unsigned nbrmat,long i)
{
	unsigned h,h2;
	PVMaterial *m;

	// Kill les materiaux	
	if(w!=NULL)
	{
		m=w->Materials;
		while(m!=NULL)
		{
			PV_GetHardwareDriver()->DeleteTexture(m);
			m=m->Next;
		}

		PV_IterateMeshList(w->Objs,MeshIterator1,0);
	}

	for(h=0;h<nbrmat;h++) PV_GetHardwareDriver()->DeleteTexture(mattab[h]);

	PV_EndAccelSupport();
	h=PV_SetHardwareDriver(hd);
	if(h!=COOL) return h;

	h=PV_InitAccelSupport(i);
	if(h!=COOL) return h;

	// Recompile les materiaux
	if(w!=NULL)
	{
		m=w->Materials;
		while(m!=NULL)
		{
			h=PV_GetHardwareDriver()->LoadTexture(m);
			if(h!=COOL) return h;

			m->Filler=(void (PVAPI *)(PVFace*))PV_GetFiller(m->Type);
			m=m->Next;
		}

		PV_IterateMeshList(w->Objs,MeshIterator2,0);
	}

	for(h=0;h<nbrmat;h++) 
	{
		h2=PV_GetHardwareDriver()->LoadTexture(mattab[h]);
		if(h2!=COOL) return h2;

		mattab[h]->Filler=(void (PVAPI *)(PVFace*))PV_GetFiller(mattab[h]->Type);
	}

	return COOL;
}

int PVAPI PV_SetHardwareDriverWithoutDetect(PVHardwareDriver *hd)
{
	if(hd==NULL) return ARG_INVALID;

	// Tests driver
	if(hd->MagicNumber!=PV_MN2) return INVALID_DRIVER;
	if(hd->Detect==NULL) return INVALID_DRIVER;
	if(hd->InitSupport==NULL) return INVALID_DRIVER;
	if(hd->EndSupport==NULL) return INVALID_DRIVER;
	if(hd->SetViewPort==NULL) return INVALID_DRIVER;
	if(hd->LoadTexture==NULL) return INVALID_DRIVER;
	if(hd->DeleteTexture==NULL) return INVALID_DRIVER;
	if(hd->GetFiller==NULL) return INVALID_DRIVER;
	if(hd->PreRender==NULL) return INVALID_DRIVER;
	if(hd->PrepareFace==NULL) return INVALID_DRIVER;
	if(hd->PostRender==NULL) return INVALID_DRIVER;
	if(hd->BeginFrame==NULL) return INVALID_DRIVER;
	if(hd->EndFrame==NULL) return INVALID_DRIVER;
	if(hd->FlipSurface==NULL) return INVALID_DRIVER;
	if(hd->FillSurface==NULL) return INVALID_DRIVER;
	if(hd->RefreshMaterial==NULL) return INVALID_DRIVER;
	if(hd->GetInfo==NULL) return INVALID_DRIVER;

	HardwareDriver=hd;
	return COOL;
}

int PVAPI PV_SetHardwareDriver(PVHardwareDriver *hd)
{
	if(hd==NULL) return ARG_INVALID;

	// Tests driver
	if(hd->MagicNumber!=PV_MN2) return INVALID_DRIVER;
	if(hd->Detect==NULL) return INVALID_DRIVER;
	if(hd->InitSupport==NULL) return INVALID_DRIVER;
	if(hd->EndSupport==NULL) return INVALID_DRIVER;
	if(hd->SetViewPort==NULL) return INVALID_DRIVER;
	if(hd->LoadTexture==NULL) return INVALID_DRIVER;
	if(hd->DeleteTexture==NULL) return INVALID_DRIVER;
	if(hd->GetFiller==NULL) return INVALID_DRIVER;
	if(hd->PreRender==NULL) return INVALID_DRIVER;
	if(hd->PrepareFace==NULL) return INVALID_DRIVER;
	if(hd->PostRender==NULL) return INVALID_DRIVER;
	if(hd->BeginFrame==NULL) return INVALID_DRIVER;
	if(hd->EndFrame==NULL) return INVALID_DRIVER;
	if(hd->FlipSurface==NULL) return INVALID_DRIVER;
	if(hd->FillSurface==NULL) return INVALID_DRIVER;
	if(hd->RefreshMaterial==NULL) return INVALID_DRIVER;
	if(hd->GetInfo==NULL) return INVALID_DRIVER;

	if (hd->Detect())
	{
		HardwareDriver=hd;
		return COOL;
	}
	else return NO_ACCELSUPPORT;
}

int PVAPI PV_SetHardwareDevice(unsigned id)
{
	if(HardwareDriver!=NULL)
		if(HardwareDriver->SetCurrentDevice!=NULL) return HardwareDriver->SetCurrentDevice(id);
	
	return ARG_INVALID;
}

int PVAPI PV_InitAccelSupport(long i)
{
	int b;
	if (HardwareDriver!=NULL)
	{
		b=HardwareDriver->InitSupport(i);
		return b;
	}
	else return NO_ACCELSUPPORT;
}

void PVAPI PV_EndAccelSupport(void)
{
	if (HardwareDriver!=NULL)
	{
		HardwareDriver->EndSupport();
	}
}

int PVAPI PV_FlipSurface(void)
{
	if (HardwareDriver!=NULL)
	{
		return HardwareDriver->FlipSurface();
	}
	else return NO_ACCELSUPPORT;
}

int PVAPI PV_FillSurface(unsigned surfacenum,float r,float g,float b,float a)
{
	if (HardwareDriver!=NULL)
	{
		return HardwareDriver->FillSurface(surfacenum,r,g,b,a);
	}
	else return NO_ACCELSUPPORT;
}

void PVAPI PV_BeginFrame(void)
{
	unsigned i;

	if(PV_Mode&PVM_USEHARDWARE)
	{
		if (HardwareDriver!=NULL)
		{
			HardwareDriver->BeginFrame(PV_Mode,PV_GetPipelineControl());
		}
	}
	else
	{    
        // Clear le SBuffer si needed
        if(PV_Mode&PVM_SBUFFER)
        {	
            if(SBufferN==SBUFFER_BLOCK_SEG)				// Pour la premiere fois seulement
			{				
				SBufferCurrentBlock=0;
				SBufferCurrentSeg=SBufferBlocks[0];
			}
			else
			{
				SBufferCurrentSeg=SBufferBlocks[0];
				SBufferN=0;					
				SBufferCurrentBlock=1;
				for(i=0;i<SBufferSize;i++) SBuffer[i]=NULL;
			}
        }

		if((PV_Mode&PVM_ZBUFFER)&&(!(PV_GetPipelineControl()&PVP_NO_ZBUFFERCLEAR))) PV_ClearZBuffer();			
	}
}

void PVAPI PV_EndFrame(void)
{
	if (HardwareDriver!=NULL)
	{
		HardwareDriver->EndFrame();
	}
}

PVHardwareDriver * PVAPI PV_GetHardwareDriver(void)
{
	return HardwareDriver;
}

void PVAPI PV_RefreshMaterial(PVMaterial *m)
{
	if(m==NULL) return;
	
	m->Filler=(void (PVAPI *)(PVFace*))PV_GetFiller(m->Type);
	
	if (HardwareDriver!=NULL)
	{
		HardwareDriver->RefreshMaterial(m);
	}
}

void PVAPI PV_GetHardwareInfo(PVHardwareCaps *caps)
{
	if (HardwareDriver!=NULL)
	{
		memcpy(caps,HardwareDriver->GetInfo(),HardwareDriver->SizeOfCaps);
	}
}

void * PVAPI PV_LockFrameBuffer(unsigned surfacenum,PVFLAGS mode)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->LockFB==NULL) return NULL;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_FRAMEBUFFER)
			return HardwareDriver->LockFB(surfacenum,mode);
	}
	return NULL;
}

void PVAPI PV_UnLockFrameBuffer(unsigned surfacenum,PVFLAGS mode)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->UnLockFB==NULL) return;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_FRAMEBUFFER)
			HardwareDriver->UnLockFB(surfacenum,mode);
	}
}

void * PVAPI PV_LockDepthBuffer(PVFLAGS mode)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->LockDB==NULL) return NULL;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_DEPTHBUFFER)
				return HardwareDriver->LockDB(mode);		
	}
	return NULL;
}

void PVAPI PV_UnLockDepthBuffer(PVFLAGS mode)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->UnLockDB==NULL) return;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_DEPTHBUFFER)
			HardwareDriver->UnLockDB(mode);
	}
}

void * PVAPI PV_LockAlphaBuffer(PVFLAGS mode)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->LockAB==NULL) return NULL;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_ALPHABUFFER)
			return HardwareDriver->LockAB(mode);
	}
	return NULL;
}

void PVAPI PV_UnLockAlphaBuffer(PVFLAGS mode)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->UnLockAB==NULL) return;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_ALPHABUFFER)
			HardwareDriver->UnLockAB(mode);
	}
}

int PVAPI PV_BitBltFrameBuffer(unsigned surfacenum,unsigned xdest,unsigned ydest,void *src,unsigned width, unsigned height,unsigned stride)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->BitBltFB==NULL) return ACCEL_FUNCTION_UNSUPPORTED;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_BITBLTFB)
			return HardwareDriver->BitBltFB(surfacenum,xdest,ydest,src,width,height,stride);
		else
			return ACCEL_FUNCTION_UNSUPPORTED;
	}
	return NO_ACCELSUPPORT;
}

int PVAPI PV_BitBltDepthBuffer(unsigned xdest,unsigned ydest,void *src,unsigned width, unsigned height,unsigned stride)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->BitBltDB==NULL) return ACCEL_FUNCTION_UNSUPPORTED;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_BITBLTDB)
			return HardwareDriver->BitBltDB(xdest,ydest,src,width,height,stride);
		else
			return ACCEL_FUNCTION_UNSUPPORTED;
	}
	return NO_ACCELSUPPORT;
}

int PVAPI PV_BitBltAlphaBuffer(unsigned xdest,unsigned ydest,void *src,unsigned width, unsigned height,unsigned stride)
{
	if (HardwareDriver!=NULL)
	{
		if(HardwareDriver->BitBltAB==NULL) return ACCEL_FUNCTION_UNSUPPORTED;
		Caps=HardwareDriver->GetInfo();
		if (Caps->FrameCaps&PHF_BITBLTAB)
			return HardwareDriver->BitBltAB(xdest,ydest,src,width,height,stride);
		else
			return ACCEL_FUNCTION_UNSUPPORTED;
	}
	return NO_ACCELSUPPORT;
}

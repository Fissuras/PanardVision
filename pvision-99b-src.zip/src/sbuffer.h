/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <malloc.h>
#include <stdlib.h>

// Sbuffer
#define SBuffer(HLRoutine,IncRoutine)\
		if((XD-XG)==0) goto StepIt;                                                                                                                                                           \
                                                                                                                                                                                                        \
                /* Allocation d'un nouvo bloc de 512 segments si nescessaire*/                                                                                                                          \
                if (SBufferN==SBUFFER_BLOCK_SEG)                                                                                                                                                        \
                {                                                                                                                                                                                       \
                    if(SBufferCurrentBlock>=SBufferNbrBlocksAllocated) PV_Fatal("SBuffering: Internal error, not enough blocks.",BIZAR_ERROR);                                                          \
                    if(SBufferBlocks[SBufferCurrentBlock]==NULL)                                                                                                                                        \
                        if ((SBufferBlocks[SBufferCurrentBlock]=(TSBuffer*)malloc(sizeof(TSBuffer)*SBUFFER_BLOCK_SEG))==NULL) PV_Fatal("SBuffering : Not enough memory for SBuffering.",NO_MEMORY);     \
                    SBufferN=0;                                                                                                                                                                         \
                    SBufferCurrentSeg=SBufferBlocks[SBufferCurrentBlock];                                                                                                                               \
                    SBufferCurrentBlock++;                                                                                                                                                              \
                }                                                                                                                                                                                       \
                                                                                                                                                                                                        \
                b=*FSB;                                                                                                                                                                                 \
                LastSeg=NULL;                                                                                                                                                                           \
                                                                                                                                                                                                        \
                /* Gestion SBuffering putain ce ke c'est lourd ! */                                                                                                                                       \
                while(b!=NULL)                                                                                                                                                                          \
                {                                                                                                                                                                                       \
                    /* Segment contenu dans un autre, on gicle   */                                                                                                                                       \
                    if ((XG>=b->XStart)&&(XD<=b->XEnd+1)) goto StepIt;                                                                                                                                \
                                                                                                                                                                                                        \
                    /* Seg Bout a bout par l'avant  */                                                                                                                                                    \
                    if (XD==b->XStart)                                                                                                                                                                 \
                    {                                                                                                                                                                                   \
                        HLRoutine(XG,XD);                                                                                                                                                          \
                        b->XStart=XG;                                                                                                                                                                  \
                        goto StepIt;                                                                                                                                                                    \
                    }                                                                                                                                                                                   \
                                                                                                                                                                                                        \
                    /* Chevauchement avant   */                                                                                                                                                           \
                    if ((XD>b->XStart)&&(XG<b->XStart))                                                                                                                                               \
                    {                                                                                                                                                                                   \
                        /* Trace le debut   */                                                                                                                                                            \
                        HLRoutine(XG,b->XStart);                                                                                                                                                    \
                                                                                                                                                                                                        \
                        tmp=b->XStart;                                                                                                                                                                  \
                        b->XStart=XG;                                                                                                                                                                  \
                                                                                                                                                                                                        \
                        /* Matte si depasse le segment courant ou pas */                                                                                                                                  \
                        if (XD>=b->XEnd+2)                                                                                                                                                             \
                        {                                                                                                                                                                               \
                            /* Stepping      */                                                                                                                                                           \
                            IncRoutine(b->XEnd,tmp);                                                                                                                                                    \
BackChevauch:                                                                                                                                                                                           \
                            /* verifie si ca atteint le debut de l'autre segment   */                                                                                                                     \
                            if ((b->Next!=NULL)&&(XD>=b->Next->XStart))                                                                                                                                \
                            {                                                                                                                                                                           \
                                /* oui Trace le seg  */                                                                                                                                                   \
                                HLRoutine(b->XEnd+1,b->Next->XStart);                                                                                                                                \
                                                                                                                                                                                                        \
                                /* On supprime le segment suivant de la liste */                                                                                                                          \
                                tmp=b->Next->XStart;                                                                                                                                                    \
                                b->XEnd=b->Next->XEnd;                                                                                                                                                  \
                                b->Next=b->Next->Next;                                                                                                                                                  \
                                                                                                                                                                                                        \
                                /* Reste il un morco ?  */                                                                                                                                                \
                                XG=b->XEnd+1;                                                                                                                                                          \
                                if (XD<=XG) goto StepIt;                                                                                                                                              \
                                else                                                                                                                                                                    \
                                {                                                                                                                                                                       \
                                    /* Stepping */                                                                                                                                                        \
                                    IncRoutine(b->XEnd,tmp);                                                                                                                                                    \
                                }                                                                                                                                                                       \
                            }                                                                                                                                                                           \
                            else                                                                                                                                                                        \
                            {                                                                                                                                                                           \
                                /* non Trace le debut */                                                                                                                                                  \
                                HLRoutine(b->XEnd+1,XD);                                                                                                                                            \
                                                                                                                                                                                                        \
                                b->XEnd=XD-1;                                                                                                                                                          \
                                goto StepIt;                                                                                                                                                            \
                            }                                                                                                                                                                           \
                        }                                                                                                                                                                               \
                        else goto StepIt;                                                                                                                                                               \
                    }                                                                                                                                                                                   \
                                                                                                                                                                                                        \
                    /* Chevauchement Arriere */                                                                                                                                                           \
                    if ((XG<=b->XEnd)&&(XD>=b->XEnd+2))                                                                                                                                               \
                    {                                                                                                                                                                                   \
                        /* Stepping */                                                                                                                                                                    \
                        IncRoutine(b->XEnd,XG);                                                                                                                                                    \
                                                                                                                                                                                                        \
                        goto BackChevauch;                                                                                                                                                              \
                    }                                                                                                                                                                                   \
                                                                                                                                                                                                        \
                    /* Seg Bout a bout par l'arriere */                                                                                                                                                   \
                    if (XG==b->XEnd+1) goto BackChevauch;                                                                                                                                              \
                                                                                                                                                                                                        \
                    /* Ajout en tete, aucun pt commun */                                                                                                                                                  \
                    if (XD<b->XStart)                                                                                                                                                                  \
                    {                                                                                                                                                                                   \
                        /* Cr�ation seg */                                                                                                                                                                \
                        SBufferCurrentSeg->XStart=XG;                                                                                                                                                  \
                        SBufferCurrentSeg->XEnd=XD-1;                                                                                                                                                  \
                        SBufferCurrentSeg->Next=b;                                                                                                                                                      \
                                                                                                                                                                                                        \
                        if (LastSeg!=NULL )LastSeg->Next=SBufferCurrentSeg;                                                                                                                             \
                        else *FSB=SBufferCurrentSeg;                                                                                                                                                    \
                                                                                                                                                                                                        \
                        SBufferCurrentSeg++;                                                                                                                                                            \
                        SBufferN++;                                                                                                                                                                     \
                                                                                                                                                                                                        \
                        /* Trace */                                                                                                                                                                       \
                        HLRoutine(XG,XD);                                                                                                                                                          \
                                                                                                                                                                                                        \
                        goto StepIt;                                                                                                                                                                    \
                    }                                                                                                                                                                                   \
                                                                                                                                                                                                        \
                    LastSeg=b;                                                                                                                                                                          \
                    b=b->Next;                                                                                                                                                                          \
                }                                                                                                                                                                                       \
                                                                                                                                                                                                        \
                /* On a rien trouve de tout ca, on rajoute le segment  */                                                                                                                                 \
                SBufferCurrentSeg->XStart=XG;                                                                                                                                                          \
                SBufferCurrentSeg->XEnd=XD-1;                                                                                                                                                          \
                SBufferCurrentSeg->Next=NULL;                                                                                                                                                           \
                                                                                                                                                                                                        \
                if (LastSeg!=NULL )LastSeg->Next=SBufferCurrentSeg;                                                                                                                                     \
                else *FSB=SBufferCurrentSeg;                                                                                                                                                            \
                                                                                                                                                                                                        \
                SBufferCurrentSeg++;                                                                                                                                                                    \
                SBufferN++;                                                                                                                                                                             \
                                                                                                                                                                                                        \
                /* Trace */                                                                                                                                                                               \
                HLRoutine(XG,XD);


/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <malloc.h>
#include <string.h>
#include "fillcom.h"

/*-------------------------------- Variables communes ----------------------*/
PVD32 col;

UPVD8 *Texture;
unsigned ShiftWidth;
unsigned AndWidth,AndHeight;

UPVD8 *AuxiliaryTex;
unsigned ShiftWidthA;
unsigned AndWidthA,AndHeightA;

UPVD8 *LineMapLightTransTable;
UPVD16 *LineMapLightTransTable16;
UPVD8 *MapLightTranslateTable;
UPVD16 *MapLightTranslateTable16;

PVBumpInfo *BumpMap;

UPVD8 *ofs;
UPVD16 *ofs16;

void (__cdecl *HLineRoutine)(unsigned, unsigned);

void (*IncRoutine)(unsigned,unsigned);

PVRGBF *RGBAmbientLight;
PVRGBF RGBFlatColor;

/*--------------------------------------------------------------------------*/

extern FillerUserFunct AffineMapping,Flat,Gouraud,GouraudAffineMapping,AmbientAffineMapping,PerspectiveMapping,GouraudPerspectiveMapping,PerspectiveAmbientMapping,RGBGouraudAffineMapping,RGBTextureMapping,RGBFlatMapping,RGBGouraud,RGBFlat,
                       FastPerspectiveTextureMapping,RGBPerspectiveTextureMapping,RGBFlatPerspectiveMapping,RGBGouraudPerspectiveMapping;

void PVAPI TriNULL(PVFace *f)
{
    f=f;
}

void PVAPI TriAffineMapping(PVFace *f)
{
    GenFiller(f,&AffineMapping);
}

void PVAPI TriFlat(PVFace *f)
{
    GenFiller(f,&Flat);
}

void PVAPI TriGouraud(PVFace *f)
{
    GenFiller(f,&Gouraud);
}

void PVAPI TriGouraudAffineMapping(PVFace *f)
{
    GenFiller(f,&GouraudAffineMapping);
}

void PVAPI TriAmbientAffineMapping(PVFace *f)
{
    GenFiller(f,&AmbientAffineMapping);
}

void PVAPI TriPerspectiveMapping(PVFace *f)
{
    GenFiller(f,&PerspectiveMapping);
}

void PVAPI TriPerspectiveAmbientMapping(PVFace *f)
{
    GenFiller(f,&PerspectiveAmbientMapping);
}

void PVAPI TriGouraudPerspectiveMapping(PVFace *f)
{
    GenFiller(f,&GouraudPerspectiveMapping);
}

//////////////////////////////////////////////////// RGB

void PVAPI TriRGBTextureMapping(PVFace *f)
{
    GenFiller(f,&RGBTextureMapping);
}

void PVAPI TriRGBFlat(PVFace *f)
{
    GenFiller(f,&RGBFlat);
}

void PVAPI TriRGBGouraud(PVFace *f)
{
    GenFiller(f,&RGBGouraud);
}

void PVAPI TriRGBGouraudMapping(PVFace *f)
{
    GenFiller(f,&RGBGouraudAffineMapping);
}

void PVAPI TriRGBFlatMapping(PVFace *f)
{
    GenFiller(f,&RGBFlatMapping);
}

void PVAPI TriRGBPerspectiveMapping(PVFace *f)
{
    GenFiller(f,&RGBPerspectiveTextureMapping);
}

void PVAPI TriRGBPerspectiveFlatMapping(PVFace *f)
{
    GenFiller(f,&RGBFlatPerspectiveMapping);
}

void PVAPI TriRGBPerspectiveGouraudMapping(PVFace *f)
{
    GenFiller(f,&RGBGouraudPerspectiveMapping);
}

////////////////////////////////////////////////////// LIGHT MAP

void PVAPI TriFastPerspectiveMapping(PVFace *f)
{
    GenFiller(f,&FastPerspectiveTextureMapping);
}



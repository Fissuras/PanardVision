/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Heavily stolen from the Texus lib of the 3dfx's glide sdk

#include <stdlib.h>
#include "pvision.h"

#define debug(x)	//x

#define MAX_TEXWIDTH	8192

static unsigned rescol,channel;
static PVFLAGS flags;
static PVRGB *pal;

static int FloorPow2(int n)
{
        // Find next smallest integer which is also a power of 2.

        int             i;

        if ((n & (n -1)) == 0) {
                return n;               // already a power of 2.
        }

        for (i=1; i<= n; i+=i);
        return i>>1;
}

static int CeilPow2(int n)
{
        // Find next smallest integer which is also a power of 2.

        int             i;

        if ((n & (n -1)) == 0) return n;                // already a power of 2.

        for (i=1; i<= n; i+=i);
        return i;
}


/*
 * For resampling in the x direction:
 * Assume ix input pixels become ox output pixels.
 * Imagine that ix input pixels are each divided into ox fragments, for a total
 * of ix * ox fragments.
 * Imagine also that ox output pixels are each divided into ix fragments, for a
 * total of ox * ix fragments, same as before.
 * Initialize an accumulator to 0. Add the first input pixel, multiplied by ox
 * the number of fragments per input pixel. Keep track of the number of 
 * fragments in the accumulator; when this is >= ix, (the number of fragments
 * it takes to make an output pixel), multiply the accumulator by 
 */

static void _txResampleX(UPVD32 *out, UPVD8 *in, int ox, int ix)
{
    UPVD32 accr, accg, accb, acca, r, g, b, a;
    int   i, accf,  nf;

    accf = accr = accg = accb = acca = 0;

    for (i=0; i<ix; i++) 
	{
        if(flags&TEXTURE_RGBA)
		{
			a = (in[i*4+3] );
			r = (in[i*4]   );
			g = (in[i*4+1] );
			b = (in[i*4+2] );
		}
		else
		if(flags&TEXTURE_RGB)
		{
			a = 255;
			r = (in[i*3]   );
			g = (in[i*3+1] );
			b = (in[i*3+2] );
		}
		else
		if(flags&TEXTURE_PALETIZED8)
		{
			a = 255;
			if(pal!=NULL)
			{
			r = (pal[in[i]].r)<<2;
			g = (pal[in[i]].g)<<2;
			b = (pal[in[i]].b)<<2;
			}
			else
			{
				r=g=b=in[i];
			}
		}

		// Each input pixel brings ox fragments
		nf = ox;

		while ((accf + nf) >= ix) 
		{
			int          ef;
			int    oa, or, og, ob;

			// Yes, we have (possibly more than) enough to generate an output 
			// pixel. Of the nf new fragments, use up enough to generate an 
			// output pixel.

			ef = ix - accf;         // the excessive # of fragments.

			acca += a * ef;
            accr += r * ef;
            accg += g * ef;
            accb += b * ef;

			oa = acca / ix;
			or = accr / ix;
			og = accg / ix;
			ob = accb / ix;

			*out++ = (oa << 24) | (or << 16) | (og << 8) | ob;
			
			acca = accr = accg = accb = accf  = 0;
			nf -= ef;
		}

		// If there's any fragments left over, accumulate them.
		if (nf) 
		{
            acca += a * nf;
            accr += r * nf;
            accg += g * nf;
            accb += b * nf;
			accf += nf;
		}
    }    
}

static  UPVD32 AccA[MAX_TEXWIDTH];
static  UPVD32 AccR[MAX_TEXWIDTH];
static  UPVD32 AccG[MAX_TEXWIDTH];
static  UPVD32 AccB[MAX_TEXWIDTH];
static  UPVD32 argb[MAX_TEXWIDTH];

static void _txImgResample(UPVD8 *out, int ox, int oy, UPVD8 *in, int ix, int iy)
{
    int r, g, b, a;
    int   i, j, accf,  nf;
	PVRGB col;

    for (i=0; i<ox; i++) AccA[i] = AccR[i] = AccG[i] = AccB[i] = 0;

    accf = 0;
    for (i=0; i<iy; i++) 
	{
        // Resample a row of input into temporary array.    
		_txResampleX( argb, in, ox, ix);
		in += channel*ix;

		// This row brings in oy fragments per scanline.
		nf = oy;

		while ((accf + nf) >= iy) 
		{
			int ef;

			// Yes, we have (possibly more than) enough to generate an output 
			// pixel. Of the nf new fragments, use up enough to generate an 
			// output pixel.

			ef = iy - accf;         // the excessive # of fragments.

			// A	ccumulate  input * ef + acc, and generate a line of output.
			for (j=0; j<ox; j++) 
			{

                a = (argb[j] & 0xff000000) >> 24;
                r = (argb[j] & 0x00ff0000) >> 16;
                g = (argb[j] & 0x0000ff00) >>  8;
                b = (argb[j] & 0x000000ff)      ;

				AccA[j] += a * ef;
				AccR[j] += r * ef;
				AccG[j] += g * ef;
				AccB[j] += b * ef;

				a = AccA[j] / iy;
				r = AccR[j] / iy;
				g = AccG[j] / iy;
				b = AccB[j] / iy;

				
		        if(flags&TEXTURE_RGBA)
				{
					out[j*4] =b; 
					out[j*4+1] =g;
					out[j*4+2] =r;
					out[j*4+3] =a;
				}
				else
				if(flags&TEXTURE_RGB)
				{
					out[j*3] = b; 
					out[j*3+1] =g;
					out[j*3+2] =r;
				}
				else
				if(flags&TEXTURE_PALETIZED8)
				{
					if(pal!=NULL)
					{
					col.r=r>>2;
					col.g=g>>2;
					col.b=b>>2;
					out[j]=PV_LookClosestColor(pal,col,rescol);
					}
					else
					{
						out[j]=r;
					}
				}

				
				AccA[j] = 0;
				AccR[j] = 0;
				AccG[j] = 0;
				AccB[j] = 0;
			}
			out += channel*ox;
			accf = 0;
			nf  -= ef;
		}
		
		if (nf) 
		{
			for (j=0; j<ox; j++) 
			{
                a = (argb[j] & 0xff000000) >> 24;
                r = (argb[j] & 0x00ff0000) >> 16;
                g = (argb[j] & 0x0000ff00) >>  8;
                b = (argb[j] & 0x000000ff)      ;

				AccA[j] += a * nf;
				AccR[j] += r * nf;
				AccG[j] += g * nf;
				AccB[j] += b * nf;
			}
			accf += nf;
		}
    }
}

PVTexture *PVAPI PV_MipResample(UPVD8 *mip, unsigned width,unsigned height,char grow,PVFLAGS texflags,PVRGB *Pal,unsigned reserved)
{
		UPVD8 *nmip;
		unsigned nwidth,nheight;
		static PVTexture ot;

		if(mip==NULL) return NULL;
		
		ot.Width=width;
		ot.Height=height;
		ot.Texture=mip;	

		// Test si deja puissance de 2
	    if(((width&(-width))==width)&&((height&(-height))==height))  return &ot;		
				
		if(grow)
		{
			nwidth=CeilPow2(width);
			nheight=CeilPow2(height);
		}
		else
		{
			nwidth=FloorPow2(width);
			nheight=FloorPow2(height);
		}
		ot.Width=nwidth;
		ot.Height=nheight;

		flags=texflags;
		
		if(flags&TEXTURE_PALETIZED8) channel=1;
		else
		if(flags&TEXTURE_RGB) channel=3;
		else
		if(flags&TEXTURE_RGBA) channel=4;

		if(nwidth==0) nwidth=1;
		if(nheight==0) nheight=1;

		nmip=(UPVD8*)malloc(nwidth*nheight*channel*sizeof(UPVD8));
		if(nmip==NULL) return NULL;
		ot.Texture=nmip;

		pal=Pal;
		rescol=reserved;
		flags=texflags;		

		debug(printf("_ Resizing from %ux%u to %ux%u\n",width,height,nwidth,nheight););
                
        _txImgResample (nmip, nwidth, nheight, mip, width, height);

		return &ot;
}

PVTexture *PVAPI PV_MipResample2(UPVD8 *mip, unsigned width,unsigned height,unsigned newwidth,unsigned newheight,PVFLAGS texflags,PVRGB *Pal,unsigned reserved)
{
		UPVD8 *nmip;
		unsigned nwidth,nheight;
		static PVTexture ot;

		if(mip==NULL) return NULL;
		
		ot.Width=width;
		ot.Height=height;
		ot.Texture=mip;	

		// Test si meme taille
		if((newwidth==width)&&(newheight==height)) return &ot;

		// Test si non puissance de 2
	    if(!(((width&(-width))==width)&&((height&(-height))==height)))  return &ot;		

		nwidth=newwidth;
		nheight=newheight;

		ot.Width=nwidth;
		ot.Height=nheight;

		flags=texflags;
		
		if(flags&TEXTURE_PALETIZED8) channel=1;
		else
		if(flags&TEXTURE_RGB) channel=3;
		else
		if(flags&TEXTURE_RGBA) channel=4;

		if(nwidth==0) nwidth=1;
		if(nheight==0) nheight=1;

		nmip=(UPVD8*)malloc(nwidth*nheight*channel*sizeof(UPVD8));
		if(nmip==NULL) return NULL;
		ot.Texture=nmip;

		pal=Pal;
		rescol=reserved;
		flags=texflags;		

		debug(printf("_ Resizing from %ux%u to %ux%u\n",width,height,nwidth,nheight););
                
        _txImgResample (nmip, nwidth, nheight, mip, width, height);

		return &ot;
}

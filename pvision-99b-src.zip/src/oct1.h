//
// oct1.h
//
// Header file for octree color quantization function
//
// Dean Clark
// for Dr. Dobbs Journal
// May 1995
//
#ifndef OCT1_H
#define OCT1_H
#include "config.h"

typedef unsigned char   byte;
typedef unsigned int    uint;
typedef unsigned long   ulong;
typedef byte             bool;


#ifndef True
#define False	0
#define True	1
#endif

//
// RGBType is a simple 8-bit color triple
//
typedef struct {
	byte    r,g,b;                      // The color
} RGBType;

//
// OctnodeType is a generic octree node
//
typedef struct _octnode {
	int     level;                      // Level for this node
	bool    isleaf;                     // TRUE if this is a leaf node
	byte    index;                      // Color table index
	ulong   npixels;                    // Total pixels that have this color
	ulong   redsum, greensum, bluesum;  // Sum of the color components
	struct _octnode *child[8];          // Tree pointers
	struct _octnode *nextnode;          // Reducible list pointer
} OctreeType;

#ifdef __cplusplus
extern "C" {
#endif

OctreeType *CreateOctNode(int level);
void MakePaletteTable(OctreeType *tree, RGBType table[], int *index);
ulong TotalLeafNodes(void);
void ReduceTree(void);
int InsertTree(OctreeType **tree, RGBType *color, uint depth);
byte QuantizeColor(OctreeType *tree, RGBType *color);
void KillOctree(OctreeType *tree);

#ifdef __cplusplus
}
#endif

#endif

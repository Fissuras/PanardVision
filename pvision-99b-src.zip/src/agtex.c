/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include "fillcom.h"

static int __cdecl Init1GMapping(int NumVtx,unsigned *vtx) {
    PVMesh *o=GenFill_CurrentFace->Father;
	unsigned i;

    GenFill_NbrInc=3;

	for(i=0;i<NumVtx;i++)
	{
	    GenFill_InitialValues[i][2]=(float)GetRampIndex(vtx[i],o,GenFill_CurrentFace->MaterialInfo);
	}


	for(i=1;i<NumVtx;i++) if(GenFill_InitialValues[i][2]!=GenFill_InitialValues[i-1][2]) break;
	if(i==NumVtx)
    {
        TriAffineMapping(GenFill_CurrentFace);
        return 1;
    }

    if((GenFill_CurrentFace->Flags&(PHONG|U_PHONG)))
    {
		for(i=0;i<NumVtx;i++)
	    {
		    int a=vtx[i];

			GenFill_InitialValues[i][0]=o->Mapping[a].AmbientU;
        	GenFill_InitialValues[i][1]=o->Mapping[a].AmbientV;

	    }
    }
    else
    {
		for(i=0;i<NumVtx;i++)
	    {
		    int a=vtx[i];

			GenFill_InitialValues[i][0]=o->Mapping[a].u;
        	GenFill_InitialValues[i][1]=o->Mapping[a].v;

	    }
    }
    return 0;
}

static void __cdecl Init2GMapping(int NumVtx) {
 float mu,mv;
 unsigned MipIndex;
 unsigned TextureW,TextureH,i;

    // MipMap
    if((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP))
    {
        mu=fabs(GenFill_GradientX[0]*(GenFill_CurrentFace->MaterialInfo->Tex[0].Width));
        mv=fabs(GenFill_GradientX[1]*(GenFill_CurrentFace->MaterialInfo->Tex[0].Height));
        MipIndex=GetMipMap(GenFill_CurrentFace->MaterialInfo->NbrMipMaps,mu,mv);

        Texture=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].ShiftWidth;
    }
    else
    {
        // No MipMap
        Texture=GenFill_CurrentFace->MaterialInfo->Tex[0].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[0].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[0].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[0].ShiftWidth;
    }

    GenFill_GradientX[0]*=TextureW;
    GenFill_GradientX[1]*=TextureH;
    GenFill_GradientY[0]*=TextureW;
    GenFill_GradientY[1]*=TextureH;
    GenFill_iGradientX[0]=(int)(GenFill_GradientX[0]*65536.0);
    GenFill_iGradientX[1]=(int)(GenFill_GradientX[1]*65536.0);

	for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][0]*=(TextureW);
        GenFill_InitialValues[i][1]*=(TextureH);
    }

	AndHeight=TextureH-1;
    AndWidth=TextureW-1;

    if(PV_Mode&PVM_RGB16)
    {
        MapLightTranslateTable16=GenFill_CurrentFace->MaterialInfo->RGB16TranscodeTable;
        HLineRoutine=HLineGouraudAffineMappingRGB16;
    }
    else
    {
        MapLightTranslateTable=GenFill_CurrentFace->MaterialInfo->PaletteTranscodeTable;
        HLineRoutine=HLineGouraudAffineMapping;
    }

#ifdef __386__
    HLineGouraudAffineMapping_INIT();
#endif
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct GouraudAffineMapping={Init1GMapping,Init2GMapping};



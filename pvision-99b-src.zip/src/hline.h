/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __HLINE_H__
#define __HLINE_H__

#include "pvision.h"

#ifdef __cplusplus
extern "C" {
#endif

void  __cdecl HLineGouraud(unsigned deb,unsigned fin);

void  __cdecl HLineAffineMapping(unsigned deb,unsigned fin);
void  __cdecl HLineAffineFlatMapping(unsigned deb,unsigned fin);
void  __cdecl HLineAffineFlatMappingRGB16(unsigned deb,unsigned fin);
void  __cdecl HLineAffineMapping_INIT(void);

void  __cdecl HLineGouraudAffineMapping(unsigned deb,unsigned fin);
void  __cdecl HLineGouraudAffineMappingRGB16(unsigned deb,unsigned fin);
void  __cdecl HLineGouraudAffineMapping_INIT(void);

void  __cdecl HLineAmbientAffineMapping(unsigned deb,unsigned fin);
void  __cdecl HLineAmbientAffineMappingRGB16(unsigned deb,unsigned fin);
void  __cdecl HLineAmbientAffineMapping_INIT(void);

void  __cdecl HLineBumpMapping(unsigned deb,unsigned fin);
void  __cdecl HLineBumpMappingRGB16(unsigned deb,unsigned fin);
void  __cdecl HLineBump(unsigned deb,unsigned fin);
void  __cdecl HLineBumpRGB16(unsigned deb,unsigned fin);
void  __cdecl HLineBumpMapping_INIT(void);

void  __cdecl HLRGBSetMasks(void);

void  __cdecl HLineRGBFlat16(unsigned deb,unsigned fin);
void  __cdecl HLineRGBFlat24(unsigned deb,unsigned fin);
void  __cdecl HLineRGBFlat32(unsigned deb,unsigned fin);

void  __cdecl HLineRGBTextureMapping_INIT(void);
void  __cdecl HLineRGBTextureMapping16(unsigned deb,unsigned fin);
void  __cdecl HLineRGBTextureMapping24(unsigned deb,unsigned fin);
void  __cdecl HLineRGBTextureMapping32(unsigned deb,unsigned fin);
void  __cdecl HLineRGBTextureMapping16Bi(unsigned deb,unsigned fin);
void  __cdecl HLineRGBTextureMapping24Bi(unsigned deb,unsigned fin);
void  __cdecl HLineRGBTextureMapping32Bi(unsigned deb,unsigned fin);

void  __cdecl HLineRGBGouraud16(unsigned deb,unsigned fin);
void  __cdecl HLineRGBGouraud24(unsigned deb,unsigned fin);
void  __cdecl HLineRGBGouraud32(unsigned deb,unsigned fin);

void  __cdecl HLineRGBFlatMapping_INIT(void);
void  __cdecl HLineRGBFlatMapping16(unsigned deb,unsigned fin);
void  __cdecl HLineRGBFlatMapping24(unsigned deb,unsigned fin);
void  __cdecl HLineRGBFlatMapping32(unsigned deb,unsigned fin);
void  __cdecl HLineRGBFlatMapping16Bi(unsigned deb,unsigned fin);
void  __cdecl HLineRGBFlatMapping24Bi(unsigned deb,unsigned fin);
void  __cdecl HLineRGBFlatMapping32Bi(unsigned deb,unsigned fin);

void  __cdecl HLineRGBGouraudMapping_INIT(void);
void  __cdecl HLineRGBGouraudTextureMapping16(unsigned deb,unsigned fin);
void  __cdecl HLineRGBGouraudTextureMapping24(unsigned deb,unsigned fin);
void  __cdecl HLineRGBGouraudTextureMapping32(unsigned deb,unsigned fin);
void  __cdecl HLineRGBGouraudTextureMapping16Bi(unsigned deb,unsigned fin);
void  __cdecl HLineRGBGouraudTextureMapping24Bi(unsigned deb,unsigned fin);
void  __cdecl HLineRGBGouraudTextureMapping32Bi(unsigned deb,unsigned fin);

void  __cdecl HLineAffineMappingNW(unsigned deb,unsigned fin);

#ifdef __cplusplus
}
#endif

#endif

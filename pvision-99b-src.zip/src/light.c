/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <malloc.h>
#include <math.h>
#include <string.h>
#include "pvision.h"
#include "sqrt.h"

static int NeedToRecompute=0;

static void PVAPI NullCallBack(PVMesh *m,PVLight *l)
{
    char s[255];

    m=m;
    strcpy(s,"You must specify a PV_UserLight function to use the USER_LIGHT flag !\n Light using this flag is ");
    strcat(s,l->Name);
    PV_Fatal(s,l->Type);
}

/***************************************************************************/
/*                             GESTION LUMINEUSE                           */
/***************************************************************************/
void PVAPI PV_RecomputeLight(void)
{
    NeedToRecompute=1;
}

void PVAPI PV_NoRecomputeLight(void)
{
    NeedToRecompute=0;
}

int PVAPI PV_LightRecomputeNeeded(void)
{
    return NeedToRecompute;
}

PVLight * PVAPI PV_CreateLight(PVLightType f,char *name)
{
    PVLight *h;

    h=(PVLight*)calloc(1,sizeof(PVLight));
    if(h!=NULL)
    {
        h->Type=f;
        h->Power.Intensity=1.0;
        h->Color.r=1;
        h->Color.g=1;
        h->Color.b=1;
        h->Name=NULL;
        PV_SetLightSpot(h,(float)PI/4,(float)PI/2,0);
        PV_SetLightName(h,name);
        PV_SetLightPosition(h,0,0,0);
        PV_SetLightTarget(h,0,0,0);
		PV_SetLightDirection(h,0,0,1);
		PV_SetLightRange(h,10);
		h->Attenuation0=1.0;
		h->Attenuation1=0;
		h->Attenuation2=0;

		h->RefCnt=0;

		h->UserLightFunc=NullCallBack;
    }

    return h;
}

int PVAPI PV_SetLightName(PVLight *l,char *n)
{
    if(l==NULL) return ARG_INVALID;

    if(l->Name!=NULL) free(l->Name);
    l->Name=strdup(n);
    if(l->Name==NULL) return NO_MEMORY;

    return COOL;
}

void PVAPI PV_KillLight(PVLight *l)
{
    if(l==NULL) return;
	if(l->RefCnt>0) l->RefCnt--;
	if(l->RefCnt==0)
	{
		free(l->Name);
		free(l);
	}
}

void PVAPI PV_SetLightDirection(PVLight *l,float x,float y,float z)
{
    float tmp;

    if(l==NULL) return;

    if((x==0)&&(y==0)&&(z==0)) return;

    //tmp=1/fsqrt(x*x+y*y+z*z);
	tmp=InvSqrt(x*x+y*y+z*z);
    x*=tmp; y*=tmp; z*=tmp;
    l->Direction.xf=x;
    l->Direction.yf=y;
    l->Direction.zf=z;

    PV_RecomputeLight();
}

static void ComputeDir(PVLight *l)
{
    float a,b,c;
    a=l->Target.xf-l->Position.xf;
    b=l->Target.yf-l->Position.yf;
    c=l->Target.zf-l->Position.zf;
    PV_SetLightDirection(l,a,b,c);
}

void PVAPI PV_SetLightPosition(PVLight *l,float x,float y,float z)
{
    if(l==NULL) return;
    l->Position.xf=x;
    l->Position.yf=y;
    l->Position.zf=z;
    PV_RecomputeLight();
    ComputeDir(l);
}

void PVAPI PV_SetLightTarget(PVLight *l,float x,float y,float z)
{
    if(l==NULL) return;
    l->Target.xf=x;
    l->Target.yf=y;
    l->Target.zf=z;

    PV_RecomputeLight();
    ComputeDir(l);
}

int PVAPI PV_SetLightIntensity(PVLight *l,float x)
{
    if(l==NULL) return COOL;
    if (x<0) return ARG_INVALID;
    if (x>1) return ARG_INVALID;
    l->Power.Intensity=x;
    PV_RecomputeLight();
    return COOL;
}

void PVAPI PV_SetLightType(PVLight *l,PVLightType x)
{
    if(l==NULL) return;
    l->Type=x;
    PV_RecomputeLight();
}

void PVAPI PV_SetLightFlags(PVLight *l,PVFLAGS x)
{
    if(l==NULL) return;
    l->Flags=x;
    PV_RecomputeLight();
}

void PVAPI PV_SetLightRange(PVLight *l,float x)
{
    if(l==NULL) return;
    l->Range=x;
    PV_RecomputeLight();
}

void PVAPI PV_SetLightAttenuation(PVLight *l,float a0,float a1,float a2)
{
    if(l==NULL) return;
    l->Attenuation0=a0;
    l->Attenuation1=a1;
    l->Attenuation2=a2;
    PV_RecomputeLight();
}

void PVAPI PV_SetLightSpot(PVLight *l,float Theta,float Phi,float Falloff)
{
    if(l==NULL) return;
	l->cosPh=cos(Phi/2);
    l->cosTh=cos(Theta/2);
    l->FallOff=Falloff;
    l->Theta=Theta;
    l->Phi=Phi;
	PV_RecomputeLight();
}

void PVAPI PV_SetLightColor(PVLight *l,float r,float g,float b,float a)
{
	if(l==NULL) return;
	l->Color.r=r;
	l->Color.g=g;
	l->Color.b=b;
	l->Color.a=a;
	PV_RecomputeLight();
}

/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef CRC32_H
#define CRC32_H

typedef unsigned uint32;
typedef unsigned char uint8;
typedef unsigned short uint16;

#ifdef __cplusplus
extern "C" {
#endif

extern uint32 CRC32_Array(const uint8 * buf,uint32 buflen);

extern uint32 CRC32_Start(void);
extern uint32 CRC32_Finish(uint32 crc);

extern uint32 CRC32_AddByte(uint32 crc,uint8 b);
extern uint32 CRC32_AddWord(uint32 crc,uint16 w);
extern uint32 CRC32_AddLong(uint32 crc,uint32 w);

#ifdef __cplusplus
}
#endif

#endif


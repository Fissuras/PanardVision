/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#ifndef __PVBREADPRIVATE_H__
#define __PVBREADPRIVATE_H__

#define debug(x) x

// Defs taken from the Flexporter SDK

typedef signed char			sbyte;		//!<	sizeof(sbyte)	must be 1
typedef unsigned char		ubyte;		//!<	sizeof(ubyte)	must be 1
typedef signed short		sword;		//!<	sizeof(sword)	must be 2
typedef unsigned short		uword;		//!<	sizeof(uword)	must be 2
typedef signed int			sdword;		//!<	sizeof(sdword)	must be 4
typedef unsigned int		udword;		//!<	sizeof(udword)	must be 4
typedef float				float32;	//!<	sizeof(float32)	must be 4
typedef double				float64;	//!<	sizeof(float64)	must be 4

// Chunk versions
#define	CHUNK_MAIN_VER			1
#define	CHUNK_MESH_VER			1
#define	CHUNK_LITE_VER			1
#define	CHUNK_TEXM_VER			1
#define	CHUNK_MATL_VER			1

// Mesh flags.
#define	PVB_VFACE				(1<<0)				//!< Mesh has vertex-faces.
#define	PVB_TFACE				(1<<1)				//!< Mesh has texture-faces.
#define	PVB_CFACE				(1<<2)				//!< Mesh has color-faces.
#define PVB_UVW					(1<<3)				//!< UVW's are exported
#define PVB_WDISCARDED			(1<<4)				//!< W is discarded
#define PVB_VERTEXCOLORS		(1<<5)				//!< Vertex colors are exported
#define	PVB_ONEBONEPERVERTEX	(1<<6)				//!< Simple skin with one driving bone/vertex
#define	PVB_CONVEXHULL			(1<<7)				//!< The convex hull has been exported
#define	PVB_BOUNDINGSPHERE		(1<<8)				//!< The bounding sphere has been exported
#define	PVB_INERTIATENSOR		(1<<9)				//!< The inertia tensor has been exported
#define	PVB_QUANTIZEDVERTICES	(1<<10)				//!< Vertices have been quantized
#define	PVB_WORDFACES			(1<<11)				//!< Vertex references within faces are stored as words instead of dwords
#define	PVB_COMPRESSED			(1<<12)				//!< Mesh has been saved in a compression-friendly way
#define	PVB_EDGEVIS				(1<<13)				//!< Edge visibility has been exported

#define	PVB_CONSOLIDATION		(1<<16)				//!< Mesh has been consolidated
#define	PVB_FACENORMALS			(1<<17)				//!< Export normals to faces
#define	PVB_VERTEXNORMALS		(1<<18)				//!< Export normals to vertices
#define	PVB_NORMALINFO			(1<<19)				//!< Export NormalInfo

#define	PVB_FILE_SCENE			0x00001000			//!< Complete 3D scene
#define	PVB_FILE_MOTION			0x00001100			//!< Motion file

//! Light types from MAX. Usual rendering APIs only keep Point, Spot and Directional lights.
#define	LTYPE_OMNI		 0						//!< Omnidirectional		(PointLight)
#define LTYPE_TSPOT		 1						//!< Targeted				(SpotLight)
#define	LTYPE_DIR		 2						//!< Directional			(DirectionalLight)
#define	LTYPE_FSPOT		 3						//!< Free					(SpotLight)
#define	LTYPE_TDIR		 4						//!< Targeted directional	(DirectionalLight)

// Compression type
#define	PVB_COMPRESSION_NONE		 0
#define	PVB_COMPRESSION_ZLIB		 1
#define	PVB_COMPRESSION_BZIP2		 2

struct PVBMainChunk
{
	udword	first_frame;
	udword	last_frame;
	udword	frame_rate;
	udword	delta_time;

	// Background color
	float	back_red;
	float	back_green;
	float	back_blue;

	// Global ambient color
	float	ambient_red;
	float	ambient_green;
	float	ambient_blue;

	// Scene statistics
	udword	num_geomobjects;
	udword	num_derived_objects;
	udword	num_cameras;
	udword	num_lights;
	udword	num_shapes;
	udword	num_helpers;
	udword	num_controllers;
	udword	num_materials;
	udword	num_texmaps;
	udword	num_unknown_nodes;
	udword	num_invalid_nodes;
};

struct PVBBasicInfo
{
	string name;
	udword objid;
	udword parid;
	udword linkid;
	ubyte group;
	float pos_x,pos_y,pos_z;
	float rot_x,rot_y,rot_z,rot_w;
	float scale_x,scale_y,scale_z;
	udword wire_color;
	ubyte PRSLocal;
	ubyte D3DBasis;
	string user;
};

static int PVBBasicInfoR(istream &in,PVBBasicInfo &bi);
static int PVAPI FixMaterials(PVMesh *oo,int userarg);

#endif

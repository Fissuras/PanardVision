/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include <malloc.h>

#include "fillcom.h"

static double mn=6755399441055744.0;
static double f1,f2,f3;
static unsigned *i1=(unsigned*)&f1,*i2=(unsigned*)&f2,*i3=(unsigned*)&f3;

#ifndef __386__

//-------------------------------------------------------------------------

void __cdecl HLineGouraud(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;
    while(length--!=0)
    {
        *(ofs++)=GenFill_CurrentLeftVal[0]>>16;
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
    }
}

void __cdecl HLineAffineMapping(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;
    while(length--!=0)
    {
        *(ofs++)=Texture[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineAffineFlatMapping(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;
    while(length--!=0)
    {
        *(ofs++)=LineMapLightTransTable[Texture[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)]];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineAffineFlatMappingRGB16(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        *(ofs16++)=LineMapLightTransTable16[Texture[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)]];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineGouraudAffineMapping(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;
    while(length--!=0)
    {
        *(ofs++)=MapLightTranslateTable[Texture[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)]+((GenFill_CurrentLeftVal[2]>>8)&0xff00)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
        GenFill_CurrentLeftVal[2]+=GenFill_iGradientX[2];
    }
}

void __cdecl HLineGouraudAffineMappingRGB16(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        *(ofs16++)=MapLightTranslateTable16[Texture[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)]+((GenFill_CurrentLeftVal[2]>>8)&0xff00)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
        GenFill_CurrentLeftVal[2]+=GenFill_iGradientX[2];
    }
}

void __cdecl HLineBumpMapping(unsigned deb,unsigned fin)
{
    unsigned length;
    int x,y;
    unsigned h;
    PVBumpInfo *b;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;
    while(length--!=0)
    {
        h=(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth);
        b=&BumpMap[h];
        x=(GenFill_CurrentLeftVal[2]>>16)+b->nx;
        y=(GenFill_CurrentLeftVal[3]>>16)+b->ny;
        x&=AndWidthA;
        y&=AndHeightA;
        y<<=ShiftWidthA;
        *(ofs++)=MapLightTranslateTable[Texture[h]+(AuxiliaryTex[x+y]<<8)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
        GenFill_CurrentLeftVal[2]+=GenFill_iGradientX[2];
        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
    }
}

void __cdecl HLineBumpMappingRGB16(unsigned deb,unsigned fin)
{
    unsigned length;
    int x,y;
    unsigned h;
    PVBumpInfo *b;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        h=(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth);
        b=&BumpMap[h];
        x=(GenFill_CurrentLeftVal[2]>>16)+b->nx;
        y=(GenFill_CurrentLeftVal[3]>>16)+b->ny;
        x&=AndWidthA;
        y&=AndHeightA;
        y<<=ShiftWidthA;
        *(ofs16++)=MapLightTranslateTable16[Texture[h]+(AuxiliaryTex[x+y]<<8)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
        GenFill_CurrentLeftVal[2]+=GenFill_iGradientX[2];
        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
    }
}

void __cdecl HLineBump(unsigned deb,unsigned fin)
{
    unsigned length;
    int x,y;
    PVBumpInfo *b;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;
    while(length--!=0)
    {
        b=&BumpMap[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)];
        x=(GenFill_CurrentLeftVal[0]>>16)+b->nx;
        y=(GenFill_CurrentLeftVal[1]>>16)+b->ny;
        x&=AndWidth;
        y&=AndHeight;
        y<<=ShiftWidth;
        *(ofs++)=Texture[x+y];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineBumpRGB16(unsigned deb,unsigned fin)
{
    unsigned length;
    int x,y;
    PVBumpInfo *b;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        b=&BumpMap[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)];
        x=(GenFill_CurrentLeftVal[0]>>16)+b->nx;
        y=(GenFill_CurrentLeftVal[1]>>16)+b->ny;
        x&=AndWidth;
        y&=AndHeight;
        y<<=ShiftWidth;
        *(ofs16++)=((UPVD16*)Texture)[x+y];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineAmbientAffineMapping(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb;
    while(length--!=0)
    {
        *(ofs++)=MapLightTranslateTable[Texture[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)]+(AuxiliaryTex[(((GenFill_CurrentLeftVal[3]>>16)&AndHeightA)<<ShiftWidthA)+((GenFill_CurrentLeftVal[2]>>16)&AndWidthA)]<<8)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
        GenFill_CurrentLeftVal[2]+=GenFill_iGradientX[2];
        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
    }
}

void __cdecl HLineAmbientAffineMappingRGB16(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        *(ofs16++)=MapLightTranslateTable16[Texture[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)]+(AuxiliaryTex[(((GenFill_CurrentLeftVal[3]>>16)&AndHeightA)<<ShiftWidthA)+((GenFill_CurrentLeftVal[2]>>16)&AndWidthA)]<<8)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
        GenFill_CurrentLeftVal[2]+=GenFill_iGradientX[2];
        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
    }
}

/////////////////////////////////////////////////////////////////// RGB

void __cdecl HLineRGBFlat16(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        *(ofs16++)=col;
    }

}

void __cdecl HLineRGBFlat24(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;
    while(length--!=0)
    {
        *(ofs++)=col;
        *(ofs++)=col>>8;
        *(ofs++)=col>>16;
    }

}

void __cdecl HLineRGBFlat32(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        *((PVD32*)ofs)=col;
        ofs+=4;
    }
}

void __cdecl HLineRGBTextureMapping16(unsigned deb,unsigned fin)
{
    unsigned length;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        *(ofs16++)=((UPVD16*)Texture)[(((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth)];
        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineRGBTextureMapping24(unsigned deb,unsigned fin)
{
    unsigned length;
    UPVD8 *p;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;

    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];

        *(ofs++)=(*p++);
        *(ofs++)=(*p++);
        *(ofs++)=(*p);

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }

}

void __cdecl HLineRGBTextureMapping32(unsigned deb,unsigned fin)
{
    unsigned length;
    UPVD8 *p;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        p=&Texture[4*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];

        *((PVD32*)ofs)=*((UPVD32*)p);
        ofs+=4;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }

}

void __cdecl HLineRGBFlatMapping16(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];

        f1=(*p++)*RGBFlatColor.r+mn;
        f2=(*p++)*RGBFlatColor.g+mn;
        f3=(*p++)*RGBFlatColor.b+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs16++)=t;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineRGBFlatMapping24(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];

        f1=(*p++)*RGBFlatColor.r+mn;
        f2=(*p++)*RGBFlatColor.g+mn;
        f3=(*p++)*RGBFlatColor.b+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs++)=t;
        *(ofs++)=t>>8;
        *(ofs++)=t>>16;



        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineRGBFlatMapping32(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];

        f1=(*p++)*RGBFlatColor.r+mn;
        f2=(*p++)*RGBFlatColor.g+mn;
        f3=(*p++)*RGBFlatColor.b+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *((PVD32*)ofs)=t;
        ofs+=4;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineRGBGouraud16(unsigned deb,unsigned fin)
{
    unsigned length,t;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        f1=GenFill_CurrentLeftValF[0]+mn;
        f2=GenFill_CurrentLeftValF[1]+mn;
        f3=GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs16++)=t;

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

void __cdecl HLineRGBGouraud24(unsigned deb,unsigned fin)
{
    unsigned length,t;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;
    while(length--!=0)
    {
        f1=GenFill_CurrentLeftValF[0]+mn;
        f2=GenFill_CurrentLeftValF[1]+mn;
        f3=GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs++)=t;
        *(ofs++)=t>>8;
        *(ofs++)=t>>16;

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

void __cdecl HLineRGBGouraud32(unsigned deb,unsigned fin)
{
    unsigned length,t;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        f1=GenFill_CurrentLeftValF[0]+mn;
        f2=GenFill_CurrentLeftValF[1]+mn;
        f3=GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *((PVD32*)ofs)=t;
        ofs+=4;

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

void __cdecl HLineRGBGouraudTextureMapping16(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];

        f1=(*p++)*GenFill_CurrentLeftValF[0]+mn;
        f2=(*p++)*GenFill_CurrentLeftValF[1]+mn;
        f3=(*p++)*GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs16++)=t;

        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
        GenFill_CurrentLeftVal[4]+=GenFill_iGradientX[4];

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

void __cdecl HLineRGBGouraudTextureMapping24(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];

        f1=(*p++)*GenFill_CurrentLeftValF[0]+mn;
        f2=(*p++)*GenFill_CurrentLeftValF[1]+mn;
        f3=(*p++)*GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs++)=t;
        *(ofs++)=t>>8;
        *(ofs++)=t>>16;

        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
        GenFill_CurrentLeftVal[4]+=GenFill_iGradientX[4];

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

void __cdecl HLineRGBGouraudTextureMapping32(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];

        f1=(*p++)*GenFill_CurrentLeftValF[0]+mn;
        f2=(*p++)*GenFill_CurrentLeftValF[1]+mn;
        f3=(*p++)*GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);

        *((PVD32*)ofs)=t;
        ofs+=4;

        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
        GenFill_CurrentLeftVal[4]+=GenFill_iGradientX[4];

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}


#endif

/////////////////////////////////////////////////////////////// Bilinear

void __cdecl HLineRGBTextureMapping16Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD16 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        p=&((UPVD16*)Texture)[((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p2=&((UPVD16*)Texture)[((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];
        p3=&((UPVD16*)Texture)[(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p4=&((UPVD16*)Texture)[(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[0]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[1]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)((*p)&RedMask)*c1+(float)((*p2)&RedMask)*c2+(float)((*p3)&RedMask)*c3+(float)((*p4)&RedMask)*c4)+mn;

        f2=(double)((float)((*p)&GreenMask)*c1+(float)((*p2)&GreenMask)*c2+(float)((*p3)&GreenMask)*c3+(float)((*p4)&GreenMask)*c4)+mn;

        f3=(double)((float)((*p)&BlueMask)*c1+(float)((*p2)&BlueMask)*c2+(float)((*p3)&BlueMask)*c3+(float)((*p4)&BlueMask)*c4)+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs16++)=t;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }

}

void __cdecl HLineRGBTextureMapping24Bi(unsigned deb,unsigned fin)
{
    unsigned length;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p2=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];
        p3=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p4=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[0]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[1]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4)+mn;

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4)+mn;

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4)+mn;

        *(ofs++)=(*i1);
        *(ofs++)=(*i2);
        *(ofs++)=(*i3);

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }

}

void __cdecl HLineRGBTextureMapping32Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        p=&Texture[4*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p2=&Texture[4*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];
        p3=&Texture[4*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p4=&Texture[4*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[0]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[1]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4)+mn;

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4)+mn;

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4)+mn;

		t=(*i1)|((*i2)<<8)|((*i3)<<16);

        *((PVD32*)ofs)=t;
        ofs+=4;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }

}



void __cdecl HLineRGBFlatMapping16Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p2=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];
        p3=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p4=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[0]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[1]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        f1=f1*RGBFlatColor.r+mn;
        f2=f2*RGBFlatColor.g+mn;
        f3=f3*RGBFlatColor.b+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs16++)=t;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}


void __cdecl HLineRGBFlatMapping24Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p2=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];
        p3=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p4=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[0]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[1]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);


        f1=f1*RGBFlatColor.r+mn;
        f2=f2*RGBFlatColor.g+mn;
        f3=f3*RGBFlatColor.b+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs++)=t;
        *(ofs++)=t>>8;
        *(ofs++)=t>>16;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineRGBFlatMapping32Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p2=&Texture[3*((((GenFill_CurrentLeftVal[1]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];
        p3=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[0]>>16)&AndWidth))];
        p4=&Texture[3*(((((GenFill_CurrentLeftVal[1]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[0]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[0]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[1]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        f1=f1*RGBFlatColor.r+mn;
        f2=f2*RGBFlatColor.g+mn;
        f3=f3*RGBFlatColor.b+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *((PVD32*)ofs)=t;
        ofs+=4;

        GenFill_CurrentLeftVal[0]+=GenFill_iGradientX[0];
        GenFill_CurrentLeftVal[1]+=GenFill_iGradientX[1];
    }
}

void __cdecl HLineRGBGouraudTextureMapping16Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs16=(UPVD16*)TriFill_BufOfs;
    ofs16+=deb;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];
        p2=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[3]>>16)+1)&AndWidth))];
        p3=&Texture[3*(((((GenFill_CurrentLeftVal[4]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];
        p4=&Texture[3*(((((GenFill_CurrentLeftVal[4]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[3]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[3]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[4]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        f1=f1*GenFill_CurrentLeftValF[0]+mn;
        f2=f2*GenFill_CurrentLeftValF[1]+mn;
        f3=f3*GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs16++)=t;

        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
        GenFill_CurrentLeftVal[4]+=GenFill_iGradientX[4];

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

void __cdecl HLineRGBGouraudTextureMapping24Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*3;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];
        p2=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[3]>>16)+1)&AndWidth))];
        p3=&Texture[3*(((((GenFill_CurrentLeftVal[4]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];
        p4=&Texture[3*(((((GenFill_CurrentLeftVal[4]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[3]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[3]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[4]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);


        f1=f1*GenFill_CurrentLeftValF[0]+mn;
        f2=f2*GenFill_CurrentLeftValF[1]+mn;
        f3=f3*GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *(ofs++)=t;
        *(ofs++)=t>>8;
        *(ofs++)=t>>16;

        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
        GenFill_CurrentLeftVal[4]+=GenFill_iGradientX[4];

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

void __cdecl HLineRGBGouraudTextureMapping32Bi(unsigned deb,unsigned fin)
{
    unsigned length,t;
    UPVD8 *p,*p2,*p3,*p4;
    float du,dv,du1,dv1,c1,c2,c3,c4;

    length=fin-deb;
    ofs=TriFill_BufOfs;
    ofs+=deb*4;
    while(length--!=0)
    {
        p=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];
        p2=&Texture[3*((((GenFill_CurrentLeftVal[4]>>16)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[3]>>16)+1)&AndWidth))];
        p3=&Texture[3*(((((GenFill_CurrentLeftVal[4]>>16)+1)&AndHeight)<<ShiftWidth)+((GenFill_CurrentLeftVal[3]>>16)&AndWidth))];
        p4=&Texture[3*(((((GenFill_CurrentLeftVal[4]>>16)+1)&AndHeight)<<ShiftWidth)+(((GenFill_CurrentLeftVal[3]>>16)+1)&AndWidth))];

        du=(float)(GenFill_CurrentLeftVal[3]&0xFFFF)*(double)(1/(double)65535);
        dv=(float)(GenFill_CurrentLeftVal[4]&0xFFFF)*(double)(1/(double)65535);
        du1=1-du;
        dv1=1-dv;
        c1=du1*dv1;
        c2=du*dv1;
        c3=dv*du1;
        c4=du*dv;

        f1=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f2=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        p++; p2++; p3++; p4++;

        f3=(double)((float)(*p)*c1+(float)(*p2)*c2+(float)(*p3)*c3+(float)(*p4)*c4);

        f1=f1*GenFill_CurrentLeftValF[0]+mn;
        f2=f2*GenFill_CurrentLeftValF[1]+mn;
        f3=f3*GenFill_CurrentLeftValF[2]+mn;

        t=((*i1)&RedMask)+((*i2)&GreenMask)+((*i3)&BlueMask);
        *((PVD32*)ofs)=t;
        ofs+=4;

        GenFill_CurrentLeftVal[3]+=GenFill_iGradientX[3];
        GenFill_CurrentLeftVal[4]+=GenFill_iGradientX[4];

        GenFill_CurrentLeftValF[0]+=GenFill_GradientX[0];
        GenFill_CurrentLeftValF[1]+=GenFill_GradientX[1];
        GenFill_CurrentLeftValF[2]+=GenFill_GradientX[2];
    }
}

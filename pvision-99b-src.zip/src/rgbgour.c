/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include "fillcom.h"

static int __cdecl Init1GMapping(int NumVtx,unsigned *vtx) {
    PVMesh *o=GenFill_CurrentFace->Father;
    float d,e,f;
    int i;
    
    // Accelerator
	for(i=1;i<NumVtx;i++) if(o->Shading[vtx[i]].Color.r!=o->Shading[vtx[i-1]].Color.r) break;
	if(i==NumVtx) 
	{
		for(i=1;i<NumVtx;i++) if(o->Shading[vtx[i]].Color.g!=o->Shading[vtx[i-1]].Color.g) break;
		if(i==NumVtx) 
		{	
			for(i=1;i<NumVtx;i++) if(o->Shading[vtx[i]].Color.b!=o->Shading[vtx[i-1]].Color.b) break;
			if(i==NumVtx) 
			{
				TriRGBFlat(GenFill_CurrentFace);
				return 1;
			}
		}
	}
				
	GenFill_NbrIncF=3;

    d=((1<<RMaskSize)-1)*RedFact;
    e=((1<<GMaskSize)-1)*GreenFact;
    f=((1<<BMaskSize)-1)*BlueFact;

    for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][0]=min(1,(o->Shading[vtx[i]].Color.r+RGBAmbientLight->r)*GenFill_CurrentFace->MaterialInfo->Diffuse.r+GenFill_CurrentFace->MaterialInfo->Emissive.r)*d;
        GenFill_InitialValues[i][1]=min(1,(o->Shading[vtx[i]].Color.g+RGBAmbientLight->g)*GenFill_CurrentFace->MaterialInfo->Diffuse.g+GenFill_CurrentFace->MaterialInfo->Emissive.g)*e;
        GenFill_InitialValues[i][2]=min(1,(o->Shading[vtx[i]].Color.b+RGBAmbientLight->b)*GenFill_CurrentFace->MaterialInfo->Diffuse.b+GenFill_CurrentFace->MaterialInfo->Emissive.b)*f;
    }
    return 0;
}

static void __cdecl Init2GMapping(int NumVtx)
{

    switch(PixelSize)
    {
        case 2:HLineRoutine=HLineRGBGouraud16;break;
        case 3:HLineRoutine=HLineRGBGouraud24;break;
        case 4:HLineRoutine=HLineRGBGouraud32;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct RGBGouraud={Init1GMapping,Init2GMapping};


/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include "fillcom.h"

static int __cdecl Init1RGBF(int NumVtx,unsigned *vtx) {
    PVMesh *o=GenFill_CurrentFace->Father;
    unsigned i;

    if(GenFill_CurrentFace->Flags&AUTOMATIC_PERSPECTIVE)
    if(!PerspectiveNeeded(o->Rotated[vtx[0]].zf,o->Rotated[vtx[1]].zf,o->Rotated[vtx[NumVtx-1]].zf))
    {
        TriRGBTextureMapping(GenFill_CurrentFace);
        return 1;
    }

    GenFill_NbrIncF=3;

    for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][0]=o->Projected[vtx[i]].InvertZ;
    }

    if((GenFill_CurrentFace->Flags&(PHONG|U_PHONG)))
    {
        for(i=0;i<NumVtx;i++)
        {
            GenFill_InitialValues[i][1]=o->Mapping[vtx[i]].AmbientU*GenFill_InitialValues[i][0];
            GenFill_InitialValues[i][2]=o->Mapping[vtx[i]].AmbientV*GenFill_InitialValues[i][0];
        }
    }
    else
    {
        for(i=0;i<NumVtx;i++)
        {
            GenFill_InitialValues[i][1]=o->Mapping[vtx[i]].u*GenFill_InitialValues[i][0];
            GenFill_InitialValues[i][2]=o->Mapping[vtx[i]].v*GenFill_InitialValues[i][0];
        }
    }

	HLineRoutine=GenPHLine;

    return 0;
}

static void __cdecl Init2RGBF(int NumVtx)
{
    unsigned Bi=0;
    unsigned MipIndex;
    unsigned TextureW,TextureH;
    unsigned i;

    // MipMap
    if((GenFill_CurrentFace->Flags&AUTOMATIC_BILINEAR)||((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP)))
		MipIndex=GetMipMapIndex(GenFill_CurrentFace,1,2);

    if((PV_Mode&PVM_MIPMAPPING)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_MIPMAP))
    {
        Texture=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[MipIndex].ShiftWidth;
    }
    else
    {
        // No MipMap
        Texture=GenFill_CurrentFace->MaterialInfo->Tex[0].Texture;
        TextureW=GenFill_CurrentFace->MaterialInfo->Tex[0].Width;
        TextureH=GenFill_CurrentFace->MaterialInfo->Tex[0].Height;
        ShiftWidth=GenFill_CurrentFace->MaterialInfo->Tex[0].ShiftWidth;
    }

    for(i=0;i<NumVtx;i++)
    {
        GenFill_InitialValues[i][1]*=(TextureW);
        GenFill_InitialValues[i][2]*=(TextureH);
    }

    GenFill_GradientX[1]*=TextureW;
    GenFill_GradientX[2]*=TextureH;
    GenFill_GradientY[1]*=TextureW;
    GenFill_GradientY[2]*=TextureH;

    AndHeight=TextureH-1;
    AndWidth=TextureW-1;

    GradientXAff[0]=GenFill_GradientX[0]*AFFINE_LENGTH;
    GradientXAff[1]=GenFill_GradientX[1]*AFFINE_LENGTH;
    GradientXAff[2]=GenFill_GradientX[2]*AFFINE_LENGTH;

    if((PV_Mode&PVM_BILINEAR)&&(GenFill_CurrentFace->MaterialInfo->TextureFlags&TEXTURE_BILINEAR))
        if(GenFill_CurrentFace->Flags&AUTOMATIC_BILINEAR)
        { if(MipIndex==0) Bi=1;}
        else Bi=1;

    if(Bi)
    switch(PixelSize)
    {
        case 2:SLineRoutine=HLineRGBTextureMapping16Bi;break;
        case 3:SLineRoutine=HLineRGBTextureMapping24Bi;break;
        case 4:SLineRoutine=HLineRGBTextureMapping32Bi;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }
    else
    switch(PixelSize)
    {
        case 2:SLineRoutine=HLineRGBTextureMapping16;break;
        case 3:SLineRoutine=HLineRGBTextureMapping24;break;
        case 4:SLineRoutine=HLineRGBTextureMapping32;break;
        default:PV_Fatal("Unsupported PixelSize.",PixelSize);
    }
#ifdef __386__
    HLPInitFunc=HLineRGBTextureMapping_INIT;
#endif
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

FillerUserFunct RGBPerspectiveTextureMapping={Init1RGBF,Init2RGBF};

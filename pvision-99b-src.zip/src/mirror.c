/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "pvision.h"
#include "sqrt.h"

PVMirror *PVAPI PV_CreateMirror(void)
{
    PVMirror *m;
    unsigned i;

    m=(PVMirror*)malloc(sizeof(PVMirror));

    if(m!=NULL)
    {
        m->Flags=0;
        m->NbrVertices=0;
        m->Father=NULL;
        m->Next=NULL;
        m->Pos.xf=m->Pos.yf=m->Pos.zf=0;
        m->Pivot.xf=m->Pivot.yf=m->Pivot.zf=0;

        for (i=0;i<3;i++ )
        {
            m->Matrix[i][0]=m->Matrix[i][1]=m->Matrix[i][2]=0;
        }
        m->Matrix[0][0]=m->Matrix[1][1]=m->Matrix[2][2]=1;

        m->Normal.xf=m->Normal.yf=m->Normal.zf=0;

        m->CutDist=20000;

        m->Reflectance=1;
        m->Transparency=1;

		m->RefCnt=0;
    }
    return m;
}

void PVAPI PV_KillMirror(PVMirror *m)
{
    if(m==NULL) return;
    if(m->RefCnt>0) m->RefCnt--;
	if(m->RefCnt==0) free(m);
}

void PVAPI PV_SetupMirror(PVMirror *m)
{
    float nx,ny,nz,n;
    unsigned p1,p2,p3;

    if(m==NULL) return;
    if(m->NbrVertices<3) return;

    // Calcul de la normale
    p1=m->NbrVertices-1;
    p2=1;
    p3=0;
    nx=((m->Vertex[p2].yf-m->Vertex[p1].yf)*(m->Vertex[p3].zf-m->Vertex[p1].zf))-((m->Vertex[p2].zf-m->Vertex[p1].zf)*(m->Vertex[p3].yf-m->Vertex[p1].yf));
    ny=((m->Vertex[p2].zf-m->Vertex[p1].zf)*(m->Vertex[p3].xf-m->Vertex[p1].xf))-((m->Vertex[p2].xf-m->Vertex[p1].xf)*(m->Vertex[p3].zf-m->Vertex[p1].zf));
    nz=((m->Vertex[p2].xf-m->Vertex[p1].xf)*(m->Vertex[p3].yf-m->Vertex[p1].yf))-((m->Vertex[p2].yf-m->Vertex[p1].yf)*(m->Vertex[p3].xf-m->Vertex[p1].xf));
    n=(nx*nx+ny*ny+nz*nz);
	if(n>0)
	{
		//n=1/fsqrt(n);
		n=InvSqrt(n);
		nx*=n;
		ny*=n;
		nz*=n;
	}

    m->Normal.xf=nx;
    m->Normal.yf=ny;
    m->Normal.zf=nz;

    // Calcule de la Position
    m->d=nx*m->Vertex[0].xf+ny*m->Vertex[0].yf+nz*m->Vertex[0].zf;

    // Matrice de symetrie
    m->SymMatrix[0][0]=1-2*m->Normal.xf*m->Normal.xf;
    m->SymMatrix[0][1]=-2*m->Normal.xf*m->Normal.yf;
    m->SymMatrix[0][2]=-2*m->Normal.xf*m->Normal.zf;
    m->SymMatrix[1][0]=-2*m->Normal.xf*m->Normal.yf;
    m->SymMatrix[1][1]=1-2*m->Normal.yf*m->Normal.yf;
    m->SymMatrix[1][2]=-2*m->Normal.yf*m->Normal.zf;
    m->SymMatrix[2][0]=-2*m->Normal.xf*m->Normal.zf;
    m->SymMatrix[2][1]=-2*m->Normal.yf*m->Normal.zf;
    m->SymMatrix[2][2]=1-2*m->Normal.zf*m->Normal.zf;
}

void PVAPI PV_PrepareMirror(PVPoly *m,PVCam *sc,PVPoint vtx[])
{
    PVPoint r,Up,z;
    unsigned i,nv;

    if(m==NULL) return ;
    if(m->NbrVertices<3) return ;
		
    // Calcul des N plans de coupure
	// Le mirroir est garantie d'avoir au plus 8 cot�s par le test dans pvision
    for(i=0;i<MAX_USER_CLIPPLANES;i++) PV_EnableClipPlane(sc,i,PV_DISABLE);
    for(i=0;i<m->NbrVertices;i++)
    {
        // Calcul d'un vecteur orthonormal � R Contenant le cot� du poly
        nv=i+1;
        if(nv>=m->NbrVertices) nv=0;

        Up.xf=vtx[m->Vertices[i]].xf-vtx[m->Vertices[nv]].xf;
        Up.yf=vtx[m->Vertices[i]].yf-vtx[m->Vertices[nv]].yf;
        Up.zf=vtx[m->Vertices[i]].zf-vtx[m->Vertices[nv]].zf;

        r.xf=vtx[m->Vertices[i]].xf;
        r.yf=vtx[m->Vertices[i]].yf;
        r.zf=vtx[m->Vertices[i]].zf;

        z.xf=Up.yf*r.zf-Up.zf*r.yf;
        z.yf=Up.zf*r.xf-Up.xf*r.zf;
        z.zf=Up.xf*r.yf-Up.yf*r.xf;

        PV_SetClipPlane(sc,i,vtx[m->Vertices[i]],z);
        PV_EnableClipPlane(sc,i,PV_ENABLE);
    }
}


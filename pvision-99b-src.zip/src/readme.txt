Sources found in this directory are here only for tutorial purposes,
they are already compiled in the .lib/.dll.

You can find:
- 3dsread.c : or how to make a driver for Panard Vision
- 3dspm.c : or how to make a driver for Panard Motion
- pvbread.cpp : or how to read PVB file from the Flexporter 3dsMax plugin

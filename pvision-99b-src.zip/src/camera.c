/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

#include <math.h>
#include <malloc.h>
#include <string.h>
#include "pvision.h"
#include "sqrt.h"

/***************************************************************************/
/*                          GESTION CAMERA & PLACEMENT OBJETS              */
/***************************************************************************/

void PVAPI PV_RAZCam(PVCam *c)
{
    unsigned i;

    c->roll=c->pitch=c->yaw=0;
    for (i=0;i<3;i++ )
    {
        c->Matrix[i][0]=c->Matrix[i][1]=c->Matrix[i][2]=0;
    }
    c->pos.xf=c->pos.yf=c->pos.zf=0;
    c->target.xf=c->target.yf=c->target.zf=0;
    c->roll=0;
    c->Matrix[0][0]=c->Matrix[1][1]=c->Matrix[2][2]=1;
}

PVCam * PVAPI PV_CreateCam(char *n)
{
    PVCam *t;

    t=(PVCam*)calloc(1,sizeof(PVCam));

    if(t!=NULL)
    {
        PV_RAZCam(t);

        t->Name=NULL;

        PV_SetCamName(t,n);

        memset(t->UserPlanesEnabled,0,sizeof(t->UserPlanesEnabled));

		t->FrontDist=10;
		t->BackDist=100000;
		t->CenterX=160;
		t->CenterY=100;
		t->Width=320;
		t->Height=200;

		t->StartingLocation=NULL;
		t->Flags=0;
    }

    return t;
}

int PVAPI PV_SetCamName(PVCam *c,char *n)
{
    if(c==NULL) return ARG_INVALID;
    if(c->Name!=NULL) free(c->Name);

    if(n!=NULL) c->Name=strdup(n);
    else c->Name=NULL;

    if(c->Name==NULL) return NO_MEMORY; else return COOL;
}

void PVAPI PV_KillCam(PVCam *t)
{
    if(t==NULL) return;
    free(t->Name);
    free(t);
}

void PVAPI PV_CamAhead(PVCam *c,float a)
{
   if(c==NULL) return;
   c->pos.xf+=c->Matrix[2][0]*a;
   c->pos.yf+=c->Matrix[2][1]*a;
   c->pos.zf+=c->Matrix[2][2]*a;
}

void PVAPI PV_CamSide(PVCam *c,float a)
{
   if(c==NULL) return;
   c->pos.xf+=c->Matrix[0][0]*a;
   c->pos.yf+=c->Matrix[0][1]*a;
   c->pos.zf+=c->Matrix[0][2]*a;
}

void PVAPI PV_CamUp(PVCam *c,float a)
{
   if(c==NULL) return;
   c->pos.xf+=c->Matrix[1][0]*a;
   c->pos.yf+=c->Matrix[1][1]*a;
   c->pos.zf+=c->Matrix[1][2]*a;
}


void PVAPI PV_ComputeCam(PVCam *c)
{
	float alpha = 45.0f * PI / 180.0f; // opening angle of 45 degrees
    if(c==NULL) return;

    c->xscreenscale = c->Width / c->fieldofview;
    c->yscreenscale = c->Height / c->fieldofview;
    c->fscale = max(c->xscreenscale, c->yscreenscale);

	c->W=c->Width*0.5*1.0/tan((atan(2.0/(c->fieldofview*c->fscale/c->xscreenscale)))/2.0);
	c->H=c->Height*0.5*1.0/tan((atan(2.0/(c->fieldofview*c->fscale/c->yscreenscale)))/2.0);
	
	/*c->fieldofview=tan(alpha/2);

	if(c->Width > c->Height) 
	{
		c->yscreenscale = c->fieldofview;
		c->xscreenscale = c->Width / c->Height * c->fieldofview;
	} 
	else 
	{
		c->xscreenscale = c->fieldofview;
		c->yscreenscale = c->Height / c->Width * c->fieldofview;
	}	

	c->W=c->Width*0.5*1.0/c->xscreenscale;
	c->H=c->Height*0.5*1.0/c->yscreenscale;*/
}

static void ComputeMatrix(PVCam *ca)
{
    PVPoint p;
    double a,b,c,d,e,f,n,dot;
    PVPoint Up={0,1,0};
    PVMat3x3 m,Matrix;
    
	// Compute direction vector
    p.xf=ca->pos.xf-ca->target.xf;
    p.yf=ca->pos.yf-ca->target.yf;
    p.zf=ca->pos.zf-ca->target.zf;

    n=(p.xf*p.xf+p.yf*p.yf+p.zf*p.zf);
    if(n>0)
    {
        //n=1/fsqrt(n);
		n=InvSqrt(n);
		p.xf*=n;
        p.yf*=n;
        p.zf*=n;
    }

	// Check for degenerate
	if((p.xf==Up.xf)&&(p.zf==Up.zf)&&(p.zf==Up.zf))
	{
		Up.xf=p.yf;
		Up.yf=-p.xf;
		Up.zf=0;
	}

    // Vector left
    a=Up.xf;
    b=Up.yf;
    c=Up.zf;
    dot=a*p.xf+b*p.yf+c*p.zf;
    a-=dot*p.xf;
    b-=dot*p.yf;
    c-=dot*p.zf;

    n=(a*a+b*b+c*c);
    if(n>0)
    {
		//n=1/fsqrt(n);
		n=InvSqrt(n);
        a*=n;
        b*=n;
        c*=n;
    }

    // Vector up
    d=b*p.zf-c*p.yf;
    e=c*p.xf-a*p.zf;
    f=a*p.yf-b*p.xf;

    n=(d*d+e*e+f*f);
    if(n>0)
    {
        //n=1/fsqrt(n);
		n=InvSqrt(n);
		d*=n;
        e*=n;
        f*=n;
    }

    // Compute cam basis
    Matrix[2][0]=p.xf;
    Matrix[2][1]=p.yf;
    Matrix[2][2]=p.zf;

    Matrix[1][0]=a;
    Matrix[1][1]=b;
    Matrix[1][2]=c;

    Matrix[0][0]=d;
    Matrix[0][1]=e;
    Matrix[0][2]=f;

    // the roll
    SetupMatrix3x3(m,0,0,-ca->roll);
    MatrixMul(m,Matrix,ca->Matrix);
}

void PVAPI PV_SetCamPos(PVCam *c,float x,float y, float z)
{
    if(c==NULL) return;
    c->pos.xf=x;
    c->pos.yf=y;
    c->pos.zf=z;
}

void PVAPI PV_SetCamTarget(PVCam *ca,float x,float y, float z)
{
    if(ca==NULL) return;

    ca->target.xf=x;
    ca->target.yf=y;
    ca->target.zf=z;

    ComputeMatrix(ca);
}

void PVAPI PV_SetCamFieldOfView(PVCam *c,float f)
{
    if(c==NULL) return;
    c->fieldofview=f;
}

void PVAPI PV_SetCamRoll(PVCam *c,float roll)
{
    if(c==NULL) return;

    c->roll=roll;

    ComputeMatrix(c);
}

void PVAPI PV_SetCamAngles(PVCam *c,float yaw,float pitch,float roll)
{
    static PVMat3x3 mroll = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    static PVMat3x3 mpitch = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    static PVMat3x3 myaw =  {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    float  s, c2;
    PVMat3x3 mtemp1;

    if(c==NULL) return;

    c->yaw=yaw;
    c->pitch=pitch;
    c->roll=roll;

    // Set up the world-to-view rotation.
    while (c->roll < 0) c->roll += (float)(PI * 2);
    while (c->roll >= (PI * 2)) c->roll -= (float)(PI * 2);
    s = sin(c->roll);
    c2 = cos(c->roll);
    mroll[0][0] = c2;
    mroll[0][1] = s;
    mroll[1][0] = -s;
    mroll[1][1] = c2;

    while (c->pitch < 0) c->pitch += (float)(PI * 2);
    while (c->pitch >= (PI * 2)) c->pitch -= (float)(PI * 2);
    s = sin(c->pitch);
    c2 = cos(c->pitch);
    mpitch[1][1] = c2;
    mpitch[1][2] = s;
    mpitch[2][1] = -s;
    mpitch[2][2] = c2;

    while (c->yaw < 0) c->yaw += (float)(PI * 2);
    while (c->yaw >= (PI * 2)) c->yaw -= (float)(PI * 2);
    s = sin(c->yaw);
    c2 = cos(c->yaw);
    myaw[0][0] = c2;
    myaw[0][2] = -s;
    myaw[2][0] = s;
    myaw[2][2] = c2;

	MatrixMul( mroll, mpitch, mtemp1 );
	MatrixMul( mtemp1, myaw, c->Matrix);
}

int PVAPI PV_EnableClipPlane(PVCam *c,unsigned i,unsigned val)
{
    if(c==NULL) return ARG_INVALID;
    if(i>=MAX_USER_CLIPPLANES) return ARG_INVALID;
    switch(val)
    {
        case PV_ENABLE:c->UserPlanesEnabled[i]=1;break;
        case PV_DISABLE:c->UserPlanesEnabled[i]=0;break;
        default:return ARG_INVALID;
    }

    return COOL;
}

int PVAPI PV_SetClipPlane(PVCam *c,unsigned i,PVPoint Pos,PVPoint Normal)
{
    if(c==NULL) return ARG_INVALID;
    if(i>=MAX_USER_CLIPPLANES) return ARG_INVALID;
    c->UserPlanes[i].Pos=Pos;
    c->UserPlanes[i].Normal=Normal;

    return COOL;
}

static void PV_FindCurrentCameraCellRecurse(PVMesh *m,float *minvol,PVMesh **minmesh,PVCam *c)
{
	PVMesh *o=m;
	PVPoint tx,InvertCamPos;

	while(o)
	{
		PV_ComputeMeshToWorldMatrix(o);
		
		// Exprime la pos de la cam dans le repre objet
		tx=o->Owner->Camera->pos;
		tx.xf-=o->Pivot.xf+o->WorldPos.xf;
		tx.yf-=o->Pivot.yf+o->WorldPos.yf;
		tx.zf-=o->Pivot.zf+o->WorldPos.zf;
		RotateInvertPoint(&tx,o->WorldMatrix,&InvertCamPos);
		InvertCamPos.xf+=o->Pivot.xf;
		InvertCamPos.yf+=o->Pivot.yf;
		InvertCamPos.zf+=o->Pivot.zf;
        
		if(o->Box!=NULL)
		{
			// On test si la cam est dans la box
			if ((InvertCamPos.xf>=o->Box->p0.xf)&&(InvertCamPos.xf<=o->Box->t0.xf)
			  &&(InvertCamPos.yf>=o->Box->p0.yf)&&(InvertCamPos.yf<=o->Box->t0.yf)
			  &&(InvertCamPos.zf>=o->Box->p0.zf)&&(InvertCamPos.zf<=o->Box->t0.zf))
			if(o->Box->Volume<*minvol) 
			{
				*minvol=o->Box->Volume;
				*minmesh=o;
			}
		}
		
		PV_FindCurrentCameraCellRecurse(o->Child,minvol,minmesh,c);

		o=o->Next;
	}
}

PVMesh *PVAPI PV_FindCurrentCameraCell(PVMesh *m,PVCam *c)
{
	float minvol;
	PVMesh *minmesh;

	minvol=MAXFLOAT;
	minmesh=NULL;

	PV_FindCurrentCameraCellRecurse(m,&minvol,&minmesh,c);

	return minmesh;
}

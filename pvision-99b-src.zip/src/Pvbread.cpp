/*
    This file is part of The Panard Vision 3D Engine

    The Panard Vision 3D Engine is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    The Panard Vision 3D Engine is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Panard Vision 3D Engine; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright 1997-2002, Olivier Brunet

// Panard-Vision
// 3D real time engine
// (C) 2000, Olivier Brunet

// PVB 3DStudio Max3 driver (for Flexporter 1.06)
// PVB are exported through the Flexporter Max plugin by Pierre "Zappy" Terdiman (p.terdiman@wanadoo.fr)
// Flexporter home: http://www.codercorner.com/

// This code is here only for teaching purpose, this driver is included in the Panard Vision
// lib.

// Texture cropping values are ignored

// Before using this library consult the LICENSE file
#ifdef WIN32
#define ZEXPORT __cdecl
#else
#define ZEXPORT 
#include <stdio.h>
#endif
#include <zlib.h>
#include <bzlib.h>
#include <iostream.h>
#ifdef WIN32
#include <strstrea.h>
#else
#include <strstream.h>
#endif
#include <stdio.h>
#include "pvbread.h"
#include "pvbpriv.h"
#include <string>
#include <set>
using std::string;
using std::set;

const char *_PVB_READER_VERSION="0.1"; 

#define make_token(a,b,c,d) (a<<24)+(b<<16)+(c<<8)+d

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

PVBFileReader::PVBFileReader()
{
	_TheWorld=NULL;
}

PVBFileReader::~PVBFileReader()
{
	_TexMap.clear();
	_MeshMap.clear();
}

int PVBFileReader::LoadFromStream(istream &in,PVWorld *z)
{
   if (z==NULL) return ARG_INVALID;
    _TheWorld=z;
	
	_TexMap.clear();
	_MeshMap.clear();
	_NbrMaterialsToRead=_NbrTexturesToRead=_NbrHelpersToRead=_NbrLightsToRead=_NbrCamsToRead=_NbrMeshesToRead=0;

	debug(printf("� PVB Mesh file reader for Panard Vision V%s (Debug Mode Actived)\n",_PVB_READER_VERSION);)

	while(!in.eof())
	{
		char chunk[4];

		in.read(chunk,4);

		if(in.gcount()==0) return COOL;

		int h=ProcessChunk(make_token(chunk[0],chunk[1],chunk[2],chunk[3]),in);
		if(h!=COOL) return h;
	}

	return COOL;
}

int PVBFileReader::ProcessChunk(unsigned chunk,istream &in)
{
	switch(chunk)
	{
	case make_token('P','V','B','!'): return PVBHeaderR(in);
	case make_token('P','V','B','Z'): return PVBPackR(in);
	case make_token('M','A','I','N'): return PVBMainR(in);
	case make_token('M','E','S','H'): return PVBMeshR(in);
	case make_token('L','I','T','E'): return PVBLiteR(in);	
	case make_token('T','E','X','M'): return PVBTexmR(in);
	case make_token('M','A','T','L'): return PVBMatlR(in);
	default:
		return ProcessUserChunk(chunk,in);		
	}
	return BIZAR_ERROR;
}

int PVBFileReader::PVBPackR(istream &in)
{
	udword Compression, OriginalSize, PackedSize;
	
	in.read((char*)&Compression,sizeof(Compression));
	in.read((char*)&OriginalSize,sizeof(OriginalSize));
	in.read((char*)&PackedSize,sizeof(PackedSize));

	ubyte* Depacked = new ubyte[OriginalSize];
	ubyte* Packed = new ubyte[PackedSize];
	if(!Depacked) return NO_MEMORY;
	if(!Packed) return NO_MEMORY;

	in.read((char*)Packed,PackedSize);

	if(Compression==PVB_COMPRESSION_ZLIB)
	{
		debug(printf("      Unpacking with zlib\n"););
		// Use ZLib to depack the file  
		int ErrorCode = uncompress((Bytef*)Depacked, (uLongf*)&OriginalSize, Packed, PackedSize);
		if(ErrorCode!=Z_OK)	return BIZAR_ERROR; 
	}
	else if(Compression==PVB_COMPRESSION_BZIP2)
	{
		debug(printf("      Unpacking with bzip2\n"););
		// Use BZip2 to depack the file
		int ErrorCode = BZ2_bzBuffToBuffDecompress((char*)Depacked, &OriginalSize, (char*)Packed, PackedSize, 0, 0);
		if(ErrorCode!=BZ_OK) return BIZAR_ERROR;
	}
	else
	{
		cerr<<"ERROR: Unsupported compression format"<<endl;
		return BIZAR_ERROR;		
	}

	delete[] Packed;

	// Create a new array filled with depacked data
	istrstream buf((char*)Depacked,	OriginalSize);
	unsigned h=LoadFromStream(buf,_TheWorld);

	// Release depacked buffer
	delete[] Depacked;
	
	return h;
}

int PVBFileReader::PVBHeaderR(istream &in)
{
	UPVD32 dat;

	in.read((char*)&dat,4);

	if(dat!=PVB_FILE_SCENE) 
	{
		cerr<<"ERROR: Only PVB_FILE_SCENE supported."<<endl;
		return NOT_AVAILABLE;
	}

	return COOL;
}

int PVBFileReader::PVBMainR(istream &in)
{
	udword ver;
	PVBMainChunk main;

	in.read((char*)&ver,sizeof(ver));
	
	if(ver!=CHUNK_MAIN_VER)
	{
		debug(printf("ERROR: PVBMain only Version %u supported\n",CHUNK_MAIN_VER));
		return NOT_AVAILABLE;
	}

	in.read((char*)&main,sizeof(PVBMainChunk));

	cout<<"General stats:"<<endl;
	cout<<"\t * "<<main.num_geomobjects+main.num_derived_objects<<" meshes."<<endl;	
	cout<<"\t * "<<main.num_lights<<" lights."<<endl;
	cout<<"\t * "<<main.num_materials<<" materials."<<endl;
	cout<<"\t * "<<main.num_texmaps<<" textures."<<endl;	

	_NbrMeshesToRead=main.num_geomobjects+main.num_derived_objects;
	_NbrCamsToRead=main.num_cameras;
	_NbrLightsToRead=main.num_lights;
	_NbrHelpersToRead=main.num_helpers;
	_NbrTexturesToRead=main.num_texmaps;
	_NbrMaterialsToRead=main.num_materials;

	_TheWorld->AmbientLight.r=main.ambient_red;
	_TheWorld->AmbientLight.g=main.ambient_green;
	_TheWorld->AmbientLight.b=main.ambient_blue;

	return COOL;
}

int PVBFileReader::PVBMeshR(istream &in)
{
	udword ver,num_faces,num_vertices,num_texver,num_vercol,flags;
	ubyte skin,biped,parity,instance;
	PVBBasicInfo bi;
	PVMesh *m;
	PVQuat q;
	unsigned x,i;

	in.read((char*)&ver,sizeof(ver));
	
	if(ver!=CHUNK_MESH_VER)
	{
		debug(printf("ERROR: PVBMesh only Version %u supported\n",CHUNK_MESH_VER));
		return NOT_AVAILABLE;
	}
	
	while(_NbrMeshesToRead)
	{
		PVBBasicInfoR(in,bi);

		cout<<"Processing mesh "<<bi.name.data()<<"..."<<endl;

		// Skip bytes
		in.seekg(1,ios::cur);

		in.read((char*)&biped,sizeof(biped));
		in.read((char*)&instance,sizeof(instance));
		in.seekg(2,ios::cur); 
		in.read((char*)&skin,sizeof(skin));

		if(biped) in.seekg(8,ios::cur);

		if(!instance)
		{
			in.read((char*)&num_faces,sizeof(num_faces));
			in.read((char*)&num_vertices,sizeof(num_vertices));
			in.read((char*)&num_texver,sizeof(num_texver));
			in.read((char*)&num_vercol,sizeof(num_vercol));
			in.read((char*)&flags,sizeof(flags));
			in.read((char*)&parity,sizeof(parity));

			if(skin)
			{
				debug(printf("ERROR: PVBMesh skin not supported\n"));
				return NOT_AVAILABLE;
			}

			// PV stuff
			m=PV_SimpleCreateMesh(num_faces,num_vertices,0.4*(float)num_faces,0.4*(float)num_vertices);
			if(m==NULL) return NO_MEMORY;

			// Fill in the mesh
			/////////////////////////// Vertex Coords
			float qx,qy,qz;
			in.read((char*)&qx,sizeof(qx));
			in.read((char*)&qy,sizeof(qy));
			in.read((char*)&qz,sizeof(qz));

			sword *t=new sword[num_vertices*3];
			if(!t) return NO_MEMORY;

			in.read((char*)t,sizeof(sword)*3*num_vertices);
			
			for(i=0;i<num_vertices;i++)
			{				
				m->Vertex[i].xf=float(t[i*3+0])*qx;
				m->Vertex[i].yf=float(t[i*3+1])*qy;
				m->Vertex[i].zf=float(t[i*3+2])*qz;
				
				if(bi.D3DBasis)
				{
					// D3D Coordinates to PV
					m->Vertex[i].yf=-m->Vertex[i].yf;
					m->Vertex[i].zf=-m->Vertex[i].zf;
				}
				else
				{
					// Max Coordinates to PV
					float t=m->Vertex[i].yf;
					m->Vertex[i].yf=-m->Vertex[i].zf;
					m->Vertex[i].zf=-t;
				}
			}
			delete[] t;

			/////////////////// Mapping coords
			if(flags&PVB_UVW)
			{			
				in.read((char*)&qx,sizeof(qx));
				in.read((char*)&qy,sizeof(qy));

				sword *t=new sword[num_texver*2];
				if(!t) return NO_MEMORY;

				in.read((char*)t,sizeof(sword)*2*num_texver);
			
				for(i=0;i<num_vertices;i++)
				{
					m->Mapping[i].u=float(t[i*2+0])*qx;
					m->Mapping[i].v=1.0-float(t[i*2+1])*qy;
				}

				delete[] t;
			}

			////////// Topology
			unsigned stype;
			if(flags&PVB_WORDFACES) stype=sizeof(uword); else stype=sizeof(udword);

			if(flags&PVB_VFACE)
			{
				if(flags&PVB_WORDFACES)
				{
					uword *v=new uword[num_faces*3];
					if(!v) return NO_MEMORY;

					in.read((char*)v,sizeof(uword)*num_faces*3);

					if(flags&PVB_COMPRESSED) UnDelta(v,num_faces*3,2);

					for(i=0;i<num_faces;i++)
					{
						udword v2[3];

						if(!parity) 
						{
							uword t;

							t=v[i*3];
							v[i*3]=v[i*3+2];
							v[i*3+2]=t;
						}

						v2[0]=v[i*3+0];
						v2[1]=v[i*3+1];
						v2[2]=v[i*3+2];


						PV_SetVerticesToFace(&m->Face[i],v2,3);
					}

					delete[] v;
				}
				else
				{
					udword *v=new udword[num_faces*3];
					if(!v) return NO_MEMORY;

					in.read((char*)v,sizeof(udword)*num_faces*3);

					if(flags&PVB_COMPRESSED) UnDelta(v,num_faces*3,4);

					for(i=0;i<num_faces;i++)
					{					
						if(!parity) 
						{
							udword t;

							t=v[i*3];
							v[i*3]=v[i*3+2];
							v[i*3+2]=t;
						}

						PV_SetVerticesToFace(&m->Face[i],&v[i*3],3);
					}

					delete[] v;
				}
			}

			////////////////// Materials IDs
			udword *mats=new udword[num_faces];
			if(mats==NULL) return NO_MEMORY;

			in.read((char*)mats,sizeof(udword)*num_faces);
			for(i=0;i<num_faces;i++) m->Face[i].Material=(char*)mats[i];
			delete[] mats;

			///////////////// Consolidation			
			if(flags&PVB_CONSOLIDATION)
			{
				uword tot_faces,nsubmesh;
				udword *vindex=NULL,*mindex=NULL;
				float *vpool=NULL,*mpool=NULL,*npool=NULL;
				unsigned tot_vtx;

				in.read((char*)&tot_faces,sizeof(tot_faces));
				in.read((char*)&nsubmesh,sizeof(nsubmesh));

				tot_vtx=0;
				for(x=0;x<nsubmesh;x++)
				{
					udword v;
					in.read((char*)&v,sizeof(v));

					tot_vtx+=v;
				}

				PVMesh *m2=PV_SimpleCreateMesh(tot_faces,tot_vtx,0.4*(float)tot_faces,0.4*(float)tot_vtx);
				if(m2==NULL) return NO_MEMORY;
			
				unsigned curfac=0;
				for(x=0;x<nsubmesh;x++)
				{
					uword nfaces;
					udword mid;

					in.read((char*)&mid,sizeof(mid));

					in.read((char*)&nfaces,sizeof(nfaces));

					uword *t=new uword[nfaces*3];
					if(!t) return NO_MEMORY;

					in.read((char*)t,sizeof(uword)*nfaces*3);

					for(unsigned y=0;y<nfaces;y++)
					{
						unsigned v[3];

						PV_SetVerticesToFace(&m2->Face[curfac],v,3);
						if(parity) 
						{
							m2->Face[curfac].V[0]=t[y*3+2];
							m2->Face[curfac].V[1]=t[y*3+1];
							m2->Face[curfac].V[2]=t[y*3+0];
						}
						else
						{
							m2->Face[curfac].V[0]=t[y*3+0];
							m2->Face[curfac].V[1]=t[y*3+1];
							m2->Face[curfac].V[2]=t[y*3+2];
						}

						m2->Face[curfac].Material=(char*)mid;
						curfac++;
					}

					delete[] t;
				}

				//////////////////////////////////////////
				uword org_num_vert,fin_num_vert,org_num_tex;

				in.read((char*)&org_num_vert,sizeof(org_num_vert));
				in.read((char*)&fin_num_vert,sizeof(fin_num_vert));
				in.read((char*)&org_num_tex,sizeof(org_num_tex));

				vindex=new udword[fin_num_vert];
				if(vindex==NULL) return NO_MEMORY;

				in.read((char*)vindex,fin_num_vert*sizeof(udword));

				//////////////////////////////////////////
				udword num_vert_pool;
				in.read((char*)&num_vert_pool,sizeof(num_vert_pool));
				vpool=new float[num_vert_pool*3];
				if(vpool==NULL) return NO_MEMORY;

				in.read((char*)vpool,num_vert_pool*3*sizeof(float));

				//////////////////////////////////////////
				if(flags&PVB_UVW)
				{
					mindex=new udword[fin_num_vert];
					if(mindex==NULL) return NO_MEMORY;

					in.read((char*)mindex,sizeof(udword)*fin_num_vert);

					udword num_tex_pool;
					in.read((char*)&num_tex_pool,sizeof(num_tex_pool));
					mpool=new float[num_tex_pool*2];
					if(mpool==NULL) return NO_MEMORY;

					in.read((char*)mpool,sizeof(float)*2*num_tex_pool);
				}

				//////////////////////////////////////////
				if(flags&PVB_VERTEXNORMALS)
				{
					udword num_vnorm;
					in.read((char*)&num_vnorm,sizeof(num_vnorm));

					npool=new float[num_vnorm*3];
					if(npool==NULL) return NO_MEMORY;
					
					in.read((char*)npool,sizeof(float)*3*num_vnorm);
				}

				////////////////////////////////////////// Remap				
				for(x=0;x<fin_num_vert;x++)
				{
					if(bi.D3DBasis)
					{
						m2->Vertex[x].xf=vpool[vindex[x]*3];
						m2->Vertex[x].yf=-vpool[vindex[x]*3+1];
						m2->Vertex[x].zf=-vpool[vindex[x]*3+2];

						if(npool)
						{
							m2->Vertex[x].Normal.xf=npool[x*3];
							m2->Vertex[x].Normal.yf=-npool[x*3+1];
							m2->Vertex[x].Normal.zf=-npool[x*3+2];
						}
					}
					else
					{
						m2->Vertex[x].xf=vpool[vindex[x]*3];
						m2->Vertex[x].yf=-vpool[vindex[x]*3+2];
						m2->Vertex[x].zf=-vpool[vindex[x]*3+1];

						if(npool)
						{
							m2->Vertex[x].Normal.xf=npool[x*3];
							m2->Vertex[x].Normal.yf=-npool[x*3+2];
							m2->Vertex[x].Normal.zf=-npool[x*3+1];
						}
					}

					if(mpool)
					{
						m2->Mapping[x].u=mpool[mindex[x]*2];
						m2->Mapping[x].v=1.0-mpool[mindex[x]*2+1];
					}
				}

				for(x=0;x<m->NbrFaces;x++)
				{					
					//PV_SetVerticesToFace(&m2->Face[x],m->Face[x].V,3); 
					///m2->Face[x].Material=m->Face[x].Material;
					m->Face[x].Material=NULL;
				}

				PV_MeshNormCalc(m2);
				if(npool)
				for(x=0;x<fin_num_vert;x++)
				{
					if(bi.D3DBasis)
					{
						m2->Vertex[x].Normal.xf=npool[x*3];
						m2->Vertex[x].Normal.yf=-npool[x*3+1];
						m2->Vertex[x].Normal.zf=-npool[x*3+2];
					}
					else
					{
						m2->Vertex[x].Normal.xf=npool[x*3];
						m2->Vertex[x].Normal.yf=-npool[x*3+2];
						m2->Vertex[x].Normal.zf=-npool[x*3+1];
					}
				}


				PV_KillMesh(m);
				m=m2;
				
				////////////////////////////////////////// Clean
				delete[] vpool;
				delete[] mpool;
				delete[] npool;
				delete[] vindex;
				delete[] mindex;
			}
		}
		else
		{
			// Mesh is an instance
			std::map<unsigned,PVMesh*>::iterator iter;
			iter=_MeshMap.find(bi.linkid);
			if(iter!=_MeshMap.end())
			{
				m=PV_CreateMeshInstance((*iter).second);
			}
			if(m==NULL) return NO_MEMORY;
		}

		// Ligthing infos
		udword nlcol;

		in.read((char*)&nlcol,sizeof(nlcol));
		in.seekg(3*4*nlcol,ios::cur);

		// PRS
		PV_SetMeshName(m,(char*)bi.name.data());

		m->Position.xf=bi.pos_x;
		m->Position.yf=bi.pos_y;
		m->Position.zf=bi.pos_z;

		m->ScaleX=bi.scale_x;
		m->ScaleY=bi.scale_y;
		m->ScaleZ=bi.scale_z;

		q.w=bi.rot_w;
		q.x=bi.rot_x;
		q.y=bi.rot_y;
		q.z=bi.rot_z;

		QuatToMatrix(&q,m->Matrix);

		// User stuff
		ProcessUserMesh(m,bi.user);

		if((m->NbrFaces!=0) && (m->NbrVertices!=0))
		{
			if(bi.parid!=0)
			{
				std::map<unsigned,PVMesh*>::iterator iter;
				iter=_MeshMap.find(bi.parid);
				if(iter!=_MeshMap.end())
				{
					PV_AddChildMesh((*iter).second,m);
					if(bi.PRSLocal) m->Flags|=MESH_INHERIT;
				}
				else
					PV_AddMesh(_TheWorld,m);
			}
			else
				PV_AddMesh(_TheWorld,m);

			_MeshMap.insert(std::map<unsigned,PVMesh*>::value_type(bi.objid,m));

			if(!(flags&PVB_CONSOLIDATION))
				PV_MeshNormCalc(m);
			PV_MeshBuildBoxes(m,700);
		}
		else 
			PV_KillMesh(m);

		_NbrMeshesToRead--;
	}

	return COOL;
}

int PVBFileReader::PVBLiteR(istream &in)
{
	udword ver;

	in.read((char*)&ver,sizeof(ver));
	
	if(ver!=CHUNK_LITE_VER)
	{
		debug(printf("ERROR: PVBLite only Version %u supported\n",CHUNK_LITE_VER));
		return NOT_AVAILABLE;
	}

	for(unsigned i=0;i<_NbrLightsToRead;i++)
	{
		PVBBasicInfo bi;		

		PVBBasicInfoR(in,bi);

		udword ltype;
		ubyte directional,spotlight,used;
		float r,g,b,intensity,near_start,near_end,start,end;

		in.read((char*)&ltype,sizeof(ltype));

		PVLightType pvl[]={PVL_INFINITEPOINT,PVL_SPOT,PVL_DIRECTIONAL,PVL_SPOT,PVL_DIRECTIONAL};
		
		// PV stuff
		PVLight *l=PV_CreateLight(pvl[ltype],(char*)bi.name.data());
		PV_AddLight(_TheWorld,l);

		in.read((char*)&spotlight,sizeof(spotlight));
		in.read((char*)&directional,sizeof(directional));

		in.read((char*)&r,sizeof(r));
		in.read((char*)&g,sizeof(g));
		in.read((char*)&b,sizeof(b));
		in.read((char*)&intensity,sizeof(intensity));
		in.seekg(2*4,ios::cur);
		in.read((char*)&used,sizeof(used));

		in.seekg(6,ios::cur);

		in.read((char*)&near_start,sizeof(near_start));
		in.read((char*)&near_end,sizeof(near_end));
		in.read((char*)&start,sizeof(start));
		in.read((char*)&end,sizeof(end));

		in.seekg(12*4+2,ios::cur);

		l->Color.r=r;
		l->Color.g=g;
		l->Color.b=b;
		l->Power.Intensity=intensity;

		l->Range=end;		

		l->Position.xf=bi.pos_x;
		l->Position.yf=bi.pos_y;
		l->Position.zf=bi.pos_z;

		if(!used) l->Flags|=LIGHT_FORGET;

		// Let's extract direction from quaternion
		PVQuat q;
		PVMat3x3 mat;

		q.w=bi.rot_w;
		q.x=bi.rot_x;
		q.y=bi.rot_y;
		q.z=bi.rot_z;

		QuatToMatrix(&q,mat);

		l->Direction.xf=mat[2][0];
		l->Direction.yf=mat[2][1];
		l->Direction.zf=mat[2][2];

		ProcessUserLight(l,bi.name);
	}

	return COOL;
}

int PVBFileReader::PVBTexmR(istream &in)
{
	string name;
	udword ver,matid,w,h;
	ubyte alpha,withtex;

	in.read((char*)&ver,sizeof(ver));
	
	if(ver!=CHUNK_TEXM_VER)
	{
		debug(printf("ERROR: PVBTexm only Version %u supported\n",CHUNK_TEXM_VER));
		return NOT_AVAILABLE;
	}

	for(unsigned i=0;i<_NbrTexturesToRead;i++)
	{
		char c;		

		name="";

		do
		{
			in.read(&c,1);
			name+=c;
		}
		while(c!=0);

		in.read((char*)&matid,sizeof(matid));
		in.read((char*)&withtex,sizeof(withtex));
		if(withtex)
		{
			in.read((char*)&w,sizeof(w));
			in.read((char*)&h,sizeof(h));
			in.read((char*)&alpha,sizeof(alpha));

			PVTexture tex;

			tex.Height=h;
			tex.Width=w;
			
			if(alpha)
			{
				tex.Texture=(unsigned char*)malloc(w*h*4);
				tex.ShiftHeight=1; // Hack ! Will tell the material reader that it's a 
									// 32 bits texture for the PV_CreateMaterial() call
			}
			else
			{
				tex.Texture=(unsigned char*)malloc(w*h*3);
				tex.ShiftHeight=0; // Hack ! Will tell the material reader that it's a 
									// 24 bits texture for the PV_CreateMaterial() call
			}
			
			if(tex.Texture==NULL) return NO_MEMORY;

			if(alpha)
				in.read(tex.Texture,w*h*4);
			else
				in.read(tex.Texture,w*h*3);

			_TexMap.insert(std::map<unsigned,PVTexture>::value_type(matid,tex));
		}
		else
		{
			debug(printf("ERROR: Textures are not included in file, which is not supported\n"));
			return BIZAR_ERROR;
		}

		in.seekg(16*4,ios::cur);		
	}
	return COOL;
}

int PVBFileReader::PVBMatlR(istream &in)
{
	udword ver;
	string name;
	udword matid,ambid,difid;
	PVMaterial *m;
	std::set<unsigned> alreadyused;

	in.read((char*)&ver,sizeof(ver));
	
	if(ver!=CHUNK_MATL_VER)
	{
		debug(printf("ERROR: PVBMatl only Version %u supported\n",CHUNK_MATL_VER));
		return NOT_AVAILABLE;
	}

	for(unsigned i=0;i<_NbrMaterialsToRead;i++)
	{
		char c;		

		name="";

		do
		{
			in.read(&c,1);
			name+=c;
		}
		while(c!=0);

		in.read((char*)&matid,sizeof(matid));
		in.read((char*)&ambid,sizeof(ambid));
		in.read((char*)&difid,sizeof(difid));

		in.seekg(10*4,ios::cur);

		in.seekg(12*4,ios::cur);

		float ar,ag,ab,dr,dg,db,sr,sg,sb,opacity;

		in.read((char*)&ar,sizeof(ar));
		in.read((char*)&ag,sizeof(ag));
		in.read((char*)&ab,sizeof(ab));
		in.read((char*)&dr,sizeof(dr));
		in.read((char*)&dg,sizeof(dg));
		in.read((char*)&db,sizeof(db));
		in.read((char*)&sr,sizeof(sr));
		in.read((char*)&sg,sizeof(sg));
		in.read((char*)&sb,sizeof(sb));

		in.seekg(4*3,ios::cur); // Filter Color

		ubyte double_sided,wire;
		udword shading;

		in.read((char*)&shading,sizeof(shading));
		in.seekg(2,ios::cur);
		in.read((char*)&double_sided,sizeof(double_sided));
		in.read((char*)&wire,sizeof(wire));
		in.seekg(4+2,ios::cur);
		
		in.seekg(3*4,ios::cur);
		in.read((char*)&opacity,sizeof(opacity));
		in.seekg(6*4,ios::cur);

		// PV Stuff
		if(difid==0xFFFFFFFF)
			m=PV_CreateMaterial((char*)name.data(),GOURAUD|ZBUFFER,TEXTURE_NONE,0);
		else
			m=PV_CreateMaterial((char*)name.data(),GOURAUD|PERSPECTIVE|MAPPING|ZBUFFER,TEXTURE_RGBA|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
		if(m==NULL) return NO_MEMORY;

		// Process Faceted attribute
		if(shading==0) 
		{
			m->Type&=~GOURAUD;
			m->Type|=FLAT;
		}

		m->Diffuse.r=dr;
		m->Diffuse.g=dg;
		m->Diffuse.b=db;
		m->Specular.r=sr;
		m->Specular.g=sg;
		m->Specular.b=sb;
		m->Emissive.r=ar*_TheWorld->AmbientLight.r;
		m->Emissive.g=ag*_TheWorld->AmbientLight.g;
		m->Emissive.b=ab*_TheWorld->AmbientLight.b;
		if(opacity!=1.0)
		{
			m->AlphaConstant=opacity;
			m->BlendRgbSrcFactor=BLEND_SRC_ALPHA;
			m->BlendRgbDstFactor=BLEND_ONE_MINUS_SRC_ALPHA;
			m->Type|=BLENDING;
		}

		if(double_sided) m->Type|=DOUBLE_SIDED;
		if(wire) m->Type|=WIREFRAME;

		if(difid!=0xFFFFFFFF)
		{
			std::map<unsigned,PVTexture>::iterator iter;
			iter=_TexMap.find(difid);

			if(iter==_TexMap.end())
			{
				cerr<<"ERROR: Unmatched texture/material\n"<<endl;
				return BIZAR_ERROR;
			}

			// Check if 24 bits texture instead of 32
			if((*iter).second.ShiftHeight==0)
				m->TextureFlags=TEXTURE_RGB|TEXTURE_BILINEAR|TEXTURE_MIPMAP;

			// Check if texture is already used
			std::set<unsigned>::iterator i2;
			i2=alreadyused.find(difid);

			if(i2!=alreadyused.end())
				m->TextureFlags|=TEXTURE_TEX_DONT_FREE;
			else
				alreadyused.insert(difid);

			PV_SetMaterialTexture(m,(*iter).second.Width,(*iter).second.Height,(*iter).second.Texture,NULL);
		}

		unsigned userarg[2];
		userarg[0]=(unsigned)m;
		userarg[1]=matid;
		PV_IterateMeshList(_TheWorld->Objs,FixMaterials,(int)userarg);

		PV_AddMaterial(_TheWorld,m);
	}
	
	return COOL;
}
//////////////////////////////////////////////////////////////////////////////////////////////
static int PVAPI FixMaterials(PVMesh *oo,int userarg)
{
	int *u=(int*)userarg;
	for(unsigned k=0;k<oo->NbrFaces;k++)
	{
		if(oo->Face[k].MaterialInfo==NULL)
		if(oo->Face[k].Material==(char*)u[1])
		{
			oo->Face[k].MaterialInfo=(PVMaterial*)u[0];
			oo->Face[k].Material=NULL;
		}
	}
	return COOL;
}

int PVBBasicInfoR(istream &in,PVBBasicInfo &bi)
{
	char c;		

	bi.name="";
	do
	{
		in.read(&c,1);
		bi.name+=c;
	}
	while(c!=0);

	in.read((char*)&bi.objid,sizeof(bi.objid));
	in.read((char*)&bi.parid,sizeof(bi.parid));
	in.read((char*)&bi.linkid,sizeof(bi.linkid));
	in.read((char*)&bi.group,sizeof(bi.group));

	in.read((char*)&bi.pos_x,sizeof(bi.pos_x));
	in.read((char*)&bi.pos_y,sizeof(bi.pos_y));
	in.read((char*)&bi.pos_z,sizeof(bi.pos_z));

	in.read((char*)&bi.rot_x,sizeof(bi.rot_x));
	in.read((char*)&bi.rot_y,sizeof(bi.rot_y));
	in.read((char*)&bi.rot_z,sizeof(bi.rot_z));
	in.read((char*)&bi.rot_w,sizeof(bi.rot_w));

	in.read((char*)&bi.scale_x,sizeof(bi.scale_x));
	in.read((char*)&bi.scale_y,sizeof(bi.scale_y));
	in.read((char*)&bi.scale_z,sizeof(bi.scale_z));

	in.read((char*)&bi.wire_color,sizeof(bi.wire_color));

	in.read((char*)&bi.PRSLocal,sizeof(bi.PRSLocal));
	in.read((char*)&bi.D3DBasis,sizeof(bi.D3DBasis));

	if(bi.D3DBasis)
	{
		bi.pos_y=-bi.pos_y;
		bi.pos_z=-bi.pos_z;

		bi.rot_y=-bi.rot_y;
		bi.rot_z=-bi.rot_z;
	}
	else
	{
		float t;
		t=bi.pos_y;
		bi.pos_y=-bi.pos_z;
		bi.pos_z=-t;

		t=bi.rot_y;
		bi.rot_y=-bi.rot_z;
		bi.rot_z=-t;

		t=bi.scale_y;
		bi.scale_y=bi.scale_z;
		bi.scale_z=t;
	}

	do
	{
		in.read(&c,1);
		bi.user+=c;
	}
	while(c!=0);

	return COOL;
}

//////////////////////////////////////////////////////////////////////////////////////////

bool PVBFileReader::UnDelta(void* buffer, udword nbitems, udword itemsize)
{
	switch(itemsize)
	{
		case 1:
		{
			sbyte* Buf = (sbyte*)buffer;
			for(udword i=1;i<nbitems;i++)	Buf[i]+=Buf[i-1];
			return true;
		}
		break;

		case 2:
		{
			sword* Buf = (sword*)buffer;
			for(udword i=1;i<nbitems;i++)	Buf[i]+=Buf[i-1];
			return true;
		}
		break;

		case 4:
		{
			sdword* Buf = (sdword*)buffer;
			for(udword i=1;i<nbitems;i++)	Buf[i]+=Buf[i-1];
			return true;
		}
		break;
	}
	return false;
}

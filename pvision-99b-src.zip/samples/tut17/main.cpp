// Panard Vision Sample
// (C) 1997-98, Olivier Brunet

// Demonstrates Procedural textures

// SMKaribou/GMF

#include <stdio.h>
#include <stdlib.h>
#include <pvision.h>
#include <3dsread.h>						// The 3dstudio 4 driver
#include "pvd3d6.h"
#include "DirectDrawEasy.h"
#include "DXMen.h"

#define WIDTH			16
#define HEIGHT			32

class PVEasy:public DDrawEasy
{
	PVWorld *World;
	PVCam *Cam;	

	PVMesh *Mesh1;
	PVMaterial *mat;
	float ax,ay,az;

public:
	PVEasy();
	~PVEasy();
	void InitPV(void);
	int OnIdle(void);
	void DoFire(UPVD8 *dst,PVRGBFormat *rgb);
};

///////////////////////////////////////////////////////////////////////////////
PVEasy::PVEasy()
{
	ax=ay=az=0;
	World=NULL;
	Cam=NULL;
}

PVEasy::~PVEasy()
{
	// Destructor
	PV_KillWorld(World);
	PV_KillCam(Cam);
}

// This routine do the procedural computation (a fire :)
// This is not as fast as it should be of course, just here to show how to fill
// a procedural texture.
extern UPVD8 palette[];
void PVEasy::DoFire(UPVD8 *dst,PVRGBFormat *rgb)
{
	unsigned i,j,val,r,g,b;
	UPVD8 *p,*t8,*pa;
	UPVD16 *t16;
	UPVD32 *t32;
	static UPVD8 fire[WIDTH*(HEIGHT+2)];

	for(i=0;i<25;i++) fire[WIDTH*(HEIGHT+2-1)+(unsigned)(WIDTH*((float)rand()/(float)RAND_MAX))]=80*((float)rand()/(float)RAND_MAX)+100;
	
	// Do the fire effect
	for(i=0;i<HEIGHT+2-1;i++)
	{
		for(j=1;j<WIDTH-1;j++)
		{
			p=&fire[i*WIDTH+j];
			val=*(p+WIDTH)+*(p+WIDTH-1)+*(p+WIDTH+1)+*(p+2*WIDTH);
			val>>=2;
			if(val) val--;
			*p=val;
		}
	}

	// Update surface according to the surface format
	t8=dst;
	t16=(UPVD16*)dst;
	t32=(UPVD32*)dst;
	for(i=0,p=fire;i<HEIGHT;i++)
	{		
		for(j=0;j<WIDTH;j++,p++)
		{
			pa=&palette[(*p)*3];
			r=pa[0];g=pa[1];b=pa[2];

			switch(rgb->NbrBitsPerPixel)
			{
			case 16:				
					r>>=(8-rgb->RedSize);
					g>>=(8-rgb->GreenSize);
					b>>=(8-rgb->BlueSize);
					*t16=(r<<rgb->RedPos)|
						(g<<rgb->GreenPos)|
						(b<<rgb->BluePos);
					t16++;
					break;
			case 24:
					val=(r<<rgb->RedPos)|
						(g<<rgb->GreenPos)|
						(b<<rgb->BluePos);
					*t8=val;
					val>>=8;
					t8++;
					*t8=val;
					val>>=8;
					t8++;
					*t8=val;
					t8++;
					break;
			case 32:val=(r<<rgb->RedPos)|
						(g<<rgb->GreenPos)|
						(b<<rgb->BluePos);
					*t32=val;
					t32++;
					break;
			}
		}
		t8+=rgb->Pitch-(rgb->NbrBitsPerPixel/8)*WIDTH;
		t16+=rgb->Pitch/2-(rgb->NbrBitsPerPixel/8)*WIDTH/2;
		t32+=rgb->Pitch/4-(rgb->NbrBitsPerPixel/8)*WIDTH/4;
	}
}

void PVEasy::InitPV(void)
{
    PVRGBF ambient={0.5,0.5,0.5,0};    // Ambient Light
    PVRGBF em={0,0,0,0};				 // Material's emmissive
	PVRGBF di={1,1,1,1};				 // Material's diffuse
	PVRGBF sp={0,0,0,0};				 // Material's Specular

    // Render Mode Setup
    PV_SetClipLimit(0,Width-1,0,Height-1,Pitch);			// Sets rendering window   
	PV_SetHardwareDriver(&PVDriver);						// Register the hardware driver
	
	// Starts Hardware
//	if(PV_InitAccelSupport((long)win)!=COOL)
	if(PV_InitAccelSupport((long)lpDD)!=COOL)				// The Direct3D driver needs a pointer to the DirectDraw object, other driver take the window handle
	{
		printf("Unable to initialize hardware");
		exit(1);
	}
	
/*	if(Depth<=8)
	{
		MessageBox(win,"This samples works only in RGB modes (depth>8)","Sorry",MB_ICONERROR|MB_OK);
		exit(1);
	}*/
	PV_SetMode(PVM_RGB|PVM_USEHARDWARE);			// Sets rendering mode

	PV_SetRGBIndexingMode(GetMaskSize(RedMask),GetMaskSize(GreenMask),GetMaskSize(BlueMask),GetMaskPos(RedMask),GetMaskPos(GreenMask),GetMaskPos(BlueMask),GetMaskSize(AlphaMask));
	
	// World setup
	World=PV_CreateWorld();
	if(World==NULL)
	{
		Error("Unable to Create World");
		exit(1);
	}

	PV_WorldSetAmbientLight(World,ambient);

	// Camera Setup
	Cam=PV_CreateCam("CAMERA");
	if(Cam==NULL)
	{
		Error("Unable to create camera");
		exit(1);
	}
	PV_SetCamFieldOfView(Cam,(float)Width/(float)Height);
	Cam->Height=Height;
    Cam->Width=Width;
	Cam->CenterX=Width/2;
	Cam->CenterY=Height/2;
	World->Camera=Cam;
	Cam->pos.yf=-100;
	Cam->pos.zf=800;

	// Mesh Setup
	if(LoadMeshFrom3DS("../data/cube.3ds",World)!=COOL)
	{
		Error("Unable to load mesh");
		exit(1);
	}
	Mesh1=World->Objs;		// Gets a pointer to the first mesh

    // Procedural Material Setup (16*16)
	mat=PV_CreateProceduralMaterial("APE",WIDTH,HEIGHT,PERSPECTIVE|MAPPING,TEXTURE_RGB|TEXTURE_BILINEAR);
	PV_AddMaterial(World,mat);

    // Prepare to render
	if(PV_CompileMeshes(World)!=COOL)
	{
		Error("Unable to compile meshes");
		exit(1);
	}
	if(PV_CompileMaterials(World,NULL,NULL)!=COOL)
	{
		Error("Unable to compile materials");
		exit(1);
	}	

	// Fix the fire palette
	for(unsigned i=0;i<768;i++) palette[i]*=4;
}

int PVEasy::OnIdle(void)
{		
	//Fill(0,0,0,Height,Width,0);
	PV_FillSurface(0,0,0,0,0);

	// Animate the beauty
	ay+=PI/50;
	az+=PI/40;
	if(ay>2*PI) ay-=2*PI;
	if(az>2*PI) az-=2*PI;

	PV_MeshSetupMatrix(Mesh1,ay,ax,ax);

	// Updates the procedural texture
	UPVD8 *buf;
	PVRGBFormat rgb;
	PV_LockProceduralMaterial(mat,&rgb,&buf,0);				// Read/Write Lock
	DoFire(buf,&rgb);
	PV_UnLockProceduralMaterial(mat);
	
	// The Lock primitives gives access to the DirectDraw surface
	// The surface should be unlocked ASAP!
	PV_BeginFrame();
	PV_RenderWorld(World,0/*Lock()*/);
	PV_EndFrame();

	//Unlock();
		
	//Flip();
	PV_FlipSurface();

	return TRUE;
}

//////////////////////////////////////////////////////////////

int main(int argc,char **argv)
{
	PVEasy pve;
	DDInfo *ddi;

	InitPVision();

	printf("Panard Vision : Procedural textures\n ALT+F4 to quit.");
	printf("\n\nPanard Vision version : %s\nBuild : %s, %s\n",PVISION_VERSION,PVISION_DATE,PVISION_TIME);
	
	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Panard Vision Setup
	pve.InitPV();

	// Some nice things
	pve.Run();

	return 0;
}


UPVD8 palette[768]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,1,0,0,3,0,0,5,0,0,7,1,0,9,1,0,11,1,0,
                                 14,2,0,16,2,0,18,2,0,20,3,0,22,3,1,24,4,1,26,
                                 4,1,28,5,1,30,5,1,33,5,1,35,6,1,37,7,1,39,8,
                                 1,41,8,1,42,9,1,44,11,1,46,11,1,48,13,2,50,14,2,
                                 52,15,2,53,16,2,55,17,2,57,18,3,59,20,3,61,21,3,63,
                                 23,4,63,25,5,63,27,6,63,29,7,63,31,8,63,34,9,63,35,
                                 9,63,36,10,63,38,11,63,39,11,63,40,12,63,42,13,63,43,13,
                                 63,44,14,63,45,15,63,46,15,63,47,16,63,49,17,63,50,18,63,
                                 50,18,63,52,19,63,53,20,63,53,22,63,54,24,63,54,27,63,55,
                                 29,63,55,32,63,56,34,63,56,36,63,                                   57,39,63,58,41,63,58,43,
                                 63,59,46,63,59,48,63,60,51,63,60,53,63,61,55,63,61,58,63,
                                 62,60,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,63,
                                 63,63,63,63,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                 0,0,0,0,0,21,21,21};

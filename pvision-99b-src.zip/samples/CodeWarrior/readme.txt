This directory contains 2 tutorials with their project for CodeWarrior.

You surely have to set the path contained in the projects to suit your installation.

They have been converted by Jesper Juul <jj@pobox.com>.
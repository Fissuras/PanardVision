// Panard Vision Sample
// (C) 1997-98, Olivier Brunet

// Demonstrates per face UV coordinates

// SMKaribou/GMF

#include <stdio.h>
#include <pvision.h>
#include <pvut.h>
#include "DirectDrawEasy.h"
#include "DXMen.h"

class PVEasy:public DDrawEasy
{
	PVWorld *World;
	PVCam *Cam;

	PVMesh *Mesh1;
	float ax,ay,az;

public:
	PVEasy();
	~PVEasy();
	void InitPV(void);
	int OnIdle(void);
	PVMesh *CreateSkyBox(float mins[],float maxs[],PVMaterial *sky[]);
};

///////////////////////////////////////////////////////////////////////////////
PVEasy::PVEasy()
{
	ax=ay=az=0;
	World=NULL;
	Cam=NULL;
}

PVEasy::~PVEasy()
{
	// Destructor
	PV_KillWorld(World);
	PV_KillCam(Cam);
}

PVMesh *PVEasy::CreateSkyBox(float mins[],float maxs[],PVMaterial *sky[])
{
	PVMesh* Mesh1;
	unsigned V[4];

	Mesh1=PV_SimpleCreateMeshWithAdditionalMappings(6,8,50,50,6*4);     // Clip Values a lot overestimated
																		// Each of the 6 faces has 4 vertices,
																		// we need 6*4 UV pairs.
	if(Mesh1==NULL) return NULL;
    Mesh1->Flags|=MESH_NOSORT;				 // no sorting needed for a cube, since it's a convex polyhedron

	Mesh1->Vertex[0].xf=mins[0];
    Mesh1->Vertex[0].yf=mins[1];
    Mesh1->Vertex[0].zf=mins[2];

	Mesh1->Vertex[1].xf=maxs[0];
    Mesh1->Vertex[1].yf=mins[1];
    Mesh1->Vertex[1].zf=mins[2];

	Mesh1->Vertex[2].xf=maxs[0];
    Mesh1->Vertex[2].yf=maxs[1];
    Mesh1->Vertex[2].zf=mins[2];

	Mesh1->Vertex[3].xf=mins[0];
    Mesh1->Vertex[3].yf=maxs[1];
    Mesh1->Vertex[3].zf=mins[2];

	Mesh1->Vertex[4].xf=mins[0];
    Mesh1->Vertex[4].yf=mins[1];
    Mesh1->Vertex[4].zf=maxs[2];

	Mesh1->Vertex[5].xf=maxs[0];
    Mesh1->Vertex[5].yf=mins[1];
    Mesh1->Vertex[5].zf=maxs[2];

	Mesh1->Vertex[6].xf=maxs[0];
    Mesh1->Vertex[6].yf=maxs[1];
    Mesh1->Vertex[6].zf=maxs[2];

	Mesh1->Vertex[7].xf=mins[0];
    Mesh1->Vertex[7].yf=maxs[1];
    Mesh1->Vertex[7].zf=maxs[2];
	
	// Setup One face
	Mesh1->Face[0].NbrVertices=4;        
    Mesh1->Face[0].MaterialInfo=sky[0];		

	V[0]=3;
	V[1]=2;
	V[2]=1;
	V[3]=0;
	PV_SetVerticesToFace(&Mesh1->Face[0],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[0],0,0,1.0-1.0/256.0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[0],1,1.0-1.0/256.0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[0],2,1.0-1.0/256.0,0);
	PV_SetPerFaceUV(&Mesh1->Face[0],3,0,0);			

	// Setup One face
	Mesh1->Face[1].NbrVertices=4;        
    Mesh1->Face[1].MaterialInfo=sky[1];

	V[0]=4;
	V[1]=5;
	V[2]=6;
	V[3]=7;
	PV_SetVerticesToFace(&Mesh1->Face[1],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[1],0,1.0-1.0/256.0,0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[1],1,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[1],2,0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[1],3,1.0-1.0/256.0,1.0-1.0/256.0);

	// Setup One face
	Mesh1->Face[2].NbrVertices=4;        
    Mesh1->Face[2].MaterialInfo=sky[2];

	V[0]=6;
	V[1]=5;
	V[2]=1;
	V[3]=2;
	PV_SetVerticesToFace(&Mesh1->Face[2],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[2],0,1.0-1.0/256.0,1.0-1.0/256.0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[2],1,1.0-1.0/256.0,0);
	PV_SetPerFaceUV(&Mesh1->Face[2],2,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[2],3,0,1.0-1.0/256.0);

	// Setup One face
	Mesh1->Face[3].NbrVertices=4;        
    Mesh1->Face[3].MaterialInfo=sky[3];

	V[0]=3;
	V[1]=0;
	V[2]=4;
	V[3]=7;
	PV_SetVerticesToFace(&Mesh1->Face[3],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[3],0,1.0-1.0/256.0,1.0-1.0/256.0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[3],1,1.0-1.0/256.0,0);
	PV_SetPerFaceUV(&Mesh1->Face[3],2,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[3],3,0,1.0-1.0/256.0);

	// Setup One face
	Mesh1->Face[4].NbrVertices=4;        
    Mesh1->Face[4].MaterialInfo=sky[4];

	V[0]=5;
	V[1]=4;
	V[2]=0;
	V[3]=1;
	PV_SetVerticesToFace(&Mesh1->Face[4],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[4],0,0,0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[4],1,0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[4],2,1.0-1.0/256.0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[4],3,1.0-1.0/256.0,0);

	// Setup One face
	Mesh1->Face[5].NbrVertices=4;        
    Mesh1->Face[5].MaterialInfo=sky[5];

	V[0]=2;
	V[1]=3;
	V[2]=7;
	V[3]=6;
	PV_SetVerticesToFace(&Mesh1->Face[5],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[5],0,1.0-1.0/256.0,0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[5],1,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[5],2,0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[5],3,1.0-1.0/256.0,1.0-1.0/256.0);
	
	PV_SetMeshName(Mesh1,"NICE SKY BOX");

	PV_MeshNormCalc(Mesh1);    
    PV_MeshBuildBoxes(Mesh1,10);

	return Mesh1;
}

void PVEasy::InitPV(void)
{
    PVRGBF ambient={0.1,0.1,0.1,0};    // Ambient Light
    PVMaterial *mats[6];

    // Render Mode Setup
    PV_SetClipLimit(0,Width-1,0,Height-1,Pitch);			// Sets rendering window   
	
	PV_SetMode(/*PVM_BILINEAR|*/(Depth!=8?PVM_RGB:PVM_PALETIZED8));			// Sets rendering mode (ZBuffer)

	if(!(PV_Mode&PVM_PALETIZED8)) 
	{
		// We are in RGB rendering, sets the RGB masks according to the current device
		PV_SetRGBIndexingMode(GetMaskSize(RedMask),GetMaskSize(GreenMask),GetMaskSize(BlueMask),GetMaskPos(RedMask),GetMaskPos(GreenMask),GetMaskPos(BlueMask),GetMaskSize(AlphaMask));
	}

	// World setup
	World=PV_CreateWorld();
	if(World==NULL)
	{
		Error("Unable to Create World");
		exit(1);
	}
	if(Depth==8) World->ReservedColors=10;							// the 10 first colors are for windows
	PV_WorldSetAmbientLight(World,ambient);

	// Camera Setup
	Cam=PV_CreateCam("CAMERA");
	if(Cam==NULL)
	{
		Error("Unable to create camera");
		exit(1);
	}
	PV_SetCamFieldOfView(Cam,(float)Width/(float)Height);
	Cam->Height=Height;
    Cam->Width=Width;
	Cam->CenterX=Width/2;
	Cam->CenterY=Height/2;
	World->Camera=Cam;
	PV_SetCamTarget(Cam,0,0,-1);

	// Do the sky
	mats[0]=PV_CreateMaterial("FRONT",NOTHING|MAPPING|PERSPECTIVE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_ft.jpg",mats[0])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[0]->RepeatU=TEXTURE_CLAMP;
	mats[0]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[0]);

	mats[1]=PV_CreateMaterial("BACK",NOTHING|MAPPING|PERSPECTIVE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_bk.jpg",mats[1])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[1]->RepeatU=TEXTURE_CLAMP;
	mats[1]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[1]);

	mats[2]=PV_CreateMaterial("LEFT",NOTHING|MAPPING|PERSPECTIVE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_lf.jpg",mats[2])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[2]->RepeatU=TEXTURE_CLAMP;
	mats[2]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[2]);

	mats[3]=PV_CreateMaterial("RIGHT",NOTHING|MAPPING|PERSPECTIVE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_rt.jpg",mats[3])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[3]->RepeatU=TEXTURE_CLAMP;
	mats[3]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[3]);

	mats[4]=PV_CreateMaterial("UP",NOTHING|MAPPING|PERSPECTIVE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_up.jpg",mats[4])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[4]->RepeatU=TEXTURE_CLAMP;
	mats[4]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[4]);

	mats[5]=PV_CreateMaterial("DOWN",NOTHING|MAPPING|PERSPECTIVE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_dn.jpg",mats[5])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[5]->RepeatU=TEXTURE_CLAMP;
	mats[5]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[5]);

	float mins[]={-2200,-500,-1000};		// these defines the zize of the cube
	float maxs[]={1500,1000,2000};
	Mesh1=CreateSkyBox(mins,maxs,mats);
	PV_AddMesh(World,Mesh1);		

    // Prepare to render
	if(PV_CompileMeshes(World)!=COOL)
	{
		Error("Unable to compile meshes");
		exit(1);
	}
	if(PV_CompileMaterials(World,NULL,NULL)!=COOL)
	{
		Error("Unable to compile materials");
		exit(1);
	}

	// Sets the final reduced color map if needed
	if(Depth==8)
	{
		// We are on a paletized device, sets a grayscale palette 		
		char Pal[256*3];
		unsigned i;
		for(i=0;i<256;i++)
		{
			// This is because PV's palette is from 0 to 64
			Pal[i*3]=World->Global256Palette[i].r*4;
			Pal[i*3+1]=World->Global256Palette[i].g*4;
			Pal[i*3+2]=World->Global256Palette[i].b*4;
		}

		SetPal(Pal);
	}
}

int PVEasy::OnIdle(void)
{		
	Fill(0,0,0,Height,Width,0);

	// Animate the beauty
	ay+=PI/50;
	az+=PI/40;
	if(ay>2*PI) ay-=2*PI;
	if(az>2*PI) az-=2*PI;

	PV_MeshSetupMatrix(Mesh1,ax,ay,az);
	
	// The Lock primitives gives access to the DirectDraw surface
	// The surface should be unlocked ASAP!
	PV_BeginFrame();
	PV_RenderWorld(World,Lock());
	PV_EndFrame();

	Unlock();
		
	Flip();

	return TRUE;
}

//////////////////////////////////////////////////////////////

int main(int argc,char **argv)
{
	PVEasy pve;
	DDInfo *ddi;

	InitPVision();

	printf("Panard Vision : Per face UV coordinates\n ALT+F4 to quit.");
	printf("\n\nPanard Vision version : %s\nBuild : %s, %s\n",PVISION_VERSION,PVISION_DATE,PVISION_TIME);
	
	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Panard Vision Setup
	pve.InitPV();

	// Some nice things
	pve.Run();

	return 0;
}

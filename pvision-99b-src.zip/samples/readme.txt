--------------------------------------------------------------------------------------------------
Panard Vision Samples
--------------------------------------------------------------------------------------------------

- DATA\
  Contains meshes and textures used by the samples.

- BIN\
  Precompiled version of the samples

- TUT1\
  Simple Panard Primitive sample. Draw a triangle.

- TUT2\
  Same as TUT1 but use hardware.

- TUT3\
  A dynamic tutorial :) Converted from a OpenGL sample. Demonstrates Panard
  Primitives 3D (indexed) and palette management

- TUT4\
  Demonstrates LoadMesh, ZBuffer and World&Light management
  This directory includes mainhard.cpp, which is the hardware version of tut4
  study the differences and the depth field function for tuning hardware
  depth buffering precision

- TUT5\ 
  Demonstrates PVUT ?

- TUT6\
  Demonstrates some material attributes (hardware rendering)

- TUT7\
  Same as TUT4 with user clip planes

- TUT8\
  "Demonstrates" (it's buggy) mirrors, see comment at the beginning of ddwin.cpp in
  ViewerSrc\ for a more pretty (and strong) sample

- TUT9\
  Derived from TUT3. Demonstrates what ambient mapping & bilinear can do for you.

- TUT10\
  Simple hierarchy demonstration. Cube power.

- TUT11\
  VERY simple 'demonstration' of portals functions. Just interesting to see how to create 
  a portal. See comments in main.cpp

- TUT12\
  Bezier surface.

- TUT13\
  Switchable nodes demonstration. Usable to implement LODs and plenty of other special FX.

- TUT14\
  The more asked sample !! Mesh building by hands. If you want to construct your meshes
  without using drivers, look at this.

- TUT15\
  Lines demonstration.

- TUT16\
  Display lists and teapot demo.

- TUT17\
  Procedural texture demo. Fire+Cube power :) (this version runs with DirectX6, but comments are
  included to make it run in software).

- TUT18\
  Hand mesh made cube + mapping. Show that cubes are not only good for tutorials :)

- TUT19\
  Shadow casting capabilities sample. Requires DX6 and stencil capable hardware. See release notes for 
  infos.

- TUT20\
  Detail texturing through PV's multitexture capabilities. Requires hardware.

- TUT21\
  Per face UV demo. Show you how you can have multiple UV coordinates set per vertex.

- TUT22\
  Demonstrates use of mesh instances.

- CodeWarrior\
  Some of these tuts ported for CodeWarrior (windows).

--------------------------------------------------------------------------------------------------
Panard Confettis Samples
--------------------------------------------------------------------------------------------------
All Panard Confettis samples are located under the pconf/ directory.
Most of them requires hardware.

- PCONF\TUT1\
  Read infos from object state files, and "play" the particle system. See shortcuts in pconf/bin/
  and scripts in pconf/data/*.pcs

- PCONF\TUT2\
  Simple thing with moving emitter.

- PCONF\TUT3\
  Same than tut2 with a second emitter.

- PCONF\TUT4\
  Particles applied to smoke.

--------------------------------------------------------------------------------------------------
Panard Scape Samples
--------------------------------------------------------------------------------------------------
All Panard Scape samples are located under the pscape/ directory.
Most of them requires hardware.

- PSCAPE\SPLITTER\
  Little utility which can split a big landscape into smaller pieces to be used through
  the threading engine of PScape.

- PSCAPE\TUT1\
  Shows how to handle landscape built with multiple blocks, the multithreading, and basic
  functionalities for Panard Scape.

------------------
If you want to mix software and hardware rendering see the Panard Viewer
source or study the differences beetween TUT1 and TUT2. It's simple, believe
me :)

There is near no error checking in the samples to keep them as clear
and simple as possible.


If you want me to write specific samples, feel free to contact me.

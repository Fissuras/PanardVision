// Panard Vision Sample
// (C) 1997-99, Olivier Brunet

// Demonstrates PV Shadows functions. Requires Stencil Buffer enabled hardware and driver

// SMKaribou/GMF

#include <stdio.h>
#include <pvision.h>
#include <3dsread.h>						// The 3dstudio 4 driver
#include "DirectDrawEasy.h"
#include "DXMen.h"
#include "pvd3d6.h"
#include "pvut.h"

class PVEasy:public DDrawEasy
{
	PVWorld *World;
	PVCam *Cam;
	PVLight *Light;

	PVMesh *Mesh1,*Mesh2,*Mesh3;
	float ax,ay,az;

public:
	PVEasy();
	~PVEasy();
	void InitPV(void);
	int OnIdle(void);
};

///////////////////////////////////////////////////////////////////////////////
PVEasy::PVEasy()
{
	ax=ay=az=0;
	World=NULL;
	Cam=NULL;
	Light=NULL;
}

PVEasy::~PVEasy()
{
	// Destructor
	PV_EndAccelSupport();
	PV_KillWorld(World);
	PV_KillCam(Cam);
}

void PVEasy::InitPV(void)
{
    PVRGBF ambient={0.2,0.2,0.2,0};	     // Ambient Light
    PVRGBF em={0,0,0,0};				 // Material's emmissive
	PVRGBF di={1,1,1,1};				 // Material's diffuse
	PVRGBF sp={0,0,0,0};				 // Material's Specular

    PVMaterial *m;
    unsigned i;

    // Render Mode Setup
    PV_SetClipLimit(0,Width-1,0,Height-1,Pitch);			// Sets rendering window   
	
	PV_SetHardwareDriver(&PVDriver);						// Register hardware driver

	// Starts Hardware
	if(PV_InitAccelSupport((long)lpDD/*(long)win*/)!=COOL)				// The Direct3D driver needs a pointer to the DirectDraw object, other driver take the window handle
	{
		printf("Unable to initialize hardware");
		exit(1);
	}

	// Checks for shadow support
	PVHardwareCaps *caps;
	caps=PV_GetHardwareDriver()->GetInfo();
	if(!((caps->GeneralCaps&PHG_STENCILBUFFER)&&(caps->BitsPerStencil>1)))
	{
		Error("Underlaying hardware doesn't support stencil buffer, exiting\n");
	}

	PV_SetMode(PVM_SHADOWS|PVM_STENCILBUFFER|PVM_USEHARDWARE|PVM_ZBUFFER|(Depth!=8?PVM_RGB:PVM_PALETIZED8));			// Sets rendering mode (ZBuffer)

	if(!(PV_Mode&PVM_PALETIZED8)) 
	{
		// We are in RGB rendering, sets the RGB masks according to the current device
		PV_SetRGBIndexingMode(GetMaskSize(RedMask),GetMaskSize(GreenMask),GetMaskSize(BlueMask),GetMaskPos(RedMask),GetMaskPos(GreenMask),GetMaskPos(BlueMask),GetMaskSize(AlphaMask));
	}
	else
	{
		// We are on a paletized device, sets a grayscale palette 
		char p[768];

		for(int i=0;i<256;i++)
		{
			p[i*3]=i;
			p[i*3+1]=i;
			p[i*3+2]=i;
		}
		SetPal(p);
	}

	// World setup
	World=PV_CreateWorld();
	if(World==NULL)
	{
		Error("Unable to Create World");
		exit(1);
	}
	if(Depth==8) World->ReservedColors=10;							// the 10 first colors are for windows
	PV_WorldSetAmbientLight(World,ambient);

	// Camera Setup
	Cam=PV_CreateCam("CAMERA");
	if(Cam==NULL)
	{
		Error("Unable to create camera");
		exit(1);
	}
	PV_SetCamFieldOfView(Cam,(float)Width/(float)Height);
	Cam->Height=Height;
    Cam->Width=Width;
	Cam->CenterX=Width/2;
	Cam->CenterY=Height/2;
	World->Camera=Cam;
	Cam->pos.yf=-100;
	Cam->pos.zf=800;
	Cam->FrontDist=500;				// Sets a reasonable depth field, hardware have a limited precision for depth buffering
	Cam->BackDist=1500;
	Cam->Flags|=CAMERA_DO_NOT_DRAW_SHADOW_CAP;	// Speeds up things for shadows, here we do not have problems
												// with 'top' of shadow volumes

	// Light Setup
	Light=PV_CreateLight(PVL_DIRECTIONAL,"LIGHT");
	if(Light==NULL)
	{
		Error("Unable to create light");
		exit(1);
	}
	PV_AddLight(World,Light);
	PV_SetLightDirection(Light,1,0,0);
	Light->Flags|=LIGHT_CAST_SHADOWS;

	// Mesh Setup
	if(LoadMeshFrom3DS("../data/cube.3ds",World)!=COOL)
	{
		Error("Unable to load mesh");
		exit(1);
	}
	Mesh1=World->Objs;		// Gets a pointer to the first mesh
	
	// We make one of the cube and normal fliped to serve as a background
	PV_MeshScaleVertices(Mesh1,1.5,1.5,1.5);
	PV_MeshSetupMatrix(Mesh1,0,PI/4,0);
	for(i=0;i<Mesh1->NbrVertices;i++){Mesh1->Vertex[i].Normal.xf*=-1.0;Mesh1->Vertex[i].Normal.yf*=-1.0;Mesh1->Vertex[i].Normal.zf*=-1.0;}
	for(i=0;i<Mesh1->NbrFaces;i++){Mesh1->Face[i].Normal.xf*=-1.0;Mesh1->Face[i].Normal.yf*=-1.0;Mesh1->Face[i].Normal.zf*=-1.0;}
	for(i=0;i<Mesh1->NbrFaces;i++) pvuInverseWinding(&Mesh1->Face[i]); 
	PV_MeshSetupPos(Mesh1,0,50,0);
	Mesh1->Pivot.xf=0;
	Mesh1->Pivot.yf=0;
	Mesh1->Pivot.zf=0;
	
	// And 2 shadow casters
	if(LoadMeshFrom3DS("../data/cube.3ds",World)!=COOL)
	{
		Error("Unable to load mesh");
		exit(1);
	}
	Mesh2=World->Objs;		// Gets a pointer to the first mesh
	PV_MeshScaleVertices(Mesh2,0.7,0.7,0.7);
	PV_MeshScaleVertices(Mesh2,0.7,0.7,0.7);
	PV_MeshSetupPos(Mesh2,0,-100,0);
	Mesh2->Flags|=MESH_CONVEX_CAST_SHADOWS; // We use the faster shadowing algorithm for the cube
											// This algo works only on convex mesh

	if(LoadMeshFrom3DS("../data/torus.3ds",World)!=COOL)
	{
		Error("Unable to load mesh");
		exit(1);
	}
	Mesh3=World->Objs;						// Gets a pointer to the first mesh	
	PV_MeshSetupPos(Mesh3,100,-100,20);
	Mesh3->Flags|=MESH_CAST_SHADOWS;		// Here we use the generic algo

    // Material Setup
    m=PV_CreateMaterial("APE",FLAT|ZBUFFER,TEXTURE_NONE,0);             // Gets a FLAT shaded material, APE is the material of the cube (activate ZBuffer for this material)
	PV_SetMaterialLightInfo(m,em,di,sp,0);								// Sets material light props
	if(Depth==8)
	{
		PV_SetMaterialPureColorsIndex(m,10,245);					// Sets the extent of the used colors for gouraud inside the whole palette
	}
	PV_AddMaterial(World,m);

    // Prepare to render
	if(PV_CompileMeshes(World)!=COOL)
	{
		Error("Unable to compile meshes");
		exit(1);
	}
	if(PV_CompileMaterials(World,NULL,NULL)!=COOL)
	{
		Error("Unable to compile materials");
		exit(1);
	}

}

int PVEasy::OnIdle(void)
{		
	PV_FillSurface(0,0,0,0,0);

	// Animate the beauty
	ay+=PI/150;
	az+=PI/140;
	if(ay>2*PI) ay-=2*PI;
	if(az>2*PI) az-=2*PI;

	PV_MeshSetupMatrix(Mesh2,az,az,0);
	PV_MeshSetupMatrix(Mesh3,az,ay,ax);
	
	// The second parameter of PV_RenderWorld is the surface number where the scene will be rendered	
	PV_BeginFrame();
	PV_RenderWorld(World,0);
	PV_EndFrame();	
		
	PV_FlipSurface();	

	return TRUE;
}

//////////////////////////////////////////////////////////////

int main(int argc,char **argv)
{
	PVEasy pve;
	DDInfo *ddi;

	InitPVision();

	printf("Panard Vision : Demonstrates PV Shadows functions. Requires Stencil Buffer enabled hardware and driver.\n ALT+F4 to quit.");
	printf("\n\nPanard Vision version : %s\nBuild : %s, %s\n",PVISION_VERSION,PVISION_DATE,PVISION_TIME);
	
	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Panard Vision Setup
	pve.InitPV();

	// Some nice things
	pve.Run();

	return 0;
}

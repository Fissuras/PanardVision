// Panard Vision Sample
// (C) 1997-2000, Olivier Brunet

// Simple Panard Scape sample
// See below to activate detail texturing or ligthing

// SMKaribou/GMF

//#define DETAIL_TEXTURE	// uncomment this to have detail texturing
//#define LIGHT				// uncomment this to add 2 dynamic lights to scene
#define NBR_BLOCKS		8	// Number of blocks of the landscape

#include <stdio.h>
#include <pvision.h>
#include "DirectDrawEasy.h"
#include "DXMen.h"
#include "pscape.h"
#include "pvd3d.h"
#include "pvut.h"
#include "imgload.h"
#include "pvzip.h"

class SampleLandPart : public psLandscapePartPV
{
private:	
	PVMaterial *m2,*m3;

public:
	SampleLandPart();
	~SampleLandPart();
#ifdef LIGHT
	void SetupRender();
#endif
	int Load();
	void Unload();
};

class PVEasy:public DDrawEasy
{
private:	
	psLandscapePartManager landscape;
	PVCam *Cam;
	PVWorld *World;
	float _Steady;

public:
	PVEasy();
	~PVEasy();
	void InitPV(void);
	int OnIdle(void);
	PVMesh *CreateSkyBox(float mins[],float maxs[],PVMaterial *sky[]);
};



///////////////////////////////////////////////////////////////////////////////

SampleLandPart::SampleLandPart()
{		
	PVRGBF ambient={0.3,0.3,0.3,0};    // Ambient Light
    PVRGBF em={0.1,0.1,0.1,0};			 // Material's emmissive
	PVRGBF di={1,1,1,1};				 // Material's diffuse
	PVRGBF sp={0,0,0,0};				 // Material's Specular
	pvImageLoader il;
	pvImageLoader::pvImageData *id;

	// Loads main texture for block
	// Here I load the same texture for every block
	// But you should assign a different pre-lit texture to each block
#ifdef DETAIL_TEXTURE
	id=il.LoadFromFile("../data/tut1.jpg");
	if(id==NULL)
	{
		cout<<"error loading textures"<<endl;
	}
	else
	{
		m2=NULL;

#ifdef LIGHT
		if(id->Flags==pvImageLoader::pvidRGBA)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",GOURAUD|MULTITEXTURE|ZBUFFER|FOGABLE,TEXTURE_RGBA|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
		
		if(id->Flags==pvImageLoader::pvidRGB)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",GOURAUD|MULTITEXTURE|ZBUFFER|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
#else
		if(id->Flags==pvImageLoader::pvidRGBA)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",MULTITEXTURE|ZBUFFER|FOGABLE,TEXTURE_RGBA|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
		
		if(id->Flags==pvImageLoader::pvidRGB)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",MULTITEXTURE|ZBUFFER|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
#endif
		if(m2==NULL)
		{
			cout<<"error creating material"<<endl;
		}
		PV_SetMaterialTexture(m2,id->Width,id->Height,id->Pixels,0);
		PV_SetMaterialLightInfo(m2,em,di,sp,0);						
		m2->RepeatU=TEXTURE_WRAP;									
		m2->RepeatV=TEXTURE_WRAP;			
		PV_CompileMaterial(m2,NULL,NULL,ambient,0);					
	}

	// Loads detail texture
	id=il.LoadFromFile("../data/detail06.jpg");
	if(id==NULL)
	{
		cout<<"error loading textures"<<endl;
	}
	else
	{
		m3=NULL;

		if(id->Flags==pvImageLoader::pvidRGBA)
			m3=PV_CreateMaterial("DETAIL",MAPPING|ZBUFFER|FOGABLE,TEXTURE_RGBA|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
		
		if(id->Flags==pvImageLoader::pvidRGB)
			m3=PV_CreateMaterial("DETAIL",MAPPING|ZBUFFER|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);

		if(m3==NULL)
		{
			cout<<"error creating material"<<endl;
		}
		PV_SetMaterialTexture(m3,id->Width,id->Height,id->Pixels,0);
		PV_SetMaterialLightInfo(m3,em,di,sp,0);						
		m3->RepeatU=TEXTURE_WRAP;									
		m3->RepeatV=TEXTURE_WRAP;			
		PV_CompileMaterial(m3,NULL,NULL,ambient,0);					
	}

	// Enable multitexturing, sets the detail texture operator
    m2->TexStage[0].Mat=m3;
	m2->TexStage[0].ColorOp=PVTSO_DETAILTEXTURE;
	m2->TexStage[0].Data1=6;		// This 2 arguments give the number of tiling for
	m2->TexStage[0].Data2=6;		// Detail texture in both U and V direction with respect 
#else								// to original coordinates
	id=il.LoadFromFile("../data/tut1.jpg");
	if(id==NULL)
	{
		cout<<"error loading textures"<<endl;
	}
	else
	{
		m2=NULL;

#ifdef LIGHT
		if(id->Flags==pvImageLoader::pvidRGBA)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",GOURAUD|MAPPING|ZBUFFER|FOGABLE,TEXTURE_RGBA|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
		
		if(id->Flags==pvImageLoader::pvidRGB)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",GOURAUD|MAPPING|ZBUFFER|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
#else
		if(id->Flags==pvImageLoader::pvidRGBA)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",MAPPING|ZBUFFER|FOGABLE,TEXTURE_RGBA|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
		
		if(id->Flags==pvImageLoader::pvidRGB)
			m2=PV_CreateMaterial("TEXTURE MATERIAL",MAPPING|ZBUFFER|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);
#endif
		if(m2==NULL)
		{
			cout<<"error creating material"<<endl;
		}
		PV_SetMaterialTexture(m2,id->Width,id->Height,id->Pixels,0);
		PV_SetMaterialLightInfo(m2,em,di,sp,0);						
		m2->RepeatU=TEXTURE_WRAP;									
		m2->RepeatV=TEXTURE_WRAP;			
		PV_CompileMaterial(m2,NULL,NULL,ambient,0);					
	}
#endif
}

SampleLandPart::~SampleLandPart()
{
	PV_KillMaterial(m2);
	PV_KillMaterial(m3);
}

int SampleLandPart::Load()			// this member is called each time a part has to be loaded (near visible)
{
	pvImageLoader il;
	PVRGBF ambient={0.1,0.1,0.1,0};    // Ambient Light
    PVRGBF em={0,0,0,0};				 // Material's emmissive
	PVRGBF di={1,1,1,1};				 // Material's diffuse
	PVRGBF sp={0,0,0,0};				 // Material's Specular

	psLandscapePartPV::Load();

	pvzifstream zipfile("../data/tut1.zip");
	zipfile.setcurrentfile(GetShortName());
	if(LoadFromStream(zipfile,"r16"))
	{
		cout<<"Errore loading file"<<endl;
	}

	SetTextureSubdivisionLevel(0);
	SetTexture(0,0,1,1,m2);

	return 0;
}

void SampleLandPart::Unload()			// this member is called each time a part has to be discarded
{
	psLandscapePartPV::Unload();
}

#ifdef LIGHT
// This part enables transfer to PP subsystem of normal infos for lighting
void SampleLandPart::SetupRender()
{
	pvEnableIndex(PPI_MAPCOORD|PPI_NORMAL);
	pvSetVertexIndex(&_Terrain[0].x,sizeof(psLoadTerrainInterface::psTerrainData));
	pvSetMapIndex(&_Terrain[0].u,sizeof(psLoadTerrainInterface::psTerrainData));
	pvSetNormalIndex(&_VertNormals[0].x,sizeof(pvVector3D));
}
#endif

///////////////////////////////////////////////////////////////////////////////
PVEasy::PVEasy()
{
	World=NULL;
	Cam=NULL;
	_Steady=20;
}

PVEasy::~PVEasy()
{
	PV_KillWorld(World);
	PV_KillCam(Cam);
}

PVMesh *PVEasy::CreateSkyBox(float mins[],float maxs[],PVMaterial *sky[])
{
	PVMesh* Mesh1;
	unsigned V[4];

	Mesh1=PV_SimpleCreateMeshWithAdditionalMappings(6,8,50,50,6*4);     // Clip Values a lot overestimated
																		// Each of the 6 faces has 4 vertices,
																		// we need 6*4 UV pairs.
	if(Mesh1==NULL) return NULL;
    Mesh1->Flags|=MESH_NOSORT;				 // no sorting needed for a cube, since it's a convex polyhedron

	Mesh1->Vertex[0].xf=mins[0];
    Mesh1->Vertex[0].yf=mins[1];
    Mesh1->Vertex[0].zf=mins[2];

	Mesh1->Vertex[1].xf=maxs[0];
    Mesh1->Vertex[1].yf=mins[1];
    Mesh1->Vertex[1].zf=mins[2];

	Mesh1->Vertex[2].xf=maxs[0];
    Mesh1->Vertex[2].yf=maxs[1];
    Mesh1->Vertex[2].zf=mins[2];

	Mesh1->Vertex[3].xf=mins[0];
    Mesh1->Vertex[3].yf=maxs[1];
    Mesh1->Vertex[3].zf=mins[2];

	Mesh1->Vertex[4].xf=mins[0];
    Mesh1->Vertex[4].yf=mins[1];
    Mesh1->Vertex[4].zf=maxs[2];

	Mesh1->Vertex[5].xf=maxs[0];
    Mesh1->Vertex[5].yf=mins[1];
    Mesh1->Vertex[5].zf=maxs[2];

	Mesh1->Vertex[6].xf=maxs[0];
    Mesh1->Vertex[6].yf=maxs[1];
    Mesh1->Vertex[6].zf=maxs[2];

	Mesh1->Vertex[7].xf=mins[0];
    Mesh1->Vertex[7].yf=maxs[1];
    Mesh1->Vertex[7].zf=maxs[2];
	
	// Setup One face
	Mesh1->Face[0].NbrVertices=4;        
    Mesh1->Face[0].MaterialInfo=sky[0];		

	V[0]=3;
	V[1]=2;
	V[2]=1;
	V[3]=0;
	PV_SetVerticesToFace(&Mesh1->Face[0],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[0],0,0,1.0-1.0/256.0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[0],1,1.0-1.0/256.0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[0],2,1.0-1.0/256.0,0);
	PV_SetPerFaceUV(&Mesh1->Face[0],3,0,0);			

	// Setup One face
	Mesh1->Face[1].NbrVertices=4;        
    Mesh1->Face[1].MaterialInfo=sky[1];

	V[0]=4;
	V[1]=5;
	V[2]=6;
	V[3]=7;
	PV_SetVerticesToFace(&Mesh1->Face[1],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[1],0,1.0-1.0/256.0,0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[1],1,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[1],2,0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[1],3,1.0-1.0/256.0,1.0-1.0/256.0);

	// Setup One face
	Mesh1->Face[2].NbrVertices=4;        
    Mesh1->Face[2].MaterialInfo=sky[2];

	V[0]=6;
	V[1]=5;
	V[2]=1;
	V[3]=2;
	PV_SetVerticesToFace(&Mesh1->Face[2],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[2],0,1.0-1.0/256.0,1.0-1.0/256.0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[2],1,1.0-1.0/256.0,0);
	PV_SetPerFaceUV(&Mesh1->Face[2],2,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[2],3,0,1.0-1.0/256.0);

	// Setup One face
	Mesh1->Face[3].NbrVertices=4;        
    Mesh1->Face[3].MaterialInfo=sky[3];

	V[0]=3;
	V[1]=0;
	V[2]=4;
	V[3]=7;
	PV_SetVerticesToFace(&Mesh1->Face[3],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[3],0,1.0-1.0/256.0,1.0-1.0/256.0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[3],1,1.0-1.0/256.0,0);
	PV_SetPerFaceUV(&Mesh1->Face[3],2,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[3],3,0,1.0-1.0/256.0);

	// Setup One face
	Mesh1->Face[4].NbrVertices=4;        
    Mesh1->Face[4].MaterialInfo=sky[4];

	V[0]=5;
	V[1]=4;
	V[2]=0;
	V[3]=1;
	PV_SetVerticesToFace(&Mesh1->Face[4],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[4],0,0,0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[4],1,0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[4],2,1.0-1.0/256.0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[4],3,1.0-1.0/256.0,0);

	// Setup One face
	Mesh1->Face[5].NbrVertices=4;        
    Mesh1->Face[5].MaterialInfo=sky[5];

	V[0]=2;
	V[1]=3;
	V[2]=7;
	V[3]=6;
	PV_SetVerticesToFace(&Mesh1->Face[5],V,4);
	// Sets the four UV pairs for this face
	PV_SetPerFaceUV(&Mesh1->Face[5],0,1.0-1.0/256.0,0);				// WARNING: SetPerFaceUV MUST be called after SetVerticesToFace
	PV_SetPerFaceUV(&Mesh1->Face[5],1,0,0);
	PV_SetPerFaceUV(&Mesh1->Face[5],2,0,1.0-1.0/256.0);
	PV_SetPerFaceUV(&Mesh1->Face[5],3,1.0-1.0/256.0,1.0-1.0/256.0);
	
	PV_SetMeshName(Mesh1,"NICE SKY BOX");

	PV_MeshNormCalc(Mesh1);    
    PV_MeshBuildBoxes(Mesh1,10);

	return Mesh1;
}

void PVEasy::InitPV(void)
{
    PVRGBF ambient={0.1,0.1,0.1,0};    // Ambient Light
    PVRGBF em={0,0,0,0};				 // Material's emmissive
	PVRGBF di={1,1,1,1};				 // Material's diffuse
	PVRGBF sp={0,0,0,0};				 // Material's Specular

    PVMat3x3 Id={1,0,0,0,1,0,0,0,1};
    PVPoint Pos={0,0,0};

	PVMaterial *mats[6];
	PVMesh *Mesh1;

    // Render Mode Setup
    PV_SetClipLimit(0,Width-1,0,Height-1,Pitch);			// Sets rendering window
    PV_SetHardwareDriver(&PVDriver);						// Register the hardware driver
	
	// Starts Hardware
	//if(PV_InitAccelSupport((long)win)!=COOL)
	if(PV_InitAccelSupport((long)lpDD)!=COOL)				// The Direct3D driver needs a pointer to the DirectDraw object, other driver take the window handle
	{
		printf("Unable to initialize hardware");
		exit(1);
	}

	PV_SetMode(PVM_ZBUFFER|PVM_RGB|PVM_USEHARDWARE);					// Sets rendering mode

	// World setup
	World=PV_CreateWorld();
	if(World==NULL)
	{
		Error("Unable to Create World");
		exit(1);
	}
	if(Depth==8) World->ReservedColors=10;							// the 10 first colors are for windows
	PV_WorldSetAmbientLight(World,ambient);

	
	// Setup a camera
    Cam=PV_CreateCam("zeCam");
    PV_SetCamFieldOfView(Cam,(float)Width/(float)Height);
    Cam->Height=Height;
    Cam->Width=Width;
    Cam->CenterX=Width/2;
    Cam->CenterY=Height/2;    
	Cam->BackDist=800000;
	Cam->FrontDist=100;
	World->Camera=Cam;	

	// And a light
#ifdef LIGHT
	unsigned lHandle;
	PVLight *l=PV_CreateLight(PVL_DIRECTIONAL,"LIGHT");
	PVLight *l2=PV_CreateLight(PVL_DIRECTIONAL,"LIGHT");
	PV_SetLightDirection(l,0,0,-1);
	PV_SetLightDirection(l2,0,0,1);
	l->Color.r=1;									// Some coloured light
	l->Color.g=0;
	l->Color.b=1;

	l2->Color.r=1;									// Some coloured light
	l2->Color.g=1;
	l2->Color.b=0;
#endif


	// Panard Primitive Setup
    pvSetMode(PV_3D);								// 3D drawing    
    //pvSetCull(PV_CULL_CW);						// every faces will be displayed, xxxx a tester pour la vitesse
	pvSetCull(PV_CULL_NONE);
#ifdef LIGHT		
	pvSetLightingMode(PV_LIGHTING);
	pvAddLight(l,&lHandle);
	pvAddLight(l2,&lHandle);
#else
	pvSetLightingMode(PV_NOLIGHTING);
#endif

	pvSetCamera(Cam);
    pvSetModelMatrix(Id);
    pvSetModelPos(Pos);
    pvSetModelPivot(Pos);

	// Sky Setup
	mats[0]=PV_CreateMaterial("FRONT",NOTHING|MAPPING|PERSPECTIVE|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_ft.jpg",mats[0])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[0]->RepeatU=TEXTURE_CLAMP;
	mats[0]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[0]);

	mats[1]=PV_CreateMaterial("BACK",NOTHING|MAPPING|PERSPECTIVE|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_bk.jpg",mats[1])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[1]->RepeatU=TEXTURE_CLAMP;
	mats[1]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[1]);

	mats[2]=PV_CreateMaterial("LEFT",NOTHING|MAPPING|PERSPECTIVE|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_lf.jpg",mats[2])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[2]->RepeatU=TEXTURE_CLAMP;
	mats[2]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[2]);

	mats[3]=PV_CreateMaterial("RIGHT",NOTHING|MAPPING|PERSPECTIVE|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_rt.jpg",mats[3])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[3]->RepeatU=TEXTURE_CLAMP;
	mats[3]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[3]);

	mats[4]=PV_CreateMaterial("UP",NOTHING|MAPPING|PERSPECTIVE|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_up.jpg",mats[4])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[4]->RepeatU=TEXTURE_CLAMP;
	mats[4]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[4]);

	mats[5]=PV_CreateMaterial("DOWN",NOTHING|MAPPING|PERSPECTIVE|FOGABLE,TEXTURE_RGB|TEXTURE_BILINEAR,1);
	if(pvuLoadJpeg("../data/unit1_dn.jpg",mats[5])!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	mats[5]->RepeatU=TEXTURE_CLAMP;
	mats[5]->RepeatV=TEXTURE_CLAMP;
	PV_AddMaterial(World,mats[5]);

	float mins[]={-2200,-500,-1000};		// these defines the zize of the cube
	float maxs[]={1500,1000,2000};
	Mesh1=CreateSkyBox(mins,maxs,mats);
	PV_AddMesh(World,Mesh1);		

    // Prepare to render
	if(PV_CompileMeshes(World)!=COOL)
	{
		Error("Unable to compile meshes");
		exit(1);
	}
	if(PV_CompileMaterials(World,NULL,NULL)!=COOL)
	{
		Error("Unable to compile materials");
		exit(1);
	}

	// Sets the final reduced color map if needed
	if(Depth==8)
	{
		// We are on a paletized device, sets a grayscale palette 		
		char Pal[256*3];
		unsigned i;
		for(i=0;i<256;i++)
		{
			// This is because PV's palette is from 0 to 64
			Pal[i*3]=World->Global256Palette[i].r*4;
			Pal[i*3+1]=World->Global256Palette[i].g*4;
			Pal[i*3+2]=World->Global256Palette[i].b*4;
		}

		SetPal(Pal);
	}

	// Fog for Parnard Primitives
	pvSetFogType(PVF_LINEAR);
	pvSetFogStart(750000);
	pvSetFogEnd(800000);
	pvSetFogColor(0,0,0);

	PV_Hint("PV_FOG_RANGE",1);
	PV_Hint("PV_FOG_TABLE",0);
	PV_Hint("PV_WBUFFER",1);

	// Panard Scape setup	
	// Load all blocks
	cout<<"Please wait while pre-loading data..."<<endl;
	PV_FillSurface(0,0,0,0,0);
	
	Print(0,160,"Please wait while pre-loading....",255,0,0);
	Print(0,0,"Controls:");
	Print(20,20," Arrows, P, M, A, Q: Move/Rotate Camera");
	Print(20,40," Num KeyPad +,- : Change thresold");
	Print(20,60," F1, F2 : Change guard height");
	Print(20,80," F9, F10 : Increase/Decrease maximum number of triangles per patch");
	Print(20,100," Num KeyPad 9,3 : Change distance thresold");
	Print(20,120," Spacebar : Display current values on text console");
	Flip();	

	unsigned i;
	for(i=0;i<NBR_BLOCKS;i++)
	{
		for(unsigned j=0;j<NBR_BLOCKS;j++)
		{
			char t[4096];

			sprintf(t,"tut1-%u_%u.r16",i,j);

			psLandscapePart *lp=new SampleLandPart;
			lp->SetShortName(t);
			lp->SetTextureSubdivisionLevel(0);
			lp->SetScaleX(10000);
			lp->SetScaleY(70);
			lp->SetScaleZ(10000);
			
			lp->Load();
			lp->SetState(psLandscapePart::READY);

			int handle=landscape.AddPart(lp);
			pvVector3D tmpv(j*(lp->GetSide()-1)*lp->GetScaleX(),0,i*(lp->GetSide()-1)*lp->GetScaleZ());
			landscape.SetPartPos(handle,tmpv);

			if((i==(NBR_BLOCKS/2))&&(j==(NBR_BLOCKS/2)))
			{
				// Sets starting position
				// We do that here, because we need to be sure the part is loaded and ready
				// before querying for heigth							
				float x=(NBR_BLOCKS/2)*lp->GetSide()*lp->GetScaleX();
				float z=(NBR_BLOCKS/2)*lp->GetSide()*lp->GetScaleZ();
				float y;
				landscape.GetHeight(x,z,y);				
				PV_SetCamPos(Cam,x,y-_Steady*lp->GetScaleY(),z);
			}

			lp->Unload();
			lp->SetState(psLandscapePart::NOT_READY);

#ifdef LIGHT
			lp->SetFlags(PSF_CALCNORMALS);		// Computes normals for terrain for dynamic lighting
#endif			
			cout<<"\r"<<100*((i*NBR_BLOCKS)+j)/(NBR_BLOCKS*NBR_BLOCKS)<<"%";
			cout.flush();
		}
	}
	cout<<endl;

	// Setup links beetwen patches
	for(i=0;i<NBR_BLOCKS;i++)
	{
		for(unsigned j=0;j<NBR_BLOCKS;j++)
		{
			int n,s,e,w;

			n=i-1;
			if(n<0) n=-1;
			s=i+1;
			if(s>=NBR_BLOCKS) s=-1;
			e=j+1;
			if(e>=NBR_BLOCKS) e=-1;
			w=j-1;
			if(w<0) w=-1;

			landscape.GetPart(i*NBR_BLOCKS+j+1)->SetNeighbor(PS_NORTH,n==-1?NULL:landscape.GetPart(n*NBR_BLOCKS+j+1));
			landscape.GetPart(i*NBR_BLOCKS+j+1)->SetNeighbor(PS_SOUTH,s==-1?NULL:landscape.GetPart(s*NBR_BLOCKS+j+1));
			landscape.GetPart(i*NBR_BLOCKS+j+1)->SetNeighbor(PS_EAST,e==-1?NULL:landscape.GetPart(i*NBR_BLOCKS+e+1));
			landscape.GetPart(i*NBR_BLOCKS+j+1)->SetNeighbor(PS_WEST,w==-1?NULL:landscape.GetPart(i*NBR_BLOCKS+w+1));
		}
	}

	// Sets whole landscape	
	landscape.SetThresold(1000);
	landscape.SetDistThresold(2770);
	landscape.SetMaxTriCount(300);
	landscape.SetLoadingRadius(2*129000);		// this sets distance at which parts are being loaded

	cout<<"Ready."<<endl;
}

#define TestKey(x) (((signed char)keyb[x])<0)

int PVEasy::OnIdle(void)
{	
   char keyb[256];
   GetKeyboardState((BYTE*)keyb);

	if(TestKey(VK_UP)) PV_CamAhead(Cam,-5000);
	if(TestKey(VK_DOWN)) PV_CamAhead(Cam,5000);
	if(TestKey(VK_LEFT)) PV_SetCamAngles(Cam,Cam->yaw+0.1,Cam->pitch,Cam->roll);
	if(TestKey(VK_RIGHT)) PV_SetCamAngles(Cam,Cam->yaw-0.1,Cam->pitch,Cam->roll);
	
	if(TestKey('P')) PV_SetCamPos(Cam,Cam->pos.xf,Cam->pos.yf-1000,Cam->pos.zf);
	if(TestKey('M')) PV_SetCamPos(Cam,Cam->pos.xf,Cam->pos.yf+1000,Cam->pos.zf);
	if(TestKey('A')) PV_SetCamAngles(Cam,Cam->yaw,Cam->pitch-0.1,Cam->roll);
	if(TestKey('Q')) PV_SetCamAngles(Cam,Cam->yaw,Cam->pitch+0.1,Cam->roll);
	if(TestKey(' ')) cout<<"Total Triangles Count                     :"<<landscape.GetTriCount()<<endl<<"Thresold: "<<landscape.GetThresold()<<" DistThresold: "<<landscape.GetDistThresold()<<" MaxTriCount/part: "<<landscape.GetMaxTriCount()<<endl;
	
	if(TestKey(VK_ADD)) landscape.SetThresold(landscape.GetThresold()-7000);
	if(TestKey(VK_SUBTRACT)) landscape.SetThresold(landscape.GetThresold()+7000);
	
	if(TestKey(VK_F1)) _Steady+=10;
	if(TestKey(VK_F2)) _Steady-=10;
	
	if(TestKey(VK_F9)) landscape.SetMaxTriCount(landscape.GetMaxTriCount()-10);
	if(TestKey(VK_F10)) landscape.SetMaxTriCount(landscape.GetMaxTriCount()+10);
	
	if(TestKey(VK_NUMPAD9)) landscape.SetDistThresold(landscape.GetDistThresold()-10);
	if(TestKey(VK_NUMPAD3)) landscape.SetDistThresold(landscape.GetDistThresold()+10);
	
	// Keep Cam over the terrain
	float h;
	if(landscape.GetHeight(Cam->pos.xf,Cam->pos.zf,h))
	{
		if(Cam->pos.yf>h) 
			PV_SetCamPos(Cam,Cam->pos.xf,h-_Steady*landscape.GetPart(1)->GetScaleY(),Cam->pos.zf);
	}

	// Make sky looks like sky
	PV_MeshSetupPos(PV_GetMeshPtr(World,"NICE SKY BOX"),Cam->pos.xf,Cam->pos.yf,Cam->pos.zf);
	
	PV_BeginFrame();			
	PV_RenderWorld(World,0);
	landscape.Render();
	PV_EndFrame();		
		
	PV_FlipSurface();

	return TRUE;
}

//////////////////////////////////////////////////////////////

int main(int argc,char **argv)
{
	PVEasy pve;
	DDInfo *ddi;

	InitPVision();

	printf("Panard Vision : Panard Scape tutorial\n ALT+F4 to quit.");
	printf("\n\nPanard Vision version : %s\nBuild : %s, %s\n",PVISION_VERSION,PVISION_DATE,PVISION_TIME);
	
	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Panard Vision Setup
	pve.InitPV();

	// Some nice things
	pve.Run();

	// Wait for all threads to terminate before shutting down hardware (not clean)	
	pve.Print(100,100,"Please wait ...");
	pve.Flip();
	cout<<"Please wait..."<<endl;
	pvSystem::Sleep(3000);

	PV_EndAccelSupport();				// Stops hardware

	return 0;
}

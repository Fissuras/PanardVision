// Panard Vision Sample
// (C) 1997-99, Olivier Brunet

// This litle utility is used to split a n*n landscape to many m*m blocks 
// to be used by the multithread scaping engine

// SMKaribou/GMF

#include "pscape.h"
#include <fstream.h>
#include <stdio.h>

int main(int argc,char **argv)
{
	cout<<"Landscape splitter utility, for use with the Panard Scape library"<<endl;
	cout<<"(C) 1999, Olivier Brunet"<<endl<<endl;
	
	if(argc<3)
	{
		cout<<"This program will export multiple blocks of m*m height from a n*n big landscape."<<endl;
		cout<<"Usage: SPLITTER [LandscapeName] [NumberOfBlocksOnEachAxis] [OutputName]"<<endl;
		exit(1);
	}

	psLandscapePart *lp=new psLandscapePart;

	cout<<"Loading "<<argv[1]<<"..."<<endl;

	if(lp->LoadFromFile(argv[1]))
	{
		cout<<"Errore loading file."<<endl;
		exit(2);
	}	

	// Compute size of blocks
	unsigned side=lp->GetSide();
	unsigned nside=side/atoi(argv[2]);

	cout<<"Original file is "<<side<<" long."<<endl;
	cout<<"New blocks will be "<<nside+1<<" long."<<endl;

	if(!((nside&(-nside))==nside))
	{
		cout<<"ERROR: Output size must be a power of 2 +1 (ex: 5)."<<endl;
		exit(3);
	}

	// Ouputs blocks
	for(unsigned i=0;i<atoi(argv[2]);i++)
	{
		for(unsigned j=0;j<atoi(argv[2]);j++)
		{
			char t[4096];

			sprintf(t,"%s-%u_%u.r16",argv[3],i,j);

			ofstream ofs(t,ios::out|ios::binary);

			lp->WriteSubBlock(ofs,j*nside,nside+1,i*nside,nside+1);
		}
	}
	
	cout<<"Done."<<endl;

	return 0;
}
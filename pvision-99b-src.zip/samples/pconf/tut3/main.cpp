// Panard Vision Sample
// (C) 1997-98, Olivier Brunet

// 2 particles systems demo

// SMKaribou/GMF

#include <fstream.h>
#include <stdio.h>
#include <pvision.h>

#include "pconf.h"
#include "pvmath.h"
#include "DirectDrawEasy.h"
#include "DXMen.h"

#include "pvd3d.h"							// Direct3D driver, change at will
#include "pvut.h"

//////////////////////////////////////////////////////////////////////////////////

class PVEasy:public DDrawEasy
{
private:
    pcParticlesSystem ps,ps2;

public:    
	void InitPV();
	int OnIdle(void);
};

///////////////////////////////////////////////////////////////////////////////

void PVEasy::InitPV()
{
    PVRGBF ambient={0.1,0.1,0.1,0};    // Ambient Light
    PVRGBF em={0,0,0,0};				 // Material's emmissive
	PVRGBF di={1,1,1,1};				 // Material's diffuse
	PVRGBF sp={0,0,0,0};				 // Material's Specular

    PVMaterial *m;
    PVCam *c;
	pcPointEmitter *emt;
    
	// Sets name of the Particle System
	ps.SetShortName("DemoSystem1");	
    ps.Lock();

    // Let's play with the emitter
	emt=new pcPointEmitter;
	emt->SetShortName("emit1");	
	emt->_Direction=pvVector3D(1,0,0);
	emt->_Position=pvVector3D(50,0,0);
	emt->_Speed=2;

	ps.AddEmitter(emt);
	ps.AddOperator(10,new pcNewtonOperator);			// simple movements
    ps.AddOperator(20,new pcTimeTrashCanOperator(3));	// particles time life is 3 units
    ps.UnLock();

	// Now th second system
	ps2.SetShortName("DemoSystem2");
	ps2.Lock();
	emt=new pcPointEmitter;
	emt->SetShortName("emit2");	
	emt->_Direction=pvVector3D(1,0,0);
	emt->_Position=pvVector3D(50,0,0);
	emt->_Speed=4;

	ps2.AddEmitter(emt);
	ps2.AddOperator(10,new pcNewtonOperator);			// simple movements
    ps2.AddOperator(20,new pcTimeTrashCanOperator(3));	// particles time life is 3 units
	ps2.UnLock();

    // Render Mode Setup
    PV_SetClipLimit(0,Width-1,0,Height-1,Pitch);			// Sets rendering window
    PV_SetHardwareDriver(&PVDriver);						// Register the hardware driver
	
	// Starts Hardware
	//if(PV_InitAccelSupport((long)win)!=COOL)
	if(PV_InitAccelSupport((long)lpDD)!=COOL)				// The Direct3D driver needs a pointer to the DirectDraw object, other driver take the window handle
	{
		printf("Unable to initialize hardware");
		exit(1);
	}

	PV_SetMode(PVM_RGB|PVM_USEHARDWARE);					// Sets rendering mode
	
    // Particle Material Setup
    m=PV_CreateMaterial("PMATERIAL",MAPPING|NOTHING,TEXTURE_RGB|TEXTURE_BILINEAR,1);	// Gets a GOURAUD shaded maetrial
    pvuLoadJpeg("../data/bullet.jpg",m);
    m->BlendRgbSrcFactor=BLEND_ONE;
	m->BlendRgbDstFactor=BLEND_ONE;
    PV_SetMaterialLightInfo(m,em,di,sp,0);					// Sets material light props
    PV_CompileMaterial(m,NULL,NULL,ambient,0);				// Prepare material for use
    PV_SetMode(PV_Mode|PVM_ALPHABLENDING);

   	// Setup a camera
    c=PV_CreateCam("zeCam");
    PV_SetCamFieldOfView(c,(float)Width/(float)Height);
    c->Height=Height;
    c->Width=Width;
    c->CenterX=Width/2;
    c->CenterY=Height/2;    
	PV_SetCamPos(c,0,100,100);
	PV_SetCamTarget(c,0,0,0);
	
	// Adds display operator to Particle system 1
    ps.Lock();
    ps.AddOperator(100,new pcPVDisplayOperator(c,m));	
    ps.UnLock();	

	// Another material for second system
    m=PV_CreateMaterial("PMATERIAL2",MAPPING|NOTHING,TEXTURE_RGB|TEXTURE_BILINEAR,1);	// Gets a GOURAUD shaded maetrial
    pvuLoadJpeg("../data/yelfla.jpg",m);
    m->BlendRgbSrcFactor=BLEND_ONE;
	m->BlendRgbDstFactor=BLEND_ONE;
    PV_SetMaterialLightInfo(m,em,di,sp,0);					// Sets material light props
    PV_CompileMaterial(m,NULL,NULL,ambient,0);				// Prepare material for use

	// Adds display operator to Particle system 2
    ps2.Lock();
    ps2.AddOperator(100,new pcPVDisplayOperator(c,m));	
    ps2.UnLock();	
}

int PVEasy::OnIdle(void)
{	
	pcPointEmitter *emt;
	
	// Let the emitter move
	emt=(pcPointEmitter*)pomGetObjectFromName("/domains/PanardConfettis/Emitters/emit1");
	emt->_Position=pvMath::RotateVector(pvVector3D(0,1,0),emt->_Position,-2.0*PI/140.0);
	emt->_Direction=pvVector3D(emt->_Position.z,emt->_Position.y,emt->_Position.x);	//sets direction to be orthogonal to radius of circle

	emt=(pcPointEmitter*)pomGetObjectFromName("/domains/PanardConfettis/Emitters/emit2");
	emt->_Position=pvMath::RotateVector(pvVector3D(0,1,0),emt->_Position,-2.0*PI/140.0);
	emt->_Direction=pvVector3D(emt->_Position.z,emt->_Position.y,emt->_Position.x);	//sets direction to be orthogonal to radius of circle
	
	PV_FillSurface(0,0,0,0,0);
	PV_BeginFrame();		

    ps.ComputeSystem();
    ps.SetTime(ps.GetTime()+0.1);

	ps2.ComputeSystem();
    ps2.SetTime(ps2.GetTime()+0.1);
	
	PV_EndFrame();		
		
	PV_FlipSurface();

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////

int main()
{
	PVEasy pve;
	DDInfo *ddi;
		
	InitPVision();

	printf("Panard Vision : 2 Particles systems demo\n ALT+F4 to quit.");
	printf("\n\nPanard Vision version : %s\nBuild : %s, %s\n",PVISION_VERSION,PVISION_DATE,PVISION_TIME);
	
	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Panard Vision Setup
	pve.InitPV();

	// Some nice things
	pve.Run();

	PV_EndAccelSupport();				// Stops hardware

	return 0;
}
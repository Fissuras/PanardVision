// Panard Vision Sample
// (C) 1997-99, Olivier Brunet

// Demonstrates Detail Texturing
// A detail texture is added to a main texture to fake higher resolution textures
// This uses the multitexture pipe of PV

// SMKaribou/GMF

#include <stdio.h>
#include <pvision.h>
#include <pvut.h>
#include "DirectDrawEasy.h"
#include "DXMen.h"
#include "pvd3d6.h"

class PVEasy:public DDrawEasy
{
	PVWorld *World;
	PVCam *Cam;

	PVMesh *Mesh1;
	PVMaterial *m;
	float ax,ay,az;

public:
	PVEasy();
	~PVEasy();
	void InitPV(void);
	int OnIdle(void);
	PVMesh *CreateSkyBox(float mins[],float maxs[],PVMaterial *m);
};

///////////////////////////////////////////////////////////////////////////////
PVEasy::PVEasy()
{
	ax=ay=az=0;
	World=NULL;
	Cam=NULL;
}

PVEasy::~PVEasy()
{
	// Destructor
	PV_KillWorld(World);
	PV_KillCam(Cam);
}

PVMesh *PVEasy::CreateSkyBox(float mins[],float maxs[],PVMaterial *m)
{
	PVMesh* Mesh1;
	unsigned V[4];

	Mesh1=PV_SimpleCreateMesh(6,8*3,50,50);    // Clip Values a lot overestimated
	if(Mesh1==NULL) return NULL;
    Mesh1->Flags|=MESH_NOSORT;				 // no sorting needed for a cube, since it's a convex polyhedron

	Mesh1->Vertex[0].xf=mins[0];
    Mesh1->Vertex[0].yf=mins[1];
    Mesh1->Vertex[0].zf=mins[2];
	Mesh1->Mapping[0].u=0.0+0.00;
	Mesh1->Mapping[0].v=0.0+0.00;

	Mesh1->Vertex[1].xf=maxs[0];
    Mesh1->Vertex[1].yf=mins[1];
    Mesh1->Vertex[1].zf=mins[2];
	Mesh1->Mapping[1].u=1.0-1.0/256.0;
	Mesh1->Mapping[1].v=0.0+0.00;

	Mesh1->Vertex[2].xf=maxs[0];
    Mesh1->Vertex[2].yf=maxs[1];
    Mesh1->Vertex[2].zf=mins[2];
	Mesh1->Mapping[2].u=1.0-1.0/256.0;
	Mesh1->Mapping[2].v=1.0-1.0/256.0;

	Mesh1->Vertex[3].xf=mins[0];
    Mesh1->Vertex[3].yf=maxs[1];
    Mesh1->Vertex[3].zf=mins[2];
	Mesh1->Mapping[3].u=0.0+0.00;
	Mesh1->Mapping[3].v=1.0-1.0/256.0;

	Mesh1->Vertex[4].xf=mins[0];
    Mesh1->Vertex[4].yf=mins[1];
    Mesh1->Vertex[4].zf=maxs[2];
	Mesh1->Mapping[4].u=1.0-1.0/256.0;
	Mesh1->Mapping[4].v=0.0+0.00;

	Mesh1->Vertex[5].xf=maxs[0];
    Mesh1->Vertex[5].yf=mins[1];
    Mesh1->Vertex[5].zf=maxs[2];
	Mesh1->Mapping[5].u=0.0+0.00;
	Mesh1->Mapping[5].v=0.0+0.00;

	Mesh1->Vertex[6].xf=maxs[0];
    Mesh1->Vertex[6].yf=maxs[1];
    Mesh1->Vertex[6].zf=maxs[2];
	Mesh1->Mapping[6].u=0.0+0.00;
	Mesh1->Mapping[6].v=1.0-1.0/256.0;

	Mesh1->Vertex[7].xf=mins[0];
    Mesh1->Vertex[7].yf=maxs[1];
    Mesh1->Vertex[7].zf=maxs[2];
	Mesh1->Mapping[7].u=1.0-1.0/256.0;
	Mesh1->Mapping[7].v=1.0-1.0/256.0;

	Mesh1->Vertex[0+8].xf=mins[0];
    Mesh1->Vertex[0+8].yf=mins[1];
    Mesh1->Vertex[0+8].zf=mins[2];
	Mesh1->Mapping[0+8].u=1.0-1.0/256.0;
	Mesh1->Mapping[0+8].v=0.0+0.00;

	Mesh1->Vertex[1+8].xf=maxs[0];
    Mesh1->Vertex[1+8].yf=mins[1];
    Mesh1->Vertex[1+8].zf=mins[2];
	Mesh1->Mapping[1+8].u=0.0+0.00;
	Mesh1->Mapping[1+8].v=0.0+0.00;

	Mesh1->Vertex[2+8].xf=maxs[0];
    Mesh1->Vertex[2+8].yf=maxs[1];
    Mesh1->Vertex[2+8].zf=mins[2];
	Mesh1->Mapping[2+8].u=0.0+0.00;
	Mesh1->Mapping[2+8].v=1.0-1.0/256.0;

	Mesh1->Vertex[3+8].xf=mins[0];
    Mesh1->Vertex[3+8].yf=maxs[1];
    Mesh1->Vertex[3+8].zf=mins[2];
	Mesh1->Mapping[3+8].u=1.0-1.0/256.0;
	Mesh1->Mapping[3+8].v=1.0-1.0/256.0;

	Mesh1->Vertex[4+8].xf=mins[0];
    Mesh1->Vertex[4+8].yf=mins[1];
    Mesh1->Vertex[4+8].zf=maxs[2];
	Mesh1->Mapping[4+8].u=0.0+0.00;
	Mesh1->Mapping[4+8].v=0.0+0.00;

	Mesh1->Vertex[5+8].xf=maxs[0];
    Mesh1->Vertex[5+8].yf=mins[1];
    Mesh1->Vertex[5+8].zf=maxs[2];
	Mesh1->Mapping[5+8].u=1.0-1.0/256.0;
	Mesh1->Mapping[5+8].v=0.0+0.00;

	Mesh1->Vertex[6+8].xf=maxs[0];
    Mesh1->Vertex[6+8].yf=maxs[1];
    Mesh1->Vertex[6+8].zf=maxs[2];
	Mesh1->Mapping[6+8].u=1.0-1.0/256.0;
	Mesh1->Mapping[6+8].v=1.0-1.0/256.0;

	Mesh1->Vertex[7+8].xf=mins[0];
    Mesh1->Vertex[7+8].yf=maxs[1];
    Mesh1->Vertex[7+8].zf=maxs[2];
	Mesh1->Mapping[7+8].u=0.0+0.00;
	Mesh1->Mapping[7+8].v=1.0-1.0/256.0;

	Mesh1->Vertex[0+16].xf=mins[0];
    Mesh1->Vertex[0+16].yf=mins[1];
    Mesh1->Vertex[0+16].zf=mins[2];
	Mesh1->Mapping[0+16].u=1.0-1.0/256.0;
	Mesh1->Mapping[0+16].v=1.0-1.0/256.0;

	Mesh1->Vertex[1+16].xf=maxs[0];
    Mesh1->Vertex[1+16].yf=mins[1];
    Mesh1->Vertex[1+16].zf=mins[2];
	Mesh1->Mapping[1+16].u=1.0-1.0/256.0;
	Mesh1->Mapping[1+16].v=0.0+0.00;

	Mesh1->Vertex[2+16].xf=maxs[0];
    Mesh1->Vertex[2+16].yf=maxs[1];
    Mesh1->Vertex[2+16].zf=mins[2];
	Mesh1->Mapping[2+16].u=1.0-1.0/256.0;
	Mesh1->Mapping[2+16].v=0.0+0.00;

	Mesh1->Vertex[3+16].xf=mins[0];
    Mesh1->Vertex[3+16].yf=maxs[1];
    Mesh1->Vertex[3+16].zf=mins[2];
	Mesh1->Mapping[3+16].u=0.0+0.00;
	Mesh1->Mapping[3+16].v=0.0+0.00;

	Mesh1->Vertex[4+16].xf=mins[0];
    Mesh1->Vertex[4+16].yf=mins[1];
    Mesh1->Vertex[4+16].zf=maxs[2];
	Mesh1->Mapping[4+16].u=0.0+0.00;
	Mesh1->Mapping[4+16].v=1.0-1.0/256.0;

	Mesh1->Vertex[5+16].xf=maxs[0];
    Mesh1->Vertex[5+16].yf=mins[1];
    Mesh1->Vertex[5+16].zf=maxs[2];
	Mesh1->Mapping[5+16].u=0.0+0.00;
	Mesh1->Mapping[5+16].v=0.0+0.00;

	Mesh1->Vertex[6+16].xf=maxs[0];
    Mesh1->Vertex[6+16].yf=maxs[1];
    Mesh1->Vertex[6+16].zf=maxs[2];
	Mesh1->Mapping[6+16].u=1.0-1.0/256.0;
	Mesh1->Mapping[6+16].v=1.0-1.0/256.0;

	Mesh1->Vertex[7+16].xf=mins[0];
    Mesh1->Vertex[7+16].yf=maxs[1];
    Mesh1->Vertex[7+16].zf=maxs[2];
	Mesh1->Mapping[7+16].u=0.0+0.00;
	Mesh1->Mapping[7+16].v=1.0-1.0/256.0;

	
	Mesh1->Face[0].NbrVertices=4;        
    Mesh1->Face[0].MaterialInfo=m;		

	V[0]=3;
	V[1]=2;
	V[2]=1;
	V[3]=0;
	PV_SetVerticesToFace(&Mesh1->Face[0],V,4);

	Mesh1->Face[1].NbrVertices=4;        
    Mesh1->Face[1].MaterialInfo=m;

	V[0]=4;
	V[1]=5;
	V[2]=6;
	V[3]=7;
	PV_SetVerticesToFace(&Mesh1->Face[1],V,4);

	Mesh1->Face[2].NbrVertices=4;        
    Mesh1->Face[2].MaterialInfo=m;

	V[0]=6+8;
	V[1]=5+8;
	V[2]=1+8;
	V[3]=2+8;
	PV_SetVerticesToFace(&Mesh1->Face[2],V,4);

	Mesh1->Face[3].NbrVertices=4;        
    Mesh1->Face[3].MaterialInfo=m;

	V[0]=3+8;
	V[1]=0+8;
	V[2]=4+8;
	V[3]=7+8;
	PV_SetVerticesToFace(&Mesh1->Face[3],V,4);

	Mesh1->Face[4].NbrVertices=4;        
    Mesh1->Face[4].MaterialInfo=m;

	V[0]=5+16;
	V[1]=4+16;
	V[2]=0+16;
	V[3]=1+16;
	PV_SetVerticesToFace(&Mesh1->Face[4],V,4);

	Mesh1->Face[5].NbrVertices=4;        
    Mesh1->Face[5].MaterialInfo=m;

	V[0]=2+16;
	V[1]=3+16;
	V[2]=7+16;
	V[3]=6+16;
	PV_SetVerticesToFace(&Mesh1->Face[5],V,4);
	
	PV_SetMeshName(Mesh1,"NICE SKY BOX");

	PV_MeshNormCalc(Mesh1);    
    PV_MeshBuildBoxes(Mesh1,10);

	return Mesh1;
}

void PVEasy::InitPV(void)
{
    PVRGBF ambient={0.1,0.1,0.1,0};    // Ambient Light

    // Render Mode Setup
    PV_SetClipLimit(0,Width-1,0,Height-1,Pitch);			// Sets rendering window   
	PV_SetHardwareDriver(&PVDriver);						// Register the hardware driver

	// Starts Hardware
    //if(PV_InitAccelSupport((long)win)!=COOL)                                                       // Other driver needs a handle to the window
	if(PV_InitAccelSupport((long)lpDD)!=COOL)				// The Direct3D driver needs a pointer to the DirectDraw object, other driver take the window handle
	{
		printf("Unable to initialize hardware");
		exit(1);
	}
	
	PV_SetMode(PVM_ZBUFFER|PVM_RGB|PVM_USEHARDWARE);					// Sets rendering mode

	// World setup
	World=PV_CreateWorld();
	if(World==NULL)
	{
		Error("Unable to Create World");
		exit(1);
	}
	if(Depth==8) World->ReservedColors=10;							// the 10 first colors are for windows
	PV_WorldSetAmbientLight(World,ambient);

	// Camera Setup
	Cam=PV_CreateCam("CAMERA");
	if(Cam==NULL)
	{
		Error("Unable to create camera");
		exit(1);
	}
	PV_SetCamFieldOfView(Cam,(float)Width/(float)Height);
	Cam->Height=Height;
    Cam->Width=Width;
	Cam->CenterX=Width/2;
	Cam->CenterY=Height/2;
	World->Camera=Cam;
	PV_SetCamPos(Cam,0,800,2000);
	PV_SetCamTarget(Cam,0,1000,0);

	// Prepare detail texture
	m=PV_CreateMaterial("DETAIL",MAPPING,TEXTURE_RGB|TEXTURE_BILINEAR|TEXTURE_MIPMAP,0);	// The mipmap flag is very important
	if(pvuLoadJpeg("../data/detail06.jpg",m)!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}
	PV_AddMaterial(World,m);

	// Normal Texture
	m=PV_CreateMaterial("MAIN",MULTITEXTURE,TEXTURE_RGB|TEXTURE_BILINEAR,0);
	if(pvuLoadJpeg("../data/ambient.jpg",m)!=COOL)
	{
		Error("Unable to load texture");
		exit(1);
	}

	// Enable multitexturing, sets the detail texture operator
    m->TexStage[0].Mat=PV_GetMaterialPtrByName("DETAIL",World);
	m->TexStage[0].ColorOp=PVTSO_DETAILTEXTURE;
	m->TexStage[0].Data1=6;		// This 2 arguments give the number of tiling for
	m->TexStage[0].Data2=6;		// Detail texture in both U and V direction with respect 
								// to original coordinates

	PV_AddMaterial(World,m);

	float mins[]={-2200,-500,-1000};		// these defines the size of the cube
	float maxs[]={1500,1000,2000};
	Mesh1=CreateSkyBox(mins,maxs,m);
	PV_AddMesh(World,Mesh1);		

    // Prepare to render
	if(PV_CompileMeshes(World)!=COOL)
	{
		Error("Unable to compile meshes");
		exit(1);
	}
	if(PV_CompileMaterials(World,NULL,NULL)!=COOL)
	{
		Error("Unable to compile materials");
		exit(1);
	}
}

int PVEasy::OnIdle(void)
{		
	PV_FillSurface(0,0,0,0,0);
	//Fill(0,0,0,Height,Width,0);

	// Animate the beauty
	ay+=PI/100;
	az+=PI/40;
	if(ay>2*PI) ay-=2*PI;
	if(az>2*PI) az-=2*PI;

	PV_MeshSetupMatrix(Mesh1,0,ay,0);
	
	// The Lock primitives gives access to the DirectDraw surface
	// The surface should be unlocked ASAP!
	PV_BeginFrame();
	PV_RenderWorld(World,/*Lock()*/0);
	PV_EndFrame();

	Unlock();
		
	//Flip();
	PV_FlipSurface();

	return TRUE;
}

//////////////////////////////////////////////////////////////

int main(int argc,char **argv)
{
	PVEasy pve;
	DDInfo *ddi;

	InitPVision();

	printf("Panard Vision : Demonstrates detail texturing\n ALT+F4 to quit.");
	printf("\n\nPanard Vision version : %s\nBuild : %s, %s\n",PVISION_VERSION,PVISION_DATE,PVISION_TIME);
	
	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Panard Vision Setup
	pve.InitPV();

	// Some nice things
	pve.Run();

	return 0;
}

// Panard Vision Sample
// (C) 1997-99, Olivier Brunet

// Demonstrates display lists and pvuTeapot() :)

// SMKaribou/GMF

#include <math.h>
#include <stdio.h>
#include <pvision.h>
#include "DirectDrawEasy.h"
#include "DXMen.h"
#include "pvut.h"

class PVEasy:public DDrawEasy
{
	PVMaterial *red,*green;

	// Member functions
public:
	void InitPV(void);
	int OnIdle(void);
};

///////////////////////////////////////////////////////////////////////////////

void PVEasy::InitPV(void)
{
    PVRGBF ambient={0.1,0.1,0.1,0};    // Ambient Light
    PVRGBF em={0,0,0,0};				 // Material's emmissive
	PVRGBF di={1,1,1,1};				 // Material's diffuse
	PVRGBF sp={0,0,0,0};				 // Material's Specular

    PVMat3x3 Id={1,0,0,0,1,0,0,0,1};
    PVPoint Pos={0,50,0};

    PVCam *c;
	PVLight *l;
	unsigned lHandle;

    // Render Mode Setup
    PV_SetClipLimit(0,Width-1,0,Height-1,Pitch);			// Sets rendering window
    PV_SetMode(Depth==8?PVM_PALETIZED8:PVM_RGB);			// Sets rendering mode

	PV_SetMode(PV_Mode|PVM_ZBUFFER);

	if(!(PV_Mode&PVM_PALETIZED8)) 
	{
		// We are in RGB rendering, sets the RGB masks according to the current device
		PV_SetRGBIndexingMode(GetMaskSize(RedMask),GetMaskSize(GreenMask),GetMaskSize(BlueMask),GetMaskPos(RedMask),GetMaskPos(GreenMask),GetMaskPos(BlueMask),GetMaskSize(AlphaMask));
	}
	else
	{
		// We are on a paletized device, sets a nice palette 
		char p[768];
		unsigned i;

		for(i=15;i<100+15;i++)
		{
			p[i*3]=(float)(255*(i-15))/(float)100;
			p[i*3+1]=0;
			p[i*3+2]=0;
		}
		for(i=100+15;i<100+15+100;i++)
		{
			p[i*3]=0;
			p[i*3+1]=(float)(255*(i-100-15))/(float)100;
			p[i*3+2]=0;
		}
		SetPal(p);
	}

    // Material Setup
	em.r=0.3;
	di.r=1.0;
	di.g=0.2;
	di.b=0.4;
    red=PV_CreateMaterial("RED",GOURAUD|ZBUFFER,TEXTURE_NONE,0);		// Gets a GOURAUD shaded material
	PV_SetMaterialLightInfo(red,em,di,sp,0);					// Sets material light props
	if(Depth==8) PV_SetMaterialPureColorsIndex(red,15,114);		// Sets the extent of the used colors for gouraud inside the whole palette
	PV_CompileMaterial(red,NULL,NULL,ambient,0);				// Prepare material for use

	em.g=0.1;
	em.r=0;
	di.g=1.0;
	di.r=1.0;
	di.b=1.0;
    green=PV_CreateMaterial("GREEN",GOURAUD|ZBUFFER,TEXTURE_NONE,0);	// Gets a GOURAUD shaded material
	PV_SetMaterialLightInfo(green,em,di,sp,0);					// Sets material light props
	if(Depth==8) PV_SetMaterialPureColorsIndex(green,115,214);  // Sets the extent of the used colors for gouraud inside the whole palette
    PV_CompileMaterial(green,NULL,NULL,ambient,0);				// Prepare material for use

	// Setup a camera
    c=PV_CreateCam("zeCam");
    PV_SetCamFieldOfView(c,(float)Width/(float)Height);
    c->Height=Height;
    c->Width=Width;
    c->CenterX=Width/2;
    c->CenterY=Height/2;    
	c->BackDist=1000;
	PV_SetCamPos(c,0,0,200);
	PV_SetCamTarget(c,0,0,0);

	// And a light
	l=PV_CreateLight(PVL_DIRECTIONAL,"LIGHT");
	PV_SetLightDirection(l,0,0,-1);
	l->Color.r=0.3;								// Some coloured light
	l->Color.g=0.7;
	l->Color.b=1;

    // Panard Primitive Setup
    pvSetMode(PV_3D);							// 3D drawing    
    pvSetCull(PV_CULL_CW);						
	pvSetLightingMode(PV_LIGHTING);				// Perform lighting
	pvAddLight(l,&lHandle);						// add a light

	pvSetCamera(c);
    pvSetModelMatrix(Id);
    pvSetModelPos(Pos);
    pvSetModelPivot(Pos);
}

int PVEasy::OnIdle(void)
{
	static float ax=0,ay=0,az=0;
	PVMat3x3 m;
	static unsigned dlist=0;
    static unsigned dlist2=0;
	UPVD8 *s;
	PVPoint Pos={0,50,0};
	PVPoint Pos2={10,-10,-100};

	Fill(0,0,0,Height,Width,0);
	    
	SetupMatrix3x3(m,ax,az,ax);
	az+=2*PI/50;
	pvSetModelMatrix(m);
    
	PV_BeginFrame();
		
	if(dlist==0)
	{
		pvSetMaterial(red);
		dlist=pvCompileList();
		pvuTeapot(50,3,(UPVD8*)-1);
		pvEndList();        
		pvSetMaterial(green);
		dlist2=pvCompileList();
		pvuTeapot(50,3,(UPVD8*)-1);
		pvEndList();
	}
	else 
	{
		s=Lock();
		pvSetModelPos(Pos);
		pvDisplayList(dlist,s);
		pvSetModelPos(Pos2);
		pvDisplayList(dlist2,s);
		Unlock();
	}    

	PV_EndFrame();

	Flip();
	return TRUE;
}

//////////////////////////////////////////////////////////////

int main(int argc,char **argv)
{
	PVEasy pve;
	DDInfo *ddi;

	InitPVision();

	printf("Panard Vision : Display lists and teapot demo\n ALT+F4 to quit.");
	printf("\n\nPanard Vision version : %s\nBuild : %s, %s\n",PVISION_VERSION,PVISION_DATE,PVISION_TIME);
	
	// Direct X Initialization
	ddi=DoDXMenu();	
	if(ddi==NULL) return 1;	
	if(pve.SetMode(&ddi->GUID,NULL,ddi->Width,ddi->Height,ddi->Depth,!ddi->Windowed)!=0) return 1;
		
	// Panard Vision Setup
	pve.InitPV();
	
	// Some nice things
	pve.Run();

	return 0;
}
